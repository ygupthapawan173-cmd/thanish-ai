package com.example.autonomous

internal object UpdateTransferPolicy {
    const val MAX_APK_BYTES = 512L * 1024 * 1024
    fun validHash(hash: String?) = hash != null && Regex("[0-9a-fA-F]{64}").matches(hash)
    fun allowedAsset(url: String): Boolean = runCatching {
        val u = java.net.URI(url)
        u.scheme.equals("https", true) && u.host.equals("github.com", true) && u.userInfo == null && (u.port == -1 || u.port == 443) &&
            Regex("/[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+/releases/download/.+").matches(u.path.orEmpty())
    }.getOrDefault(false)
}
