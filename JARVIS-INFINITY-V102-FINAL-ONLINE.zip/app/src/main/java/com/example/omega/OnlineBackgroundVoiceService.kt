package com.example.omega

import android.Manifest
import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.IBinder
import android.os.PowerManager
import androidx.core.content.ContextCompat
import com.example.MainActivity
import com.example.ai.PanduAiRepository
import com.example.control.AgentHudBus
import com.example.control.DeviceActionExecutor
import com.example.data.AppDatabase
import com.example.data.OmegaPreferences
import com.example.voice.BackgroundVoicePolicy
import com.example.voice.TeluguTtsController
import com.example.voice.VoiceInputController
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collect

/** Explicitly started, bounded online conversation; no boot restart, no screen-lock capture, no autonomous tools. */
class OnlineBackgroundVoiceService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private lateinit var prefs: OmegaPreferences
    private lateinit var db: AppDatabase
    private lateinit var repository: PanduAiRepository
    private lateinit var input: VoiceInputController
    private lateinit var tts: TeluguTtsController
    private var started = false
    private var phase = "Idle"
    private var turns = 0
    private var responseJob: Job? = null
    private val history = mutableListOf<Pair<String,String>>()
    override fun onBind(intent: Intent?): IBinder? = null
    private fun allowed(): Boolean = started && !prefs.settings.value.micPrivacyMuted &&
        ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED &&
        getSystemService(PowerManager::class.java).isInteractive && !getSystemService(KeyguardManager::class.java).isDeviceLocked &&
        getSystemService(NotificationManager::class.java).areNotificationsEnabled()
    override fun onCreate() {
        super.onCreate()
        prefs = OmegaPreferences(this)
        db = AppDatabase(this)
        repository = PanduAiRepository({ prefs.settings.value }, DeviceActionExecutor(this, db, prefs), db)
        input = VoiceInputController(this, owner = "background-capture") { text -> accept(text) }
        tts = TeluguTtsController(this, backgroundOwned = true, cloudSettings = { prefs.settings.value }, backgroundCloudAllowed = { phase == "Speaking" && allowed() })
        tts.setOnSpeechFinished {
            if (phase == "Speaking" && allowed() && tts.lastSpeechSucceeded && BackgroundVoicePolicy.followUp(prefs.settings.value.continuousConversation, turns)) listen()
            else if (phase == "Speaking") finish("Session complete")
        }
        scope.launch { input.state.collect { if (started && phase == "Listening" && it.errorMessage != null) finish("Voice ended: ${it.errorMessage}") } }
        scope.launch { AgentHudBus.abortSignal.collect { if (started) finish("Stopped") } }
        getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel(CHANNEL, "Online voice session", NotificationManager.IMPORTANCE_LOW))
    }
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action != START) { finish("Stopped"); return START_NOT_STICKY }
        if (started) return START_NOT_STICKY
        // Start from a visible app button only. No background auto-restart.
        if (!AgentHudBus.isAppInForeground.value || AgentHudBus.isMainMicBusy.value || AgentHudBus.isTtsBusy.value) { finish("Start from JARVIS when the microphone is idle"); return START_NOT_STICKY }
        started = true
        if (!allowed()) { finish("Microphone, notification permission and unlocked screen required"); return START_NOT_STICKY }
        try { startForeground(ID, notification("Starting online voice")) } catch (_: Exception) { finish("Android rejected microphone foreground service"); return START_NOT_STICKY }
        scope.launch {
            while (started) { delay(200); if (!allowed()) { finish("Stopped for microphone or screen privacy"); break } }
        }
        scope.launch { delay(180_000); if (started) finish("Session time limit reached") }
        listen()
        return START_NOT_STICKY
    }
    private fun listen() {
        if (!allowed()) { finish("Session unavailable"); return }
        phase = "Listening"; publish("Listening online — speak now")
        input.startListening(prefs.settings.value.languageTag, preferOffline = false, timeoutMs = 30000L)
    }
    private fun accept(text: String) {
        if (!allowed() || phase != "Listening") return
        if (BackgroundVoicePolicy.classify(text) == BackgroundVoicePolicy.Action.STOP) { finish("Stopped by voice"); return }
        phase = "Thinking"; turns++; publish("Thinking online")
        responseJob = scope.launch {
            val reply = withTimeoutOrNull(45000L) { repository.answerBackgroundQuestion(text.take(1000), history.toList()).getOrNull() }
            coroutineContext.ensureActive()
            if (!allowed()) { finish("Session stopped"); return@launch }
            if (reply.isNullOrBlank()) { finish("Online AI unavailable — check connection"); return@launch }
            history.add(text.take(500) to reply.take(700)); while(history.size > 2) history.removeAt(0)
            if (!prefs.settings.value.autoSpeak) { finish("Auto speak is disabled"); return@launch }
            val s = prefs.settings.value
            phase = "Speaking"; publish("Speaking — online AI reply")
            tts.configure(s.languageTag, s.ttsSpeed, s.ttsPitch, s.ttsStyle)
            tts.speak(reply.take(1000))
        }
    }
    private fun notification(message: String): Notification {
        val open = PendingIntent.getActivity(this, 1071, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val stop = PendingIntent.getService(this, 1072, Intent(this, OnlineBackgroundVoiceService::class.java).setAction(STOP), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        return Notification.Builder(this, CHANNEL).setSmallIcon(android.R.drawable.ic_btn_speak_now).setContentTitle("JARVIS • Online voice")
            .setContentText(message).setVisibility(Notification.VISIBILITY_PRIVATE).setOngoing(true).setContentIntent(open)
            .addAction(Notification.Action.Builder(null, "Stop", stop).build()).build()
    }
    private fun publish(message: String) { _status.value = message; runCatching { getSystemService(NotificationManager::class.java).notify(ID, notification(message)) } }
    private fun finish(message: String) {
        started = false; phase = "Idle"; _status.value = message
        responseJob?.cancel(); input.stopListening(); tts.stop(); stopForeground(STOP_FOREGROUND_REMOVE); stopSelf()
    }
    override fun onDestroy() {
        started = false; scope.cancel(); input.release(); tts.release(); prefs.close(); db.close(); stopForeground(STOP_FOREGROUND_REMOVE)
        if (_status.value.startsWith("Listening") || _status.value.startsWith("Thinking") || _status.value.startsWith("Speaking")) _status.value = "Stopped"
        super.onDestroy()
    }
    companion object {
        private const val CHANNEL = "jarvis_online_voice"
        private const val ID = 10701
        private const val START = "com.example.action.ONLINE_VOICE_START"
        private const val STOP = "com.example.action.ONLINE_VOICE_STOP"
        private val _status = MutableStateFlow("Idle")
        val status = _status.asStateFlow()
        fun start(context: Context): Boolean {
            if (!AgentHudBus.isAppInForeground.value) return false
            return runCatching { ContextCompat.startForegroundService(context, Intent(context, OnlineBackgroundVoiceService::class.java).setAction(START)); true }.getOrDefault(false)
        }
        fun stop(context: Context) { context.stopService(Intent(context, OnlineBackgroundVoiceService::class.java)) }
    }
}
