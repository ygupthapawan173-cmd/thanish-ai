from pathlib import Path
p=Path('app/src/main/java/com/example')
def r(x): return (p/x).read_text()
a=r('data/OmegaPreferences.kt'); e=r('ai/GeminiLiveDuplexEngine.kt'); u=r('ui/SettingsScreen.kt')
checks=[ any(v in Path('app/build.gradle.kts').read_text() for v in ('versionCode = 102','versionCode = 103','versionCode = 104','versionCode = 105','versionCode = 106','versionCode = 107')), 'val geminiLiveSpeaker: String = ""' in a, 'prefs.getString("gemini_live_speaker"' in a, '.putString("gemini_live_speaker"' in a, 'put("geminiLiveSpeaker"' in a, 'obj.optString("geminiLiveSpeaker"' in a, 'if (speaker.isNotEmpty()) generation.put("speechConfig"' in e, 'JSONObject().put("voiceName", speaker)' in e, '.put("generationConfig", generation)' in e, 'liveSpeakerProvider = { preferences.settings.value.geminiLiveSpeaker }' in r('ui/PanduViewModel.kt'), 'liveSpeakerProvider={prefs.settings.value.geminiLiveSpeaker}' in r('omega/OmegaWakeService.kt'), 'it.copy(geminiLiveSpeaker = name)' in u, 'onVoicePreview("te-IN")' in u and 'onVoicePreview("en-IN")' in u, 'style.speed(speed)' in r('voice/TeluguTtsController.kt'), 'style.pitch(pitch)' in r('voice/TeluguTtsController.kt') ]
for i,c in enumerate(checks): assert c,i+1
print(f'{len(checks)}/{len(checks)} V100.2 voice integration source guards passed')
