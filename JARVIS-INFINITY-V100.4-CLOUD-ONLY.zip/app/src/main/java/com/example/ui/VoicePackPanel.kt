package com.example.ui

import android.content.Intent
import android.speech.tts.TextToSpeech
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.voice.AndroidRecognitionPacks
import com.example.voice.VoicePackCatalog
import com.example.ui.theme.mutedText
import com.example.ui.theme.primaryText
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Real capabilities only: local pack hashes, provider download status, installed engine voice IDs. */
@Composable
internal fun VoicePackPanel(state:PanduUiState, refresh:()->Unit, preview:(String)->Unit) {
    val context=LocalContext.current
    val theme=state.settings.visualTheme
    val scope=rememberCoroutineScope()
    val provider=remember { AndroidRecognitionPacks(context) }
    DisposableEffect(provider) { onDispose { provider.close() } }
    var bundled by remember { mutableStateOf<Map<String,String>>(emptyMap()) }
    var verifying by remember { mutableStateOf(false) }
    var locale by remember { mutableStateOf("te-IN") }
    var providerStatus by remember { mutableStateOf("Not checked") }
    var selected by remember(locale) { mutableStateOf(VoicePackCatalog.selected(context,locale.substringBefore('-'))) }
    var expanded by remember { mutableStateOf(false) }
    var installStatus by remember { mutableStateOf("") }
    val labels=linkedMapOf("model-en-us" to "English wake / owner verification", "model-spk" to "Owner speaker model")
    fun verify() {
        if(verifying) return
        verifying=true
        scope.launch {
            bundled=withContext(Dispatchers.IO) { labels.keys.associateWith { VoicePackCatalog.verifyBundled(context,it) } }
            verifying=false
        }
    }
    LaunchedEffect(Unit) { refresh(); verify() }
    Column(Modifier.fillMaxWidth().padding(14.dp),verticalArrangement=Arrangement.spacedBy(8.dp)) {
        Text("VOICE PACKS",color=theme.primaryText(),fontSize=14.sp)
        labels.forEach { (id,label) -> Text("$label: ${bundled[id] ?: if(verifying) "Checking…" else "Not checked"}",color=theme.mutedText(),fontSize=12.sp) }
        OutlinedButton(onClick={verify()},enabled=!verifying,modifier=Modifier.fillMaxWidth()) { Text("Verify bundled packs") }
        Text("Online speech uses Android provider. Offline wake and owner verification retain English Vosk. Android on-device packs are optional.",color=theme.mutedText(),fontSize=11.sp)
        Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
            FilterChip(selected=locale=="te-IN",onClick={provider.close();locale="te-IN";providerStatus="Not checked"},label={Text("తెలుగు")})
            FilterChip(selected=locale=="en-IN",onClick={provider.close();locale="en-IN";providerStatus="Not checked"},label={Text("English")})
        }
        Text("Android speech pack: $providerStatus",color=theme.mutedText(),fontSize=12.sp)
        Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick={provider.check(locale){providerStatus=it}},modifier=Modifier.weight(1f)) { Text("Check") }
            OutlinedButton(onClick={provider.download(locale){providerStatus=it}},enabled=!providerStatus.contains("does not support") && !providerStatus.startsWith("Installed"),modifier=Modifier.weight(1f)) { Text("Download") }
        }
        val voices=state.ttsVoiceChoices.filter { it.locale.substringBefore('-')==locale.substringBefore('-') }
        val eligible=voices.filter { !it.needsData }
        Text("Reply voices: ${voices.size} reported · ${eligible.size} selectable",color=theme.mutedText(),fontSize=12.sp)
        if(selected.isNotBlank() && eligible.none { it.id==selected }) Text("Saved voice unavailable; automatic eligible voice fallback will be used.",color=theme.mutedText(),fontSize=12.sp)
        Box {
            OutlinedButton(onClick={expanded=true},modifier=Modifier.fillMaxWidth()) { Text(if(selected.isBlank()) "Automatic voice" else selected, maxLines=2) }
            DropdownMenu(expanded=expanded,onDismissRequest={expanded=false}) {
                DropdownMenuItem(text={Text("Automatic (prefer offline)")},onClick={VoicePackCatalog.select(context,locale.substringBefore('-'),"");selected="";expanded=false})
                eligible.forEach { voice -> DropdownMenuItem(text={Text("${voice.id}\n${voice.locale} • ${if(voice.network) "Online" else "Offline"}",fontSize=12.sp)},onClick={VoicePackCatalog.select(context,locale.substringBefore('-'),voice.id);selected=voice.id;expanded=false}) }
            }
        }
        OutlinedButton(onClick={preview(locale)},enabled=eligible.isNotEmpty() && !state.isListening && !state.liveDuplexState.isConnected && !state.liveDuplexState.isConnecting,modifier=Modifier.fillMaxWidth()) { Text("Preview selected voice") }
        Text(state.ttsStatusNote,color=theme.primaryText(),fontSize=12.sp)
        OutlinedButton(onClick={
            val intent=Intent(TextToSpeech.Engine.ACTION_INSTALL_TTS_DATA)
            installStatus=runCatching { context.startActivity(intent); "Install voice data in the engine, then refresh." }.getOrElse { "No TTS installer available. Open Android Text-to-speech settings." }
        },modifier=Modifier.fillMaxWidth()) { Text("Install / repair Android TTS voices") }
        OutlinedButton(onClick={
            installStatus=runCatching {
                context.startActivity(Intent("com.android.settings.TTS_SETTINGS"))
                "Choose an installed speech engine in Android settings. Reopen JARVIS to load it."
            }.getOrElse { "TTS settings unavailable on this device; use Android Settings search." }
        },modifier=Modifier.fillMaxWidth()) { Text("Android speech engine settings") }
        OutlinedButton(onClick={refresh()},modifier=Modifier.fillMaxWidth()) { Text("Refresh available voices") }
        if(installStatus.isNotBlank()) Text(installStatus,color=theme.mutedText(),fontSize=12.sp)
        Text("Voice names are reported by the engine; Android does not provide reliable male/female labels. Preview a voice before selecting it. Network voices are disabled in local mode and while locked.",color=theme.mutedText(),fontSize=11.sp)
    }
}
