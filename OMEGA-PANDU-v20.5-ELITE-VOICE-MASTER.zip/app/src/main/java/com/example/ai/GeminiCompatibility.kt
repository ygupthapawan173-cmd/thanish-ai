package com.example.ai

internal object GeminiCompatibility {
    fun canDowngrade(message: String, hasTools: Boolean, hasToolHistory: Boolean): Boolean {
        val m = message.lowercase()
        return hasTools && !hasToolHistory && m.contains("http 400") &&
            ((m.contains("function calling") || m.contains("function declarations") || m.contains("tools")) &&
            (m.contains("not enabled") || m.contains("not supported") || m.contains("unsupported")))
    }
    fun tryAnotherModel(message: String): Boolean = listOf("HTTP 404", "HTTP 429", "HTTP 503").any { message.contains(it) } || canDowngrade(message, true, false)
}
