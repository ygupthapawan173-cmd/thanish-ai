package com.example.ai

import com.example.control.DeviceActionExecutor
import com.example.control.NotificationInbox
import com.example.data.AppDatabase
import com.example.data.OmegaSettings
import com.example.data.SemanticMemoryEngine
import kotlinx.coroutines.ensureActive
import kotlin.coroutines.coroutineContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.pow

data class LocalBrainResponse(
    val text: String,
    val toolsUsed: List<String>,
    val engineTag: String
)

/**
 * 100% On-Device Local Brain (Zero Internet, Zero API Cost):
 * 1. Executes local device controls & routines via LocalCommandRouter.
 * 2. Online Edition has no local generative model.
 * 3. Native zero-dependency offline engine: Math evaluator, unit converter,
 *    Semantic Memory Q&A, Time/Date/Battery/Notifications, and Telugu/English assistant.
 */
class LocalBrainEngine(
    private val localRouter: LocalCommandRouter,
    private val executor: DeviceActionExecutor,
    private val database: AppDatabase
) {
    suspend fun processOffline(prompt: String, settings: OmegaSettings): LocalBrainResponse {
        val trimmed = prompt.trim()
        val lower = trimmed.lowercase()
        coroutineContext.ensureActive()

        // 1. Instant local phone command & routine check
        val cmdHit = localRouter.tryHandleInstant(trimmed)
        if (cmdHit != null) {
            return LocalBrainResponse(cmdHit.replyText, listOf(cmdHit.executedTool, "local_brain"), "on-device-command")
        }

        OfflineUnitConverter.convert(trimmed)?.let { result ->
            return LocalBrainResponse(result, listOf("local_unit_conversion"), "on-device-native")
        }

        coroutineContext.ensureActive()
        // 3. Built-in Zero-Dependency Local Knowledge & Math Engine
        // 3a. Save memory locally ("remember my ... is ...")
        val memSave = Regex("""^(?:remember|save memory|gurthu pettuko)\s+(?:that\s+)?(.+?)\s+(?:is|=)\s+(.+)$""", RegexOption.IGNORE_CASE).find(trimmed)
        if (memSave != null) {
            val k = memSave.groupValues[1].trim()
            val v = memSave.groupValues[2].trim()
            try { database.upsertMemory(k, v) } catch (e: Exception) {
                return LocalBrainResponse("Memory was not saved: ${e.message}", emptyList(), "on-device-memory")
            }
            return LocalBrainResponse("Saved locally (AES-256 encrypted): $k = $v.", listOf("save_memory", "local_brain"), "on-device-memory")
        }

        // 3b. Math & Percentage Evaluator
        val mathAns = tryEvaluateMath(trimmed)
        if (mathAns != null) {
            return LocalBrainResponse("Result: $mathAns (computed 100% offline).", listOf("local_math"), "on-device-math")
        }

        // 3c. Time / Date / Day
        if (lower.contains("time") || lower.contains("samayam") || lower.contains("టైం")) {
            val now = SimpleDateFormat("hh:mm a, EEEE dd MMM yyyy", Locale.getDefault()).format(Date())
            return LocalBrainResponse("Current time is $now.", listOf("local_clock"), "on-device-native")
        }
        if (lower.contains("date") || lower.contains("today") || lower.contains("తేదీ")) {
            val today = SimpleDateFormat("EEEE, dd MMMM yyyy", Locale.getDefault()).format(Date())
            return LocalBrainResponse("Today is $today.", listOf("local_clock"), "on-device-native")
        }

        // 3d. Notifications offline read
        if (lower.contains("notification") || lower.contains("message") || lower.contains("unread")) {
            val notifs = NotificationInbox.formatForAgent(5)
            return LocalBrainResponse("Offline Notification Inbox:\n$notifs", listOf("read_notifications", "local_brain"), "on-device-native")
        }

        // 3e. Calendar offline read
        if (lower.contains("calendar") || lower.contains("schedule") || lower.contains("meeting")) {
            val cal = executor.readCalendarSummary(2)
            return LocalBrainResponse("Upcoming local calendar:\n$cal", listOf("read_calendar", "local_brain"), "on-device-native")
        }

        // 3f. Semantic Personal Memory Q&A
        val allMemories = database.getAllMemories()
        if (allMemories.isNotEmpty() && (lower.contains("my ") || lower.contains("naa ") || lower.contains("remember") || lower.contains("what is"))) {
            val hits = SemanticMemoryEngine.search(trimmed, allMemories, topK = 3)
            if (hits.isNotEmpty()) {
                val summary = hits.joinToString("\n") { "• ${it.key}: ${it.value}" }
                return LocalBrainResponse("From your encrypted on-device memory:\n$summary", listOf("semantic_memory", "local_brain"), "on-device-memory")
            }
        }

        // 3g. Offline Greetings & Telugu/Tenglish conversational responses
        if (lower in listOf("hi", "hello", "hey", "hey jarvis", "namaste", "ela unnav", "bagunnava")) {
            return LocalBrainResponse(
                "Hello ${settings.userName}! On-Device Local Brain active (0 internet, 0 API cost). Battery ${executor.getBatteryPercent()}%. Ask math, time, memory, or phone commands anytime!",
                listOf("local_brain"),
                "on-device-native"
            )
        }

        return LocalBrainResponse(
            "Local Brain (Offline Mode) could not handle this request. I can control Torch, Volume, Apps, Routines, Math, Clock, Calendar, Notifications, & Encrypted Memory with zero internet. For open-web AI answers, switch off Local Brain Mode.",
            listOf("local_brain"),
            "on-device-native"
        )
    }

    companion object {
        /**
         * Pure-Kotlin recursive descent math parser (supports +, -, *, /, ^, parentheses).
         */
        fun tryEvaluateMath(input: String): String? {
            val expr = input.lowercase()
                .replace("calculate", "")
                .replace("what is", "")
                .replace("=", "")
                .replace("x", "*")
                .trim()
            if (expr.isEmpty() || expr.length > 256 || expr.count { it == '(' } > 32 || !expr.any { it.isDigit() }) return null
            if (!Regex("""^[0-9.+\-*/^()\s]+$""").matches(expr)) return null
            if (!expr.any { it in "+-*/^" }) return null

            return runCatching {
                val res = ExprParser(expr).parse()
                if (res.isNaN() || res.isInfinite()) null
                else if (res % 1.0 == 0.0 && res >= Long.MIN_VALUE.toDouble() && res < Long.MAX_VALUE.toDouble()) res.toLong().toString()
                else String.format(Locale.US, "%.4f", res).trimEnd('0').trimEnd('.')
            }.getOrNull()
        }
    }

    private class ExprParser(private val str: String) {
        private var pos = -1
        private var ch = 0

        private fun nextChar() { ch = if (++pos < str.length) str[pos].code else -1 }
        private fun eat(charToEat: Int): Boolean {
            while (ch == ' '.code) nextChar()
            if (ch == charToEat) { nextChar(); return true }
            return false
        }

        fun parse(): Double {
            nextChar()
            val x = parseExpression()
            if (pos < str.length) throw IllegalArgumentException("Unexpected char")
            return x
        }

        private fun parseExpression(): Double {
            var x = parseTerm()
            while (true) {
                x = when {
                    eat('+'.code) -> x + parseTerm()
                    eat('-'.code) -> x - parseTerm()
                    else -> return x
                }
            }
        }

        private fun parseTerm(): Double {
            var x = parseFactor()
            while (true) {
                x = when {
                    eat('*'.code) -> x * parseFactor()
                    eat('/'.code) -> x / parseFactor()
                    else -> return x
                }
            }
        }

        private fun parseFactor(): Double {
            if (eat('+'.code)) return parseFactor()
            if (eat('-'.code)) return -parseFactor()
            var x: Double
            val startPos = pos
            if (eat('('.code)) {
                x = parseExpression()
                if (!eat(')'.code)) throw IllegalArgumentException("Missing ')'")
            } else if ((ch in '0'.code..'9'.code) || ch == '.'.code) {
                while ((ch in '0'.code..'9'.code) || ch == '.'.code) nextChar()
                x = str.substring(startPos, pos).toDouble()
            } else {
                throw IllegalArgumentException("Unexpected token")
            }
            if (eat('^'.code)) x = x.pow(parseFactor())
            return x
        }
    }
}
