package com.example.aiassistant.ui

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.Send
import androidx.compose.material.icons.automirrored.rounded.VolumeOff
import androidx.compose.material.icons.automirrored.rounded.VolumeUp
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat

enum class AssistantScreen { HOME, LISTENING, CHAT, SETTINGS }

@Composable
fun PastelAiAssistantApp(viewModel: AssistantViewModel) {
    val uiState by viewModel.uiState.collectAsState()
    val context = LocalContext.current

    val micPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            viewModel.startVoiceListening()
        }
    }

    fun launchVoiceWithPermission() {
        val granted = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED

        if (granted) {
            viewModel.startVoiceListening()
        } else {
            micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    Crossfade(targetState = uiState.currentScreen, label = "screenNav") { screen ->
        when (screen) {
            AssistantScreen.HOME -> HomeScreen(
                userName = uiState.settings.userName,
                wakeWord = uiState.settings.wakeWord,
                wakeEnabled = uiState.settings.wakeWordEnabled,
                onVoiceClick = { launchVoiceWithPermission() },
                onChatClick = { viewModel.navigateTo(AssistantScreen.CHAT) },
                onSettingsClick = { viewModel.navigateTo(AssistantScreen.SETTINGS) },
                onQuickPrompt = { prompt -> viewModel.sendTextPrompt(prompt, openChatScreen = true) }
            )
            AssistantScreen.LISTENING -> ListeningScreen(
                uiState = uiState,
                onBack = {
                    viewModel.stopAllActivity()
                    viewModel.navigateTo(AssistantScreen.HOME)
                },
                onSwitchToChat = { viewModel.navigateTo(AssistantScreen.CHAT) },
                onToggleMic = {
                    if (uiState.isListening) viewModel.stopVoiceListening()
                    else launchVoiceWithPermission()
                },
                onToggleLanguage = {
                    val nextLang = if (uiState.settings.languageTag == "en-IN") "te-IN" else "en-IN"
                    viewModel.setVoiceLanguage(nextLang)
                },
                onToggleAutoSpeak = { viewModel.toggleAutoSpeak() }
            )
            AssistantScreen.CHAT -> VoiceChatScreen(
                uiState = uiState,
                onBack = { viewModel.navigateTo(AssistantScreen.HOME) },
                onMicClick = { launchVoiceWithPermission() },
                onSendPrompt = { viewModel.sendTextPrompt(it, openChatScreen = false) },
                onSpeakReply = { viewModel.speakMessage(it) }
            )
            AssistantScreen.SETTINGS -> SettingsScreen(
                settings = uiState.settings,
                onBack = { viewModel.navigateTo(AssistantScreen.HOME) },
                onSaveSettings = { viewModel.updateSettings(it) },
                onToggleWakeService = { viewModel.setWakeWordServiceEnabled(it) },
                onClearHistory = { viewModel.clearChatHistory() }
            )
        }
    }
}

// ------------------------------------------------------------
// SCREEN 1: HOME DASHBOARD
// ------------------------------------------------------------
@Composable
private fun HomeScreen(
    userName: String,
    wakeWord: String,
    wakeEnabled: Boolean,
    onVoiceClick: () -> Unit,
    onChatClick: () -> Unit,
    onSettingsClick: () -> Unit,
    onQuickPrompt: (String) -> Unit
) {
    var promptText by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .pastelMeshBackground()
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(horizontal = 20.dp, vertical = 14.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(42.dp)
                        .clip(CircleShape)
                        .background(Color.White.copy(alpha = 0.85f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Rounded.Person, contentDescription = "Profile", tint = AssistantColors.TextDark)
                }
                if (wakeEnabled) {
                    Box(
                        modifier = Modifier
                            .frostedGlassCard(16.dp)
                            .padding(horizontal = 10.dp, vertical = 5.dp)
                    ) {
                        Text("Wake: \"$wakeWord\"", fontSize = 11.sp, color = AssistantColors.TextDark, fontWeight = FontWeight.Medium)
                    }
                }
            }

            IconButton(
                onClick = onSettingsClick,
                modifier = Modifier
                    .size(44.dp)
                    .frostedGlassCard(cornerRadius = 22.dp)
            ) {
                Icon(Icons.Rounded.Settings, contentDescription = "Settings", tint = AssistantColors.TextDark)
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        Text(
            text = "Hi $userName,",
            fontSize = 28.sp,
            fontWeight = FontWeight.SemiBold,
            color = Color.White
        )
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = "Ask anything or control your phone -\napps, screen reader, flashlight & notifications.",
            fontSize = 13.sp,
            color = Color.White.copy(alpha = 0.92f),
            textAlign = TextAlign.Center,
            lineHeight = 18.sp
        )

        Spacer(modifier = Modifier.height(20.dp))

        Box(modifier = Modifier.clickable { onVoiceClick() }) {
            IridescentSwirlOrb(size = 160.dp, isListening = false)
        }

        Spacer(modifier = Modifier.height(22.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            QuickActionTile(
                icon = Icons.Rounded.Mic,
                title = "Voice\nAgent AI",
                modifier = Modifier.weight(1f),
                onClick = onVoiceClick
            )
            QuickActionTile(
                icon = Icons.Rounded.ChatBubbleOutline,
                title = "Chat\nwith AI",
                modifier = Modifier.weight(1f),
                onClick = onChatClick
            )
        }
        Spacer(modifier = Modifier.height(14.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            QuickActionTile(
                icon = Icons.Rounded.CenterFocusWeak,
                title = "Read &\nSummarize",
                modifier = Modifier.weight(1f),
                onClick = { onQuickPrompt("Read my current screen and summarize what is on it.") }
            )
            QuickActionTile(
                icon = Icons.Rounded.NotificationsActive,
                title = "Read My\nNotifications",
                modifier = Modifier.weight(1f),
                onClick = { onQuickPrompt("Read my latest notifications and summarize any important messages.") }
            )
        }

        Spacer(modifier = Modifier.weight(1f))

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .frostedGlassCard(cornerRadius = 30.dp)
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            TextField(
                value = promptText,
                onValueChange = { promptText = it },
                placeholder = { Text("Try: Open YouTube or Turn on torch", color = AssistantColors.TextMuted, fontSize = 13.5.sp) },
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = Color.Transparent,
                    unfocusedContainerColor = Color.Transparent,
                    focusedIndicatorColor = Color.Transparent,
                    unfocusedIndicatorColor = Color.Transparent,
                    focusedTextColor = AssistantColors.TextDark,
                    unfocusedTextColor = AssistantColors.TextDark
                ),
                singleLine = true,
                modifier = Modifier.weight(1f)
            )
            Box(
                modifier = Modifier
                    .size(42.dp)
                    .clickable {
                        if (promptText.isNotBlank()) {
                            onQuickPrompt(promptText)
                            promptText = ""
                        } else {
                            onChatClick()
                        }
                    },
                contentAlignment = Alignment.Center
            ) {
                IridescentSwirlOrb(size = 40.dp)
                Icon(
                    imageVector = Icons.AutoMirrored.Rounded.Send,
                    contentDescription = "Send",
                    tint = Color.White,
                    modifier = Modifier.size(18.dp)
                )
            }
        }
    }
}

@Composable
private fun QuickActionTile(
    icon: ImageVector,
    title: String,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Column(
        modifier = modifier
            .height(114.dp)
            .frostedGlassCard(cornerRadius = 22.dp)
            .clickable(onClick = onClick)
            .padding(16.dp),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Box(
            modifier = Modifier
                .size(34.dp)
                .clip(CircleShape)
                .background(Color.White.copy(alpha = 0.78f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, contentDescription = title, tint = AssistantColors.TextDark, modifier = Modifier.size(18.dp))
        }
        Text(
            text = title,
            fontSize = 14.sp,
            fontWeight = FontWeight.Medium,
            color = AssistantColors.TextDark,
            lineHeight = 18.sp
        )
    }
}

// ------------------------------------------------------------
// SCREEN 2: LIVE VOICE LISTENING SCREEN
// ------------------------------------------------------------
@Composable
private fun ListeningScreen(
    uiState: AssistantUiState,
    onBack: () -> Unit,
    onSwitchToChat: () -> Unit,
    onToggleMic: () -> Unit,
    onToggleLanguage: () -> Unit,
    onToggleAutoSpeak: () -> Unit
) {
    val headerStatus = when {
        uiState.liveToolStatus != null -> uiState.liveToolStatus
        uiState.isListening -> "Listening..."
        uiState.isThinking -> "Thinking..."
        uiState.isSpeaking -> "Speaking..."
        else -> "Tap mic to speak"
    }

    val centerSubtitle = when {
        uiState.voiceError != null -> uiState.voiceError
        uiState.liveTranscript.isNotBlank() && uiState.isListening -> "\"${uiState.liveTranscript}\""
        uiState.isThinking -> uiState.liveToolStatus ?: "Processing \"${uiState.liveTranscript}\"..."
        uiState.lastAiReply.isNotBlank() -> uiState.lastAiReply
        else -> "Speak naturally in English or Telugu.\nTry: \"Turn on flashlight\" or \"Open YouTube\"."
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .pastelMeshBackground()
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(horizontal = 20.dp, vertical = 14.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            GlassCircleButton(icon = Icons.AutoMirrored.Rounded.ArrowBack, onClick = onBack)

            Box(
                modifier = Modifier
                    .frostedGlassCard(cornerRadius = 18.dp)
                    .clickable { onToggleLanguage() }
                    .padding(horizontal = 14.dp, vertical = 8.dp)
            ) {
                Text(
                    text = if (uiState.settings.languageTag == "te-IN") "Voice: తెలుగు" else "Voice: English",
                    color = AssistantColors.TextDark,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium
                )
            }

            GlassCircleButton(
                icon = if (uiState.settings.autoSpeak) Icons.AutoMirrored.Rounded.VolumeUp else Icons.AutoMirrored.Rounded.VolumeOff,
                onClick = onToggleAutoSpeak
            )
        }

        Spacer(modifier = Modifier.height(28.dp))

        Text(
            text = headerStatus,
            fontSize = 21.sp,
            fontWeight = FontWeight.SemiBold,
            color = Color.White,
            textAlign = TextAlign.Center
        )

        Spacer(modifier = Modifier.height(26.dp))

        Box(modifier = Modifier.clickable { onToggleMic() }) {
            IridescentSwirlOrb(
                size = 215.dp,
                isListening = uiState.isListening || uiState.isThinking,
                audioAmplitude = if (uiState.isThinking) 0.55f else uiState.audioAmplitude
            )
        }

        Spacer(modifier = Modifier.height(24.dp))

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(min = 72.dp, max = 165.dp)
                .frostedGlassCard(cornerRadius = 20.dp)
                .padding(horizontal = 16.dp, vertical = 14.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = centerSubtitle,
                fontSize = 14.sp,
                color = if (uiState.voiceError != null) Color(0xFFB91C1C) else AssistantColors.TextDark,
                textAlign = TextAlign.Center,
                lineHeight = 20.sp
            )
        }

        Spacer(modifier = Modifier.weight(1f))

        LiveWaveformBars(
            isActive = uiState.isListening || uiState.isSpeaking,
            amplitude = uiState.audioAmplitude
        )

        Spacer(modifier = Modifier.height(22.dp))

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 12.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            GlassCircleButton(icon = Icons.Rounded.ChatBubbleOutline, size = 50.dp, onClick = onSwitchToChat)

            Box(
                modifier = Modifier
                    .size(72.dp)
                    .clip(CircleShape)
                    .background(Color.White.copy(alpha = 0.55f))
                    .clickable { onToggleMic() },
                contentAlignment = Alignment.Center
            ) {
                Box(
                    modifier = Modifier
                        .size(56.dp)
                        .clip(CircleShape)
                        .background(
                            Brush.linearGradient(
                                listOf(AssistantColors.OrbCyan, AssistantColors.OrbViolet, AssistantColors.OrbPink)
                            )
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (uiState.isListening) Icons.Rounded.Mic else Icons.Rounded.MicNone,
                        contentDescription = "Mic",
                        tint = Color.White,
                        modifier = Modifier.size(28.dp)
                    )
                }
            }

            GlassCircleButton(icon = Icons.Rounded.Close, size = 50.dp, onClick = onBack)
        }
    }
}

@Composable
private fun LiveWaveformBars(isActive: Boolean, amplitude: Float) {
    val baseWeights = listOf(0.45f, 0.85f, 0.65f, 1.0f, 0.72f, 0.5f)
    val transition = rememberInfiniteTransition(label = "wave")

    Row(
        horizontalArrangement = Arrangement.spacedBy(5.dp),
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.height(40.dp)
    ) {
        baseWeights.forEachIndexed { idx, weight ->
            val idleWave by transition.animateFloat(
                initialValue = 8f,
                targetValue = if (isActive) (16f + amplitude * 24f) * weight else 8f,
                animationSpec = infiniteRepeatable(
                    animation = tween(durationMillis = 320 + idx * 70, easing = FastOutSlowInEasing),
                    repeatMode = RepeatMode.Reverse
                ),
                label = "bar$idx"
            )
            Box(
                modifier = Modifier
                    .width(4.dp)
                    .height(idleWave.coerceIn(6f, 38f).dp)
                    .clip(RoundedCornerShape(4.dp))
                    .background(Color.White)
            )
        }
    }
}

// ------------------------------------------------------------
// SCREEN 3: CHAT SCREEN WITH AUDIO WAVEFORM & AGENT TOOL BADGES
// ------------------------------------------------------------
@Composable
private fun VoiceChatScreen(
    uiState: AssistantUiState,
    onBack: () -> Unit,
    onMicClick: () -> Unit,
    onSendPrompt: (String) -> Unit,
    onSpeakReply: (String) -> Unit
) {
    var inputText by remember { mutableStateOf("") }
    val listState = rememberLazyListState()

    LaunchedEffect(uiState.messages.size, uiState.isThinking) {
        if (uiState.messages.isNotEmpty()) {
            listState.animateScrollToItem(uiState.messages.lastIndex)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .pastelMeshBackground()
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(horizontal = 16.dp, vertical = 12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            GlassCircleButton(icon = Icons.AutoMirrored.Rounded.ArrowBack, onClick = onBack)
            Text("Gemini Agent", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Medium)
            GlassCircleButton(icon = Icons.Rounded.Mic, onClick = onMicClick)
        }

        Spacer(modifier = Modifier.height(14.dp))

        LazyColumn(
            state = listState,
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            items(uiState.messages, key = { it.id }) { msg ->
                when {
                    msg.isFromUser && msg.isVoiceInput -> UserAudioBubble(
                        transcript = msg.text,
                        duration = msg.audioDuration
                    )
                    msg.isFromUser -> UserTextBubble(text = msg.text)
                    else -> AiTextBubble(
                        text = msg.text,
                        executedTools = msg.executedTools,
                        isError = msg.isError,
                        onSpeakClick = { onSpeakReply(msg.text) }
                    )
                }
            }

            if (uiState.isThinking) {
                item {
                    AiTextBubble(
                        text = uiState.liveToolStatus ?: "Thinking...",
                        executedTools = emptyList(),
                        isError = false,
                        onSpeakClick = {}
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .frostedGlassCard(cornerRadius = 28.dp)
                .padding(horizontal = 10.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            TextField(
                value = inputText,
                onValueChange = { inputText = it },
                placeholder = { Text("Type command or question...", color = AssistantColors.TextMuted, fontSize = 14.sp) },
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = Color.Transparent,
                    unfocusedContainerColor = Color.Transparent,
                    focusedIndicatorColor = Color.Transparent,
                    unfocusedIndicatorColor = Color.Transparent,
                    focusedTextColor = AssistantColors.TextDark,
                    unfocusedTextColor = AssistantColors.TextDark
                ),
                singleLine = true,
                modifier = Modifier.weight(1f)
            )
            IconButton(onClick = onMicClick) {
                Icon(Icons.Rounded.Mic, contentDescription = "Voice", tint = AssistantColors.TextDark)
            }
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clickable {
                        if (inputText.isNotBlank() && !uiState.isThinking) {
                            onSendPrompt(inputText)
                            inputText = ""
                        }
                    },
                contentAlignment = Alignment.Center
            ) {
                IridescentSwirlOrb(size = 38.dp)
                Icon(Icons.AutoMirrored.Rounded.Send, contentDescription = "Send", tint = Color.White, modifier = Modifier.size(16.dp))
            }
        }
    }
}

@Composable
private fun UserAudioBubble(transcript: String, duration: String) {
    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.End
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Row(
                modifier = Modifier
                    .clip(RoundedCornerShape(24.dp))
                    .background(AssistantColors.AudioPillDark)
                    .padding(horizontal = 12.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(26.dp)
                        .clip(CircleShape)
                        .background(Color.White),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Rounded.GraphicEq, contentDescription = "Voice", tint = Color.Black, modifier = Modifier.size(16.dp))
                }
                val bars = listOf(8, 16, 12, 20, 10, 18, 14, 22, 12, 16, 9, 14)
                Row(horizontalArrangement = Arrangement.spacedBy(3.dp), verticalAlignment = Alignment.CenterVertically) {
                    bars.forEach { h ->
                        Box(
                            modifier = Modifier
                                .width(2.5.dp)
                                .height(h.dp)
                                .clip(RoundedCornerShape(2.dp))
                                .background(Color.White)
                        )
                    }
                }
                Text(duration, color = Color.White.copy(alpha = 0.8f), fontSize = 11.sp)
            }
            Spacer(modifier = Modifier.width(8.dp))
            Box(
                modifier = Modifier
                    .size(30.dp)
                    .clip(CircleShape)
                    .background(Color.White),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Rounded.Person, contentDescription = null, tint = AssistantColors.TextDark, modifier = Modifier.size(18.dp))
            }
        }
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = transcript,
            color = AssistantColors.TextMuted,
            fontSize = 11.5.sp,
            modifier = Modifier.padding(end = 42.dp)
        )
    }
}

@Composable
private fun UserTextBubble(text: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.End,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .widthIn(max = 270.dp)
                .clip(RoundedCornerShape(20.dp))
                .background(AssistantColors.AudioPillDark)
                .padding(horizontal = 14.dp, vertical = 10.dp)
        ) {
            Text(text = text, color = Color.White, fontSize = 13.5.sp, lineHeight = 19.sp)
        }
    }
}

@Composable
private fun AiTextBubble(
    text: String,
    executedTools: List<String>,
    isError: Boolean,
    onSpeakClick: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(0.88f),
        verticalAlignment = Alignment.Top,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        IridescentSwirlOrb(size = 28.dp)
        Column(
            modifier = Modifier
                .frostedGlassCard(cornerRadius = 18.dp)
                .padding(horizontal = 14.dp, vertical = 12.dp)
        ) {
            if (executedTools.isNotEmpty()) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.padding(bottom = 6.dp)
                ) {
                    executedTools.distinct().forEach { tool ->
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(10.dp))
                                .background(AssistantColors.AudioPillDark.copy(alpha = 0.85f))
                                .padding(horizontal = 8.dp, vertical = 3.dp)
                        ) {
                            Text(
                                text = "Action: $tool",
                                color = AssistantColors.OrbCyan,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }
            }

            Text(
                text = text,
                color = if (isError) Color(0xFFB91C1C) else AssistantColors.TextDark,
                fontSize = 13.5.sp,
                lineHeight = 19.sp
            )
            if (!isError && text != "Thinking...") {
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.clickable { onSpeakClick() },
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Rounded.VolumeUp,
                        contentDescription = "Read aloud",
                        tint = AssistantColors.TextMuted,
                        modifier = Modifier.size(14.dp)
                    )
                    Text("Listen", color = AssistantColors.TextMuted, fontSize = 11.sp)
                }
            }
        }
    }
}

@Composable
fun GlassCircleButton(
    icon: ImageVector,
    size: Dp = 42.dp,
    onClick: () -> Unit
) {
    IconButton(
        onClick = onClick,
        modifier = Modifier
            .size(size)
            .frostedGlassCard(cornerRadius = size / 2)
    ) {
        Icon(icon, contentDescription = null, tint = AssistantColors.TextDark, modifier = Modifier.size(20.dp))
    }
}
