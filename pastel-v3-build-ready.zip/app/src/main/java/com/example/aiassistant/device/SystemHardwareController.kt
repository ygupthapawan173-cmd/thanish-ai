package com.example.aiassistant.device

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.provider.AlarmClock
import android.provider.Settings
import androidx.core.content.ContextCompat

class SystemHardwareController(private val context: Context) {

    fun setFlashlight(enabled: Boolean): String {
        return try {
            val cameraManager = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val cameraId = cameraManager.cameraIdList.firstOrNull { id ->
                val chars = cameraManager.getCameraCharacteristics(id)
                chars.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true &&
                    chars.get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_BACK
            } ?: return "No rear flashlight found on this device."

            cameraManager.setTorchMode(cameraId, enabled)
            if (enabled) "Flashlight turned ON." else "Flashlight turned OFF."
        } catch (e: Exception) {
            "Could not change flashlight: ${e.message}"
        }
    }

    fun setMediaVolume(percent: Int): String {
        return try {
            val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            val clamped = percent.coerceIn(0, 100)
            val maxVol = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
            val targetVol = ((clamped / 100f) * maxVol).toInt()
            audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, targetVol, AudioManager.FLAG_SHOW_UI)
            "Media volume set to $clamped%."
        } catch (e: Exception) {
            "Failed to adjust volume: ${e.message}"
        }
    }

    fun openAppByName(appName: String): String {
        val query = appName.trim().lowercase()
        if (query.isEmpty()) return "App name was empty."

        val pm = context.packageManager
        val mainIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(mainIntent, 0)

        val exactOrPartial = apps.firstOrNull { resolve ->
            resolve.loadLabel(pm).toString().lowercase() == query
        } ?: apps.firstOrNull { resolve ->
            resolve.loadLabel(pm).toString().lowercase().contains(query) ||
                resolve.activityInfo.packageName.lowercase().contains(query)
        } ?: return "Could not find an installed app matching '$appName'."

        val launchIntent = pm.getLaunchIntentForPackage(exactOrPartial.activityInfo.packageName)
            ?: return "Unable to launch '${exactOrPartial.loadLabel(pm)}'."

        launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(launchIntent)
        return "Opened ${exactOrPartial.loadLabel(pm)}."
    }

    fun setAlarm(hour24: Int, minute: Int, label: String): String {
        return try {
            val intent = Intent(AlarmClock.ACTION_SET_ALARM).apply {
                putExtra(AlarmClock.EXTRA_HOUR, hour24.coerceIn(0, 23))
                putExtra(AlarmClock.EXTRA_MINUTES, minute.coerceIn(0, 59))
                putExtra(AlarmClock.EXTRA_MESSAGE, label.ifBlank { "AI Assistant Alarm" })
                putExtra(AlarmClock.EXTRA_SKIP_UI, false)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            String.format("Alarm set for %02d:%02d (%s).", hour24, minute, label.ifBlank { "Alarm" })
        } catch (e: Exception) {
            "Could not set alarm: ${e.message}"
        }
    }

    fun setTimer(seconds: Int, label: String): String {
        return try {
            val intent = Intent(AlarmClock.ACTION_SET_TIMER).apply {
                putExtra(AlarmClock.EXTRA_LENGTH, seconds.coerceAtLeast(1))
                putExtra(AlarmClock.EXTRA_MESSAGE, label.ifBlank { "AI Assistant Timer" })
                putExtra(AlarmClock.EXTRA_SKIP_UI, false)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            "Timer started for $seconds seconds."
        } catch (e: Exception) {
            "Could not start timer: ${e.message}"
        }
    }

    fun callPhoneNumber(phoneNumber: String): String {
        val clean = phoneNumber.filter { it.isDigit() || it == '+' }
        if (clean.isEmpty()) return "Phone number was invalid."

        val hasCallPerm = ContextCompat.checkSelfPermission(
            context,
            android.Manifest.permission.CALL_PHONE
        ) == PackageManager.PERMISSION_GRANTED

        val action = if (hasCallPerm) Intent.ACTION_CALL else Intent.ACTION_DIAL
        val intent = Intent(action, Uri.parse("tel:$clean")).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
        return if (hasCallPerm) "Calling $clean." else "Opened dialer with $clean."
    }

    fun openWhatsAppMessage(phoneNumber: String, message: String): String {
        return try {
            val digits = phoneNumber.filter { it.isDigit() }
            val uri = if (digits.isNotEmpty()) {
                Uri.parse("https://wa.me/$digits?text=${Uri.encode(message)}")
            } else {
                Uri.parse("https://wa.me/?text=${Uri.encode(message)}")
            }
            val intent = Intent(Intent.ACTION_VIEW, uri).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            "Opened WhatsApp with your draft message."
        } catch (e: Exception) {
            "Could not open WhatsApp: ${e.message}"
        }
    }

    fun openSystemSetting(section: String): String {
        val action = when (section.lowercase()) {
            "wifi", "wi-fi" -> Settings.ACTION_WIFI_SETTINGS
            "bluetooth" -> Settings.ACTION_BLUETOOTH_SETTINGS
            "brightness", "display" -> Settings.ACTION_DISPLAY_SETTINGS
            "sound", "volume", "dnd" -> Settings.ACTION_SOUND_SETTINGS
            "battery" -> Settings.ACTION_BATTERY_SAVER_SETTINGS
            "accessibility" -> Settings.ACTION_ACCESSIBILITY_SETTINGS
            else -> Settings.ACTION_SETTINGS
        }
        val intent = Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
        return "Opened $section settings."
    }
}
