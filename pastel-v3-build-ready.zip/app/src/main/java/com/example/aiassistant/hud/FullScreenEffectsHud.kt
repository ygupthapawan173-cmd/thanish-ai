package com.example.aiassistant.hud

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.aiassistant.ui.IridescentSwirlOrb
import kotlinx.coroutines.launch

class ActiveRipple(
    val x: Float,
    val y: Float,
    val progress: Animatable<Float, *> = Animatable(0f)
)

class ActiveSwipe(
    val startX: Float,
    val startY: Float,
    val endX: Float,
    val endY: Float,
    val progress: Animatable<Float, *> = Animatable(0f)
)

@Composable
fun FullScreenEffectsHud() {
    val state by AgentHudBus.state.collectAsState()
    val ripples = remember { mutableStateListOf<ActiveRipple>() }
    val swipes = remember { mutableStateListOf<ActiveSwipe>() }

    LaunchedEffect(Unit) {
        AgentHudBus.events.collect { event ->
            when (event) {
                is HudVisualEvent.TapRipple -> {
                    val ripple = ActiveRipple(event.x, event.y)
                    ripples.add(ripple)
                    launch {
                        ripple.progress.animateTo(1f, tween(450, easing = FastOutSlowInEasing))
                        ripples.remove(ripple)
                    }
                }
                is HudVisualEvent.SwipeTrail -> {
                    val swipe = ActiveSwipe(event.startX, event.startY, event.endX, event.endY)
                    swipes.add(swipe)
                    launch {
                        swipe.progress.animateTo(1f, tween(500, easing = FastOutSlowInEasing))
                        swipes.remove(swipe)
                    }
                }
            }
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        val activeState = state as? AgentHudState.Active
        if (activeState != null) {
            AiEdgeGlowOverlay(audioAmplitude = activeState.audioAmplitude)
        }

        Canvas(modifier = Modifier.fillMaxSize()) {
            ripples.forEach { ripple ->
                val p = ripple.progress.value
                val radius = 16.dp.toPx() + (52.dp.toPx() * p)
                val alpha = (1f - p).coerceIn(0f, 1f)

                drawCircle(
                    color = Color(0xFF00F0FF).copy(alpha = alpha * 0.35f),
                    radius = radius,
                    center = Offset(ripple.x, ripple.y)
                )
                drawCircle(
                    color = Color(0xFF00F0FF).copy(alpha = alpha),
                    radius = radius,
                    center = Offset(ripple.x, ripple.y),
                    style = Stroke(width = 3.dp.toPx())
                )
            }

            swipes.forEach { swipe ->
                val p = swipe.progress.value
                val alpha = (1f - p).coerceIn(0f, 1f)
                val currX = swipe.startX + (swipe.endX - swipe.startX) * p
                val currY = swipe.startY + (swipe.endY - swipe.startY) * p

                drawLine(
                    color = Color(0xFF00F0FF).copy(alpha = alpha),
                    start = Offset(swipe.startX, swipe.startY),
                    end = Offset(currX, currY),
                    strokeWidth = 6.dp.toPx(),
                    cap = StrokeCap.Round
                )
                drawCircle(
                    color = Color.White.copy(alpha = alpha),
                    radius = 10.dp.toPx(),
                    center = Offset(currX, currY)
                )
            }

            val box = activeState?.highlightBox
            if (box != null) {
                drawRoundRect(
                    color = Color(0xFF00F0FF),
                    topLeft = Offset(box.left.toFloat(), box.top.toFloat()),
                    size = Size(box.width().toFloat(), box.height().toFloat()),
                    cornerRadius = CornerRadius(12f, 12f),
                    style = Stroke(width = 2.dp.toPx())
                )
            }
        }
    }
}

@Composable
fun FloatingStatusPill(onStopClick: () -> Unit) {
    val state by AgentHudBus.state.collectAsState()
    val activeState = state as? AgentHudState.Active

    AnimatedVisibility(
        visible = activeState != null,
        enter = fadeIn(),
        exit = fadeOut()
    ) {
        if (activeState != null) {
            Row(
                modifier = Modifier
                    .clip(RoundedCornerShape(28.dp))
                    .background(Color(0xEE141724))
                    .border(1.dp, Color(0xFF00F0FF).copy(alpha = 0.5f), RoundedCornerShape(28.dp))
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                IridescentSwirlOrb(
                    size = 24.dp,
                    isListening = true,
                    audioAmplitude = activeState.audioAmplitude
                )

                Text(
                    text = activeState.statusText,
                    color = Color.White,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium
                )

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(16.dp))
                        .background(Color(0xFFEF4444))
                        .clickable { onStopClick() }
                        .padding(horizontal = 12.dp, vertical = 5.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "STOP",
                        color = Color.White,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}
