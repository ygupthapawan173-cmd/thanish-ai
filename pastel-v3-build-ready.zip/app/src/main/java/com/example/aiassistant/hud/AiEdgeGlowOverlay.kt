package com.example.aiassistant.hud

import android.graphics.RuntimeShader
import android.os.Build
import androidx.annotation.RequiresApi
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ShaderBrush
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import org.intellij.lang.annotations.Language

@Language("AGSL")
private const val EDGE_GLOW_SHADER = """
    uniform float2 iResolution;
    uniform float iTime;
    uniform float iAmplitude;
    uniform float iCornerRadius;

    float sdRoundedBox(float2 p, float2 b, float r) {
        float2 q = abs(p) - b + r;
        return min(max(q.x, q.y), 0.0) + length(max(q, 0.0)) - r;
    }

    half4 main(float2 fragCoord) {
        float2 halfRes = iResolution * 0.5;
        float2 p = fragCoord - halfRes;

        float dist = sdRoundedBox(p, halfRes, iCornerRadius);
        float edgeDist = abs(dist);

        float angle = atan(p.y, p.x);
        float wave = sin(angle * 4.0 + iTime * 3.0) * 6.0
                   + cos(angle * 7.0 - iTime * 2.2) * 4.0;

        float baseThickness = 26.0 + (iAmplitude * 48.0) + wave;
        float glow = exp(-edgeDist / max(baseThickness, 1.0));
        float crispRim = smoothstep(6.0, 0.0, edgeDist);

        float t1 = 0.5 + 0.5 * sin(angle * 2.0 + iTime * 2.4);
        float t2 = 0.5 + 0.5 * cos(angle * 3.0 - iTime * 1.8);

        half3 cyan   = half3(0.0, 0.94, 1.0);
        half3 blue   = half3(0.23, 0.51, 0.96);
        half3 violet = half3(0.66, 0.33, 0.97);

        half3 color = mix(cyan, blue, t1);
        color = mix(color, violet, t2 * 0.65);

        float alpha = clamp(glow * (0.55 + iAmplitude * 0.45) + crispRim * 0.6, 0.0, 1.0);
        return half4(color * alpha, alpha);
    }
"""

@Composable
fun AiEdgeGlowOverlay(
    audioAmplitude: Float,
    modifier: Modifier = Modifier,
    cornerRadiusPx: Float = 96f
) {
    val smoothAmplitude by animateFloatAsState(
        targetValue = audioAmplitude.coerceIn(0f, 1f),
        animationSpec = spring(stiffness = Spring.StiffnessMediumLow),
        label = "audioAmplitude"
    )

    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
        AgslEdgeGlow(
            amplitude = smoothAmplitude,
            cornerRadiusPx = cornerRadiusPx,
            modifier = modifier
        )
    } else {
        LegacyEdgeGlowFallback(
            amplitude = smoothAmplitude,
            modifier = modifier
        )
    }
}

@RequiresApi(Build.VERSION_CODES.TIRAMISU)
@Composable
private fun AgslEdgeGlow(
    amplitude: Float,
    cornerRadiusPx: Float,
    modifier: Modifier = Modifier
) {
    var time by remember { mutableFloatStateOf(0f) }
    LaunchedEffect(Unit) {
        val startNanos = withFrameNanos { it }
        while (true) {
            withFrameNanos { frameNanos ->
                time = (frameNanos - startNanos) / 1_000_000_000f
            }
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .drawWithCache {
                val shader = RuntimeShader(EDGE_GLOW_SHADER)
                val brush = ShaderBrush(shader)

                onDrawBehind {
                    shader.setFloatUniform("iResolution", size.width, size.height)
                    shader.setFloatUniform("iTime", time)
                    shader.setFloatUniform("iAmplitude", amplitude)
                    shader.setFloatUniform("iCornerRadius", cornerRadiusPx)
                    drawRect(brush = brush)
                }
            }
    )
}

@Composable
private fun LegacyEdgeGlowFallback(
    amplitude: Float,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .drawWithCache {
                val brush = Brush.sweepGradient(
                    listOf(Color(0xFF00F0FF), Color(0xFF3B82F6), Color(0xFFA855F7), Color(0xFF00F0FF))
                )
                onDrawBehind {
                    val strokeWidth = (6.dp + (10.dp * amplitude)).toPx()
                    drawRect(brush = brush, style = Stroke(width = strokeWidth))
                }
            }
    )
}
