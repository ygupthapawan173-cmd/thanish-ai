package com.example.aiassistant.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.aiassistant.ai.GeminiClient
import com.example.aiassistant.data.AssistantPreferences
import com.example.aiassistant.data.AssistantSettings
import com.example.aiassistant.device.DeviceActionExecutor
import com.example.aiassistant.hud.AgentHudBus
import com.example.aiassistant.hud.AgentHudState
import com.example.aiassistant.voice.AssistantTtsEngine
import com.example.aiassistant.voice.LiveVoiceRecognizer
import com.example.aiassistant.voice.WakeWordForegroundService
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class ChatMessage(
    val id: Long = System.nanoTime(),
    val text: String,
    val isFromUser: Boolean,
    val isVoiceInput: Boolean = false,
    val audioDuration: String = "0:04",
    val executedTools: List<String> = emptyList(),
    val isError: Boolean = false
)

data class AssistantUiState(
    val currentScreen: AssistantScreen = AssistantScreen.HOME,
    val settings: AssistantSettings = AssistantSettings(),
    val messages: List<ChatMessage> = listOf(
        ChatMessage(
            text = "Hi! I'm your Gemini v3 AI Agent. Ask me to open apps, toggle flashlight, set alarms, read notifications, or chat in Telugu/English.",
            isFromUser = false
        )
    ),
    val isListening: Boolean = false,
    val isThinking: Boolean = false,
    val isSpeaking: Boolean = false,
    val liveToolStatus: String? = null,
    val liveTranscript: String = "",
    val lastAiReply: String = "",
    val audioAmplitude: Float = 0f,
    val voiceError: String? = null
)

class AssistantViewModel(application: Application) : AndroidViewModel(application) {

    private val appContext = application.applicationContext
    private val preferences = AssistantPreferences(appContext)
    private val actionExecutor = DeviceActionExecutor(appContext)
    private val geminiClient = GeminiClient(
        apiKeyProvider = { preferences.settings.value.effectiveApiKey() },
        actionExecutor = actionExecutor
    )
    private val ttsEngine = AssistantTtsEngine(appContext)
    private var activeRequestJob: Job? = null

    private val _uiState = MutableStateFlow(AssistantUiState(settings = preferences.settings.value))
    val uiState: StateFlow<AssistantUiState> = _uiState.asStateFlow()

    private val voiceRecognizer = LiveVoiceRecognizer(appContext) { finalTranscript ->
        onVoiceTranscriptReady(finalTranscript)
    }

    init {
        viewModelScope.launch {
            preferences.settings.collect { latest ->
                ttsEngine.setLanguage(latest.languageTag)
                _uiState.update { it.copy(settings = latest) }
            }
        }

        viewModelScope.launch {
            voiceRecognizer.state.collect { vState ->
                _uiState.update { current ->
                    current.copy(
                        isListening = vState.isListening,
                        liveTranscript = if (vState.partialTranscript.isNotBlank()) vState.partialTranscript else current.liveTranscript,
                        audioAmplitude = vState.audioAmplitude,
                        voiceError = vState.errorMessage
                    )
                }

                if (vState.isListening) {
                    AgentHudBus.updateState(
                        AgentHudState.Active(
                            statusText = vState.partialTranscript.ifBlank { "Listening..." },
                            isThinking = false,
                            audioAmplitude = vState.audioAmplitude
                        )
                    )
                } else if (!_uiState.value.isThinking) {
                    AgentHudBus.updateState(AgentHudState.Hidden)
                }
            }
        }

        viewModelScope.launch {
            ttsEngine.isSpeaking.collect { speaking ->
                _uiState.update { it.copy(isSpeaking = speaking) }
            }
        }

        viewModelScope.launch {
            AgentHudBus.abortSignal.collect {
                stopAllActivity()
            }
        }

        viewModelScope.launch {
            AgentHudBus.wakeTriggers.collect { inlineCommand ->
                if (inlineCommand.isNotBlank()) {
                    handleInlineWakeCommand(inlineCommand)
                } else {
                    startVoiceListening()
                }
            }
        }
    }

    fun navigateTo(screen: AssistantScreen) {
        if (screen != AssistantScreen.LISTENING) {
            voiceRecognizer.stopListening()
        }
        _uiState.update { it.copy(currentScreen = screen, voiceError = null) }
    }

    fun updateSettings(transform: (AssistantSettings) -> AssistantSettings) {
        preferences.update(transform)
    }

    fun setWakeWordServiceEnabled(enabled: Boolean) {
        preferences.update { it.copy(wakeWordEnabled = enabled) }
        if (enabled) {
            WakeWordForegroundService.start(appContext)
        } else {
            WakeWordForegroundService.stop(appContext)
        }
    }

    fun setVoiceLanguage(localeTag: String) {
        preferences.update { it.copy(languageTag = localeTag) }
    }

    fun toggleAutoSpeak() {
        val next = !_uiState.value.settings.autoSpeak
        if (!next) ttsEngine.stop()
        preferences.update { it.copy(autoSpeak = next) }
    }

    fun startVoiceListening() {
        ttsEngine.stop()
        _uiState.update {
            it.copy(
                currentScreen = AssistantScreen.LISTENING,
                liveTranscript = "",
                liveToolStatus = null,
                voiceError = null
            )
        }
        voiceRecognizer.startListening(_uiState.value.settings.languageTag)
    }

    fun handleInlineWakeCommand(command: String) {
        ttsEngine.stop()
        _uiState.update {
            it.copy(
                currentScreen = AssistantScreen.LISTENING,
                liveTranscript = command,
                voiceError = null
            )
        }
        dispatchToGemini(command, isVoiceInput = true)
    }

    fun stopVoiceListening() {
        voiceRecognizer.stopListening()
    }

    fun speakMessage(text: String) {
        ttsEngine.speak(text)
    }

    fun clearChatHistory() {
        geminiClient.clearHistory()
        _uiState.update {
            it.copy(
                messages = listOf(
                    ChatMessage(text = "Conversation cleared. How can I help?", isFromUser = false)
                ),
                lastAiReply = ""
            )
        }
    }

    fun stopAllActivity() {
        voiceRecognizer.stopListening()
        ttsEngine.stop()
        activeRequestJob?.cancel()
        activeRequestJob = null
        _uiState.update {
            it.copy(isThinking = false, isListening = false, liveToolStatus = null, audioAmplitude = 0f)
        }
        AgentHudBus.updateState(AgentHudState.Hidden)
    }

    fun sendTextPrompt(prompt: String, openChatScreen: Boolean = true) {
        val trimmed = prompt.trim()
        if (trimmed.isEmpty()) return
        ttsEngine.stop()

        if (openChatScreen) {
            _uiState.update { it.copy(currentScreen = AssistantScreen.CHAT) }
        }
        dispatchToGemini(trimmed, isVoiceInput = false)
    }

    private fun onVoiceTranscriptReady(transcript: String) {
        dispatchToGemini(transcript, isVoiceInput = true)
    }

    private fun dispatchToGemini(prompt: String, isVoiceInput: Boolean) {
        val estimatedSeconds = (prompt.split(" ").size / 2).coerceIn(2, 59)
        val durationLabel = String.format("0:%02d", estimatedSeconds)

        _uiState.update { state ->
            state.copy(
                messages = state.messages + ChatMessage(
                    text = prompt,
                    isFromUser = true,
                    isVoiceInput = isVoiceInput,
                    audioDuration = durationLabel
                ),
                isThinking = true,
                liveToolStatus = null,
                voiceError = null
            )
        }

        AgentHudBus.updateState(
            AgentHudState.Active(
                statusText = "Gemini is thinking...",
                isThinking = true,
                audioAmplitude = 0.45f
            )
        )

        activeRequestJob?.cancel()
        activeRequestJob = viewModelScope.launch {
            val result = geminiClient.sendMessage(
                userMessage = prompt,
                onToolStatus = { toolStatus ->
                    _uiState.update { it.copy(liveToolStatus = toolStatus) }
                }
            )
            result.onSuccess { agentResult ->
                _uiState.update { state ->
                    state.copy(
                        messages = state.messages + ChatMessage(
                            text = agentResult.replyText,
                            isFromUser = false,
                            executedTools = agentResult.executedTools
                        ),
                        isThinking = false,
                        liveToolStatus = null,
                        lastAiReply = agentResult.replyText
                    )
                }
                if (_uiState.value.settings.autoSpeak && _uiState.value.currentScreen == AssistantScreen.LISTENING) {
                    ttsEngine.speak(agentResult.replyText)
                }
            }.onFailure { err ->
                val errorText = err.message ?: "Unable to reach Gemini API."
                _uiState.update { state ->
                    state.copy(
                        messages = state.messages + ChatMessage(
                            text = errorText,
                            isFromUser = false,
                            isError = true
                        ),
                        isThinking = false,
                        liveToolStatus = null,
                        voiceError = errorText
                    )
                }
            }
            AgentHudBus.updateState(AgentHudState.Hidden)
        }
    }

    override fun onCleared() {
        voiceRecognizer.release()
        ttsEngine.release()
        super.onCleared()
    }
}
