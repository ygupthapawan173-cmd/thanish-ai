package com.example.aiassistant.device

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class CapturedNotification(
    val key: String,
    val appName: String,
    val title: String,
    val body: String,
    val timeLabel: String
)

object NotificationInbox {
    private val _items = MutableStateFlow<List<CapturedNotification>>(emptyList())
    val items: StateFlow<List<CapturedNotification>> = _items.asStateFlow()

    fun add(item: CapturedNotification) {
        val current = _items.value.filterNot { it.key == item.key }
        _items.value = (listOf(item) + current).take(20)
    }

    fun removeByKey(key: String) {
        _items.value = _items.value.filterNot { it.key == key }
    }

    fun clear() {
        _items.value = emptyList()
    }

    fun formatForAgent(limit: Int = 6): String {
        val recent = _items.value.take(limit)
        if (recent.isEmpty()) return "No unread notifications captured yet."
        return recent.joinToString("\n") { n ->
            "[${n.timeLabel}] ${n.appName} - ${n.title}: ${n.body}"
        }
    }
}

class AssistantNotificationListener : NotificationListenerService() {

    private val timeFormat = SimpleDateFormat("hh:mm a", Locale.getDefault())

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        if (sbn == null || sbn.isOngoing) return
        if (sbn.packageName == packageName) return

        val extras = sbn.notification.extras
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString()?.trim().orEmpty()
        val text = extras.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString()?.trim()
            ?: extras.getCharSequence(Notification.EXTRA_TEXT)?.toString()?.trim().orEmpty()

        if (title.isBlank() && text.isBlank()) return

        val appLabel = try {
            val info = packageManager.getApplicationInfo(sbn.packageName, 0)
            packageManager.getApplicationLabel(info).toString()
        } catch (_: Exception) {
            sbn.packageName
        }

        NotificationInbox.add(
            CapturedNotification(
                key = sbn.key,
                appName = appLabel,
                title = title.ifBlank { appLabel },
                body = text,
                timeLabel = timeFormat.format(Date(sbn.postTime))
            )
        )
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification?) {
        if (sbn != null) {
            NotificationInbox.removeByKey(sbn.key)
        }
    }
}
