package com.example.aiassistant

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.material3.MaterialTheme
import com.example.aiassistant.ui.AssistantViewModel
import com.example.aiassistant.ui.PastelAiAssistantApp

class MainActivity : ComponentActivity() {

    private val viewModel: AssistantViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        handleWakeIntent(intent)

        setContent {
            MaterialTheme {
                PastelAiAssistantApp(viewModel = viewModel)
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleWakeIntent(intent)
    }

    private fun handleWakeIntent(intent: Intent?) {
        if (intent?.getBooleanExtra(EXTRA_START_LISTENING, false) == true) {
            val inlineCommand = intent.getStringExtra(EXTRA_WAKE_COMMAND).orEmpty()
            if (inlineCommand.isNotBlank()) {
                viewModel.handleInlineWakeCommand(inlineCommand)
            } else {
                viewModel.startVoiceListening()
            }
            intent.removeExtra(EXTRA_START_LISTENING)
            intent.removeExtra(EXTRA_WAKE_COMMAND)
        }
    }

    companion object {
        const val EXTRA_START_LISTENING = "extra_start_listening"
        const val EXTRA_WAKE_COMMAND = "extra_wake_command"
    }
}
