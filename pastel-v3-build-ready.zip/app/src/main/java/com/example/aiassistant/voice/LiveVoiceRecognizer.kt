package com.example.aiassistant.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import com.example.aiassistant.hud.AgentHudBus
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale

data class VoiceRecognizerState(
    val isListening: Boolean = false,
    val partialTranscript: String = "",
    val audioAmplitude: Float = 0f,
    val errorMessage: String? = null
)

class LiveVoiceRecognizer(
    private val context: Context,
    private val onFinalTranscript: (String) -> Unit
) {
    private val mainHandler = Handler(Looper.getMainLooper())
    private var speechRecognizer: SpeechRecognizer? = null

    private val _state = MutableStateFlow(VoiceRecognizerState())
    val state: StateFlow<VoiceRecognizerState> = _state.asStateFlow()

    fun startListening(languageTag: String = Locale.getDefault().toLanguageTag()) {
        mainHandler.post {
            if (!SpeechRecognizer.isRecognitionAvailable(context)) {
                _state.value = _state.value.copy(
                    isListening = false,
                    errorMessage = "Speech recognition service is not available on this device."
                )
                return@post
            }

            // Pause background wake-word listener to avoid mic contention
            AgentHudBus.setMainMicBusy(true)
            destroyInternal()

            val recognizer = SpeechRecognizer.createSpeechRecognizer(context)
            speechRecognizer = recognizer

            recognizer.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {
                    _state.value = VoiceRecognizerState(
                        isListening = true,
                        partialTranscript = "",
                        audioAmplitude = 0.1f,
                        errorMessage = null
                    )
                }

                override fun onBeginningOfSpeech() {
                    _state.value = _state.value.copy(isListening = true)
                }

                override fun onRmsChanged(rmsdB: Float) {
                    val normalized = ((rmsdB + 2f) / 12f).coerceIn(0f, 1f)
                    _state.value = _state.value.copy(audioAmplitude = normalized)
                }

                override fun onBufferReceived(buffer: ByteArray?) = Unit

                override fun onEndOfSpeech() {
                    _state.value = _state.value.copy(isListening = false, audioAmplitude = 0f)
                }

                override fun onError(error: Int) {
                    AgentHudBus.setMainMicBusy(false)
                    val message = when (error) {
                        SpeechRecognizer.ERROR_AUDIO -> "Audio recording error"
                        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Microphone permission required"
                        SpeechRecognizer.ERROR_NETWORK,
                        SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Network error during speech recognition"
                        SpeechRecognizer.ERROR_NO_MATCH -> "Didn't catch that. Tap mic to try again."
                        SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "No speech detected."
                        SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "Recognizer is busy. Try again."
                        else -> "Voice recognition error ($error)"
                    }
                    _state.value = _state.value.copy(
                        isListening = false,
                        audioAmplitude = 0f,
                        errorMessage = message
                    )
                }

                override fun onResults(results: Bundle?) {
                    AgentHudBus.setMainMicBusy(false)
                    val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    val finalText = matches?.firstOrNull()?.trim().orEmpty()
                    _state.value = _state.value.copy(
                        isListening = false,
                        partialTranscript = finalText,
                        audioAmplitude = 0f,
                        errorMessage = null
                    )
                    if (finalText.isNotEmpty()) {
                        onFinalTranscript(finalText)
                    }
                }

                override fun onPartialResults(partialResults: Bundle?) {
                    val matches = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    val partial = matches?.firstOrNull()?.trim().orEmpty()
                    if (partial.isNotEmpty()) {
                        _state.value = _state.value.copy(partialTranscript = partial)
                    }
                }

                override fun onEvent(eventType: Int, params: Bundle?) = Unit
            })

            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, languageTag)
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            }

            recognizer.startListening(intent)
        }
    }

    fun stopListening() {
        mainHandler.post {
            speechRecognizer?.stopListening()
            AgentHudBus.setMainMicBusy(false)
            _state.value = _state.value.copy(isListening = false, audioAmplitude = 0f)
        }
    }

    fun release() {
        mainHandler.post {
            destroyInternal()
            AgentHudBus.setMainMicBusy(false)
        }
    }

    private fun destroyInternal() {
        speechRecognizer?.cancel()
        speechRecognizer?.destroy()
        speechRecognizer = null
    }
}
