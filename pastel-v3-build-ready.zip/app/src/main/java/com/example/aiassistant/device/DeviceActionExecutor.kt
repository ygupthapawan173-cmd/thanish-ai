package com.example.aiassistant.device

import android.content.Context
import com.example.aiassistant.hud.AgentAccessibilityService
import com.example.aiassistant.hud.AgentHudBus
import com.example.aiassistant.hud.AgentHudState
import org.json.JSONObject

class DeviceActionExecutor(context: Context) {

    private val hardware = SystemHardwareController(context.applicationContext)

    suspend fun executeTool(
        name: String,
        args: JSONObject,
        onActionLog: (String) -> Unit = {}
    ): JSONObject {
        val statusLabel = when (name) {
            "open_app" -> "Opening ${args.optString("app_name")}..."
            "tap_ui_text" -> "Tapping ${args.optString("target_text")}..."
            "scroll_screen" -> "Scrolling ${args.optString("direction")}..."
            "navigate_device" -> "Navigating ${args.optString("action")}..."
            "read_current_screen" -> "Reading current screen..."
            "toggle_flashlight" -> "Toggling flashlight..."
            "set_media_volume" -> "Adjusting volume..."
            "set_alarm" -> "Setting alarm..."
            "set_timer" -> "Starting timer..."
            "make_phone_call" -> "Preparing call..."
            "send_whatsapp_message" -> "Opening WhatsApp..."
            "open_system_settings" -> "Opening settings..."
            "read_notifications" -> "Checking notifications..."
            else -> "Running $name..."
        }

        AgentHudBus.updateState(
            AgentHudState.Active(statusText = statusLabel, isThinking = true, audioAmplitude = 0.55f)
        )
        onActionLog(statusLabel)

        val message = when (name) {
            "open_app" -> hardware.openAppByName(args.optString("app_name"))

            "toggle_flashlight" -> hardware.setFlashlight(args.optBoolean("enabled", true))

            "set_media_volume" -> hardware.setMediaVolume(args.optInt("percent", 50))

            "set_alarm" -> hardware.setAlarm(
                hour24 = args.optInt("hour_24", 7),
                minute = args.optInt("minute", 0),
                label = args.optString("label", "AI Alarm")
            )

            "set_timer" -> hardware.setTimer(
                seconds = args.optInt("seconds", 60),
                label = args.optString("label", "AI Timer")
            )

            "make_phone_call" -> hardware.callPhoneNumber(args.optString("phone_number"))

            "send_whatsapp_message" -> hardware.openWhatsAppMessage(
                phoneNumber = args.optString("phone_number"),
                message = args.optString("message")
            )

            "open_system_settings" -> hardware.openSystemSetting(args.optString("section", "general"))

            "read_notifications" -> NotificationInbox.formatForAgent(args.optInt("limit", 6))

            "tap_ui_text" -> {
                val service = AgentAccessibilityService.instance
                if (service == null) {
                    "Accessibility Service is OFF. Ask the user to enable AI Assistant in Settings > Accessibility."
                } else {
                    service.clickNodeByText(args.optString("target_text"))
                }
            }

            "scroll_screen" -> {
                val service = AgentAccessibilityService.instance
                if (service == null) {
                    "Accessibility Service is OFF. Enable it in Settings > Accessibility."
                } else {
                    service.scrollScreen(args.optString("direction", "down"))
                }
            }

            "navigate_device" -> {
                val service = AgentAccessibilityService.instance
                if (service == null) {
                    "Accessibility Service is OFF. Enable it in Settings > Accessibility."
                } else {
                    service.performDeviceNavigation(args.optString("action", "back"))
                }
            }

            "read_current_screen" -> {
                val service = AgentAccessibilityService.instance
                if (service == null) {
                    "Accessibility Service is OFF. Enable it in Settings > Accessibility to read screen content."
                } else {
                    service.captureActiveScreenText()
                }
            }

            else -> "Unknown tool: $name"
        }

        return JSONObject().put("result", message)
    }
}
