package com.example.aiassistant.data

import android.content.Context
import com.example.aiassistant.BuildConfig
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class AssistantSettings(
    val userName: String = "User",
    val geminiApiKey: String = "",
    val wakeWord: String = "hey jarvis",
    val languageTag: String = "en-IN",
    val autoSpeak: Boolean = true,
    val wakeWordEnabled: Boolean = false
) {
    fun effectiveApiKey(): String =
        geminiApiKey.trim().ifEmpty { BuildConfig.GEMINI_API_KEY.trim() }
}

class AssistantPreferences(context: Context) {

    private val prefs = context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    private val _settings = MutableStateFlow(load())
    val settings: StateFlow<AssistantSettings> = _settings.asStateFlow()

    private fun load(): AssistantSettings = AssistantSettings(
        userName = prefs.getString(KEY_USER_NAME, "User") ?: "User",
        geminiApiKey = prefs.getString(KEY_API_KEY, "") ?: "",
        wakeWord = prefs.getString(KEY_WAKE_WORD, "hey jarvis") ?: "hey jarvis",
        languageTag = prefs.getString(KEY_LANGUAGE, "en-IN") ?: "en-IN",
        autoSpeak = prefs.getBoolean(KEY_AUTO_SPEAK, true),
        wakeWordEnabled = prefs.getBoolean(KEY_WAKE_ENABLED, false)
    )

    fun update(transform: (AssistantSettings) -> AssistantSettings) {
        val updated = transform(_settings.value)
        _settings.value = updated
        prefs.edit()
            .putString(KEY_USER_NAME, updated.userName.trim().ifEmpty { "User" })
            .putString(KEY_API_KEY, updated.geminiApiKey.trim())
            .putString(KEY_WAKE_WORD, updated.wakeWord.trim().lowercase().ifEmpty { "hey jarvis" })
            .putString(KEY_LANGUAGE, updated.languageTag)
            .putBoolean(KEY_AUTO_SPEAK, updated.autoSpeak)
            .putBoolean(KEY_WAKE_ENABLED, updated.wakeWordEnabled)
            .apply()
    }

    companion object {
        private const val PREFS_NAME = "ai_assistant_v3_prefs"
        private const val KEY_USER_NAME = "user_name"
        private const val KEY_API_KEY = "gemini_api_key"
        private const val KEY_WAKE_WORD = "wake_word"
        private const val KEY_LANGUAGE = "language_tag"
        private const val KEY_AUTO_SPEAK = "auto_speak"
        private const val KEY_WAKE_ENABLED = "wake_word_enabled"
    }
}
