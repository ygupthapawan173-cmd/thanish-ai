package com.example.aiassistant.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

object AssistantColors {
    val LavenderTop = Color(0xFFB3B0FA)
    val PeriwinkleMid = Color(0xFFD9DCFF)
    val SoftWhiteGlow = Color(0xFFF3F5FF)
    val LavenderBottom = Color(0xFFC7C4FA)

    val TextDark = Color(0xFF1F2233)
    val TextMuted = Color(0xFF5A5F78)
    val AudioPillDark = Color(0xFF14151B)

    val OrbCyan = Color(0xFF8EF1FF)
    val OrbPink = Color(0xFFF6A4E8)
    val OrbViolet = Color(0xFFA29BFF)
}

fun Modifier.pastelMeshBackground(): Modifier = this.background(
    brush = Brush.linearGradient(
        colors = listOf(
            AssistantColors.LavenderTop,
            AssistantColors.PeriwinkleMid,
            AssistantColors.SoftWhiteGlow,
            AssistantColors.LavenderBottom
        ),
        start = Offset(0f, 0f),
        end = Offset(900f, 1900f)
    )
)

fun Modifier.frostedGlassCard(cornerRadius: Dp = 24.dp): Modifier = this
    .clip(RoundedCornerShape(cornerRadius))
    .background(Color.White.copy(alpha = 0.56f))
    .border(
        width = 1.dp,
        color = Color.White.copy(alpha = 0.82f),
        shape = RoundedCornerShape(cornerRadius)
    )
