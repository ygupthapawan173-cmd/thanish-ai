package com.example.aiassistant.voice

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.example.aiassistant.MainActivity
import com.example.aiassistant.data.AssistantPreferences
import com.example.aiassistant.hud.AgentHudBus
import com.example.aiassistant.hud.AgentHudState
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

/**
 * Lightweight background wake-word detector using Android SpeechRecognizer in a Foreground Service.
 * Automatically yields the microphone whenever the main assistant listening UI is active.
 */
class WakeWordForegroundService : Service() {

    private val mainHandler = Handler(Looper.getMainLooper())
    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private lateinit var preferences: AssistantPreferences

    private var recognizer: SpeechRecognizer? = null
    private var isServiceRunning = false
    private var isRestartScheduled = false

    override fun onCreate() {
        super.onCreate()
        preferences = AssistantPreferences(this)
        createNotificationChannel()
        startForegroundSafely()
        isServiceRunning = true

        serviceScope.launch {
            AgentHudBus.isMainMicBusy.collect { busy ->
                if (busy) {
                    destroyRecognizer()
                } else if (isServiceRunning) {
                    scheduleRestart(900L)
                }
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        startForegroundSafely()
        if (!AgentHudBus.isMainMicBusy.value) {
            scheduleRestart(400L)
        }
        return START_STICKY
    }

    private fun startForegroundSafely() {
        val wakeWord = preferences.settings.value.wakeWord
        val launchIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
            putExtra(MainActivity.EXTRA_START_LISTENING, true)
        }
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            launchIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification: Notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("AI Assistant Active")
            .setContentText("Say \"$wakeWord\" to wake your assistant")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true)
            .setContentIntent(pendingIntent)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun scheduleRestart(delayMs: Long) {
        if (!isServiceRunning || isRestartScheduled || AgentHudBus.isMainMicBusy.value) return
        isRestartScheduled = true
        mainHandler.postDelayed({
            isRestartScheduled = false
            if (isServiceRunning && !AgentHudBus.isMainMicBusy.value) {
                startPassiveListening()
            }
        }, delayMs)
    }

    private fun startPassiveListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) return
        destroyRecognizer()

        val sr = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer = sr

        sr.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) = Unit
            override fun onBeginningOfSpeech() = Unit
            override fun onRmsChanged(rmsdB: Float) = Unit
            override fun onBufferReceived(buffer: ByteArray?) = Unit
            override fun onEndOfSpeech() = Unit

            override fun onPartialResults(partialResults: Bundle?) {
                checkMatches(partialResults)
            }

            override fun onResults(results: Bundle?) {
                val triggered = checkMatches(results)
                if (!triggered) {
                    scheduleRestart(600L)
                }
            }

            override fun onError(error: Int) {
                val backoff = when (error) {
                    SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> 1800L
                    SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> 5000L
                    else -> 900L
                }
                scheduleRestart(backoff)
            }

            override fun onEvent(eventType: Int, params: Bundle?) = Unit
        })

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, preferences.settings.value.languageTag)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        }

        try {
            sr.startListening(intent)
        } catch (_: Exception) {
            scheduleRestart(2000L)
        }
    }

    private fun checkMatches(bundle: Bundle?): Boolean {
        val spoken = bundle?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
            ?.firstOrNull()?.lowercase()?.trim().orEmpty()
        if (spoken.isEmpty()) return false

        val wakePhrase = preferences.settings.value.wakeWord.lowercase().trim()
        if (wakePhrase.isEmpty()) return false

        if (spoken.contains(wakePhrase)) {
            val remainder = spoken.substringAfter(wakePhrase).trim()
            onWakeWordDetected(remainder)
            return true
        }
        return false
    }

    private fun onWakeWordDetected(inlineCommand: String) {
        destroyRecognizer()
        AgentHudBus.updateState(
            AgentHudState.Active(
                statusText = if (inlineCommand.isBlank()) "Wake word detected!" else inlineCommand,
                isThinking = false,
                audioAmplitude = 0.65f
            )
        )
        AgentHudBus.emitWakeTrigger(inlineCommand)

        val wakeIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
            putExtra(MainActivity.EXTRA_START_LISTENING, true)
            if (inlineCommand.isNotBlank()) {
                putExtra(MainActivity.EXTRA_WAKE_COMMAND, inlineCommand)
            }
        }
        startActivity(wakeIntent)
    }

    private fun destroyRecognizer() {
        recognizer?.cancel()
        recognizer?.destroy()
        recognizer = null
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Wake-Word Listener",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Keeps your AI assistant wake-word trigger ready in the background."
            }
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        isServiceRunning = false
        mainHandler.removeCallbacksAndMessages(null)
        destroyRecognizer()
        serviceScope.cancel()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        private const val CHANNEL_ID = "ai_assistant_wake_word_channel"
        private const val NOTIFICATION_ID = 3001
        private const val ACTION_STOP = "com.example.aiassistant.STOP_WAKE_SERVICE"

        fun start(context: Context) {
            val intent = Intent(context, WakeWordForegroundService::class.java)
            ContextCompat.startForegroundService(context, intent)
        }

        fun stop(context: Context) {
            val intent = Intent(context, WakeWordForegroundService::class.java).apply {
                action = ACTION_STOP
            }
            context.startService(intent)
        }
    }
}
