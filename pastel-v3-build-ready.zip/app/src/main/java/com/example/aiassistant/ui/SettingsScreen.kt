package com.example.aiassistant.ui

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.example.aiassistant.data.AssistantSettings
import com.example.aiassistant.hud.AgentAccessibilityService

@Composable
fun SettingsScreen(
    settings: AssistantSettings,
    onBack: () -> Unit,
    onSaveSettings: ((AssistantSettings) -> AssistantSettings) -> Unit,
    onToggleWakeService: (Boolean) -> Unit,
    onClearHistory: () -> Unit
) {
    val context = LocalContext.current
    var apiKeyDraft by remember(settings.geminiApiKey) { mutableStateOf(settings.geminiApiKey) }
    var wakeWordDraft by remember(settings.wakeWord) { mutableStateOf(settings.wakeWord) }
    var userNameDraft by remember(settings.userName) { mutableStateOf(settings.userName) }
    var showApiKey by remember { mutableStateOf(false) }
    var savedBanner by remember { mutableStateOf(false) }

    val micPermLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) onToggleWakeService(true)
    }

    val notifPermLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) {}

    val hasMic = ContextCompat.checkSelfPermission(
        context,
        Manifest.permission.RECORD_AUDIO
    ) == PackageManager.PERMISSION_GRANTED
    val hasAccessibility = AgentAccessibilityService.instance != null
    val hasNotifListener = isNotificationListenerEnabled(context)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .pastelMeshBackground()
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(horizontal = 18.dp, vertical = 12.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            GlassCircleButton(icon = Icons.AutoMirrored.Rounded.ArrowBack, onClick = onBack)
            Text("Assistant Settings", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
            Spacer(modifier = Modifier.size(42.dp))
        }

        // API Key & Identity Card
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .frostedGlassCard(22.dp)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text("Gemini API & Wake Word", fontWeight = FontWeight.SemiBold, color = AssistantColors.TextDark, fontSize = 15.sp)

            OutlinedTextField(
                value = userNameDraft,
                onValueChange = { userNameDraft = it; savedBanner = false },
                label = { Text("Your Name") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            OutlinedTextField(
                value = apiKeyDraft,
                onValueChange = { apiKeyDraft = it; savedBanner = false },
                label = { Text("Gemini API Key (No rebuild needed)") },
                placeholder = { Text("AIza...") },
                singleLine = true,
                visualTransformation = if (showApiKey) VisualTransformation.None else PasswordVisualTransformation(),
                trailingIcon = {
                    IconButton(onClick = { showApiKey = !showApiKey }) {
                        Icon(
                            imageVector = if (showApiKey) Icons.Rounded.VisibilityOff else Icons.Rounded.Visibility,
                            contentDescription = "Toggle key visibility"
                        )
                    }
                },
                modifier = Modifier.fillMaxWidth()
            )

            OutlinedTextField(
                value = wakeWordDraft,
                onValueChange = { wakeWordDraft = it; savedBanner = false },
                label = { Text("Custom Wake Word") },
                placeholder = { Text("hey jarvis") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            Button(
                onClick = {
                    onSaveSettings {
                        it.copy(
                            userName = userNameDraft,
                            geminiApiKey = apiKeyDraft,
                            wakeWord = wakeWordDraft
                        )
                    }
                    savedBanner = true
                },
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(containerColor = AssistantColors.AudioPillDark),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(if (savedBanner) "Saved!" else "Save Settings", color = Color.White)
            }
        }

        // Background Wake Word & Voice Behavior
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .frostedGlassCard(22.dp)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text("Voice & Background Mode", fontWeight = FontWeight.SemiBold, color = AssistantColors.TextDark, fontSize = 15.sp)

            SettingSwitchRow(
                title = "Background Wake-Word Service",
                subtitle = "Listen for \"${settings.wakeWord}\" in background",
                checked = settings.wakeWordEnabled,
                onCheckedChange = { enable ->
                    if (enable && !hasMic) {
                        micPermLauncher.launch(Manifest.permission.RECORD_AUDIO)
                    } else {
                        if (enable && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                            notifPermLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                        }
                        onToggleWakeService(enable)
                    }
                }
            )

            SettingSwitchRow(
                title = "Auto-Speak Replies (TTS)",
                subtitle = "Read Gemini replies aloud in Voice Mode",
                checked = settings.autoSpeak,
                onCheckedChange = { enabled -> onSaveSettings { it.copy(autoSpeak = enabled) } }
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                LanguageChip(
                    label = "English (IN)",
                    selected = settings.languageTag == "en-IN",
                    modifier = Modifier.weight(1f),
                    onClick = { onSaveSettings { it.copy(languageTag = "en-IN") } }
                )
                LanguageChip(
                    label = "తెలుగు (TE)",
                    selected = settings.languageTag == "te-IN",
                    modifier = Modifier.weight(1f),
                    onClick = { onSaveSettings { it.copy(languageTag = "te-IN") } }
                )
            }
        }

        // Permissions & System Services Dashboard
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .frostedGlassCard(22.dp)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text("Device Control Permissions", fontWeight = FontWeight.SemiBold, color = AssistantColors.TextDark, fontSize = 15.sp)

            PermissionStatusRow(
                title = "Accessibility Service (HUD & Taps)",
                isGranted = hasAccessibility,
                onActionClick = {
                    context.startActivity(
                        Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    )
                }
            )

            PermissionStatusRow(
                title = "Notification Reader (WhatsApp/SMS)",
                isGranted = hasNotifListener,
                onActionClick = {
                    context.startActivity(
                        Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    )
                }
            )

            PermissionStatusRow(
                title = "Microphone Permission",
                isGranted = hasMic,
                onActionClick = { micPermLauncher.launch(Manifest.permission.RECORD_AUDIO) }
            )
        }

        OutlinedButton(
            onClick = onClearHistory,
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Clear Conversation Memory", color = AssistantColors.TextDark)
        }
    }
}

@Composable
private fun SettingSwitchRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f).padding(end = 8.dp)) {
            Text(title, color = AssistantColors.TextDark, fontWeight = FontWeight.Medium, fontSize = 14.sp)
            Text(subtitle, color = AssistantColors.TextMuted, fontSize = 12.sp)
        }
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}

@Composable
private fun LanguageChip(
    label: String,
    selected: Boolean,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .background(if (selected) AssistantColors.AudioPillDark else Color.White.copy(alpha = 0.65f))
            .clickable { onClick() }
            .padding(vertical = 10.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            color = if (selected) Color.White else AssistantColors.TextDark,
            fontWeight = FontWeight.Medium,
            fontSize = 13.sp
        )
    }
}

@Composable
private fun PermissionStatusRow(
    title: String,
    isGranted: Boolean,
    onActionClick: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.weight(1f)
        ) {
            Icon(
                imageVector = if (isGranted) Icons.Rounded.CheckCircle else Icons.Rounded.ErrorOutline,
                contentDescription = null,
                tint = if (isGranted) Color(0xFF16A34A) else Color(0xFFDC2626),
                modifier = Modifier.size(18.dp)
            )
            Text(title, color = AssistantColors.TextDark, fontSize = 13.sp)
        }
        TextButton(onClick = onActionClick) {
            Text(if (isGranted) "Active" else "Enable", fontWeight = FontWeight.SemiBold)
        }
    }
}

private fun isNotificationListenerEnabled(context: Context): Boolean {
    return NotificationManagerCompat.getEnabledListenerPackages(context).contains(context.packageName)
}
