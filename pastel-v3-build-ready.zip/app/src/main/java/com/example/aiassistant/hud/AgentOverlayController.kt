package com.example.aiassistant.hud

import android.content.Context
import android.graphics.PixelFormat
import android.os.Build
import android.view.Gravity
import android.view.WindowManager
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.ComposeView
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner

class AgentOverlayController(private val serviceContext: Context) {

    private val windowManager = serviceContext.getSystemService(WindowManager::class.java)
    private val lifecycleOwner = OverlayLifecycleOwner()

    private var effectsView: ComposeView? = null
    private var pillView: ComposeView? = null

    fun attachOverlays() {
        lifecycleOwner.onCreate()
        lifecycleOwner.onResume()

        val effectsParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }

        effectsView = createComposeView { FullScreenEffectsHud() }
        windowManager.addView(effectsView, effectsParams)

        val pillParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = 110
        }

        pillView = createComposeView {
            FloatingStatusPill(onStopClick = { AgentHudBus.triggerAbort() })
        }
        windowManager.addView(pillView, pillParams)
    }

    private fun createComposeView(content: @Composable () -> Unit): ComposeView {
        return ComposeView(serviceContext).apply {
            setViewTreeLifecycleOwner(lifecycleOwner)
            setViewTreeSavedStateRegistryOwner(lifecycleOwner)
            setContent(content)
        }
    }

    fun detachOverlays() {
        effectsView?.let { windowManager.removeViewImmediate(it) }
        pillView?.let { windowManager.removeViewImmediate(it) }
        effectsView = null
        pillView = null
        lifecycleOwner.onDestroy()
    }
}
