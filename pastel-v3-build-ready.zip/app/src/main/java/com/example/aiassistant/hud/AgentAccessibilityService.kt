package com.example.aiassistant.hud

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.graphics.Rect
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlin.coroutines.resume

class AgentAccessibilityService : AccessibilityService() {

    private lateinit var overlayController: AgentOverlayController
    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var activeTaskJob: Job? = null

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        overlayController = AgentOverlayController(this)
        overlayController.attachOverlays()

        serviceScope.launch {
            AgentHudBus.abortSignal.collect {
                abortCurrentExecution()
            }
        }
    }

    suspend fun performVisualTap(
        x: Float,
        y: Float,
        label: String,
        highlightBox: Rect? = null
    ): Boolean = withContext(Dispatchers.Main) {
        suspendCancellableCoroutine { cont ->
            AgentHudBus.updateState(
                AgentHudState.Active(statusText = label, highlightBox = highlightBox, audioAmplitude = 0.6f)
            )
            AgentHudBus.emitEvent(HudVisualEvent.TapRipple(x, y))

            val path = Path().apply { moveTo(x, y) }
            val stroke = GestureDescription.StrokeDescription(path, 0L, 60L)
            val gesture = GestureDescription.Builder().addStroke(stroke).build()

            val dispatched = dispatchGesture(gesture, object : GestureResultCallback() {
                override fun onCompleted(gestureDescription: GestureDescription?) {
                    if (cont.isActive) cont.resume(true)
                }

                override fun onCancelled(gestureDescription: GestureDescription?) {
                    if (cont.isActive) cont.resume(false)
                }
            }, null)

            if (!dispatched && cont.isActive) cont.resume(false)
        }
    }

    suspend fun scrollScreen(direction: String): String = withContext(Dispatchers.Main) {
        val metrics = resources.displayMetrics
        val cx = metrics.widthPixels * 0.5f
        val topY = metrics.heightPixels * 0.28f
        val bottomY = metrics.heightPixels * 0.74f

        val isDown = direction.lowercase() != "up"
        val startY = if (isDown) bottomY else topY
        val endY = if (isDown) topY else bottomY

        AgentHudBus.emitEvent(HudVisualEvent.SwipeTrail(cx, startY, cx, endY))

        val ok = suspendCancellableCoroutine<Boolean> { cont ->
            val path = Path().apply {
                moveTo(cx, startY)
                lineTo(cx, endY)
            }
            val stroke = GestureDescription.StrokeDescription(path, 0L, 320L)
            val gesture = GestureDescription.Builder().addStroke(stroke).build()

            val dispatched = dispatchGesture(gesture, object : GestureResultCallback() {
                override fun onCompleted(gestureDescription: GestureDescription?) {
                    if (cont.isActive) cont.resume(true)
                }

                override fun onCancelled(gestureDescription: GestureDescription?) {
                    if (cont.isActive) cont.resume(false)
                }
            }, null)

            if (!dispatched && cont.isActive) cont.resume(false)
        }

        if (ok) "Scrolled ${if (isDown) "down" else "up"}." else "Scroll gesture was cancelled."
    }

    suspend fun clickNodeByText(targetText: String): String = withContext(Dispatchers.Main) {
        val query = targetText.trim()
        if (query.isEmpty()) return@withContext "Target text was empty."

        val root = rootInActiveWindow ?: return@withContext "Cannot inspect current screen."
        val matched = root.findAccessibilityNodeInfosByText(query).firstOrNull()
            ?: findNodeByContentDescription(root, query)
            ?: return@withContext "Could not find '$query' on the current screen."

        val rect = Rect()
        matched.getBoundsInScreen(rect)

        if (!rect.isEmpty) {
            val tapped = performVisualTap(
                x = rect.exactCenterX(),
                y = rect.exactCenterY(),
                label = "Tapping '$query'",
                highlightBox = rect
            )
            delay(250)
            if (tapped) return@withContext "Tapped '$query'."
        }

        var clickableNode: AccessibilityNodeInfo? = matched
        while (clickableNode != null && !clickableNode.isClickable) {
            clickableNode = clickableNode.parent
        }
        val clicked = clickableNode?.performAction(AccessibilityNodeInfo.ACTION_CLICK) == true
        if (clicked) "Clicked '$query'." else "Found '$query' but could not click it."
    }

    fun performDeviceNavigation(action: String): String {
        val globalAction = when (action.lowercase()) {
            "back" -> GLOBAL_ACTION_BACK
            "home" -> GLOBAL_ACTION_HOME
            "recents" -> GLOBAL_ACTION_RECENTS
            "notifications" -> GLOBAL_ACTION_NOTIFICATIONS
            else -> return "Unsupported navigation action: $action"
        }
        val ok = performGlobalAction(globalAction)
        return if (ok) "Performed $action." else "Failed to perform $action."
    }

    fun captureActiveScreenText(maxChars: Int = 3500): String {
        val root = rootInActiveWindow ?: return "Unable to read the active screen right now."
        val collected = LinkedHashSet<String>()

        fun traverse(node: AccessibilityNodeInfo?) {
            if (node == null) return
            val text = node.text?.toString()?.trim().orEmpty()
            val desc = node.contentDescription?.toString()?.trim().orEmpty()
            if (text.isNotEmpty()) collected.add(text)
            else if (desc.isNotEmpty()) collected.add(desc)

            for (i in 0 until node.childCount) {
                traverse(node.getChild(i))
            }
        }

        traverse(root)
        if (collected.isEmpty()) return "No readable text found on the current screen."

        val joined = collected.joinToString(" | ")
        return if (joined.length > maxChars) joined.take(maxChars) + "..." else joined
    }

    private fun findNodeByContentDescription(
        node: AccessibilityNodeInfo?,
        query: String
    ): AccessibilityNodeInfo? {
        if (node == null) return null
        val desc = node.contentDescription?.toString()?.lowercase().orEmpty()
        if (desc.contains(query.lowercase())) return node
        for (i in 0 until node.childCount) {
            val found = findNodeByContentDescription(node.getChild(i), query)
            if (found != null) return found
        }
        return null
    }

    override fun onKeyEvent(event: KeyEvent?): Boolean {
        if (event?.keyCode == KeyEvent.KEYCODE_VOLUME_DOWN && event.action == KeyEvent.ACTION_DOWN) {
            AgentHudBus.triggerAbort()
        }
        return super.onKeyEvent(event)
    }

    private fun abortCurrentExecution() {
        activeTaskJob?.cancel()
        activeTaskJob = null
        AgentHudBus.updateState(AgentHudState.Hidden)
    }

    override fun onDestroy() {
        if (instance == this) instance = null
        overlayController.detachOverlays()
        serviceScope.cancel()
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) = Unit

    override fun onInterrupt() {
        abortCurrentExecution()
    }

    companion object {
        @Volatile
        var instance: AgentAccessibilityService? = null
            private set
    }
}
