package com.example.aiassistant.ai

import com.example.aiassistant.device.DeviceActionExecutor
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

data class GeminiAgentResult(
    val replyText: String,
    val executedTools: List<String> = emptyList()
)

class GeminiClient(
    private val apiKeyProvider: () -> String,
    private val actionExecutor: DeviceActionExecutor,
    private val modelName: String = "gemini-2.5-flash"
) {
    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(45, TimeUnit.SECONDS)
        .writeTimeout(20, TimeUnit.SECONDS)
        .build()

    // Stores Gemini Content objects (user / model / tool responses)
    private val conversationHistory = mutableListOf<JSONObject>()

    private val systemPrompt =
        "You are a fast, helpful Android voice AI agent. Reply naturally in the same language the user uses (Telugu, English, or Tenglish). " +
            "You have device control tools to open apps, tap on-screen text, scroll, read the current screen, read notifications, toggle flashlight, set volume, set alarms/timers, open WhatsApp, or place calls. " +
            "Use tools whenever the user asks to control the phone or inspect the screen/notifications, then give a concise confirmation."

    fun clearHistory() {
        conversationHistory.clear()
    }

    suspend fun sendMessage(
        userMessage: String,
        onToolStatus: (String) -> Unit = {}
    ): Result<GeminiAgentResult> = withContext(Dispatchers.IO) {
        val apiKey = apiKeyProvider().trim()
        if (apiKey.isBlank() || apiKey == "PASTE_YOUR_GEMINI_API_KEY_HERE") {
            return@withContext Result.failure(
                IllegalStateException("Gemini API key missing. Open Settings (top-right gear) and paste your API key.")
            )
        }

        val executedTools = mutableListOf<String>()

        try {
            val workingContents = JSONArray().apply {
                conversationHistory.forEach { put(it) }
                put(
                    JSONObject().apply {
                        put("role", "user")
                        put("parts", JSONArray().put(JSONObject().put("text", userMessage)))
                    }
                )
            }

            var finalReplyText = ""

            // Allow up to 4 chained function-calling turns
            for (hop in 0 until 4) {
                val payload = JSONObject().apply {
                    put(
                        "system_instruction",
                        JSONObject().put("parts", JSONArray().put(JSONObject().put("text", systemPrompt)))
                    )
                    put("contents", workingContents)
                    put("tools", buildToolsSchema())
                }

                val responseJson = postGenerateContent(apiKey, payload)
                val candidates = responseJson.optJSONArray("candidates")
                    ?: return@withContext Result.failure(IOException("No candidates returned by Gemini."))
                if (candidates.length() == 0) {
                    return@withContext Result.failure(IOException("Empty candidates array from Gemini."))
                }

                val modelContent = candidates.getJSONObject(0).optJSONObject("content")
                    ?: return@withContext Result.failure(IOException("Missing content in Gemini response."))
                val parts = modelContent.optJSONArray("parts") ?: JSONArray()

                // Append model turn to working contents
                workingContents.put(modelContent)

                val functionCalls = mutableListOf<JSONObject>()
                val textBuilder = StringBuilder()

                for (i in 0 until parts.length()) {
                    val part = parts.getJSONObject(i)
                    if (part.has("functionCall")) {
                        functionCalls.add(part.getJSONObject("functionCall"))
                    }
                    val t = part.optString("text", "")
                    if (t.isNotBlank()) {
                        if (textBuilder.isNotEmpty()) textBuilder.append("\n")
                        textBuilder.append(t)
                    }
                }

                if (functionCalls.isEmpty()) {
                    finalReplyText = textBuilder.toString().trim()
                    break
                }

                // Execute all requested device tools and return functionResponse parts
                val responseParts = JSONArray()
                for (call in functionCalls) {
                    val toolName = call.optString("name")
                    val toolArgs = call.optJSONObject("args") ?: JSONObject()
                    executedTools.add(toolName)

                    val toolResult = actionExecutor.executeTool(toolName, toolArgs, onToolStatus)
                    responseParts.put(
                        JSONObject().put(
                            "functionResponse",
                            JSONObject().apply {
                                put("name", toolName)
                                put("response", toolResult)
                            }
                        )
                    )
                }

                workingContents.put(
                    JSONObject().apply {
                        put("role", "user")
                        put("parts", responseParts)
                    }
                )
            }

            if (finalReplyText.isBlank()) {
                finalReplyText = if (executedTools.isNotEmpty()) {
                    "Done! Executed: ${executedTools.joinToString(", ")}."
                } else {
                    "I didn't receive a response. Please try again."
                }
            }

            // Persist clean user & final assistant turns in memory
            conversationHistory.add(
                JSONObject().apply {
                    put("role", "user")
                    put("parts", JSONArray().put(JSONObject().put("text", userMessage)))
                }
            )
            conversationHistory.add(
                JSONObject().apply {
                    put("role", "model")
                    put("parts", JSONArray().put(JSONObject().put("text", finalReplyText)))
                }
            )
            while (conversationHistory.size > 20) {
                conversationHistory.removeAt(0)
            }

            Result.success(GeminiAgentResult(replyText = finalReplyText, executedTools = executedTools))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private fun postGenerateContent(apiKey: String, payload: JSONObject): JSONObject {
        val url = "https://generativelanguage.googleapis.com/v1beta/models/$modelName:generateContent"
        val request = Request.Builder()
            .url(url)
            .addHeader("x-goog-api-key", apiKey)
            .addHeader("Content-Type", "application/json")
            .post(payload.toString().toRequestBody("application/json; charset=utf-8".toMediaType()))
            .build()

        httpClient.newCall(request).execute().use { response ->
            val rawBody = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                val msg = try {
                    JSONObject(rawBody).optJSONObject("error")?.optString("message")
                } catch (_: Exception) {
                    null
                }
                throw IOException(msg ?: "HTTP ${response.code}: Gemini request failed")
            }
            return JSONObject(rawBody)
        }
    }

    private fun buildToolsSchema(): JSONArray {
        val declarations = JSONArray()

        fun addDecl(
            name: String,
            description: String,
            properties: Map<String, Pair<String, String>> = emptyMap(),
            required: List<String> = emptyList()
        ) {
            val decl = JSONObject().apply {
                put("name", name)
                put("description", description)
                if (properties.isNotEmpty()) {
                    val propsObj = JSONObject()
                    properties.forEach { (propName, typeAndDesc) ->
                        propsObj.put(
                            propName,
                            JSONObject().apply {
                                put("type", typeAndDesc.first)
                                put("description", typeAndDesc.second)
                            }
                        )
                    }
                    put(
                        "parameters",
                        JSONObject().apply {
                            put("type", "OBJECT")
                            put("properties", propsObj)
                            if (required.isNotEmpty()) {
                                put("required", JSONArray(required))
                            }
                        }
                    )
                }
            }
            declarations.put(decl)
        }

        addDecl(
            name = "open_app",
            description = "Launch an installed Android app by its name (e.g. YouTube, WhatsApp, Chrome, Settings, Instagram).",
            properties = mapOf("app_name" to ("STRING" to "Name of the app to open")),
            required = listOf("app_name")
        )
        addDecl(
            name = "tap_ui_text",
            description = "Find a button or label containing the given text on the currently active screen and tap it via Accessibility Service.",
            properties = mapOf("target_text" to ("STRING" to "Visible text or button label to tap")),
            required = listOf("target_text")
        )
        addDecl(
            name = "scroll_screen",
            description = "Scroll the active app screen up or down using a swipe gesture.",
            properties = mapOf("direction" to ("STRING" to "Either 'down' or 'up'")),
            required = listOf("direction")
        )
        addDecl(
            name = "navigate_device",
            description = "Perform a global Android navigation action: back, home, recents, or notifications.",
            properties = mapOf("action" to ("STRING" to "One of: back, home, recents, notifications")),
            required = listOf("action")
        )
        addDecl(
            name = "read_current_screen",
            description = "Capture all visible text currently displayed on the phone screen so you can summarize, translate, or answer questions about it."
        )
        addDecl(
            name = "read_notifications",
            description = "Read recent incoming notifications (WhatsApp, SMS, alerts) captured by Notification Listener.",
            properties = mapOf("limit" to ("INTEGER" to "Maximum number of recent notifications to return (default 6)"))
        )
        addDecl(
            name = "toggle_flashlight",
            description = "Turn the phone rear camera flashlight (torch) ON or OFF.",
            properties = mapOf("enabled" to ("BOOLEAN" to "true to turn on, false to turn off")),
            required = listOf("enabled")
        )
        addDecl(
            name = "set_media_volume",
            description = "Set media playback volume percentage from 0 to 100.",
            properties = mapOf("percent" to ("INTEGER" to "Target media volume percent (0-100)")),
            required = listOf("percent")
        )
        addDecl(
            name = "set_alarm",
            description = "Set an alarm on the Android Clock app.",
            properties = mapOf(
                "hour_24" to ("INTEGER" to "Hour in 24-hour format (0-23)"),
                "minute" to ("INTEGER" to "Minute (0-59)"),
                "label" to ("STRING" to "Optional alarm label")
            ),
            required = listOf("hour_24", "minute")
        )
        addDecl(
            name = "set_timer",
            description = "Start a countdown timer in seconds.",
            properties = mapOf(
                "seconds" to ("INTEGER" to "Duration in seconds"),
                "label" to ("STRING" to "Optional timer label")
            ),
            required = listOf("seconds")
        )
        addDecl(
            name = "make_phone_call",
            description = "Dial or place a phone call to a phone number.",
            properties = mapOf("phone_number" to ("STRING" to "Phone number to call")),
            required = listOf("phone_number")
        )
        addDecl(
            name = "send_whatsapp_message",
            description = "Open WhatsApp with a pre-filled draft message for a phone number or contact chooser.",
            properties = mapOf(
                "phone_number" to ("STRING" to "Optional phone number with country code, e.g. 919876543210"),
                "message" to ("STRING" to "Message text to pre-fill")
            ),
            required = listOf("message")
        )
        addDecl(
            name = "open_system_settings",
            description = "Open an Android Settings page: wifi, bluetooth, brightness, sound, battery, accessibility, or general.",
            properties = mapOf("section" to ("STRING" to "Settings section name")),
            required = listOf("section")
        )

        return JSONArray().put(JSONObject().put("function_declarations", declarations))
    }
}
