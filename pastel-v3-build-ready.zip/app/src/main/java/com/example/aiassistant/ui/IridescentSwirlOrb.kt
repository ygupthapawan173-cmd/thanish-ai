package com.example.aiassistant.ui

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlin.math.sin

@Composable
fun IridescentSwirlOrb(
    size: Dp = 170.dp,
    isListening: Boolean = false,
    audioAmplitude: Float = 0f,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "orbAnim")

    val smoothAmp by animateFloatAsState(
        targetValue = audioAmplitude.coerceIn(0f, 1f),
        animationSpec = spring(stiffness = Spring.StiffnessMediumLow),
        label = "orbAmp"
    )

    val rotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(
                durationMillis = if (isListening) 5500 else 14000,
                easing = LinearEasing
            )
        ),
        label = "rotation"
    )

    val idlePulse by infiniteTransition.animateFloat(
        initialValue = 0.97f,
        targetValue = 1.03f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 2000, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )

    val waveShift by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = (2 * Math.PI).toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 3000, easing = LinearEasing)
        ),
        label = "waveShift"
    )

    val scaleFactor = if (isListening) 1f + (smoothAmp * 0.14f) else idlePulse

    Canvas(
        modifier = modifier
            .size(size * scaleFactor)
            .shadow(
                elevation = (20 + (smoothAmp * 14)).dp,
                shape = CircleShape,
                ambientColor = AssistantColors.OrbViolet,
                spotColor = AssistantColors.OrbPink
            )
            .clip(CircleShape)
    ) {
        val radius = this.size.minDimension / 2f
        val center = Offset(this.size.width / 2f, this.size.height / 2f)

        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(
                    Color(0xFFE6FAFF),
                    AssistantColors.OrbCyan,
                    AssistantColors.OrbViolet,
                    AssistantColors.OrbPink
                ),
                center = Offset(center.x - radius * 0.25f, center.y - radius * 0.25f),
                radius = radius * 1.35f
            )
        )

        rotate(degrees = -28f + (rotation * 0.1f), pivot = center) {
            val stripeCount = 9
            val spacing = this.size.height / (stripeCount - 1)
            val waveIntensity = 8f + (smoothAmp * 16f)

            for (i in -1..stripeCount) {
                val baseY = i * spacing
                val offset = sin(waveShift + i * 0.6f) * waveIntensity

                val path = Path().apply {
                    moveTo(-radius * 0.4f, baseY + offset)
                    cubicTo(
                        center.x * 0.5f, baseY - 26f + offset,
                        center.x * 1.5f, baseY + 26f - offset,
                        this@Canvas.size.width + radius * 0.4f, baseY + offset
                    )
                }

                drawPath(
                    path = path,
                    brush = Brush.horizontalGradient(
                        colors = listOf(
                            Color(0xFF7B7FE8).copy(alpha = 0.45f),
                            Color(0xFFEC8CE2).copy(alpha = 0.55f),
                            Color(0xFF67D7F2).copy(alpha = 0.50f)
                        )
                    ),
                    style = Stroke(width = spacing * 0.52f, cap = StrokeCap.Round)
                )

                drawPath(
                    path = path,
                    brush = Brush.horizontalGradient(
                        colors = listOf(
                            Color.White.copy(alpha = 0.75f),
                            AssistantColors.OrbCyan.copy(alpha = 0.85f),
                            Color.White.copy(alpha = 0.65f)
                        )
                    ),
                    style = Stroke(width = spacing * 0.22f, cap = StrokeCap.Round)
                )
            }
        }

        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(
                    Color.Transparent,
                    Color.Transparent,
                    Color(0xFF6E62D8).copy(alpha = 0.28f)
                ),
                center = center,
                radius = radius
            )
        )
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(Color.White.copy(alpha = 0.55f), Color.Transparent),
                center = Offset(center.x - radius * 0.35f, center.y - radius * 0.38f),
                radius = radius * 0.55f
            )
        )
    }
}
