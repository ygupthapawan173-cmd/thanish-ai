# Pastel Glassmorphism Android AI Agent v3 (Complete Bundle)

Full Jetpack Compose Android AI Assistant source code with **Gemini Function Calling**, **Custom Wake-Word Foreground Service**, **Accessibility App Control & Screen Reader**, **Hardware Controls**, **Notification Reader**, **In-App Settings**, and **AGSL Edge-Glow HUD**.

## What's Included in v3
1. **Gemini Function Calling (`ai/GeminiClient.kt` + `device/DeviceActionExecutor.kt`)**
   - Uses `gemini-2.5-flash` with 13 built-in device tools and up to 4 chained tool calls per request.
   - Natural voice/text prompts in Telugu, English, or Tenglish automatically trigger the right Android actions.
2. **Wake-Word Trigger & Background Foreground Service (`voice/WakeWordForegroundService.kt`)**
   - Listens for your custom wake phrase (default: `"hey jarvis"`), pauses cleanly when the main mic is busy, and supports inline commands like *"Hey Jarvis turn on flashlight"*.
3. **Accessibility Agent & Screen Reader (`hud/AgentAccessibilityService.kt`)**
   - Launches apps, taps on-screen UI text with cyan bounding-box + tap-ripple visuals, scrolls up/down with glowing swipe trails, performs global Back/Home/Recents, and reads active screen text for summaries/translations.
   - Hardware kill-switch: press **Volume Down** or tap **STOP** on the floating pill to abort instantly.
4. **System Hardware Controls (`device/SystemHardwareController.kt`)**
   - Rear Flashlight (Torch) ON/OFF, Media Volume %, Alarm & Timer, Direct Call/Dialer, WhatsApp message draft, and System Settings shortcuts (Wi-Fi, Bluetooth, Display, Sound, Battery).
5. **Notification Reader (`device/AssistantNotificationListener.kt`)**
   - Captures incoming WhatsApp/SMS/app notifications so you can ask *"Read my notifications"*.
6. **In-App Glassmorphism Settings (`ui/SettingsScreen.kt` + `data/AssistantPreferences.kt`)**
   - Enter/update your Gemini API Key directly inside the app (no rebuild needed), customize your wake word & name, toggle background wake-word service, switch English (`en-IN`) / Telugu (`te-IN`), and enable permissions with one tap.

## Quick Setup in Android Studio
1. Create a new **Empty Activity (Compose)** project with package `com.example.aiassistant` (or update package names to match yours).
2. Extract this ZIP and copy the `app/` folder into your project's `app/` directory.
3. Sync Gradle and run on a physical Android device (API 33+ recommended for AGSL RuntimeShader edge glow).
4. Open the **Settings (gear icon)** in the app to paste your **Gemini API Key**, customize your wake word, and enable:
   - **Microphone** (required for voice & wake word)
   - **Accessibility Service** (required for AGSL HUD, tap/scroll control, and screen reading)
   - **Notification Access** (optional, required for reading WhatsApp/SMS notifications)

## Standalone test build
Root Gradle configuration has been added for AGP 8.7.3 / Gradle 8.9 / JDK 17 / Android SDK 35. Run `gradle :app:assembleDebug` with those tools installed. The original JARVIS launcher icons are retained. The package is `com.example.aiassistant` (separate from OMEGA). No API key is embedded; configure in Settings. This is not yet a compiled or tested release. Existing source contains optional notification reading and accessibility screen-reading/automation; enable only after reviewing permissions. Do not use sensitive accounts in an untested build.
