from pathlib import Path
p=Path('app/src/main/java/com/example')
r=(p/'ai/PanduAiRepository.kt').read_text(); e=(p/'control/DeviceActionExecutor.kt').read_text(); c=(p/'control/PhoneControlManager.kt').read_text(); s=(p/'ai/SmartActionPolicy.kt').read_text()
checks=['SmartActionPolicy.permits(userMessage)' in r,'SmartActionPolicy.parse(response.text)' in r,'attachedImageBase64.isNullOrBlank() && SmartActionPolicy.permits' in r,'actionExecutor.executeTool(action.tool, args, onActionLog = onToolStatus)' in r,'results.add(result.responseJson.optString("result"))' in r,'SmartActionPolicy.matchApp(appName, apps)' in c,'matches.size > 1' in c,'Intent.ACTION_DIAL, Uri.fromParts' in c,'Intent.ACTION_CALL' not in c.split('fun dialForConfirmation',1)[1].split('fun setAlarm',1)[0],'"dial_contact" -> phoneControl.dialForConfirmation' in e,'"web_search" -> phoneControl.openWebSearch' in e,'"adjust_media_volume" -> phoneControl.adjustMediaVolume' in e,'MAX_STEPS = 3' in s,'"make_phone_call" ->' not in s,'versionCode = 105' in Path('app/build.gradle.kts').read_text()]
for i,x in enumerate(checks,1): assert x,i
print(f'{len(checks)}/{len(checks)} V100.5 source checks passed')
