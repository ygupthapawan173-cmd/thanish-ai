package com.example.omega

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import com.example.MainActivity
import com.example.R

/**
 * Pastel Glass Home Screen Widget (v15 Pro) with one-tap Voice, Camera Vision, and Good Night Routine.
 */
class OmegaHomeWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        for (widgetId in appWidgetIds) {
            val views = RemoteViews(context.packageName, R.layout.omega_home_widget)

            val voicePi = buildActivityPendingIntent(
                context,
                5001,
                Intent(context, MainActivity::class.java).apply {
                    putExtra(MainActivity.EXTRA_START_LISTENING, true)
                }
            )
            val visionPi = buildActivityPendingIntent(
                context,
                5002,
                Intent(context, MainActivity::class.java).apply {
                    putExtra(MainActivity.EXTRA_OPEN_CAMERA, true)
                }
            )
            val routinePi = buildActivityPendingIntent(
                context,
                5003,
                Intent(context, MainActivity::class.java).apply {
                    putExtra(MainActivity.EXTRA_RUN_ROUTINE, "Good Night")
                }
            )

            views.setOnClickPendingIntent(R.id.widget_orb_icon, voicePi)
            views.setOnClickPendingIntent(R.id.widget_voice_btn, voicePi)
            views.setOnClickPendingIntent(R.id.widget_vision_btn, visionPi)
            views.setOnClickPendingIntent(R.id.widget_routine_btn, routinePi)

            appWidgetManager.updateAppWidget(widgetId, views)
        }
    }

    private fun buildActivityPendingIntent(context: Context, reqCode: Int, intent: Intent): PendingIntent {
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
        return PendingIntent.getActivity(
            context,
            reqCode,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }
}
