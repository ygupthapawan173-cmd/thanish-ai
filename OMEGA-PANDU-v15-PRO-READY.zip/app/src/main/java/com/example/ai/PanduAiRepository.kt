package com.example.ai

import com.example.control.DeviceActionExecutor
import com.example.data.AiProvider
import com.example.data.AppDatabase
import com.example.data.OmegaSettings
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

data class AgentReplyResult(
    val replyText: String,
    val executedTools: List<String> = emptyList(),
    val latencyMs: Long = 0L,
    val usedModel: String = ""
)

data class ConnectionDiagnosticResult(
    val isSuccess: Boolean,
    val provider: AiProvider,
    val modelId: String,
    val latencyMs: Long,
    val summary: String
)

class PanduAiRepository(
    private val settingsProvider: () -> OmegaSettings,
    private val actionExecutor: DeviceActionExecutor,
    private val database: AppDatabase
) {
    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(50, TimeUnit.SECONDS)
        .writeTimeout(25, TimeUnit.SECONDS)
        .build()

    private val conversationHistory = mutableListOf<JSONObject>()

    fun seedHistoryFromDatabase() {
        conversationHistory.clear()
        database.getRecentMessages(limit = 16).forEach { msg ->
            if (!msg.isError && msg.text.isNotBlank()) {
                conversationHistory.add(
                    JSONObject().apply {
                        put("role", if (msg.isFromUser) "user" else "model")
                        put("parts", JSONArray().put(JSONObject().put("text", msg.text)))
                    }
                )
            }
        }
    }

    fun clearHistory() {
        conversationHistory.clear()
    }

    suspend fun runConnectionDiagnostic(): ConnectionDiagnosticResult = withContext(Dispatchers.IO) {
        val settings = settingsProvider()
        val apiKey = settings.effectiveApiKey()
        val model = settings.sanitizedModelId()
        val startMs = System.currentTimeMillis()

        if (apiKey.isBlank() || apiKey == "PASTE_YOUR_GEMINI_API_KEY_HERE") {
            return@withContext ConnectionDiagnosticResult(
                isSuccess = false,
                provider = settings.provider,
                modelId = model,
                latencyMs = 0L,
                summary = "API key is empty. Paste a valid ${settings.provider.displayName} key and tap Save."
            )
        }

        return@withContext try {
            val reply = when (settings.provider) {
                AiProvider.GEMINI -> {
                    val payload = JSONObject().put(
                        "contents",
                        JSONArray().put(
                            JSONObject().put("role", "user")
                                .put("parts", JSONArray().put(JSONObject().put("text", "Reply with OK only.")))
                        )
                    )
                    val res = postGemini(apiKey, model, payload)
                    res.optJSONArray("candidates")
                        ?.optJSONObject(0)
                        ?.optJSONObject("content")
                        ?.optJSONArray("parts")
                        ?.optJSONObject(0)
                        ?.optString("text", "")
                        .orEmpty()
                        .trim()
                        .ifBlank { "OK" }
                }
                else -> postOpenAiCompatible(settings.provider, apiKey, model, "Reply with OK only.")
            }
            val elapsed = System.currentTimeMillis() - startMs
            ConnectionDiagnosticResult(true, settings.provider, model, elapsed, "CONNECTED (${elapsed}ms) • $model • $reply")
        } catch (e: Exception) {
            val elapsed = System.currentTimeMillis() - startMs
            ConnectionDiagnosticResult(false, settings.provider, model, elapsed, "FAILED (${elapsed}ms): ${e.message}")
        }
    }

    /**
     * v12 Pro: Dedicated Live Google Search Grounded query sub-call.
     */
    private fun runGroundedGoogleSearch(apiKey: String, model: String, query: String): String {
        return try {
            val payload = JSONObject().apply {
                put(
                    "contents",
                    JSONArray().put(
                        JSONObject().put("role", "user")
                            .put("parts", JSONArray().put(JSONObject().put("text", "Search the live web and give a concise, up-to-date factual answer for: $query")))
                    )
                )
                put("tools", JSONArray().put(JSONObject().put("google_search", JSONObject())))
            }
            val res = postGemini(apiKey, model, payload)
            val parts = res.optJSONArray("candidates")
                ?.optJSONObject(0)
                ?.optJSONObject("content")
                ?.optJSONArray("parts") ?: return "No live web results found."
            val sb = StringBuilder()
            for (i in 0 until parts.length()) {
                val t = parts.getJSONObject(i).optString("text", "")
                if (t.isNotBlank()) sb.append(t).append(" ")
            }
            sb.toString().trim().ifBlank { "No live web results found." }
        } catch (e: Exception) {
            "Live web search failed: ${e.message}"
        }
    }

    suspend fun sendMessage(
        userMessage: String,
        attachedImageBase64: String? = null,
        onToolStatus: (String) -> Unit = {}
    ): Result<AgentReplyResult> = withContext(Dispatchers.IO) {
        val settings = settingsProvider()
        val apiKey = settings.effectiveApiKey()
        val model = settings.sanitizedModelId()
        val startMs = System.currentTimeMillis()

        if (apiKey.isBlank() || apiKey == "PASTE_YOUR_GEMINI_API_KEY_HERE") {
            return@withContext Result.failure(
                IllegalStateException("API key missing. Open Settings (top-right gear) and save your ${settings.provider.displayName} API key.")
            )
        }

        if (settings.provider != AiProvider.GEMINI) {
            return@withContext try {
                val reply = postOpenAiCompatible(settings.provider, apiKey, model, userMessage)
                rememberTurn(userMessage, reply)
                Result.success(AgentReplyResult(reply, emptyList(), System.currentTimeMillis() - startMs, model))
            } catch (e: Exception) {
                Result.failure(e)
            }
        }

        val executedTools = mutableListOf<String>()
        var activeModel = model

        try {
            val userParts = JSONArray().apply {
                put(JSONObject().put("text", userMessage))
                if (!attachedImageBase64.isNullOrBlank()) {
                    put(
                        JSONObject().put(
                            "inline_data",
                            JSONObject().put("mime_type", "image/jpeg").put("data", attachedImageBase64)
                        )
                    )
                }
            }

            val workingContents = JSONArray().apply {
                conversationHistory.forEach { put(it) }
                put(JSONObject().put("role", "user").put("parts", userParts))
            }

            var finalReplyText = ""

            for (hop in 0 until 6) {
                val payload = JSONObject().apply {
                    put("system_instruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", buildSystemPrompt()))))
                    put("contents", workingContents)
                    put("tools", buildToolsSchema(includeWebSearch = settings.webSearchGrounding))
                }

                val responseJson = try {
                    postGemini(apiKey, activeModel, payload)
                } catch (primaryErr: IOException) {
                    if (activeModel != "gemini-2.5-flash-lite" && primaryErr.message?.contains("404") == true) {
                        activeModel = "gemini-2.5-flash-lite"
                        postGemini(apiKey, activeModel, payload)
                    } else throw primaryErr
                }

                val modelContent = responseJson.optJSONArray("candidates")
                    ?.optJSONObject(0)
                    ?.optJSONObject("content")
                    ?: return@withContext Result.failure(IOException("Gemini returned an empty response."))
                val parts = modelContent.optJSONArray("parts") ?: JSONArray()
                workingContents.put(modelContent)

                val functionCalls = mutableListOf<JSONObject>()
                val textBuilder = StringBuilder()

                for (i in 0 until parts.length()) {
                    val p = parts.getJSONObject(i)
                    if (p.has("functionCall")) functionCalls.add(p.getJSONObject("functionCall"))
                    val t = p.optString("text", "")
                    if (t.isNotBlank()) {
                        if (textBuilder.isNotEmpty()) textBuilder.append("\n")
                        textBuilder.append(t)
                    }
                }

                if (functionCalls.isEmpty()) {
                    finalReplyText = textBuilder.toString().trim()
                    break
                }

                val responseParts = JSONArray()
                var pendingScreenshot: String? = null

                for (call in functionCalls) {
                    val toolName = call.optString("name")
                    val toolArgs = call.optJSONObject("args") ?: JSONObject()
                    executedTools.add(toolName)

                    val out = actionExecutor.executeTool(
                        name = toolName,
                        args = toolArgs,
                        webSearchRunner = { q -> runGroundedGoogleSearch(apiKey, activeModel, q) },
                        onActionLog = onToolStatus
                    )
                    if (out.capturedImageBase64 != null) pendingScreenshot = out.capturedImageBase64
                    responseParts.put(
                        JSONObject().put(
                            "functionResponse",
                            JSONObject().put("name", toolName).put("response", out.responseJson)
                        )
                    )
                }
                workingContents.put(JSONObject().put("role", "user").put("parts", responseParts))

                if (!pendingScreenshot.isNullOrBlank()) {
                    workingContents.put(
                        JSONObject().put("role", "user").put(
                            "parts",
                            JSONArray().apply {
                                put(JSONObject().put("text", "Captured live screenshot attached. Inspect it; if you need to tap an icon/button without text, call tap_screen_coordinates(x_norm, y_norm) on a 0..1000 grid."))
                                put(
                                    JSONObject().put(
                                        "inline_data",
                                        JSONObject().put("mime_type", "image/jpeg").put("data", pendingScreenshot)
                                    )
                                )
                            }
                        )
                    )
                }
            }

            if (finalReplyText.isBlank()) {
                finalReplyText = if (executedTools.isNotEmpty()) {
                    "Done! Executed: ${executedTools.joinToString(", ")}."
                } else {
                    "No response received. Please try again."
                }
            }

            rememberTurn(userMessage, finalReplyText)
            Result.success(AgentReplyResult(finalReplyText, executedTools, System.currentTimeMillis() - startMs, activeModel))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private fun rememberTurn(userText: String, modelText: String) {
        conversationHistory.add(JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("text", userText))))
        conversationHistory.add(JSONObject().put("role", "model").put("parts", JSONArray().put(JSONObject().put("text", modelText))))
        while (conversationHistory.size > 20) conversationHistory.removeAt(0)
    }

    private fun buildSystemPrompt(): String {
        val memories = database.formatMemoriesForPrompt()
        val routines = database.getAllRoutines().joinToString(", ") { "${it.name} (${it.triggerPhrase})" }
        val base =
            "You are OMEGA 15 Pro, an elite Android AI voice agent. Match the user's language (Telugu, Tenglish, or English) naturally and keep voice replies crisp. " +
                "Use live_web_search for real-time news, weather, cricket scores, or live prices. " +
                "Use Android tools for apps, UI text tapping, visual coordinate tapping (0..1000 grid after capture_screen_vision), typing text, scrolling, screen reading, battery, notifications, contacts, calls, WhatsApp, flashlight, volume, alarms/timers, routines, and personal memory. " +
                "Saved routines: $routines."
        return if (memories.isNotBlank()) "$base\n\nRemembered user facts:\n$memories" else base
    }

    private fun postGemini(apiKey: String, model: String, payload: JSONObject): JSONObject {
        val url = "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent"
        val req = Request.Builder()
            .url(url)
            .addHeader("x-goog-api-key", apiKey)
            .addHeader("Content-Type", "application/json")
            .post(payload.toString().toRequestBody("application/json; charset=utf-8".toMediaType()))
            .build()

        httpClient.newCall(req).execute().use { resp ->
            val raw = resp.body?.string().orEmpty()
            if (!resp.isSuccessful) {
                val msg = runCatching { JSONObject(raw).optJSONObject("error")?.optString("message") }.getOrNull()
                throw IOException("HTTP ${resp.code}: ${msg ?: "Gemini API request failed"}")
            }
            return JSONObject(raw)
        }
    }

    private fun postOpenAiCompatible(provider: AiProvider, apiKey: String, model: String, userMessage: String): String {
        val endpoint = when (provider) {
            AiProvider.GROQ -> "https://api.groq.com/openai/v1/chat/completions"
            AiProvider.OPENROUTER -> "https://openrouter.ai/api/v1/chat/completions"
            else -> "https://api.openai.com/v1/chat/completions"
        }
        val messages = JSONArray().apply {
            put(JSONObject().put("role", "system").put("content", buildSystemPrompt()))
            put(JSONObject().put("role", "user").put("content", userMessage))
        }
        val payload = JSONObject().put("model", model).put("messages", messages)
        val req = Request.Builder()
            .url(endpoint)
            .addHeader("Authorization", "Bearer $apiKey")
            .addHeader("Content-Type", "application/json")
            .post(payload.toString().toRequestBody("application/json; charset=utf-8".toMediaType()))
            .build()

        httpClient.newCall(req).execute().use { resp ->
            val raw = resp.body?.string().orEmpty()
            if (!resp.isSuccessful) {
                val msg = runCatching { JSONObject(raw).optJSONObject("error")?.optString("message") }.getOrNull()
                throw IOException("HTTP ${resp.code}: ${msg ?: "${provider.displayName} failed"}")
            }
            return JSONObject(raw)
                .optJSONArray("choices")
                ?.optJSONObject(0)
                ?.optJSONObject("message")
                ?.optString("content", "")
                .orEmpty()
                .trim()
                .ifBlank { "Empty reply from ${provider.displayName}." }
        }
    }

    private fun buildToolsSchema(includeWebSearch: Boolean): JSONArray {
        val declarations = JSONArray()
        fun add(name: String, desc: String, props: Map<String, Pair<String, String>> = emptyMap(), req: List<String> = emptyList()) {
            val d = JSONObject().put("name", name).put("description", desc)
            if (props.isNotEmpty()) {
                val pObj = JSONObject()
                props.forEach { (k, v) -> pObj.put(k, JSONObject().put("type", v.first).put("description", v.second)) }
                val params = JSONObject().put("type", "OBJECT").put("properties", pObj)
                if (req.isNotEmpty()) params.put("required", JSONArray(req))
                d.put("parameters", params)
            }
            declarations.put(d)
        }

        if (includeWebSearch) {
            add("live_web_search", "Search live Google Search for current weather, cricket scores, latest news, or real-time facts.",
                mapOf("query" to ("STRING" to "Search query")), listOf("query"))
        }
        add("open_app", "Launch an installed app by name (YouTube, WhatsApp, Chrome, Settings).", mapOf("app_name" to ("STRING" to "App name")), listOf("app_name"))
        add("tap_ui_text", "Tap visible UI text or button on current screen via Accessibility.", mapOf("target_text" to ("STRING" to "Visible label")), listOf("target_text"))
        add("tap_screen_coordinates", "Tap exact normalized screen coordinates (0..1000 for X and Y) after inspecting a screenshot.",
            mapOf("x_norm" to ("INTEGER" to "X from 0 (left) to 1000 (right)"), "y_norm" to ("INTEGER" to "Y from 0 (top) to 1000 (bottom)"), "label" to ("STRING" to "Short label")),
            listOf("x_norm", "y_norm"))
        add("type_screen_text", "Type text into the currently focused input box on screen.", mapOf("text" to ("STRING" to "Text to enter")), listOf("text"))
        add("scroll_screen", "Scroll active screen up or down.", mapOf("direction" to ("STRING" to "down or up")), listOf("direction"))
        add("navigate_device", "Global Android navigation: back, home, recents, notifications.", mapOf("action" to ("STRING" to "Navigation action")), listOf("action"))
        add("read_current_screen", "Read all visible text nodes on the current screen.")
        add("capture_screen_vision", "Capture a real live screenshot of the phone screen for visual inspection and coordinate clicking.")
        add("read_notifications", "Read recent WhatsApp/SMS/app notifications.", mapOf("limit" to ("INTEGER" to "Max items")))
        add("get_battery_status", "Check current phone battery percentage and charging state.")
        add("toggle_flashlight", "Turn rear camera flashlight ON or OFF.", mapOf("enabled" to ("BOOLEAN" to "true/false")), listOf("enabled"))
        add("set_media_volume", "Set media volume percentage (0-100).", mapOf("percent" to ("INTEGER" to "0-100")), listOf("percent"))
        add("set_alarm", "Set an alarm on Android Clock.", mapOf("hour_24" to ("INTEGER" to "0-23"), "minute" to ("INTEGER" to "0-59"), "label" to ("STRING" to "Label")), listOf("hour_24", "minute"))
        add("set_timer", "Start countdown timer in seconds.", mapOf("seconds" to ("INTEGER" to "Seconds"), "label" to ("STRING" to "Label")), listOf("seconds"))
        add("lookup_contact", "Search Contacts by name.", mapOf("name" to ("STRING" to "Name")), listOf("name"))
        add("make_phone_call", "Call a contact name or phone number.", mapOf("contact_or_number" to ("STRING" to "Name or number")), listOf("contact_or_number"))
        add("send_whatsapp_message", "Open WhatsApp with a draft message for a contact or number.", mapOf("contact_or_number" to ("STRING" to "Name or number"), "message" to ("STRING" to "Message")), listOf("message"))
        add("open_system_settings", "Open Settings section: wifi, bluetooth, brightness, sound, dnd, battery, accessibility, general.", mapOf("section" to ("STRING" to "Section")), listOf("section"))
        add("save_memory", "Save a personal fact permanently to SQLite memory.", mapOf("key" to ("STRING" to "Key"), "value" to ("STRING" to "Value")), listOf("key", "value"))
        add("recall_memories", "Recall all saved personal memories.")
        add("run_routine", "Execute a saved multi-step voice routine.", mapOf("routine_name" to ("STRING" to "Routine name or trigger")), listOf("routine_name"))

        return JSONArray().put(JSONObject().put("function_declarations", declarations))
    }
}
