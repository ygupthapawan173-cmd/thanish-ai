package com.example.ai

import android.annotation.SuppressLint
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.util.Base64
import com.example.control.AgentHudBus
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import okio.ByteString
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit
import kotlin.math.sqrt

data class LiveDuplexState(
    val isConnected: Boolean = false,
    val isConnecting: Boolean = false,
    val isAiSpeaking: Boolean = false,
    val amplitude: Float = 0f,
    val statusText: String = "Live Duplex Idle",
    val error: String? = null
)

class GeminiLiveDuplexEngine(
    private val apiKeyProvider: () -> String,
    private val modelPath: String = "models/gemini-2.0-flash-exp"
) {
    private val httpClient = OkHttpClient.Builder()
        .readTimeout(0, TimeUnit.MILLISECONDS)
        .pingInterval(20, TimeUnit.SECONDS)
        .build()

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var webSocket: WebSocket? = null
    private var audioRecord: AudioRecord? = null
    private var audioTrack: AudioTrack? = null
    private var captureJob: Job? = null

    private val _state = MutableStateFlow(LiveDuplexState())
    val state: StateFlow<LiveDuplexState> = _state.asStateFlow()

    fun connect() {
        val apiKey = apiKeyProvider().trim()
        if (apiKey.isBlank()) {
            _state.value = LiveDuplexState(error = "Add your Gemini API key in Settings to use Live Duplex Audio.")
            return
        }

        disconnect()
        AgentHudBus.setMainMicBusy(true)
        _state.value = LiveDuplexState(isConnecting = true, statusText = "Connecting Gemini Live...")

        val url = "wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContent?key=$apiKey"
        webSocket = httpClient.newWebSocket(Request.Builder().url(url).build(), object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                val setup = JSONObject().put(
                    "setup",
                    JSONObject()
                        .put("model", modelPath)
                        .put("generationConfig", JSONObject().put("responseModalities", JSONArray().put("AUDIO")))
                )
                webSocket.send(setup.toString())
                initPlayback()
                startMicStream(webSocket)
                _state.value = LiveDuplexState(isConnected = true, statusText = "Gemini Live Connected")
            }

            override fun onMessage(webSocket: WebSocket, text: String) = handleMessage(text)
            override fun onMessage(webSocket: WebSocket, bytes: ByteString) = handleMessage(bytes.utf8())

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                _state.value = LiveDuplexState(error = t.message ?: "WebSocket connection failed", statusText = "Disconnected")
                cleanupAudio()
                AgentHudBus.setMainMicBusy(false)
            }

            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                _state.value = LiveDuplexState(statusText = "Live Session Ended")
                cleanupAudio()
                AgentHudBus.setMainMicBusy(false)
            }
        })
    }

    private fun handleMessage(raw: String) {
        try {
            val sc = JSONObject(raw).optJSONObject("serverContent") ?: return
            if (sc.optBoolean("interrupted", false)) {
                audioTrack?.pause(); audioTrack?.flush(); audioTrack?.play()
                _state.value = _state.value.copy(isAiSpeaking = false, statusText = "Listening...")
                return
            }
            val parts = sc.optJSONObject("modelTurn")?.optJSONArray("parts")
            if (parts != null) {
                for (i in 0 until parts.length()) {
                    val inline = parts.getJSONObject(i).optJSONObject("inlineData") ?: continue
                    if (inline.optString("mimeType", "").startsWith("audio/pcm")) {
                        val pcm = Base64.decode(inline.optString("data"), Base64.DEFAULT)
                        _state.value = _state.value.copy(isAiSpeaking = true, statusText = "OMEGA Speaking...")
                        audioTrack?.write(pcm, 0, pcm.size)
                    }
                }
            }
            if (sc.optBoolean("turnComplete", false)) {
                _state.value = _state.value.copy(isAiSpeaking = false, statusText = "Listening...")
            }
        } catch (_: Exception) {}
    }

    private fun initPlayback() {
        val rate = 24000
        val minBuf = AudioTrack.getMinBufferSize(rate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT).coerceAtLeast(4096)
        audioTrack = AudioTrack.Builder()
            .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ASSISTANT).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
            .setAudioFormat(AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT).setSampleRate(rate).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
            .setBufferSizeInBytes(minBuf)
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build()
        audioTrack?.play()
    }

    @SuppressLint("MissingPermission")
    private fun startMicStream(ws: WebSocket) {
        val rate = 16000
        val minBuf = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT).coerceAtLeast(3200)
        val rec = AudioRecord(MediaRecorder.AudioSource.VOICE_COMMUNICATION, rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, minBuf)
        audioRecord = rec
        rec.startRecording()
        captureJob?.cancel()
        captureJob = scope.launch {
            val buf = ByteArray(3200)
            while (isActive && rec.recordingState == AudioRecord.RECORDSTATE_RECORDING) {
                val read = rec.read(buf, 0, buf.size)
                if (read > 0) {
                    _state.value = _state.value.copy(amplitude = computeRms(buf, read))
                    val b64 = Base64.encodeToString(buf, 0, read, Base64.NO_WRAP)
                    val payload = JSONObject().put(
                        "realtimeInput",
                        JSONObject().put("mediaChunks", JSONArray().put(JSONObject().put("mimeType", "audio/pcm;rate=16000").put("data", b64)))
                    )
                    ws.send(payload.toString())
                }
            }
        }
    }

    private fun computeRms(pcm: ByteArray, len: Int): Float {
        var sum = 0.0; var count = 0; var i = 0
        while (i + 1 < len) {
            val s = ((pcm[i + 1].toInt() shl 8) or (pcm[i].toInt() and 0xFF)).toShort().toDouble()
            sum += s * s; count++; i += 2
        }
        return if (count == 0) 0f else (sqrt(sum / count) / 8000.0).toFloat().coerceIn(0f, 1f)
    }

    fun disconnect() {
        webSocket?.close(1000, "Stopped")
        webSocket = null
        cleanupAudio()
        AgentHudBus.setMainMicBusy(false)
        _state.value = LiveDuplexState()
    }

    private fun cleanupAudio() {
        captureJob?.cancel(); captureJob = null
        runCatching { audioRecord?.stop(); audioRecord?.release() }; audioRecord = null
        runCatching { audioTrack?.stop(); audioTrack?.release() }; audioTrack = null
    }

    fun release() { disconnect(); scope.cancel() }
}
