package com.example.data

import android.content.Context
import com.example.BuildConfig
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

enum class AiProvider(val displayName: String, val defaultModel: String) {
    GEMINI("Google Gemini", "gemini-2.5-flash"),
    GROQ("Groq (Fast)", "llama-3.3-70b-versatile"),
    OPENROUTER("OpenRouter", "google/gemini-2.5-flash"),
    OPENAI("OpenAI", "gpt-4o-mini")
}

enum class OmegaVisualTheme {
    PASTEL_GLASS_3D,
    CYBER_HORIZON_WEBGL
}

data class OmegaSettings(
    val userName: String = "Pandu",
    val provider: AiProvider = AiProvider.GEMINI,
    val apiKey: String = "",
    val modelId: String = "gemini-2.5-flash",
    val wakeWord: String = "hey jarvis",
    val languageTag: String = "en-IN",
    val autoSpeak: Boolean = true,
    val wakeWordEnabled: Boolean = false,
    val floatingOrbEnabled: Boolean = true,
    val useGeminiLiveAudio: Boolean = false,
    val webSearchGrounding: Boolean = true,
    val biometricSafetyLock: Boolean = false,
    val gyroscopeParallax: Boolean = true,
    val visualTheme: OmegaVisualTheme = OmegaVisualTheme.PASTEL_GLASS_3D
) {
    fun effectiveApiKey(): String =
        apiKey.trim().ifEmpty {
            if (provider == AiProvider.GEMINI) BuildConfig.GEMINI_API_KEY.trim() else ""
        }

    fun sanitizedModelId(): String {
        val raw = modelId.trim()
        if (raw.isEmpty()) return provider.defaultModel
        if (provider == AiProvider.GEMINI && (
                raw.startsWith("gemini-3.5") ||
                    raw.startsWith("gemini-3.6") ||
                    raw.startsWith("gemini-3.8")
                )
        ) {
            return "gemini-2.5-flash"
        }
        return raw
    }
}

class OmegaPreferences(context: Context) {

    private val prefs = context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    private val _settings = MutableStateFlow(load())
    val settings: StateFlow<OmegaSettings> = _settings.asStateFlow()

    private fun load(): OmegaSettings {
        val provider = runCatching {
            AiProvider.valueOf(prefs.getString(KEY_PROVIDER, AiProvider.GEMINI.name) ?: "")
        }.getOrDefault(AiProvider.GEMINI)

        val theme = runCatching {
            OmegaVisualTheme.valueOf(prefs.getString(KEY_THEME, OmegaVisualTheme.PASTEL_GLASS_3D.name) ?: "")
        }.getOrDefault(OmegaVisualTheme.PASTEL_GLASS_3D)

        val loaded = OmegaSettings(
            userName = prefs.getString(KEY_USER_NAME, "Pandu") ?: "Pandu",
            provider = provider,
            apiKey = prefs.getString(KEY_API_KEY, "") ?: "",
            modelId = prefs.getString(KEY_MODEL_ID, provider.defaultModel) ?: provider.defaultModel,
            wakeWord = prefs.getString(KEY_WAKE_WORD, "hey jarvis") ?: "hey jarvis",
            languageTag = prefs.getString(KEY_LANGUAGE, "en-IN") ?: "en-IN",
            autoSpeak = prefs.getBoolean(KEY_AUTO_SPEAK, true),
            wakeWordEnabled = prefs.getBoolean(KEY_WAKE_ENABLED, false),
            floatingOrbEnabled = prefs.getBoolean(KEY_FLOATING_ORB, true),
            useGeminiLiveAudio = prefs.getBoolean(KEY_LIVE_AUDIO, false),
            webSearchGrounding = prefs.getBoolean(KEY_WEB_GROUNDING, true),
            biometricSafetyLock = prefs.getBoolean(KEY_BIOMETRIC_LOCK, false),
            gyroscopeParallax = prefs.getBoolean(KEY_PARALLAX, true),
            visualTheme = theme
        )
        return loaded.copy(modelId = loaded.sanitizedModelId())
    }

    fun update(transform: (OmegaSettings) -> OmegaSettings) {
        val raw = transform(_settings.value)
        val updated = raw.copy(modelId = raw.sanitizedModelId())
        _settings.value = updated
        prefs.edit()
            .putString(KEY_USER_NAME, updated.userName.trim().ifEmpty { "Pandu" })
            .putString(KEY_PROVIDER, updated.provider.name)
            .putString(KEY_API_KEY, updated.apiKey.trim())
            .putString(KEY_MODEL_ID, updated.modelId)
            .putString(KEY_WAKE_WORD, updated.wakeWord.trim().lowercase().ifEmpty { "hey jarvis" })
            .putString(KEY_LANGUAGE, updated.languageTag)
            .putBoolean(KEY_AUTO_SPEAK, updated.autoSpeak)
            .putBoolean(KEY_WAKE_ENABLED, updated.wakeWordEnabled)
            .putBoolean(KEY_FLOATING_ORB, updated.floatingOrbEnabled)
            .putBoolean(KEY_LIVE_AUDIO, updated.useGeminiLiveAudio)
            .putBoolean(KEY_WEB_GROUNDING, updated.webSearchGrounding)
            .putBoolean(KEY_BIOMETRIC_LOCK, updated.biometricSafetyLock)
            .putBoolean(KEY_PARALLAX, updated.gyroscopeParallax)
            .putString(KEY_THEME, updated.visualTheme.name)
            .apply()
    }

    companion object {
        private const val PREFS_NAME = "omega_pandu_v15_pro_prefs"
        private const val KEY_USER_NAME = "user_name"
        private const val KEY_PROVIDER = "provider"
        private const val KEY_API_KEY = "api_key"
        private const val KEY_MODEL_ID = "model_id"
        private const val KEY_WAKE_WORD = "wake_word"
        private const val KEY_LANGUAGE = "language_tag"
        private const val KEY_AUTO_SPEAK = "auto_speak"
        private const val KEY_WAKE_ENABLED = "wake_word_enabled"
        private const val KEY_FLOATING_ORB = "floating_orb_enabled"
        private const val KEY_LIVE_AUDIO = "use_live_audio"
        private const val KEY_WEB_GROUNDING = "web_grounding"
        private const val KEY_BIOMETRIC_LOCK = "biometric_lock"
        private const val KEY_PARALLAX = "gyro_parallax"
        private const val KEY_THEME = "visual_theme"
    }
}
