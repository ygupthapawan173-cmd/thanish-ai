package com.example.data

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

data class ChatMessageEntity(
    val id: Long = System.nanoTime(),
    val text: String,
    val isFromUser: Boolean,
    val isVoiceInput: Boolean = false,
    val audioDuration: String = "0:04",
    val executedTools: List<String> = emptyList(),
    val hasImageAttachment: Boolean = false,
    val isError: Boolean = false,
    val timestampMs: Long = System.currentTimeMillis()
)

data class MemoryFact(
    val id: Long = 0L,
    val key: String,
    val value: String,
    val updatedAtMs: Long = System.currentTimeMillis()
)

data class VoiceRoutine(
    val id: Long = 0L,
    val name: String,
    val triggerPhrase: String,
    val actionsSummary: String,
    val stepsJson: String
)

class AppDatabase(context: Context) : SQLiteOpenHelper(
    context.applicationContext,
    DB_NAME,
    null,
    DB_VERSION
) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            """
            CREATE TABLE chat_messages (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                text TEXT NOT NULL,
                is_from_user INTEGER NOT NULL,
                is_voice_input INTEGER NOT NULL,
                audio_duration TEXT NOT NULL,
                executed_tools TEXT NOT NULL,
                has_image INTEGER NOT NULL,
                is_error INTEGER NOT NULL,
                timestamp_ms INTEGER NOT NULL
            )
            """.trimIndent()
        )
        db.execSQL(
            """
            CREATE TABLE memory_facts (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                fact_key TEXT NOT NULL UNIQUE,
                fact_value TEXT NOT NULL,
                updated_at_ms INTEGER NOT NULL
            )
            """.trimIndent()
        )
        db.execSQL(
            """
            CREATE TABLE voice_routines (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL UNIQUE,
                trigger_phrase TEXT NOT NULL,
                actions_summary TEXT NOT NULL,
                steps_json TEXT NOT NULL
            )
            """.trimIndent()
        )
        seedDefaultRoutines(db)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS chat_messages")
        db.execSQL("DROP TABLE IF EXISTS memory_facts")
        db.execSQL("DROP TABLE IF EXISTS voice_routines")
        onCreate(db)
    }

    private fun seedDefaultRoutines(db: SQLiteDatabase) {
        val defaults = listOf(
            VoiceRoutine(
                name = "Good Night",
                triggerPhrase = "good night",
                actionsSummary = "Volume 10% • Flashlight OFF • 6:30 AM Alarm",
                stepsJson = """[{"tool":"set_media_volume","args":{"percent":10}},{"tool":"toggle_flashlight","args":{"enabled":false}},{"tool":"set_alarm","args":{"hour_24":6,"minute":30,"label":"Morning Wake Up"}}]"""
            ),
            VoiceRoutine(
                name = "Morning Briefing",
                triggerPhrase = "good morning",
                actionsSummary = "Volume 65% • Read Notifications",
                stepsJson = """[{"tool":"set_media_volume","args":{"percent":65}},{"tool":"read_notifications","args":{"limit":8}}]"""
            ),
            VoiceRoutine(
                name = "Focus Mode",
                triggerPhrase = "focus mode",
                actionsSummary = "Mute Media (0%) • Open DND Settings",
                stepsJson = """[{"tool":"set_media_volume","args":{"percent":0}},{"tool":"open_system_settings","args":{"section":"dnd"}}]"""
            ),
            VoiceRoutine(
                name = "Emergency Torch",
                triggerPhrase = "torch max",
                actionsSummary = "Flashlight ON • Volume 100%",
                stepsJson = """[{"tool":"toggle_flashlight","args":{"enabled":true}},{"tool":"set_media_volume","args":{"percent":100}}]"""
            )
        )
        defaults.forEach { r ->
            val cv = ContentValues().apply {
                put("name", r.name)
                put("trigger_phrase", r.triggerPhrase.lowercase())
                put("actions_summary", r.actionsSummary)
                put("steps_json", r.stepsJson)
            }
            db.insertWithOnConflict("voice_routines", null, cv, SQLiteDatabase.CONFLICT_IGNORE)
        }
    }

    fun insertMessage(msg: ChatMessageEntity): Long {
        val cv = ContentValues().apply {
            put("text", msg.text)
            put("is_from_user", if (msg.isFromUser) 1 else 0)
            put("is_voice_input", if (msg.isVoiceInput) 1 else 0)
            put("audio_duration", msg.audioDuration)
            put("executed_tools", msg.executedTools.joinToString(","))
            put("has_image", if (msg.hasImageAttachment) 1 else 0)
            put("is_error", if (msg.isError) 1 else 0)
            put("timestamp_ms", msg.timestampMs)
        }
        return writableDatabase.insert("chat_messages", null, cv)
    }

    fun getRecentMessages(limit: Int = 80): List<ChatMessageEntity> {
        val result = mutableListOf<ChatMessageEntity>()
        val cursor = readableDatabase.rawQuery(
            "SELECT * FROM (SELECT * FROM chat_messages ORDER BY id DESC LIMIT ?) ORDER BY id ASC",
            arrayOf(limit.toString())
        )
        cursor.use { c ->
            while (c.moveToNext()) {
                val toolsRaw = c.getString(c.getColumnIndexOrThrow("executed_tools")).orEmpty()
                result.add(
                    ChatMessageEntity(
                        id = c.getLong(c.getColumnIndexOrThrow("id")),
                        text = c.getString(c.getColumnIndexOrThrow("text")),
                        isFromUser = c.getInt(c.getColumnIndexOrThrow("is_from_user")) == 1,
                        isVoiceInput = c.getInt(c.getColumnIndexOrThrow("is_voice_input")) == 1,
                        audioDuration = c.getString(c.getColumnIndexOrThrow("audio_duration")),
                        executedTools = toolsRaw.split(",").filter { it.isNotBlank() },
                        hasImageAttachment = c.getInt(c.getColumnIndexOrThrow("has_image")) == 1,
                        isError = c.getInt(c.getColumnIndexOrThrow("is_error")) == 1,
                        timestampMs = c.getLong(c.getColumnIndexOrThrow("timestamp_ms"))
                    )
                )
            }
        }
        return result
    }

    fun clearMessages() {
        writableDatabase.delete("chat_messages", null, null)
    }

    fun upsertMemory(key: String, value: String) {
        val k = key.trim().lowercase()
        if (k.isEmpty()) return
        val cv = ContentValues().apply {
            put("fact_key", k)
            put("fact_value", value.trim())
            put("updated_at_ms", System.currentTimeMillis())
        }
        writableDatabase.insertWithOnConflict("memory_facts", null, cv, SQLiteDatabase.CONFLICT_REPLACE)
    }

    fun deleteMemory(key: String) {
        writableDatabase.delete("memory_facts", "fact_key = ?", arrayOf(key.trim().lowercase()))
    }

    fun getAllMemories(): List<MemoryFact> {
        val list = mutableListOf<MemoryFact>()
        readableDatabase.rawQuery("SELECT * FROM memory_facts ORDER BY updated_at_ms DESC", null).use { c ->
            while (c.moveToNext()) {
                list.add(
                    MemoryFact(
                        id = c.getLong(c.getColumnIndexOrThrow("id")),
                        key = c.getString(c.getColumnIndexOrThrow("fact_key")),
                        value = c.getString(c.getColumnIndexOrThrow("fact_value")),
                        updatedAtMs = c.getLong(c.getColumnIndexOrThrow("updated_at_ms"))
                    )
                )
            }
        }
        return list
    }

    fun formatMemoriesForPrompt(): String {
        val all = getAllMemories()
        return if (all.isEmpty()) "" else all.joinToString("\n") { "- ${it.key}: ${it.value}" }
    }

    fun getAllRoutines(): List<VoiceRoutine> {
        val list = mutableListOf<VoiceRoutine>()
        readableDatabase.rawQuery("SELECT * FROM voice_routines ORDER BY id ASC", null).use { c ->
            while (c.moveToNext()) {
                list.add(
                    VoiceRoutine(
                        id = c.getLong(c.getColumnIndexOrThrow("id")),
                        name = c.getString(c.getColumnIndexOrThrow("name")),
                        triggerPhrase = c.getString(c.getColumnIndexOrThrow("trigger_phrase")),
                        actionsSummary = c.getString(c.getColumnIndexOrThrow("actions_summary")),
                        stepsJson = c.getString(c.getColumnIndexOrThrow("steps_json"))
                    )
                )
            }
        }
        return list
    }

    fun saveRoutine(routine: VoiceRoutine) {
        val cv = ContentValues().apply {
            put("name", routine.name.trim())
            put("trigger_phrase", routine.triggerPhrase.trim().lowercase())
            put("actions_summary", routine.actionsSummary.trim())
            put("steps_json", routine.stepsJson)
        }
        writableDatabase.insertWithOnConflict("voice_routines", null, cv, SQLiteDatabase.CONFLICT_REPLACE)
    }

    fun deleteRoutine(id: Long) {
        writableDatabase.delete("voice_routines", "id = ?", arrayOf(id.toString()))
    }

    fun findRoutineByNameOrTrigger(query: String): VoiceRoutine? {
        val q = query.trim().lowercase()
        return getAllRoutines().firstOrNull { r ->
            r.name.lowercase() == q ||
                r.triggerPhrase.lowercase() == q ||
                r.name.lowercase().contains(q) ||
                q.contains(r.triggerPhrase.lowercase())
        }
    }

    companion object {
        private const val DB_NAME = "omega_pandu_v10.db"
        private const val DB_VERSION = 1
    }
}
