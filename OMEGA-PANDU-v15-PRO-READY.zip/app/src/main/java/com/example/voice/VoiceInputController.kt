package com.example.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import com.example.control.AgentHudBus
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale

data class VoiceInputState(
    val isListening: Boolean = false,
    val partialTranscript: String = "",
    val audioAmplitude: Float = 0f,
    val errorMessage: String? = null
)

class VoiceInputController(
    private val context: Context,
    private val onFinalTranscript: (String) -> Unit
) {
    private val mainHandler = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null

    private val _state = MutableStateFlow(VoiceInputState())
    val state: StateFlow<VoiceInputState> = _state.asStateFlow()

    fun startListening(languageTag: String = Locale.getDefault().toLanguageTag()) {
        mainHandler.post {
            if (!SpeechRecognizer.isRecognitionAvailable(context)) {
                _state.value = VoiceInputState(errorMessage = "Speech recognition unavailable on this device.")
                return@post
            }
            AgentHudBus.setMainMicBusy(true)
            destroyInternal()

            val sr = SpeechRecognizer.createSpeechRecognizer(context)
            recognizer = sr
            sr.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {
                    _state.value = VoiceInputState(isListening = true, audioAmplitude = 0.12f)
                }
                override fun onBeginningOfSpeech() { _state.value = _state.value.copy(isListening = true) }
                override fun onRmsChanged(rmsdB: Float) {
                    _state.value = _state.value.copy(audioAmplitude = ((rmsdB + 2f) / 12f).coerceIn(0f, 1f))
                }
                override fun onBufferReceived(buffer: ByteArray?) = Unit
                override fun onEndOfSpeech() { _state.value = _state.value.copy(isListening = false, audioAmplitude = 0f) }
                override fun onError(error: Int) {
                    AgentHudBus.setMainMicBusy(false)
                    val msg = when (error) {
                        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Microphone permission required"
                        SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Network error during voice capture"
                        SpeechRecognizer.ERROR_NO_MATCH -> "Didn't catch that. Tap orb to try again."
                        SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "No speech detected."
                        else -> "Voice error ($error)"
                    }
                    _state.value = _state.value.copy(isListening = false, audioAmplitude = 0f, errorMessage = msg)
                }
                override fun onResults(results: Bundle?) {
                    AgentHudBus.setMainMicBusy(false)
                    val final = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.trim().orEmpty()
                    _state.value = _state.value.copy(isListening = false, partialTranscript = final, audioAmplitude = 0f, errorMessage = null)
                    if (final.isNotEmpty()) onFinalTranscript(final)
                }
                override fun onPartialResults(partialResults: Bundle?) {
                    val p = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.trim().orEmpty()
                    if (p.isNotEmpty()) _state.value = _state.value.copy(partialTranscript = p)
                }
                override fun onEvent(eventType: Int, params: Bundle?) = Unit
            })

            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, languageTag)
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            }
            sr.startListening(intent)
        }
    }

    fun stopListening() {
        mainHandler.post {
            recognizer?.stopListening()
            AgentHudBus.setMainMicBusy(false)
            _state.value = _state.value.copy(isListening = false, audioAmplitude = 0f)
        }
    }

    fun release() {
        mainHandler.post { destroyInternal(); AgentHudBus.setMainMicBusy(false) }
    }

    private fun destroyInternal() {
        recognizer?.cancel(); recognizer?.destroy(); recognizer = null
    }
}
