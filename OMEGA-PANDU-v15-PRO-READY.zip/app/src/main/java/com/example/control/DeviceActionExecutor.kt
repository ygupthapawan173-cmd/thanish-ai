package com.example.control

import android.content.Context
import com.example.data.AppDatabase
import kotlinx.coroutines.delay
import org.json.JSONArray
import org.json.JSONObject

data class ToolExecutionOutput(
    val responseJson: JSONObject,
    val capturedImageBase64: String? = null
)

class DeviceActionExecutor(
    context: Context,
    private val database: AppDatabase
) {
    private val phoneControl = PhoneControlManager(context.applicationContext)

    fun getBatteryPercent(): Int {
        val bm = phoneControl.getBatterySummary()
        return Regex("(\d+)%").find(bm)?.groupValues?.getOrNull(1)?.toIntOrNull() ?: 100
    }

    suspend fun executeTool(
        name: String,
        args: JSONObject,
        webSearchRunner: suspend (String) -> String = { "Web search unavailable." },
        onActionLog: (String) -> Unit = {}
    ): ToolExecutionOutput {
        val statusLabel = when (name) {
            "live_web_search" -> "Searching Google: ${args.optString("query")}..."
            "open_app" -> "Opening ${args.optString("app_name")}..."
            "tap_ui_text" -> "Tapping ${args.optString("target_text")}..."
            "tap_screen_coordinates" -> "Visual tap (${args.optInt("x_norm")}, ${args.optInt("y_norm")})..."
            "type_screen_text" -> "Typing text..."
            "scroll_screen" -> "Scrolling ${args.optString("direction")}..."
            "navigate_device" -> "Navigating ${args.optString("action")}..."
            "read_current_screen" -> "Reading screen text..."
            "capture_screen_vision" -> "Capturing live screen..."
            "toggle_flashlight" -> "Toggling flashlight..."
            "set_media_volume" -> "Adjusting volume..."
            "set_alarm" -> "Setting alarm..."
            "set_timer" -> "Starting timer..."
            "lookup_contact" -> "Searching contacts..."
            "make_phone_call" -> "Preparing call..."
            "send_whatsapp_message" -> "Opening WhatsApp..."
            "open_system_settings" -> "Opening settings..."
            "read_notifications" -> "Reading notifications..."
            "get_battery_status" -> "Checking battery..."
            "save_memory" -> "Saving memory..."
            "recall_memories" -> "Recalling memory..."
            "run_routine" -> "Running routine: ${args.optString("routine_name")}..."
            else -> "Executing $name..."
        }

        AgentHudBus.updateState(AgentHudState.Active(statusLabel, isThinking = true, audioAmplitude = 0.55f))
        onActionLog(statusLabel)

        var screenshotBase64: String? = null
        val message = when (name) {
            "live_web_search" -> webSearchRunner(args.optString("query"))
            "open_app" -> phoneControl.openAppByName(args.optString("app_name"))
            "toggle_flashlight" -> phoneControl.setFlashlight(args.optBoolean("enabled", true))
            "set_media_volume" -> phoneControl.setMediaVolume(args.optInt("percent", 50))
            "get_battery_status" -> phoneControl.getBatterySummary()
            "set_alarm" -> phoneControl.setAlarm(args.optInt("hour_24", 7), args.optInt("minute", 0), args.optString("label"))
            "set_timer" -> phoneControl.setTimer(args.optInt("seconds", 60), args.optString("label"))
            "lookup_contact" -> phoneControl.lookupContact(args.optString("name"))
            "make_phone_call" -> phoneControl.callContactOrNumber(args.optString("contact_or_number").ifBlank { args.optString("phone_number") })
            "send_whatsapp_message" -> phoneControl.openWhatsAppMessage(
                args.optString("contact_or_number").ifBlank { args.optString("phone_number") },
                args.optString("message")
            )
            "open_system_settings" -> phoneControl.openSystemSetting(args.optString("section", "general"))
            "read_notifications" -> NotificationInbox.formatForAgent(args.optInt("limit", 6))
            "save_memory" -> {
                val k = args.optString("key"); val v = args.optString("value")
                database.upsertMemory(k, v)
                "Saved '$k' = '$v' to persistent memory."
            }
            "recall_memories" -> database.formatMemoriesForPrompt().ifBlank { "No saved memories yet." }
            "run_routine" -> executeRoutineByName(args.optString("routine_name"), onActionLog)
            "tap_ui_text" -> PanduAccessibilityService.instance?.clickNodeByText(args.optString("target_text"))
                ?: "Accessibility Service is OFF. Enable OMEGA 15 Pro Agent Service in Settings > Accessibility."
            "tap_screen_coordinates" -> PanduAccessibilityService.instance?.tapNormalizedCoordinates(
                args.optInt("x_norm", 500),
                args.optInt("y_norm", 500),
                args.optString("label", "Visual Tap")
            ) ?: "Accessibility Service is OFF."
            "type_screen_text" -> PanduAccessibilityService.instance?.typeTextIntoFocusedField(args.optString("text"))
                ?: "Accessibility Service is OFF."
            "scroll_screen" -> PanduAccessibilityService.instance?.scrollScreen(args.optString("direction", "down"))
                ?: "Accessibility Service is OFF."
            "navigate_device" -> PanduAccessibilityService.instance?.performDeviceNavigation(args.optString("action", "back"))
                ?: "Accessibility Service is OFF."
            "read_current_screen" -> PanduAccessibilityService.instance?.captureActiveScreenText()
                ?: "Accessibility Service is OFF."
            "capture_screen_vision" -> {
                val svc = PanduAccessibilityService.instance
                if (svc == null) {
                    "Accessibility Service is OFF. Enable it in Settings > Accessibility."
                } else {
                    val b64 = svc.captureScreenBase64Jpeg()
                    if (b64 != null) {
                        screenshotBase64 = b64
                        "Live screen screenshot captured. You can inspect it and optionally call tap_screen_coordinates(x_norm, y_norm) on a 0..1000 grid."
                    } else {
                        "Screenshot unavailable on this Android version. Screen text: " + svc.captureActiveScreenText()
                    }
                }
            }
            else -> "Unknown tool: $name"
        }

        return ToolExecutionOutput(JSONObject().put("result", message), screenshotBase64)
    }

    suspend fun executeRoutineByName(query: String, onActionLog: (String) -> Unit = {}): String {
        val routine = database.findRoutineByNameOrTrigger(query) ?: return "No routine found matching '$query'."
        val steps = runCatching { JSONArray(routine.stepsJson) }.getOrNull() ?: return "Invalid routine steps."
        val results = mutableListOf<String>()
        for (i in 0 until steps.length()) {
            val step = steps.getJSONObject(i)
            val tool = step.optString("tool")
            val args = step.optJSONObject("args") ?: JSONObject()
            if (tool.isNotBlank() && tool != "run_routine") {
                val out = executeTool(tool, args, onActionLog = onActionLog)
                results.add(out.responseJson.optString("result"))
                delay(350)
            }
        }
        return "Completed routine '${routine.name}': ${results.joinToString(" | ")}"
    }
}
