package com.example.control

import android.graphics.Rect
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow

sealed interface AgentHudState {
    data object Hidden : AgentHudState
    data class Active(
        val statusText: String,
        val isThinking: Boolean = false,
        val highlightBox: Rect? = null,
        val audioAmplitude: Float = 0.2f
    ) : AgentHudState
}

sealed interface HudVisualEvent {
    data class TapRipple(val x: Float, val y: Float) : HudVisualEvent
    data class SwipeTrail(val startX: Float, val startY: Float, val endX: Float, val endY: Float) : HudVisualEvent
}

object AgentHudBus {
    private val _state = MutableStateFlow<AgentHudState>(AgentHudState.Hidden)
    val state: StateFlow<AgentHudState> = _state.asStateFlow()

    private val _events = MutableSharedFlow<HudVisualEvent>(extraBufferCapacity = 16)
    val events: SharedFlow<HudVisualEvent> = _events.asSharedFlow()

    private val _abortSignal = MutableSharedFlow<Unit>(extraBufferCapacity = 1)
    val abortSignal: SharedFlow<Unit> = _abortSignal.asSharedFlow()

    private val _wakeTriggers = MutableSharedFlow<String>(extraBufferCapacity = 4)
    val wakeTriggers: SharedFlow<String> = _wakeTriggers.asSharedFlow()

    private val _isMainMicBusy = MutableStateFlow(false)
    val isMainMicBusy: StateFlow<Boolean> = _isMainMicBusy.asStateFlow()

    private val _floatingOrbVisible = MutableStateFlow(true)
    val floatingOrbVisible: StateFlow<Boolean> = _floatingOrbVisible.asStateFlow()

    fun updateState(newState: AgentHudState) { _state.value = newState }
    fun emitEvent(event: HudVisualEvent) { _events.tryEmit(event) }
    fun triggerAbort() { _abortSignal.tryEmit(Unit) }
    fun emitWakeTrigger(inlineCommand: String) { _wakeTriggers.tryEmit(inlineCommand) }
    fun setMainMicBusy(busy: Boolean) { _isMainMicBusy.value = busy }
    fun setFloatingOrbVisible(visible: Boolean) { _floatingOrbVisible.value = visible }
}
