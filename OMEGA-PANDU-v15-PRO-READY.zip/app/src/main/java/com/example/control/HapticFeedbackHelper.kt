package com.example.control

import android.content.Context
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager

class HapticFeedbackHelper(context: Context) {

    private val vibrator: Vibrator? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        val mgr = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
        mgr?.defaultVibrator
    } else {
        @Suppress("DEPRECATION")
        context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
    }

    fun wakePulse() = vibrate(longArrayOf(0, 22, 35, 30), intArrayOf(0, 120, 0, 190))
    fun softTap() = vibrateOneShot(18L, 110)
    fun abortPulse() = vibrate(longArrayOf(0, 45, 30, 45), intArrayOf(0, 220, 0, 220))

    private fun vibrateOneShot(ms: Long, amp: Int) {
        runCatching {
            val v = vibrator ?: return
            if (!v.hasVibrator()) return
            v.vibrate(VibrationEffect.createOneShot(ms, amp))
        }
    }

    private fun vibrate(timings: LongArray, amps: IntArray) {
        runCatching {
            val v = vibrator ?: return
            if (!v.hasVibrator()) return
            v.vibrate(VibrationEffect.createWaveform(timings, amps, -1))
        }
    }
}
