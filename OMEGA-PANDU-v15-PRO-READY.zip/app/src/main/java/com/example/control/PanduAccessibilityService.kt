package com.example.control

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Bitmap
import android.graphics.Path
import android.graphics.Rect
import android.os.Build
import android.os.Bundle
import android.view.Display
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlin.coroutines.resume

class PanduAccessibilityService : AccessibilityService() {

    private lateinit var overlayController: AgentOverlayController
    private lateinit var haptics: HapticFeedbackHelper
    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        haptics = HapticFeedbackHelper(this)
        overlayController = AgentOverlayController(this)
        overlayController.attachOverlays()

        serviceScope.launch {
            AgentHudBus.abortSignal.collect {
                haptics.abortPulse()
                AgentHudBus.updateState(AgentHudState.Hidden)
            }
        }
    }

    suspend fun performVisualTap(x: Float, y: Float, label: String, highlightBox: Rect? = null): Boolean =
        withContext(Dispatchers.Main) {
            haptics.softTap()
            suspendCancellableCoroutine { cont ->
                AgentHudBus.updateState(AgentHudState.Active(label, highlightBox = highlightBox, audioAmplitude = 0.6f))
                AgentHudBus.emitEvent(HudVisualEvent.TapRipple(x, y))

                val path = Path().apply { moveTo(x, y) }
                val gesture = GestureDescription.Builder()
                    .addStroke(GestureDescription.StrokeDescription(path, 0L, 60L))
                    .build()

                val ok = dispatchGesture(gesture, object : GestureResultCallback() {
                    override fun onCompleted(gestureDescription: GestureDescription?) {
                        if (cont.isActive) cont.resume(true)
                    }
                    override fun onCancelled(gestureDescription: GestureDescription?) {
                        if (cont.isActive) cont.resume(false)
                    }
                }, null)
                if (!ok && cont.isActive) cont.resume(false)
            }
        }

    /**
     * v13 Pro Visual Coordinate Tap:
     * Maps normalized 0..1000 Gemini Vision coordinates onto physical screen pixels.
     */
    suspend fun tapNormalizedCoordinates(xNorm: Int, yNorm: Int, label: String): String {
        val metrics = resources.displayMetrics
        val px = (xNorm.coerceIn(0, 1000) / 1000f) * metrics.widthPixels
        val py = (yNorm.coerceIn(0, 1000) / 1000f) * metrics.heightPixels
        val targetBox = Rect((px - 42).toInt(), (py - 42).toInt(), (px + 42).toInt(), (py + 42).toInt())
        val ok = performVisualTap(px, py, label.ifBlank { "Visual Tap ($xNorm, $yNorm)" }, targetBox)
        delay(220)
        return if (ok) "Tapped coordinates ($xNorm, $yNorm) on screen." else "Visual coordinate tap was cancelled."
    }

    /**
     * v13 Pro Screen Text Input:
     * Types text directly into the currently focused EditText / input box.
     */
    suspend fun typeTextIntoFocusedField(text: String): String = withContext(Dispatchers.Main) {
        val root = rootInActiveWindow ?: return@withContext "No active window found to type into."
        val focused = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
            ?: findFirstEditableNode(root)
            ?: return@withContext "No editable text box found on the current screen."

        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        }
        val ok = focused.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
        if (ok) "Typed text into input field." else "Could not type into the active field."
    }

    private fun findFirstEditableNode(node: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        if (node == null) return null
        if (node.isEditable) return node
        for (i in 0 until node.childCount) {
            val found = findFirstEditableNode(node.getChild(i))
            if (found != null) return found
        }
        return null
    }

    suspend fun scrollScreen(direction: String): String = withContext(Dispatchers.Main) {
        val m = resources.displayMetrics
        val cx = m.widthPixels * 0.5f
        val isDown = direction.lowercase() != "up"
        val startY = if (isDown) m.heightPixels * 0.74f else m.heightPixels * 0.28f
        val endY = if (isDown) m.heightPixels * 0.28f else m.heightPixels * 0.74f
        AgentHudBus.emitEvent(HudVisualEvent.SwipeTrail(cx, startY, cx, endY))

        val ok = suspendCancellableCoroutine<Boolean> { cont ->
            val path = Path().apply { moveTo(cx, startY); lineTo(cx, endY) }
            val gesture = GestureDescription.Builder()
                .addStroke(GestureDescription.StrokeDescription(path, 0L, 320L))
                .build()
            val dispatched = dispatchGesture(gesture, object : GestureResultCallback() {
                override fun onCompleted(gestureDescription: GestureDescription?) { if (cont.isActive) cont.resume(true) }
                override fun onCancelled(gestureDescription: GestureDescription?) { if (cont.isActive) cont.resume(false) }
            }, null)
            if (!dispatched && cont.isActive) cont.resume(false)
        }
        if (ok) "Scrolled ${if (isDown) "down" else "up"}." else "Scroll cancelled."
    }

    suspend fun clickNodeByText(targetText: String): String = withContext(Dispatchers.Main) {
        val q = targetText.trim()
        if (q.isEmpty()) return@withContext "Target text empty."
        val root = rootInActiveWindow ?: return@withContext "Cannot inspect active window."
        val matched = root.findAccessibilityNodeInfosByText(q).firstOrNull()
            ?: findByDesc(root, q)
            ?: return@withContext "Could not find '$q' on screen."

        val rect = Rect()
        matched.getBoundsInScreen(rect)
        if (!rect.isEmpty) {
            val tapped = performVisualTap(rect.exactCenterX(), rect.exactCenterY(), "Tapping '$q'", rect)
            delay(250)
            if (tapped) return@withContext "Tapped '$q'."
        }
        var node: AccessibilityNodeInfo? = matched
        while (node != null && !node.isClickable) node = node.parent
        if (node?.performAction(AccessibilityNodeInfo.ACTION_CLICK) == true) "Clicked '$q'." else "Found '$q' but could not click."
    }

    fun performDeviceNavigation(action: String): String {
        val code = when (action.lowercase()) {
            "back" -> GLOBAL_ACTION_BACK
            "home" -> GLOBAL_ACTION_HOME
            "recents" -> GLOBAL_ACTION_RECENTS
            "notifications" -> GLOBAL_ACTION_NOTIFICATIONS
            else -> return "Unknown navigation action: $action"
        }
        return if (performGlobalAction(code)) "Performed $action." else "Failed to perform $action."
    }

    fun captureActiveScreenText(maxChars: Int = 3500): String {
        val root = rootInActiveWindow ?: return "Unable to read current screen."
        val collected = LinkedHashSet<String>()
        fun walk(node: AccessibilityNodeInfo?) {
            if (node == null) return
            val t = node.text?.toString()?.trim().orEmpty()
            val d = node.contentDescription?.toString()?.trim().orEmpty()
            if (t.isNotEmpty()) collected.add(t) else if (d.isNotEmpty()) collected.add(d)
            for (i in 0 until node.childCount) walk(node.getChild(i))
        }
        walk(root)
        if (collected.isEmpty()) return "No readable text found on screen."
        val joined = collected.joinToString(" | ")
        return if (joined.length > maxChars) joined.take(maxChars) + "..." else joined
    }

    suspend fun captureScreenBase64Jpeg(): String? = withContext(Dispatchers.Main) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) return@withContext null
        suspendCancellableCoroutine { cont ->
            takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : TakeScreenshotCallback {
                override fun onSuccess(screenshot: ScreenshotResult) {
                    try {
                        val hw = Bitmap.wrapHardwareBuffer(screenshot.hardwareBuffer, screenshot.colorSpace)
                        screenshot.hardwareBuffer.close()
                        if (hw != null) {
                            val sw = hw.copy(Bitmap.Config.ARGB_8888, false)
                            hw.recycle()
                            val b64 = VisionHelper.bitmapToBase64Jpeg(sw)
                            sw.recycle()
                            if (cont.isActive) cont.resume(b64)
                        } else if (cont.isActive) cont.resume(null)
                    } catch (_: Exception) {
                        if (cont.isActive) cont.resume(null)
                    }
                }
                override fun onFailure(errorCode: Int) {
                    if (cont.isActive) cont.resume(null)
                }
            })
        }
    }

    private fun findByDesc(node: AccessibilityNodeInfo?, query: String): AccessibilityNodeInfo? {
        if (node == null) return null
        if (node.contentDescription?.toString()?.lowercase().orEmpty().contains(query.lowercase())) return node
        for (i in 0 until node.childCount) {
            val found = findByDesc(node.getChild(i), query)
            if (found != null) return found
        }
        return null
    }

    override fun onKeyEvent(event: KeyEvent?): Boolean {
        if (event?.keyCode == KeyEvent.KEYCODE_VOLUME_DOWN && event.action == KeyEvent.ACTION_DOWN) {
            AgentHudBus.triggerAbort()
        }
        return super.onKeyEvent(event)
    }

    override fun onDestroy() {
        if (instance == this) instance = null
        overlayController.detachOverlays()
        serviceScope.cancel()
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) = Unit
    override fun onInterrupt() { AgentHudBus.updateState(AgentHudState.Hidden) }

    companion object {
        @Volatile
        var instance: PanduAccessibilityService? = null
            private set
    }
}
