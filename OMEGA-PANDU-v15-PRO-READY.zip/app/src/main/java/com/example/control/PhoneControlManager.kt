package com.example.control

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.BatteryManager
import android.provider.AlarmClock
import android.provider.Settings
import androidx.core.content.ContextCompat

class PhoneControlManager(private val context: Context) {

    private val contactsHelper = ContactsHelper(context)

    fun getBatterySummary(): String {
        val bm = context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        val pct = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        val charging = bm.isCharging
        return "Battery is at $pct% (${if (charging) "charging" else "on battery"})."
    }

    fun setFlashlight(enabled: Boolean): String = try {
        val cm = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val camId = cm.cameraIdList.firstOrNull { id ->
            val c = cm.getCameraCharacteristics(id)
            c.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true &&
                c.get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_BACK
        } ?: return "No rear flashlight found."
        cm.setTorchMode(camId, enabled)
        if (enabled) "Flashlight turned ON." else "Flashlight turned OFF."
    } catch (e: Exception) {
        "Flashlight error: ${e.message}"
    }

    fun setMediaVolume(percent: Int): String = try {
        val am = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val clamped = percent.coerceIn(0, 100)
        val maxVol = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        am.setStreamVolume(AudioManager.STREAM_MUSIC, ((clamped / 100f) * maxVol).toInt(), AudioManager.FLAG_SHOW_UI)
        "Media volume set to $clamped%."
    } catch (e: Exception) {
        "Volume error: ${e.message}"
    }

    fun openAppByName(appName: String): String {
        val q = appName.trim().lowercase()
        if (q.isEmpty()) return "App name was empty."
        val pm = context.packageManager
        val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
        val match = apps.firstOrNull { it.loadLabel(pm).toString().lowercase() == q }
            ?: apps.firstOrNull {
                it.loadLabel(pm).toString().lowercase().contains(q) ||
                    it.activityInfo.packageName.lowercase().contains(q)
            } ?: return "No installed app matched '$appName'."

        val launch = pm.getLaunchIntentForPackage(match.activityInfo.packageName)
            ?: return "Unable to launch '${match.loadLabel(pm)}'."
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(launch)
        return "Opened ${match.loadLabel(pm)}."
    }

    fun setAlarm(hour24: Int, minute: Int, label: String): String = try {
        val intent = Intent(AlarmClock.ACTION_SET_ALARM).apply {
            putExtra(AlarmClock.EXTRA_HOUR, hour24.coerceIn(0, 23))
            putExtra(AlarmClock.EXTRA_MINUTES, minute.coerceIn(0, 59))
            putExtra(AlarmClock.EXTRA_MESSAGE, label.ifBlank { "OMEGA Alarm" })
            putExtra(AlarmClock.EXTRA_SKIP_UI, false)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
        String.format("Alarm set for %02d:%02d (%s).", hour24, minute, label.ifBlank { "Alarm" })
    } catch (e: Exception) {
        "Alarm error: ${e.message}"
    }

    fun setTimer(seconds: Int, label: String): String = try {
        val intent = Intent(AlarmClock.ACTION_SET_TIMER).apply {
            putExtra(AlarmClock.EXTRA_LENGTH, seconds.coerceAtLeast(1))
            putExtra(AlarmClock.EXTRA_MESSAGE, label.ifBlank { "OMEGA Timer" })
            putExtra(AlarmClock.EXTRA_SKIP_UI, false)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
        "Timer started for $seconds seconds."
    } catch (e: Exception) {
        "Timer error: ${e.message}"
    }

    fun lookupContact(nameQuery: String): String {
        if (!contactsHelper.hasPermission()) return "Contacts permission not granted. Enable it in Settings."
        val matches = contactsHelper.findContacts(nameQuery, limit = 5)
        if (matches.isEmpty()) return "No contacts found matching '$nameQuery'."
        return matches.joinToString("; ") { "${it.displayName}: ${it.phoneNumber}" }
    }

    fun callContactOrNumber(contactOrNumber: String): String {
        val resolved = contactsHelper.resolvePhoneOrName(contactOrNumber)
            ?: return "Could not find contact '$contactOrNumber'. Check Contacts permission or give a number."
        val hasCall = ContextCompat.checkSelfPermission(context, android.Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED
        val intent = Intent(if (hasCall) Intent.ACTION_CALL else Intent.ACTION_DIAL, Uri.parse("tel:${resolved.phoneNumber}")).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
        return if (hasCall) "Calling ${resolved.displayName}." else "Opened dialer for ${resolved.displayName}."
    }

    fun openWhatsAppMessage(contactOrNumber: String, message: String): String = try {
        val resolved = if (contactOrNumber.isNotBlank()) contactsHelper.resolvePhoneOrName(contactOrNumber) else null
        val digits = resolved?.phoneNumber?.filter { it.isDigit() }.orEmpty()
        val uri = if (digits.isNotEmpty()) {
            Uri.parse("https://wa.me/$digits?text=${Uri.encode(message)}")
        } else {
            Uri.parse("https://wa.me/?text=${Uri.encode(message)}")
        }
        context.startActivity(Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        if (resolved != null) "Opened WhatsApp draft to ${resolved.displayName}." else "Opened WhatsApp draft."
    } catch (e: Exception) {
        "WhatsApp error: ${e.message}"
    }

    fun openSystemSetting(section: String): String {
        val action = when (section.lowercase()) {
            "wifi", "wi-fi" -> Settings.ACTION_WIFI_SETTINGS
            "bluetooth" -> Settings.ACTION_BLUETOOTH_SETTINGS
            "brightness", "display" -> Settings.ACTION_DISPLAY_SETTINGS
            "sound", "volume", "dnd" -> Settings.ACTION_SOUND_SETTINGS
            "battery" -> Settings.ACTION_BATTERY_SAVER_SETTINGS
            "accessibility" -> Settings.ACTION_ACCESSIBILITY_SETTINGS
            else -> Settings.ACTION_SETTINGS
        }
        context.startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return "Opened $section settings."
    }
}
