package com.example.control

import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.view.Gravity
import android.view.WindowManager
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import com.example.MainActivity
import com.example.ui.components.IridescentSwirlOrb
import kotlinx.coroutines.launch

private class ActiveRipple(val x: Float, val y: Float, val progress: Animatable<Float, *> = Animatable(0f))
private class ActiveSwipe(val sx: Float, val sy: Float, val ex: Float, val ey: Float, val progress: Animatable<Float, *> = Animatable(0f))

class AgentOverlayController(private val serviceContext: Context) {

    private val windowManager = serviceContext.getSystemService(WindowManager::class.java)
    private val lifecycleOwner = OverlayLifecycleOwner()

    private var effectsView: ComposeView? = null
    private var pillView: ComposeView? = null
    private var miniOrbView: ComposeView? = null

    fun attachOverlays() {
        lifecycleOwner.onCreate()
        lifecycleOwner.onResume()

        val effectsParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }
        effectsView = createComposeView { FullScreenEffectsHud() }
        windowManager.addView(effectsView, effectsParams)

        val pillParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = 110
        }
        pillView = createComposeView { FloatingStatusPill { AgentHudBus.triggerAbort() } }
        windowManager.addView(pillView, pillParams)

        val orbParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = serviceContext.resources.displayMetrics.widthPixels - 180
            y = serviceContext.resources.displayMetrics.heightPixels / 2
        }
        miniOrbView = createComposeView {
            FloatingMiniOrbWidget(
                onTapOrb = {
                    val intent = Intent(serviceContext, MainActivity::class.java).apply {
                        flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
                        putExtra(MainActivity.EXTRA_START_LISTENING, true)
                    }
                    serviceContext.startActivity(intent)
                },
                onDragDelta = { dx, dy ->
                    orbParams.x += dx.toInt()
                    orbParams.y += dy.toInt()
                    miniOrbView?.let { v -> runCatching { windowManager.updateViewLayout(v, orbParams) } }
                }
            )
        }
        windowManager.addView(miniOrbView, orbParams)
    }

    private fun createComposeView(content: @Composable () -> Unit): ComposeView =
        ComposeView(serviceContext).apply {
            setViewTreeLifecycleOwner(lifecycleOwner)
            setViewTreeSavedStateRegistryOwner(lifecycleOwner)
            setContent(content)
        }

    fun detachOverlays() {
        effectsView?.let { runCatching { windowManager.removeViewImmediate(it) } }
        pillView?.let { runCatching { windowManager.removeViewImmediate(it) } }
        miniOrbView?.let { runCatching { windowManager.removeViewImmediate(it) } }
        effectsView = null; pillView = null; miniOrbView = null
        lifecycleOwner.onDestroy()
    }
}

@Composable
private fun FullScreenEffectsHud() {
    val state by AgentHudBus.state.collectAsState()
    val ripples = remember { mutableStateListOf<ActiveRipple>() }
    val swipes = remember { mutableStateListOf<ActiveSwipe>() }

    LaunchedEffect(Unit) {
        AgentHudBus.events.collect { event ->
            when (event) {
                is HudVisualEvent.TapRipple -> {
                    val r = ActiveRipple(event.x, event.y)
                    ripples.add(r)
                    launch { r.progress.animateTo(1f, tween(450, easing = FastOutSlowInEasing)); ripples.remove(r) }
                }
                is HudVisualEvent.SwipeTrail -> {
                    val s = ActiveSwipe(event.startX, event.startY, event.endX, event.endY)
                    swipes.add(s)
                    launch { s.progress.animateTo(1f, tween(500, easing = FastOutSlowInEasing)); swipes.remove(s) }
                }
            }
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        val activeState = state as? AgentHudState.Active
        if (activeState != null) {
            AiEdgeGlowOverlay(audioAmplitude = activeState.audioAmplitude)
        }
        Canvas(modifier = Modifier.fillMaxSize()) {
            ripples.forEach { r ->
                val p = r.progress.value
                val rad = 16.dp.toPx() + 52.dp.toPx() * p
                val alpha = (1f - p).coerceIn(0f, 1f)
                drawCircle(Color(0xFF00F0FF).copy(alpha = alpha * 0.35f), rad, Offset(r.x, r.y))
                drawCircle(Color(0xFF00F0FF).copy(alpha = alpha), rad, Offset(r.x, r.y), style = Stroke(3.dp.toPx()))
            }
            swipes.forEach { s ->
                val p = s.progress.value
                val alpha = (1f - p).coerceIn(0f, 1f)
                val cx = s.sx + (s.ex - s.sx) * p
                val cy = s.sy + (s.ey - s.sy) * p
                drawLine(Color(0xFF00F0FF).copy(alpha = alpha), Offset(s.sx, s.sy), Offset(cx, cy), 6.dp.toPx(), StrokeCap.Round)
                drawCircle(Color.White.copy(alpha = alpha), 9.dp.toPx(), Offset(cx, cy))
            }
            val box = activeState?.highlightBox
            if (box != null) {
                drawRoundRect(
                    color = Color(0xFF00F0FF),
                    topLeft = Offset(box.left.toFloat(), box.top.toFloat()),
                    size = Size(box.width().toFloat(), box.height().toFloat()),
                    cornerRadius = CornerRadius(12f, 12f),
                    style = Stroke(width = 2.dp.toPx())
                )
            }
        }
    }
}

@Composable
private fun FloatingStatusPill(onStopClick: () -> Unit) {
    val state by AgentHudBus.state.collectAsState()
    val active = state as? AgentHudState.Active
    AnimatedVisibility(visible = active != null, enter = fadeIn(), exit = fadeOut()) {
        if (active != null) {
            Row(
                modifier = Modifier
                    .clip(RoundedCornerShape(28.dp))
                    .background(Color(0xEE0B1221))
                    .border(1.dp, Color(0xFF00F0FF).copy(alpha = 0.55f), RoundedCornerShape(28.dp))
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                IridescentSwirlOrb(size = 24.dp, isListening = true, audioAmplitude = active.audioAmplitude, cyberMode = true)
                Text(active.statusText, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(16.dp))
                        .background(Color(0xFFEF4444))
                        .clickable { onStopClick() }
                        .padding(horizontal = 12.dp, vertical = 5.dp)
                ) {
                    Text("STOP", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun FloatingMiniOrbWidget(onTapOrb: () -> Unit, onDragDelta: (Float, Float) -> Unit) {
    val visible by AgentHudBus.floatingOrbVisible.collectAsState()
    val hudState by AgentHudBus.state.collectAsState()
    if (!visible) return

    Box(
        modifier = Modifier
            .size(56.dp)
            .clip(CircleShape)
            .background(Color(0x990A1324))
            .border(1.5.dp, Color(0xBB00F0FF), CircleShape)
            .pointerInput(Unit) {
                detectDragGestures { change, dragAmount ->
                    change.consume()
                    onDragDelta(dragAmount.x, dragAmount.y)
                }
            }
            .clickable { onTapOrb() },
        contentAlignment = Alignment.Center
    ) {
        IridescentSwirlOrb(
            size = 44.dp,
            isListening = hudState is AgentHudState.Active,
            audioAmplitude = (hudState as? AgentHudState.Active)?.audioAmplitude ?: 0.1f,
            cyberMode = true
        )
    }
}
