package com.example.ui.components

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import androidx.compose.runtime.*
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.platform.LocalContext

/**
 * Smooth Gyroscope / Accelerometer 3D Parallax hook (v14 Pro):
 * Tilts the central 3D Swirling Orb and glass cards subtly as you move your phone.
 */
@Composable
fun rememberParallaxOffset(enabled: Boolean = true, maxDpShift: Float = 14f): State<Offset> {
    val context = LocalContext.current
    val state = remember { mutableStateOf(Offset.Zero) }

    DisposableEffect(enabled) {
        if (!enabled) {
            state.value = Offset.Zero
            return@DisposableEffect onDispose {}
        }

        val sensorManager = context.getSystemService(Context.SENSOR_SERVICE) as? SensorManager
        val sensor = sensorManager?.getDefaultSensor(Sensor.TYPE_GRAVITY)
            ?: sensorManager?.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)

        if (sensorManager == null || sensor == null) {
            return@DisposableEffect onDispose {}
        }

        var smoothX = 0f
        var smoothY = 0f

        val listener = object : SensorEventListener {
            override fun onSensorChanged(event: SensorEvent) {
                val rawX = (-event.values[0] / 9.81f).coerceIn(-1f, 1f) * maxDpShift
                val rawY = ((event.values[1] - 5f) / 9.81f).coerceIn(-1f, 1f) * maxDpShift
                smoothX += (rawX - smoothX) * 0.14f
                smoothY += (rawY - smoothY) * 0.14f
                state.value = Offset(smoothX, smoothY)
            }

            override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit
        }

        sensorManager.registerListener(listener, sensor, SensorManager.SENSOR_DELAY_UI)
        onDispose {
            sensorManager.unregisterListener(listener)
        }
    }
    return state
}
