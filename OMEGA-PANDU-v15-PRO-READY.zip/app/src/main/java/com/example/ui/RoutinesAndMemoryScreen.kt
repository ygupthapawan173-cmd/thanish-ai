package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.MemoryFact
import com.example.data.OmegaVisualTheme
import com.example.data.VoiceRoutine
import com.example.ui.theme.OmegaAuraBackdrop
import com.example.ui.theme.OmegaColors
import com.example.ui.theme.mutedText
import com.example.ui.theme.omegaGlassCard
import com.example.ui.theme.primaryText

@Composable
fun RoutinesAndMemoryScreen(
    theme: OmegaVisualTheme,
    routines: List<VoiceRoutine>,
    memories: List<MemoryFact>,
    onBack: () -> Unit,
    onRunRoutine: (VoiceRoutine) -> Unit,
    onAddRoutine: (String, String, String, String) -> Unit,
    onDeleteRoutine: (Long) -> Unit,
    onDeleteMemory: (String) -> Unit
) {
    var showCreate by remember { mutableStateOf(false) }

    OmegaAuraBackdrop(theme = theme) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(horizontal = 18.dp, vertical = 12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                GlassCircleButton(Icons.AutoMirrored.Rounded.ArrowBack, theme = theme, onClick = onBack)
                Text("Routines & Memory", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                GlassCircleButton(Icons.Rounded.Add, theme = theme, onClick = { showCreate = true })
            }

            Spacer(modifier = Modifier.height(14.dp))

            LazyColumn(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                item { Text("Voice Routines", color = Color.White.copy(0.92f), fontSize = 14.sp, fontWeight = FontWeight.SemiBold) }
                items(routines, key = { it.id }) { routine ->
                    Row(
                        modifier = Modifier.fillMaxWidth().omegaGlassCard(20.dp, theme).padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f).padding(end = 8.dp)) {
                            Text(routine.name, color = theme.primaryText(), fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
                            Text("Trigger: \"${routine.triggerPhrase}\"", color = theme.mutedText(), fontSize = 12.sp)
                            Text(routine.actionsSummary, color = theme.primaryText().copy(0.85f), fontSize = 12.sp)
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(14.dp))
                                    .background(OmegaColors.AudioPillDark)
                                    .clickable { onRunRoutine(routine) }
                                    .padding(horizontal = 12.dp, vertical = 8.dp)
                            ) {
                                Text("Run", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                            }
                            IconButton(onClick = { onDeleteRoutine(routine.id) }) {
                                Icon(Icons.Rounded.DeleteOutline, contentDescription = "Delete", tint = theme.mutedText(), modifier = Modifier.size(18.dp))
                            }
                        }
                    }
                }

                item {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Long-Term Memory (SQLite)", color = Color.White.copy(0.92f), fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                }
                if (memories.isEmpty()) {
                    item {
                        Box(modifier = Modifier.fillMaxWidth().omegaGlassCard(18.dp, theme).padding(16.dp)) {
                            Text("No memories yet. Tell OMEGA: \"Remember my favorite coffee is filter coffee.\"", color = theme.mutedText(), fontSize = 13.sp)
                        }
                    }
                } else {
                    items(memories, key = { it.id }) { fact ->
                        Row(
                            modifier = Modifier.fillMaxWidth().omegaGlassCard(18.dp, theme).padding(horizontal = 14.dp, vertical = 12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(fact.key, color = theme.mutedText(), fontSize = 11.5.sp, fontWeight = FontWeight.SemiBold)
                                Text(fact.value, color = theme.primaryText(), fontSize = 14.sp)
                            }
                            IconButton(onClick = { onDeleteMemory(fact.key) }) {
                                Icon(Icons.Rounded.Close, contentDescription = "Forget", tint = theme.mutedText(), modifier = Modifier.size(18.dp))
                            }
                        }
                    }
                }
            }
        }
    }

    if (showCreate) {
        var name by remember { mutableStateOf("") }
        var trigger by remember { mutableStateOf("") }
        var appToOpen by remember { mutableStateOf("YouTube") }
        var vol by remember { mutableStateOf("75") }

        AlertDialog(
            onDismissRequest = { showCreate = false },
            title = { Text("New Routine") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(name, { name = it }, label = { Text("Name") }, singleLine = true)
                    OutlinedTextField(trigger, { trigger = it }, label = { Text("Voice Trigger") }, singleLine = true)
                    OutlinedTextField(appToOpen, { appToOpen = it }, label = { Text("App to Open") }, singleLine = true)
                    OutlinedTextField(vol, { vol = it.filter { c -> c.isDigit() } }, label = { Text("Media Volume %") }, singleLine = true)
                }
            },
            confirmButton = {
                Button(onClick = {
                    val v = vol.toIntOrNull()?.coerceIn(0, 100) ?: 70
                    val safeApp = appToOpen.replace("\"", "")
                    val steps = "[{\"tool\":\"set_media_volume\",\"args\":{\"percent\":$v}},{\"tool\":\"open_app\",\"args\":{\"app_name\":\"$safeApp\"}}]"
                    onAddRoutine(name.ifBlank { "Quick Launch" }, trigger.ifBlank { "quick launch" }, "Vol $v% • Open $safeApp", steps)
                    showCreate = false
                }) { Text("Save") }
            },
            dismissButton = { TextButton(onClick = { showCreate = false }) { Text("Cancel") } }
        )
    }
}
