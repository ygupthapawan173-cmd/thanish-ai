package com.example.ui

import android.app.Application
import android.graphics.Bitmap
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.ai.ConnectionDiagnosticResult
import com.example.ai.GeminiLiveDuplexEngine
import com.example.ai.LiveDuplexState
import com.example.ai.PanduAiRepository
import com.example.control.AgentHudBus
import com.example.control.AgentHudState
import com.example.control.DeviceActionExecutor
import com.example.control.HapticFeedbackHelper
import com.example.control.VisionHelper
import com.example.data.AppDatabase
import com.example.data.ChatMessageEntity
import com.example.data.MemoryFact
import com.example.data.OmegaPreferences
import com.example.data.OmegaSettings
import com.example.data.VoiceRoutine
import com.example.omega.OmegaWakeService
import com.example.voice.TeluguTtsController
import com.example.voice.VoiceInputController
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

enum class OmegaScreen { HOME, LISTENING, CHAT, ROUTINES, SETTINGS }

data class PanduUiState(
    val currentScreen: OmegaScreen = OmegaScreen.HOME,
    val settings: OmegaSettings = OmegaSettings(),
    val messages: List<ChatMessageEntity> = emptyList(),
    val memories: List<MemoryFact> = emptyList(),
    val routines: List<VoiceRoutine> = emptyList(),
    val isListening: Boolean = false,
    val isThinking: Boolean = false,
    val isSpeaking: Boolean = false,
    val liveDuplexState: LiveDuplexState = LiveDuplexState(),
    val liveToolStatus: String? = null,
    val liveTranscript: String = "",
    val lastAiReply: String = "",
    val lastLatencyMs: Long = 0L,
    val batteryPercent: Int = 100,
    val audioAmplitude: Float = 0f,
    val voiceError: String? = null,
    val isTestingConnection: Boolean = false,
    val diagnosticResult: ConnectionDiagnosticResult? = null,
    val pendingWidgetCameraLaunch: Boolean = false
)

class PanduViewModel(application: Application) : AndroidViewModel(application) {

    private val appContext = application.applicationContext
    private val preferences = OmegaPreferences(appContext)
    private val database = AppDatabase(appContext)
    private val actionExecutor = DeviceActionExecutor(appContext, database)
    private val haptics = HapticFeedbackHelper(appContext)

    private val aiRepository = PanduAiRepository(
        settingsProvider = { preferences.settings.value },
        actionExecutor = actionExecutor,
        database = database
    )

    private val liveDuplex = GeminiLiveDuplexEngine(
        apiKeyProvider = { preferences.settings.value.effectiveApiKey() }
    )

    private val ttsController = TeluguTtsController(appContext)
    private var activeJob: Job? = null

    private val _uiState = MutableStateFlow(
        PanduUiState(
            settings = preferences.settings.value,
            batteryPercent = actionExecutor.getBatteryPercent()
        )
    )
    val uiState: StateFlow<PanduUiState> = _uiState.asStateFlow()

    private val voiceInput = VoiceInputController(appContext) { finalTranscript ->
        dispatchToAi(finalTranscript, isVoiceInput = true)
    }

    init {
        aiRepository.seedHistoryFromDatabase()
        refreshDbState()
        AgentHudBus.setFloatingOrbVisible(preferences.settings.value.floatingOrbEnabled)

        if (_uiState.value.messages.isEmpty()) {
            database.insertMessage(
                ChatMessageEntity(
                    text = "OMEGA 15 Pro online! Pastel Glass 3D + Live Google Search + Visual Coordinate Agent + Default Assistant ready. Tap the orb to speak.",
                    isFromUser = false
                )
            )
            refreshDbState()
        }

        viewModelScope.launch {
            preferences.settings.collect { latest ->
                ttsController.setLanguage(latest.languageTag)
                AgentHudBus.setFloatingOrbVisible(latest.floatingOrbEnabled)
                _uiState.update { it.copy(settings = latest) }
            }
        }

        viewModelScope.launch {
            voiceInput.state.collect { v ->
                _uiState.update { cur ->
                    cur.copy(
                        isListening = v.isListening,
                        liveTranscript = if (v.partialTranscript.isNotBlank()) v.partialTranscript else cur.liveTranscript,
                        audioAmplitude = v.audioAmplitude,
                        voiceError = v.errorMessage
                    )
                }
                if (v.isListening) {
                    AgentHudBus.updateState(AgentHudState.Active(v.partialTranscript.ifBlank { "Listening..." }, audioAmplitude = v.audioAmplitude))
                } else if (!_uiState.value.isThinking && !_uiState.value.liveDuplexState.isConnected) {
                    AgentHudBus.updateState(AgentHudState.Hidden)
                }
            }
        }

        viewModelScope.launch {
            liveDuplex.state.collect { ls ->
                _uiState.update { it.copy(liveDuplexState = ls) }
                if (ls.isConnected) {
                    AgentHudBus.updateState(AgentHudState.Active(ls.statusText, audioAmplitude = ls.amplitude))
                }
            }
        }

        viewModelScope.launch {
            ttsController.isSpeaking.collect { speaking -> _uiState.update { it.copy(isSpeaking = speaking) } }
        }

        viewModelScope.launch {
            AgentHudBus.abortSignal.collect { stopAllActivity() }
        }

        viewModelScope.launch {
            AgentHudBus.wakeTriggers.collect { cmd ->
                if (cmd.isNotBlank()) handleInlineWakeCommand(cmd) else startVoiceListening()
            }
        }
    }

    private fun refreshDbState() {
        _uiState.update {
            it.copy(
                messages = database.getRecentMessages(80),
                memories = database.getAllMemories(),
                routines = database.getAllRoutines(),
                batteryPercent = actionExecutor.getBatteryPercent()
            )
        }
    }

    fun requestCameraLaunchFromWidget() {
        _uiState.update { it.copy(pendingWidgetCameraLaunch = true) }
    }

    fun consumeWidgetCameraLaunch() {
        _uiState.update { it.copy(pendingWidgetCameraLaunch = false) }
    }

    fun navigateTo(screen: OmegaScreen) {
        haptics.softTap()
        if (screen != OmegaScreen.LISTENING) {
            voiceInput.stopListening()
            if (_uiState.value.liveDuplexState.isConnected || _uiState.value.liveDuplexState.isConnecting) {
                liveDuplex.disconnect()
            }
        }
        _uiState.update { it.copy(currentScreen = screen, voiceError = null, batteryPercent = actionExecutor.getBatteryPercent()) }
    }

    fun updateSettings(transform: (OmegaSettings) -> OmegaSettings) {
        preferences.update(transform)
    }

    fun setWakeWordEnabled(enabled: Boolean) {
        preferences.update { it.copy(wakeWordEnabled = enabled) }
        if (enabled) OmegaWakeService.start(appContext) else OmegaWakeService.stop(appContext)
    }

    fun runConnectionTest() {
        viewModelScope.launch {
            _uiState.update { it.copy(isTestingConnection = true, diagnosticResult = null) }
            val result = aiRepository.runConnectionDiagnostic()
            _uiState.update { it.copy(isTestingConnection = false, diagnosticResult = result) }
        }
    }

    fun startVoiceListening() {
        haptics.wakePulse()
        ttsController.stop()
        _uiState.update { it.copy(currentScreen = OmegaScreen.LISTENING, liveTranscript = "", liveToolStatus = null, voiceError = null) }
        if (_uiState.value.settings.useGeminiLiveAudio) liveDuplex.connect()
        else voiceInput.startListening(_uiState.value.settings.languageTag)
    }

    fun stopVoiceListening() {
        haptics.softTap()
        if (_uiState.value.settings.useGeminiLiveAudio) liveDuplex.disconnect() else voiceInput.stopListening()
    }

    fun toggleLiveDuplexMode() {
        val next = !_uiState.value.settings.useGeminiLiveAudio
        stopAllActivity()
        preferences.update { it.copy(useGeminiLiveAudio = next) }
    }

    fun toggleAutoSpeak() {
        val next = !_uiState.value.settings.autoSpeak
        if (!next) ttsController.stop()
        preferences.update { it.copy(autoSpeak = next) }
    }

    fun setVoiceLanguage(tag: String) {
        preferences.update { it.copy(languageTag = tag) }
    }

    fun handleInlineWakeCommand(command: String) {
        haptics.wakePulse()
        ttsController.stop()
        _uiState.update { it.copy(currentScreen = OmegaScreen.LISTENING, liveTranscript = command, voiceError = null) }
        dispatchToAi(command, isVoiceInput = true)
    }

    fun analyzeCameraBitmap(bitmap: Bitmap, prompt: String = "Describe what you see in this image and read any text.") {
        val b64 = VisionHelper.bitmapToBase64Jpeg(bitmap)
        _uiState.update { it.copy(currentScreen = OmegaScreen.CHAT) }
        dispatchToAi(prompt, isVoiceInput = false, imageBase64 = b64)
    }

    fun sendTextPrompt(prompt: String, openChat: Boolean = true) {
        val trimmed = prompt.trim()
        if (trimmed.isEmpty()) return
        haptics.softTap()
        ttsController.stop()
        if (openChat) _uiState.update { it.copy(currentScreen = OmegaScreen.CHAT) }
        dispatchToAi(trimmed, isVoiceInput = false)
    }

    fun runRoutineByName(name: String) {
        val match = database.findRoutineByNameOrTrigger(name) ?: return
        runRoutineNow(match)
    }

    fun runRoutineNow(routine: VoiceRoutine) {
        haptics.wakePulse()
        viewModelScope.launch {
            _uiState.update { it.copy(isThinking = true, liveToolStatus = "Running ${routine.name}...") }
            val summary = actionExecutor.executeRoutineByName(routine.name) { st -> _uiState.update { it.copy(liveToolStatus = st) } }
            database.insertMessage(ChatMessageEntity(text = summary, isFromUser = false, executedTools = listOf("routine:${routine.name}")))
            refreshDbState()
            _uiState.update { it.copy(isThinking = false, liveToolStatus = null, lastAiReply = summary) }
            AgentHudBus.updateState(AgentHudState.Hidden)
            if (_uiState.value.settings.autoSpeak) ttsController.speak(summary)
        }
    }

    fun saveCustomRoutine(name: String, trigger: String, summary: String, stepsJson: String) {
        if (name.isBlank() || trigger.isBlank()) return
        database.saveRoutine(VoiceRoutine(name = name, triggerPhrase = trigger, actionsSummary = summary, stepsJson = stepsJson))
        refreshDbState()
    }

    fun deleteRoutine(id: Long) { database.deleteRoutine(id); refreshDbState() }
    fun deleteMemory(key: String) { database.deleteMemory(key); refreshDbState() }
    fun speakMessage(text: String) { ttsController.speak(text) }

    fun clearChatHistory() {
        aiRepository.clearHistory()
        database.clearMessages()
        database.insertMessage(ChatMessageEntity(text = "Chat cleared. Long-term memories remain saved.", isFromUser = false))
        refreshDbState()
        _uiState.update { it.copy(lastAiReply = "") }
    }

    fun stopAllActivity() {
        haptics.abortPulse()
        voiceInput.stopListening()
        liveDuplex.disconnect()
        ttsController.stop()
        activeJob?.cancel(); activeJob = null
        _uiState.update { it.copy(isThinking = false, isListening = false, liveToolStatus = null, audioAmplitude = 0f) }
        AgentHudBus.updateState(AgentHudState.Hidden)
    }

    private fun dispatchToAi(prompt: String, isVoiceInput: Boolean, imageBase64: String? = null) {
        val dur = String.format("0:%02d", (prompt.split(" ").size / 2).coerceIn(2, 59))
        database.insertMessage(
            ChatMessageEntity(text = prompt, isFromUser = true, isVoiceInput = isVoiceInput, audioDuration = dur, hasImageAttachment = imageBase64 != null)
        )
        refreshDbState()
        _uiState.update { it.copy(isThinking = true, liveToolStatus = null, voiceError = null) }
        AgentHudBus.updateState(AgentHudState.Active(if (imageBase64 != null) "Analyzing image..." else "OMEGA 15 Pro thinking...", isThinking = true, audioAmplitude = 0.45f))

        activeJob?.cancel()
        activeJob = viewModelScope.launch {
            val res = aiRepository.sendMessage(prompt, imageBase64) { status -> _uiState.update { it.copy(liveToolStatus = status) } }
            res.onSuccess { reply ->
                database.insertMessage(ChatMessageEntity(text = reply.replyText, isFromUser = false, executedTools = reply.executedTools))
                refreshDbState()
                _uiState.update { it.copy(isThinking = false, liveToolStatus = null, lastAiReply = reply.replyText, lastLatencyMs = reply.latencyMs) }
                if (_uiState.value.settings.autoSpeak && _uiState.value.currentScreen == OmegaScreen.LISTENING) {
                    ttsController.speak(reply.replyText)
                }
            }.onFailure { err ->
                val msg = err.message ?: "Request failed."
                database.insertMessage(ChatMessageEntity(text = msg, isFromUser = false, isError = true))
                refreshDbState()
                _uiState.update { it.copy(isThinking = false, liveToolStatus = null, voiceError = msg) }
            }
            AgentHudBus.updateState(AgentHudState.Hidden)
        }
    }

    override fun onCleared() {
        voiceInput.release(); liveDuplex.release(); ttsController.release(); database.close()
        super.onCleared()
    }
}
