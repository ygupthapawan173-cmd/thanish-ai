package com.example.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.example.ai.ConnectionDiagnosticResult
import com.example.control.BiometricSafetyGate
import com.example.control.PanduAccessibilityService
import com.example.data.AiProvider
import com.example.data.OmegaSettings
import com.example.data.OmegaVisualTheme
import com.example.ui.theme.OmegaAuraBackdrop
import com.example.ui.theme.OmegaColors
import com.example.ui.theme.mutedText
import com.example.ui.theme.omegaGlassCard
import com.example.ui.theme.primaryText

@Composable
fun SettingsScreen(
    settings: OmegaSettings,
    isTestingConnection: Boolean,
    diagnosticResult: ConnectionDiagnosticResult?,
    onBack: () -> Unit,
    onSaveSettings: ((OmegaSettings) -> OmegaSettings) -> Unit,
    onRunConnectionTest: () -> Unit,
    onToggleWakeService: (Boolean) -> Unit,
    onClearHistory: () -> Unit
) {
    val context = LocalContext.current
    val theme = settings.visualTheme

    var apiKeyDraft by remember(settings.apiKey) { mutableStateOf(settings.apiKey) }
    var modelDraft by remember(settings.modelId) { mutableStateOf(settings.modelId) }
    var wakeWordDraft by remember(settings.wakeWord) { mutableStateOf(settings.wakeWord) }
    var userNameDraft by remember(settings.userName) { mutableStateOf(settings.userName) }
    var showKey by remember { mutableStateOf(false) }
    var savedBanner by remember { mutableStateOf(false) }
    var biometricNote by remember { mutableStateOf<String?>(null) }

    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {}

    val hasMic = ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
    val hasContacts = ContextCompat.checkSelfPermission(context, Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED
    val hasCamera = ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
    val hasAcc = PanduAccessibilityService.instance != null
    val hasNotif = NotificationManagerCompat.getEnabledListenerPackages(context).contains(context.packageName)

    OmegaAuraBackdrop(theme = theme) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(horizontal = 18.dp, vertical = 12.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                GlassCircleButton(Icons.AutoMirrored.Rounded.ArrowBack, theme = theme, onClick = onBack)
                Text("OMEGA 15 Pro Settings", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                Spacer(modifier = Modifier.size(42.dp))
            }

            // Visual Theme & Parallax Engine
            Column(modifier = Modifier.fillMaxWidth().omegaGlassCard(22.dp, theme).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("UI Interface & 3D Engine", fontWeight = FontWeight.SemiBold, color = theme.primaryText(), fontSize = 15.sp)
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    SelectChip(
                        label = "Pastel Glass (3D)",
                        selected = theme == OmegaVisualTheme.PASTEL_GLASS_3D,
                        modifier = Modifier.weight(1f),
                        onClick = { onSaveSettings { it.copy(visualTheme = OmegaVisualTheme.PASTEL_GLASS_3D) } }
                    )
                    SelectChip(
                        label = "Cyber Horizon (WebGL)",
                        selected = theme == OmegaVisualTheme.CYBER_HORIZON_WEBGL,
                        modifier = Modifier.weight(1f),
                        onClick = { onSaveSettings { it.copy(visualTheme = OmegaVisualTheme.CYBER_HORIZON_WEBGL) } }
                    )
                }
                SwitchRow(theme, "Gyroscope 3D Hologram Parallax", "Tilt phone for subtle 3D orb depth", settings.gyroscopeParallax) { on ->
                    onSaveSettings { it.copy(gyroscopeParallax = on) }
                }
            }

            // AI Provider & Live Diagnostic
            Column(modifier = Modifier.fillMaxWidth().omegaGlassCard(22.dp, theme).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("AI Provider & Connection Diagnostic", fontWeight = FontWeight.SemiBold, color = theme.primaryText(), fontSize = 15.sp)

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    AiProvider.entries.forEach { p ->
                        SelectChip(
                            label = p.name,
                            selected = settings.provider == p,
                            modifier = Modifier.weight(1f),
                            onClick = {
                                modelDraft = p.defaultModel
                                onSaveSettings { it.copy(provider = p, modelId = p.defaultModel) }
                            }
                        )
                    }
                }

                OutlinedTextField(userNameDraft, { userNameDraft = it; savedBanner = false }, label = { Text("Your Name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(
                    value = apiKeyDraft,
                    onValueChange = { apiKeyDraft = it; savedBanner = false },
                    label = { Text("${settings.provider.displayName} API Key") },
                    singleLine = true,
                    visualTransformation = if (showKey) VisualTransformation.None else PasswordVisualTransformation(),
                    trailingIcon = {
                        IconButton(onClick = { showKey = !showKey }) {
                            Icon(if (showKey) Icons.Rounded.VisibilityOff else Icons.Rounded.Visibility, contentDescription = null)
                        }
                    },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(modelDraft, { modelDraft = it; savedBanner = false }, label = { Text("Model ID (Default: ${settings.provider.defaultModel})") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(wakeWordDraft, { wakeWordDraft = it; savedBanner = false }, label = { Text("Custom Wake Word") }, singleLine = true, modifier = Modifier.fillMaxWidth())

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(
                        onClick = {
                            onSaveSettings { it.copy(userName = userNameDraft, apiKey = apiKeyDraft, modelId = modelDraft, wakeWord = wakeWordDraft) }
                            savedBanner = true
                        },
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = OmegaColors.AudioPillDark),
                        modifier = Modifier.weight(1f)
                    ) { Text(if (savedBanner) "Saved!" else "Save", color = Color.White) }

                    Button(
                        onClick = {
                            onSaveSettings { it.copy(userName = userNameDraft, apiKey = apiKeyDraft, modelId = modelDraft, wakeWord = wakeWordDraft) }
                            onRunConnectionTest()
                        },
                        enabled = !isTestingConnection,
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0EA5E9)),
                        modifier = Modifier.weight(1f)
                    ) { Text(if (isTestingConnection) "Testing..." else "Test Connection", color = Color.White) }
                }

                if (diagnosticResult != null) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .background(if (diagnosticResult.isSuccess) Color(0x3322C55E) else Color(0x33EF4444))
                            .padding(12.dp)
                    ) {
                        Text(
                            text = diagnosticResult.summary,
                            color = if (diagnosticResult.isSuccess) Color(0xFF16A34A) else Color(0xFFEF4444),
                            fontSize = 12.5.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }

            // Pro Capabilities (v11-v15)
            Column(modifier = Modifier.fillMaxWidth().omegaGlassCard(22.dp, theme).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("15 Pro Capabilities", fontWeight = FontWeight.SemiBold, color = theme.primaryText(), fontSize = 15.sp)

                SwitchRow(theme, "Live Google Search Grounding (v12)", "Real-time weather, scores & web answers", settings.webSearchGrounding) { on ->
                    onSaveSettings { it.copy(webSearchGrounding = on) }
                }
                SwitchRow(theme, "Silent Energy-Gated Wake Service", "Listen for \"${settings.wakeWord}\" in background", settings.wakeWordEnabled) { on ->
                    if (on && !hasMic) {
                        val p = buildList {
                            add(Manifest.permission.RECORD_AUDIO)
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) add(Manifest.permission.POST_NOTIFICATIONS)
                        }.toTypedArray()
                        permLauncher.launch(p)
                    } else onToggleWakeService(on)
                }
                SwitchRow(theme, "Gemini Live Duplex Audio (WS)", "Zero-delay streaming voice call mode", settings.useGeminiLiveAudio) { on ->
                    onSaveSettings { it.copy(useGeminiLiveAudio = on) }
                }
                SwitchRow(theme, "Draggable Floating Mini-Orb", "Float quick-wake orb over any app", settings.floatingOrbEnabled) { on ->
                    onSaveSettings { it.copy(floatingOrbEnabled = on) }
                }
                SwitchRow(theme, "Biometric Safety Lock (v14)", "Require fingerprint/face before sensitive actions", settings.biometricSafetyLock) { on ->
                    if (on) {
                        BiometricSafetyGate.authenticate(
                            context = context,
                            onSuccess = {
                                biometricNote = "Biometric Lock enabled."
                                onSaveSettings { it.copy(biometricSafetyLock = true) }
                            },
                            onError = { err -> biometricNote = err }
                        )
                    } else {
                        onSaveSettings { it.copy(biometricSafetyLock = false) }
                        biometricNote = null
                    }
                }
                if (biometricNote != null) {
                    Text(biometricNote!!, color = theme.mutedText(), fontSize = 11.5.sp)
                }
                SwitchRow(theme, "Auto-Speak Replies (TTS)", "Speak Gemini replies automatically", settings.autoSpeak) { on ->
                    onSaveSettings { it.copy(autoSpeak = on) }
                }

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    SelectChip("English (IN)", settings.languageTag == "en-IN", Modifier.weight(1f)) { onSaveSettings { it.copy(languageTag = "en-IN") } }
                    SelectChip("తెలుగు (TE)", settings.languageTag == "te-IN", Modifier.weight(1f)) { onSaveSettings { it.copy(languageTag = "te-IN") } }
                }
            }

            // Permissions & Default Assistant (v11 Pro)
            Column(modifier = Modifier.fillMaxWidth().omegaGlassCard(22.dp, theme).padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Permissions & Default Assistant", fontWeight = FontWeight.SemiBold, color = theme.primaryText(), fontSize = 15.sp)
                PermRow(theme, "Set as Default Phone Assistant (Power Btn)", false) {
                    context.startActivity(Intent(Settings.ACTION_VOICE_INPUT_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                }
                PermRow(theme, "Accessibility (HUD, Visual Taps & Vision)", hasAcc) {
                    context.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                }
                PermRow(theme, "Notification Reader (WhatsApp/SMS)", hasNotif) {
                    context.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                }
                PermRow(theme, "Mic, Contacts, Camera & Call", hasMic && hasContacts && hasCamera) {
                    val p = buildList {
                        add(Manifest.permission.RECORD_AUDIO)
                        add(Manifest.permission.READ_CONTACTS)
                        add(Manifest.permission.CAMERA)
                        add(Manifest.permission.CALL_PHONE)
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) add(Manifest.permission.POST_NOTIFICATIONS)
                    }.toTypedArray()
                    permLauncher.launch(p)
                }
            }

            OutlinedButton(onClick = onClearHistory, shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
                Text("Clear Chat History", color = theme.primaryText())
            }
        }
    }
}

@Composable
private fun SwitchRow(theme: OmegaVisualTheme, title: String, sub: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Column(modifier = Modifier.weight(1f).padding(end = 8.dp)) {
            Text(title, color = theme.primaryText(), fontWeight = FontWeight.Medium, fontSize = 14.sp)
            Text(sub, color = theme.mutedText(), fontSize = 12.sp)
        }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun SelectChip(label: String, selected: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(if (selected) OmegaColors.AudioPillDark else Color.White.copy(0.68f))
            .clickable { onClick() }
            .padding(vertical = 9.dp, horizontal = 4.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(label, color = if (selected) Color.White else OmegaColors.TextDark, fontWeight = FontWeight.Medium, fontSize = 11.5.sp, maxLines = 1)
    }
}

@Composable
private fun PermRow(theme: OmegaVisualTheme, title: String, granted: Boolean, onClick: () -> Unit) {
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.weight(1f)) {
            Icon(if (granted) Icons.Rounded.CheckCircle else Icons.Rounded.ErrorOutline, null, tint = if (granted) Color(0xFF22C55E) else Color(0xFFEF4444), modifier = Modifier.size(18.dp))
            Text(title, color = theme.primaryText(), fontSize = 13.sp)
        }
        TextButton(onClick = onClick) { Text(if (granted) "Active" else "Open", fontWeight = FontWeight.SemiBold) }
    }
}
