package com.example.ui.theme

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.data.OmegaVisualTheme
import kotlin.math.cos
import kotlin.math.sin

object OmegaColors {
    val CyberBgTop = Color(0xFF030712)
    val CyberBgMid = Color(0xFF09142B)
    val CyberBgBottom = Color(0xFF040916)
    val CyberCyan = Color(0xFF00F0FF)

    val LavenderTop = Color(0xFFAFA9FA)
    val PeriwinkleMid = Color(0xFFD9DDFF)
    val SoftWhiteGlow = Color(0xFFF4F6FF)
    val LavenderBottom = Color(0xFFC4C0FA)

    val TextDark = Color(0xFF1E2132)
    val TextMuted = Color(0xFF5A5F78)
    val AudioPillDark = Color(0xFF14151B)

    val OrbCyan = Color(0xFF8EF1FF)
    val OrbPink = Color(0xFFF6A4E8)
    val OrbViolet = Color(0xFFA29BFF)
}

fun OmegaVisualTheme.isDark(): Boolean = this == OmegaVisualTheme.CYBER_HORIZON_WEBGL
fun OmegaVisualTheme.primaryText(): Color = if (isDark()) Color(0xFFE6F4FF) else OmegaColors.TextDark
fun OmegaVisualTheme.mutedText(): Color = if (isDark()) Color(0xFF8EA7C6) else OmegaColors.TextMuted

fun Modifier.omegaBackground(theme: OmegaVisualTheme): Modifier = this.background(
    brush = if (theme.isDark()) {
        Brush.linearGradient(
            listOf(OmegaColors.CyberBgTop, OmegaColors.CyberBgMid, OmegaColors.CyberBgBottom),
            Offset(0f, 0f), Offset(900f, 1900f)
        )
    } else {
        Brush.linearGradient(
            listOf(OmegaColors.LavenderTop, OmegaColors.PeriwinkleMid, OmegaColors.SoftWhiteGlow, OmegaColors.LavenderBottom),
            Offset(0f, 0f), Offset(900f, 1900f)
        )
    }
)

/**
 * Animated ambient pastel / cyber aura mesh backdrop (v15 Pro).
 */
@Composable
fun OmegaAuraBackdrop(
    theme: OmegaVisualTheme,
    modifier: Modifier = Modifier,
    content: @Composable BoxScope.() -> Unit
) {
    val inf = rememberInfiniteTransition(label = "auraMesh")
    val phase by inf.animateFloat(
        initialValue = 0f,
        targetValue = (2 * Math.PI).toFloat(),
        animationSpec = infiniteRepeatable(tween(14000, easing = LinearEasing)),
        label = "auraPhase"
    )

    Box(modifier = modifier.fillMaxSize().omegaBackground(theme)) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            val c1 = Offset(w * (0.22f + 0.08f * cos(phase)), h * (0.18f + 0.05f * sin(phase)))
            val c2 = Offset(w * (0.82f + 0.08f * sin(phase)), h * (0.76f + 0.05f * cos(phase)))

            drawCircle(
                brush = Brush.radialGradient(
                    colors = if (theme.isDark()) {
                        listOf(OmegaColors.CyberCyan.copy(alpha = 0.16f), Color.Transparent)
                    } else {
                        listOf(Color.White.copy(alpha = 0.55f), Color.Transparent)
                    },
                    center = c1,
                    radius = w * 0.72f
                ),
                center = c1,
                radius = w * 0.72f
            )
            drawCircle(
                brush = Brush.radialGradient(
                    colors = if (theme.isDark()) {
                        listOf(Color(0xFF7C3AED).copy(alpha = 0.22f), Color.Transparent)
                    } else {
                        listOf(OmegaColors.OrbPink.copy(alpha = 0.28f), Color.Transparent)
                    },
                    center = c2,
                    radius = w * 0.68f
                ),
                center = c2,
                radius = w * 0.68f
            )
        }
        content()
    }
}

fun Modifier.omegaGlassCard(cornerRadius: Dp = 24.dp, theme: OmegaVisualTheme): Modifier = this
    .clip(RoundedCornerShape(cornerRadius))
    .background(if (theme.isDark()) Color(0xB80E1B33) else Color.White.copy(alpha = 0.58f))
    .border(
        width = 1.dp,
        color = if (theme.isDark()) OmegaColors.CyberCyan.copy(alpha = 0.35f) else Color.White.copy(alpha = 0.85f),
        shape = RoundedCornerShape(cornerRadius)
    )
