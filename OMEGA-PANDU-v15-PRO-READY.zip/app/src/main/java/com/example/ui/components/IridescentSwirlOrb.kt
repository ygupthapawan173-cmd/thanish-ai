package com.example.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.ui.theme.OmegaColors
import kotlin.math.sin

@Composable
fun IridescentSwirlOrb(
    size: Dp = 175.dp,
    isListening: Boolean = false,
    audioAmplitude: Float = 0f,
    cyberMode: Boolean = false,
    modifier: Modifier = Modifier
) {
    val infinite = rememberInfiniteTransition(label = "orbAnim")
    val smoothAmp by animateFloatAsState(audioAmplitude.coerceIn(0f, 1f), spring(stiffness = Spring.StiffnessMediumLow), label = "amp")
    val rotation by infinite.animateFloat(0f, 360f, infiniteRepeatable(tween(if (isListening) 5200 else 13500, easing = LinearEasing)), label = "rot")
    val idlePulse by infinite.animateFloat(0.97f, 1.03f, infiniteRepeatable(tween(2100, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "pulse")
    val waveShift by infinite.animateFloat(0f, (2 * Math.PI).toFloat(), infiniteRepeatable(tween(2900, easing = LinearEasing)), label = "wave")

    val scale = if (isListening) 1f + smoothAmp * 0.14f else idlePulse

    Canvas(
        modifier = modifier
            .size(size * scale)
            .shadow(
                elevation = (22 + smoothAmp * 14).dp,
                shape = CircleShape,
                ambientColor = if (cyberMode) OmegaColors.CyberCyan else OmegaColors.OrbViolet,
                spotColor = if (cyberMode) Color(0xFF3B82F6) else OmegaColors.OrbPink
            )
            .clip(CircleShape)
    ) {
        val radius = this.size.minDimension / 2f
        val center = Offset(this.size.width / 2f, this.size.height / 2f)
        val baseColors = if (cyberMode) {
            listOf(Color(0xFFCFFAFE), Color(0xFF00F0FF), Color(0xFF2563EB), Color(0xFF0F172A))
        } else {
            listOf(Color(0xFFEEFCFF), OmegaColors.OrbCyan, OmegaColors.OrbViolet, OmegaColors.OrbPink)
        }
        drawCircle(Brush.radialGradient(baseColors, Offset(center.x - radius * 0.25f, center.y - radius * 0.25f), radius * 1.38f))

        rotate(-30f + rotation * 0.12f, center) {
            val stripes = 10
            val spacing = this.size.height / (stripes - 1)
            val intensity = 9f + smoothAmp * 16f
            for (i in -1..stripes) {
                val y = i * spacing
                val off = sin(waveShift + i * 0.62f) * intensity
                val path = Path().apply {
                    moveTo(-radius * 0.4f, y + off)
                    cubicTo(center.x * 0.48f, y - 28f + off, center.x * 1.52f, y + 28f - off, this@Canvas.size.width + radius * 0.4f, y + off)
                }
                drawPath(
                    path,
                    Brush.horizontalGradient(
                        if (cyberMode) listOf(Color(0xFF00F0FF).copy(0.55f), Color(0xFF3B82F6).copy(0.65f), Color(0xFF8B5CF6).copy(0.52f))
                        else listOf(Color(0xFF7B7FE8).copy(0.44f), Color(0xFFEF8FE6).copy(0.58f), Color(0xFF67DCF5).copy(0.52f))
                    ),
                    style = Stroke(spacing * 0.54f, cap = StrokeCap.Round)
                )
                drawPath(
                    path,
                    Brush.horizontalGradient(listOf(Color.White.copy(0.82f), OmegaColors.OrbCyan.copy(0.88f), Color.White.copy(0.7f))),
                    style = Stroke(spacing * 0.21f, cap = StrokeCap.Round)
                )
            }
        }
        drawCircle(Brush.radialGradient(listOf(Color.Transparent, Color.Transparent, Color(0xFF4F46E5).copy(0.28f)), center, radius))
        drawCircle(Brush.radialGradient(listOf(Color.White.copy(0.62f), Color.Transparent), Offset(center.x - radius * 0.36f, center.y - radius * 0.38f), radius * 0.55f))
    }
}
