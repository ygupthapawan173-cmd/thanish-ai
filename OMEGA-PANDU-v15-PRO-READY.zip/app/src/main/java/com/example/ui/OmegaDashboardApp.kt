package com.example.ui

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.Send
import androidx.compose.material.icons.automirrored.rounded.VolumeOff
import androidx.compose.material.icons.automirrored.rounded.VolumeUp
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.data.OmegaVisualTheme
import com.example.ui.components.IridescentSwirlOrb
import com.example.ui.components.OmegaHorizonOrb
import com.example.ui.components.rememberParallaxOffset
import com.example.ui.theme.OmegaAuraBackdrop
import com.example.ui.theme.OmegaColors
import com.example.ui.theme.isDark
import com.example.ui.theme.mutedText
import com.example.ui.theme.omegaGlassCard
import com.example.ui.theme.primaryText

@Composable
fun OmegaDashboardApp(viewModel: PanduViewModel) {
    val uiState by viewModel.uiState.collectAsState()
    val context = LocalContext.current
    val theme = uiState.settings.visualTheme

    val micLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) viewModel.startVoiceListening()
    }
    val camPreview = rememberLauncherForActivityResult(ActivityResultContracts.TakePicturePreview()) { bmp ->
        if (bmp != null) viewModel.analyzeCameraBitmap(bmp)
    }
    val camPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) camPreview.launch(null)
    }

    fun launchVoice() {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            viewModel.startVoiceListening()
        } else micLauncher.launch(Manifest.permission.RECORD_AUDIO)
    }

    fun launchCamera() {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            camPreview.launch(null)
        } else camPerm.launch(Manifest.permission.CAMERA)
    }

    LaunchedEffect(uiState.pendingWidgetCameraLaunch) {
        if (uiState.pendingWidgetCameraLaunch) {
            viewModel.consumeWidgetCameraLaunch()
            launchCamera()
        }
    }

    Crossfade(targetState = uiState.currentScreen, label = "nav") { screen ->
        when (screen) {
            OmegaScreen.HOME -> HomeScreen(
                uiState = uiState,
                onVoiceClick = { launchVoice() },
                onChatClick = { viewModel.navigateTo(OmegaScreen.CHAT) },
                onRoutinesClick = { viewModel.navigateTo(OmegaScreen.ROUTINES) },
                onCameraClick = { launchCamera() },
                onSettingsClick = { viewModel.navigateTo(OmegaScreen.SETTINGS) },
                onQuickPrompt = { viewModel.sendTextPrompt(it, openChat = true) }
            )
            OmegaScreen.LISTENING -> ListeningScreen(
                uiState = uiState,
                onBack = { viewModel.stopAllActivity(); viewModel.navigateTo(OmegaScreen.HOME) },
                onChat = { viewModel.navigateTo(OmegaScreen.CHAT) },
                onToggleMic = {
                    if (uiState.isListening || uiState.liveDuplexState.isConnected) viewModel.stopVoiceListening()
                    else launchVoice()
                },
                onToggleLang = { viewModel.setVoiceLanguage(if (uiState.settings.languageTag == "en-IN") "te-IN" else "en-IN") },
                onToggleAutoSpeak = { viewModel.toggleAutoSpeak() },
                onToggleLiveMode = { viewModel.toggleLiveDuplexMode() }
            )
            OmegaScreen.CHAT -> ChatScreen(
                uiState = uiState,
                onBack = { viewModel.navigateTo(OmegaScreen.HOME) },
                onMic = { launchVoice() },
                onCamera = { launchCamera() },
                onSend = { viewModel.sendTextPrompt(it, openChat = false) },
                onSpeak = { viewModel.speakMessage(it) }
            )
            OmegaScreen.ROUTINES -> RoutinesAndMemoryScreen(
                theme = theme,
                routines = uiState.routines,
                memories = uiState.memories,
                onBack = { viewModel.navigateTo(OmegaScreen.HOME) },
                onRunRoutine = { viewModel.runRoutineNow(it) },
                onAddRoutine = { n, t, s, j -> viewModel.saveCustomRoutine(n, t, s, j) },
                onDeleteRoutine = { viewModel.deleteRoutine(it) },
                onDeleteMemory = { viewModel.deleteMemory(it) }
            )
            OmegaScreen.SETTINGS -> SettingsScreen(
                settings = uiState.settings,
                isTestingConnection = uiState.isTestingConnection,
                diagnosticResult = uiState.diagnosticResult,
                onBack = { viewModel.navigateTo(OmegaScreen.HOME) },
                onSaveSettings = { viewModel.updateSettings(it) },
                onRunConnectionTest = { viewModel.runConnectionTest() },
                onToggleWakeService = { viewModel.setWakeWordEnabled(it) },
                onClearHistory = { viewModel.clearChatHistory() }
            )
        }
    }
}

@Composable
private fun AdaptiveCentralOrb(
    theme: OmegaVisualTheme,
    orbState: String,
    audioLevel: Float,
    size: Dp,
    parallaxEnabled: Boolean,
    onClick: () -> Unit
) {
    val tilt by rememberParallaxOffset(enabled = parallaxEnabled, maxDpShift = 12f)
    Box(
        modifier = Modifier
            .offset(x = tilt.x.dp, y = tilt.y.dp)
            .clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        if (theme == OmegaVisualTheme.CYBER_HORIZON_WEBGL) {
            OmegaHorizonOrb(orbState = orbState, audioLevel = audioLevel, size = size)
        } else {
            IridescentSwirlOrb(
                size = size,
                isListening = orbState == "listening" || orbState == "thinking" || orbState == "speaking",
                audioAmplitude = audioLevel,
                cyberMode = false
            )
        }
    }
}

// ------------------------------------------------------------
// SCREEN 1: PASTEL GLASSMORPHISM 15 PRO HOME DASHBOARD
// ------------------------------------------------------------
@Composable
private fun HomeScreen(
    uiState: PanduUiState,
    onVoiceClick: () -> Unit,
    onChatClick: () -> Unit,
    onRoutinesClick: () -> Unit,
    onCameraClick: () -> Unit,
    onSettingsClick: () -> Unit,
    onQuickPrompt: (String) -> Unit
) {
    val theme = uiState.settings.visualTheme
    var promptText by remember { mutableStateOf("") }

    OmegaAuraBackdrop(theme = theme) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(horizontal = 20.dp, vertical = 14.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Top Bar: Avatar + Pro Telemetry Pill + Settings/Routines
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Box(
                        modifier = Modifier
                            .size(42.dp)
                            .clip(CircleShape)
                            .background(if (theme.isDark()) Color(0xFF1E293B) else Color.White.copy(0.85f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Rounded.Person, "Profile", tint = theme.primaryText())
                    }
                    Box(modifier = Modifier.omegaGlassCard(16.dp, theme).padding(horizontal = 10.dp, vertical = 5.dp)) {
                        val latText = if (uiState.lastLatencyMs > 0) "${uiState.lastLatencyMs}ms" else "15 Pro"
                        Text(
                            text = "$latText • ${uiState.batteryPercent}%",
                            color = theme.primaryText(),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    GlassCircleButton(Icons.Rounded.AutoFixHigh, theme = theme, onClick = onRoutinesClick)
                    GlassCircleButton(Icons.Rounded.Settings, theme = theme, onClick = onSettingsClick)
                }
            }

            Spacer(modifier = Modifier.height(14.dp))
            Text("Hi ${uiState.settings.userName},", fontSize = 28.sp, fontWeight = FontWeight.SemiBold, color = Color.White)
            Spacer(modifier = Modifier.height(5.dp))
            Text(
                text = "Ask any question you have – your OMEGA 15 Pro\nAI voice assistant is always listening.",
                fontSize = 12.5.sp,
                color = Color.White.copy(0.92f),
                textAlign = TextAlign.Center,
                lineHeight = 18.sp
            )

            Spacer(modifier = Modifier.height(16.dp))
            AdaptiveCentralOrb(
                theme = theme,
                orbState = "idle",
                audioLevel = 0.1f,
                size = 172.dp,
                parallaxEnabled = uiState.settings.gyroscopeParallax,
                onClick = onVoiceClick
            )
            Spacer(modifier = Modifier.height(18.dp))

            // Exact 2x2 Frosted Glass Action Grid matching reference UI
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                ActionTile(
                    theme = theme,
                    icon = Icons.Rounded.Mic,
                    title = if (uiState.settings.useGeminiLiveAudio) "Gemini\nLive Call" else "Voice\nChat AI",
                    modifier = Modifier.weight(1f),
                    onClick = onVoiceClick
                )
                ActionTile(
                    theme = theme,
                    icon = Icons.Rounded.ChatBubbleOutline,
                    title = "Chat\nwith AI",
                    modifier = Modifier.weight(1f),
                    onClick = onChatClick
                )
            }
            Spacer(modifier = Modifier.height(14.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                ActionTile(
                    theme = theme,
                    icon = Icons.Rounded.CenterFocusWeak,
                    title = "Scan and\nSearch",
                    modifier = Modifier.weight(1f),
                    onClick = onCameraClick
                )
                ActionTile(
                    theme = theme,
                    icon = Icons.Rounded.AutoAwesome,
                    title = "Voice\nRoutines",
                    modifier = Modifier.weight(1f),
                    onClick = onRoutinesClick
                )
            }

            Spacer(modifier = Modifier.weight(1f))

            // Bottom "Ask anything" Frosted Glass Bar with Mini Orb Send Trigger
            Row(
                modifier = Modifier.fillMaxWidth().omegaGlassCard(30.dp, theme).padding(horizontal = 12.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onCameraClick) {
                    Icon(Icons.Rounded.CameraAlt, "Vision", tint = theme.primaryText(), modifier = Modifier.size(20.dp))
                }
                TextField(
                    value = promptText,
                    onValueChange = { promptText = it },
                    placeholder = { Text("Ask anything", color = theme.mutedText(), fontSize = 14.sp) },
                    colors = TextFieldDefaults.colors(
                        focusedContainerColor = Color.Transparent, unfocusedContainerColor = Color.Transparent,
                        focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent,
                        focusedTextColor = theme.primaryText(), unfocusedTextColor = theme.primaryText()
                    ),
                    singleLine = true,
                    modifier = Modifier.weight(1f)
                )
                Box(
                    modifier = Modifier.size(42.dp).clickable {
                        if (promptText.isNotBlank()) { onQuickPrompt(promptText); promptText = "" } else onChatClick()
                    },
                    contentAlignment = Alignment.Center
                ) {
                    IridescentSwirlOrb(size = 40.dp, cyberMode = theme.isDark())
                    Icon(Icons.AutoMirrored.Rounded.Send, "Send", tint = Color.White, modifier = Modifier.size(17.dp))
                }
            }
        }
    }
}

@Composable
private fun ActionTile(theme: OmegaVisualTheme, icon: ImageVector, title: String, modifier: Modifier, onClick: () -> Unit) {
    Column(
        modifier = modifier.height(108.dp).omegaGlassCard(22.dp, theme).clickable(onClick = onClick).padding(15.dp),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Box(
            modifier = Modifier.size(34.dp).clip(CircleShape).background(if (theme.isDark()) Color(0xFF1E293B) else Color.White.copy(0.82f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, title, tint = if (theme.isDark()) OmegaColors.CyberCyan else OmegaColors.TextDark, modifier = Modifier.size(18.dp))
        }
        Text(title, fontSize = 14.sp, fontWeight = FontWeight.Medium, color = theme.primaryText(), lineHeight = 18.sp)
    }
}

// ------------------------------------------------------------
// SCREEN 2: VOICE LISTENING SCREEN
// ------------------------------------------------------------
@Composable
private fun ListeningScreen(
    uiState: PanduUiState,
    onBack: () -> Unit,
    onChat: () -> Unit,
    onToggleMic: () -> Unit,
    onToggleLang: () -> Unit,
    onToggleAutoSpeak: () -> Unit,
    onToggleLiveMode: () -> Unit
) {
    val theme = uiState.settings.visualTheme
    val isLive = uiState.settings.useGeminiLiveAudio
    val activeAmp = if (isLive) uiState.liveDuplexState.amplitude else uiState.audioAmplitude
    val isActive = if (isLive) uiState.liveDuplexState.isConnected else uiState.isListening

    val orbState = when {
        uiState.voiceError != null || uiState.liveDuplexState.error != null -> "error"
        uiState.isThinking -> "thinking"
        uiState.isSpeaking || uiState.liveDuplexState.isAiSpeaking -> "speaking"
        isActive -> "listening"
        else -> "idle"
    }

    val header = when {
        isLive -> uiState.liveDuplexState.statusText
        uiState.liveToolStatus != null -> uiState.liveToolStatus
        uiState.isListening -> "Listening..."
        uiState.isThinking -> "Thinking..."
        uiState.isSpeaking -> "Speaking..."
        else -> "Tap orb to speak"
    }

    val subtitle = when {
        isLive && uiState.liveDuplexState.error != null -> uiState.liveDuplexState.error
        isLive -> "Gemini Live Duplex WebSocket active. Speak or interrupt anytime."
        uiState.voiceError != null -> uiState.voiceError
        uiState.liveTranscript.isNotBlank() && uiState.isListening -> "\"${uiState.liveTranscript}\""
        uiState.isThinking -> uiState.liveToolStatus ?: "Processing \"${uiState.liveTranscript}\"..."
        uiState.lastAiReply.isNotBlank() -> uiState.lastAiReply
        else -> "Speak your thoughts freely — Live Search,\nDevice Control & Vision AI are ready."
    }

    OmegaAuraBackdrop(theme = theme) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(horizontal = 20.dp, vertical = 14.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                GlassCircleButton(Icons.AutoMirrored.Rounded.ArrowBack, theme = theme, onClick = onBack)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Box(modifier = Modifier.omegaGlassCard(18.dp, theme).clickable { onToggleLiveMode() }.padding(horizontal = 12.dp, vertical = 8.dp)) {
                        Text(if (isLive) "Live WS" else "Agent Pro", color = theme.primaryText(), fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    }
                    if (!isLive) {
                        Box(modifier = Modifier.omegaGlassCard(18.dp, theme).clickable { onToggleLang() }.padding(horizontal = 12.dp, vertical = 8.dp)) {
                            Text(if (uiState.settings.languageTag == "te-IN") "తెలుగు" else "EN-IN", color = theme.primaryText(), fontSize = 12.sp)
                        }
                    }
                }
                GlassCircleButton(if (uiState.settings.autoSpeak) Icons.AutoMirrored.Rounded.VolumeUp else Icons.AutoMirrored.Rounded.VolumeOff, theme = theme, onClick = onToggleAutoSpeak)
            }

            Spacer(modifier = Modifier.height(24.dp))
            Text(header, fontSize = 22.sp, fontWeight = FontWeight.SemiBold, color = Color.White, textAlign = TextAlign.Center)
            Spacer(modifier = Modifier.height(20.dp))

            AdaptiveCentralOrb(
                theme = theme,
                orbState = orbState,
                audioLevel = if (uiState.isThinking) 0.55f else activeAmp,
                size = 225.dp,
                parallaxEnabled = uiState.settings.gyroscopeParallax,
                onClick = onToggleMic
            )

            Spacer(modifier = Modifier.height(22.dp))
            Box(
                modifier = Modifier.fillMaxWidth().heightIn(min = 70.dp, max = 160.dp).omegaGlassCard(20.dp, theme).padding(16.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(subtitle, fontSize = 14.sp, color = if (orbState == "error") Color(0xFFEF4444) else theme.primaryText(), textAlign = TextAlign.Center, lineHeight = 20.sp)
            }

            Spacer(modifier = Modifier.weight(1f))
            LiveEqualizerBars(isActive = isActive || uiState.isSpeaking || uiState.liveDuplexState.isAiSpeaking, amplitude = activeAmp)
            Spacer(modifier = Modifier.height(20.dp))

            Row(modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
                GlassCircleButton(Icons.Rounded.ChatBubbleOutline, 50.dp, theme, onChat)
                Box(
                    modifier = Modifier.size(74.dp).clip(CircleShape).background(Color.White.copy(0.48f)).clickable { onToggleMic() },
                    contentAlignment = Alignment.Center
                ) {
                    Box(
                        modifier = Modifier.size(58.dp).clip(CircleShape).background(
                            Brush.linearGradient(
                                if (isActive) listOf(Color(0xFFEF4444), Color(0xFFF97316))
                                else listOf(OmegaColors.OrbCyan, OmegaColors.OrbViolet, OmegaColors.OrbPink)
                            )
                        ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(if (isActive) Icons.Rounded.Stop else Icons.Rounded.Mic, "Mic", tint = Color.White, modifier = Modifier.size(28.dp))
                    }
                }
                GlassCircleButton(Icons.Rounded.Close, 50.dp, theme, onBack)
            }
        }
    }
}

@Composable
private fun LiveEqualizerBars(isActive: Boolean, amplitude: Float) {
    val weights = listOf(0.45f, 0.85f, 0.65f, 1.0f, 0.72f, 0.5f)
    val inf = rememberInfiniteTransition(label = "eq")
    Row(horizontalArrangement = Arrangement.spacedBy(5.dp), verticalAlignment = Alignment.CenterVertically, modifier = Modifier.height(38.dp)) {
        weights.forEachIndexed { idx, w ->
            val h by inf.animateFloat(8f, if (isActive) (16f + amplitude * 24f) * w else 8f, infiniteRepeatable(tween(320 + idx * 70, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "b$idx")
            Box(modifier = Modifier.width(4.dp).height(h.coerceIn(6f, 36f).dp).clip(RoundedCornerShape(4.dp)).background(Color.White))
        }
    }
}

// ------------------------------------------------------------
// SCREEN 3: VOICE CHAT WITH DARK AUDIO WAVEFORM PILLS
// ------------------------------------------------------------
@Composable
private fun ChatScreen(
    uiState: PanduUiState,
    onBack: () -> Unit,
    onMic: () -> Unit,
    onCamera: () -> Unit,
    onSend: (String) -> Unit,
    onSpeak: (String) -> Unit
) {
    val theme = uiState.settings.visualTheme
    var text by remember { mutableStateOf("") }
    val listState = rememberLazyListState()

    LaunchedEffect(uiState.messages.size, uiState.isThinking) {
        if (uiState.messages.isNotEmpty()) listState.animateScrollToItem(uiState.messages.lastIndex)
    }

    OmegaAuraBackdrop(theme = theme) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(horizontal = 16.dp, vertical = 12.dp)
        ) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                GlassCircleButton(Icons.AutoMirrored.Rounded.ArrowBack, theme = theme, onClick = onBack)
                Text(
                    text = if (uiState.lastLatencyMs > 0) "Voice Chat (${uiState.lastLatencyMs}ms)" else "Voice Chat",
                    color = Color.White,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Medium
                )
                GlassCircleButton(Icons.Rounded.CameraAlt, theme = theme, onClick = onCamera)
            }

            Spacer(modifier = Modifier.height(14.dp))
            LazyColumn(state = listState, modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                items(uiState.messages, key = { it.id }) { m ->
                    if (m.isFromUser && m.isVoiceInput) {
                        UserWaveformPillBubble(theme = theme, transcript = m.text, duration = m.audioDuration)
                    } else if (m.isFromUser) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                            Column(
                                modifier = Modifier.widthIn(max = 275.dp).clip(RoundedCornerShape(20.dp)).background(OmegaColors.AudioPillDark).padding(horizontal = 14.dp, vertical = 10.dp)
                            ) {
                                if (m.hasImageAttachment) Text("Camera Image Attached", color = OmegaColors.OrbCyan, fontSize = 10.5.sp, fontWeight = FontWeight.SemiBold)
                                Text(m.text, color = Color.White, fontSize = 13.5.sp, lineHeight = 19.sp)
                            }
                        }
                    } else {
                        Row(modifier = Modifier.fillMaxWidth(0.9f), verticalAlignment = Alignment.Top, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            IridescentSwirlOrb(size = 28.dp, cyberMode = theme.isDark())
                            Column(modifier = Modifier.omegaGlassCard(18.dp, theme).padding(horizontal = 14.dp, vertical = 12.dp)) {
                                if (m.executedTools.isNotEmpty()) {
                                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.padding(bottom = 6.dp)) {
                                        m.executedTools.distinct().take(3).forEach { tool ->
                                            Box(modifier = Modifier.clip(RoundedCornerShape(10.dp)).background(OmegaColors.AudioPillDark).padding(horizontal = 8.dp, vertical = 3.dp)) {
                                                Text(tool, color = OmegaColors.OrbCyan, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                                            }
                                        }
                                    }
                                }
                                Text(m.text, color = if (m.isError) Color(0xFFEF4444) else theme.primaryText(), fontSize = 13.5.sp, lineHeight = 19.sp)
                                if (!m.isError) {
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Row(modifier = Modifier.clickable { onSpeak(m.text) }, verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                        Icon(Icons.AutoMirrored.Rounded.VolumeUp, null, tint = theme.mutedText(), modifier = Modifier.size(14.dp))
                                        Text("Listen", color = theme.mutedText(), fontSize = 11.sp)
                                    }
                                }
                            }
                        }
                    }
                }
                if (uiState.isThinking) {
                    item {
                        Box(modifier = Modifier.omegaGlassCard(16.dp, theme).padding(horizontal = 14.dp, vertical = 10.dp)) {
                            Text(uiState.liveToolStatus ?: "OMEGA 15 Pro thinking...", color = theme.primaryText(), fontSize = 13.sp)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))
            Row(
                modifier = Modifier.fillMaxWidth().omegaGlassCard(28.dp, theme).padding(horizontal = 8.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onCamera) { Icon(Icons.Rounded.Add, "Camera Vision", tint = theme.primaryText()) }
                TextField(
                    value = text,
                    onValueChange = { text = it },
                    placeholder = { Text("Type your message...", color = theme.mutedText(), fontSize = 14.sp) },
                    colors = TextFieldDefaults.colors(
                        focusedContainerColor = Color.Transparent, unfocusedContainerColor = Color.Transparent,
                        focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent,
                        focusedTextColor = theme.primaryText(), unfocusedTextColor = theme.primaryText()
                    ),
                    singleLine = true,
                    modifier = Modifier.weight(1f)
                )
                IconButton(onClick = onMic) { Icon(Icons.Rounded.Mic, "Voice", tint = theme.primaryText()) }
                Box(
                    modifier = Modifier.size(40.dp).clickable {
                        if (text.isNotBlank() && !uiState.isThinking) { onSend(text); text = "" }
                    },
                    contentAlignment = Alignment.Center
                ) {
                    IridescentSwirlOrb(size = 38.dp, cyberMode = theme.isDark())
                    Icon(Icons.AutoMirrored.Rounded.Send, "Send", tint = Color.White, modifier = Modifier.size(16.dp))
                }
            }
        }
    }
}

@Composable
private fun UserWaveformPillBubble(theme: OmegaVisualTheme, transcript: String, duration: String) {
    Column(modifier = Modifier.fillMaxWidth(), horizontalAlignment = Alignment.End) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Row(
                modifier = Modifier
                    .clip(RoundedCornerShape(24.dp))
                    .background(OmegaColors.AudioPillDark)
                    .padding(horizontal = 12.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Box(
                    modifier = Modifier.size(26.dp).clip(CircleShape).background(Color.White),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Rounded.PlayArrow, "Voice", tint = Color.Black, modifier = Modifier.size(18.dp))
                }
                val bars = listOf(8, 16, 12, 20, 10, 18, 14, 22, 12, 16, 9, 14)
                Row(horizontalArrangement = Arrangement.spacedBy(3.dp), verticalAlignment = Alignment.CenterVertically) {
                    bars.forEach { h ->
                        Box(modifier = Modifier.width(2.5.dp).height(h.dp).clip(RoundedCornerShape(2.dp)).background(Color.White))
                    }
                }
                Text(duration, color = Color.White.copy(0.82f), fontSize = 11.sp)
            }
            Spacer(modifier = Modifier.width(8.dp))
            Box(
                modifier = Modifier.size(30.dp).clip(CircleShape).background(Color.White),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Rounded.Person, null, tint = OmegaColors.TextDark, modifier = Modifier.size(18.dp))
            }
        }
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = transcript,
            color = if (theme.isDark()) Color(0xFFCBD5E1) else OmegaColors.TextMuted,
            fontSize = 11.5.sp,
            modifier = Modifier.padding(end = 42.dp)
        )
    }
}

@Composable
fun GlassCircleButton(icon: ImageVector, size: Dp = 42.dp, theme: OmegaVisualTheme, onClick: () -> Unit) {
    IconButton(onClick = onClick, modifier = Modifier.size(size).omegaGlassCard(size / 2, theme)) {
        Icon(icon, contentDescription = null, tint = theme.primaryText(), modifier = Modifier.size(20.dp))
    }
}
