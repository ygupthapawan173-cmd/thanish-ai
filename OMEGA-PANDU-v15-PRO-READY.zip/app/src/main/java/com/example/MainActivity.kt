package com.example

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.material3.MaterialTheme
import com.example.ui.OmegaDashboardApp
import com.example.ui.PanduViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: PanduViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        handleLaunchIntent(intent)

        setContent {
            MaterialTheme {
                OmegaDashboardApp(viewModel = viewModel)
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleLaunchIntent(intent)
    }

    private fun handleLaunchIntent(intent: Intent?) {
        if (intent == null) return

        // v11 Pro: Default Phone Digital Assistant (Power button / Swipe assist)
        if (intent.action == Intent.ACTION_ASSIST || intent.action == Intent.ACTION_VOICE_COMMAND) {
            viewModel.startVoiceListening()
            return
        }

        if (intent.getBooleanExtra(EXTRA_START_LISTENING, false)) {
            val inlineCommand = intent.getStringExtra(EXTRA_WAKE_COMMAND).orEmpty()
            if (inlineCommand.isNotBlank()) viewModel.handleInlineWakeCommand(inlineCommand)
            else viewModel.startVoiceListening()
            intent.removeExtra(EXTRA_START_LISTENING)
            intent.removeExtra(EXTRA_WAKE_COMMAND)
        }

        if (intent.getBooleanExtra(EXTRA_OPEN_CAMERA, false)) {
            viewModel.requestCameraLaunchFromWidget()
            intent.removeExtra(EXTRA_OPEN_CAMERA)
        }

        val routineName = intent.getStringExtra(EXTRA_RUN_ROUTINE).orEmpty()
        if (routineName.isNotBlank()) {
            viewModel.runRoutineByName(routineName)
            intent.removeExtra(EXTRA_RUN_ROUTINE)
        }
    }

    companion object {
        const val EXTRA_START_LISTENING = "extra_start_listening"
        const val EXTRA_WAKE_COMMAND = "extra_wake_command"
        const val EXTRA_OPEN_CAMERA = "extra_open_camera"
        const val EXTRA_RUN_ROUTINE = "extra_run_routine"
    }
}
