# OMEGA Pandu 15 Pro — Pastel Glassmorphism & Cyber Horizon AI Assistant

Complete **v1 → v15 Pro** Android Jetpack Compose AI Assistant project tailored to the **Pastel Glassmorphism & 3D Swirling Orb** interface (with your **Cyber Horizon WebGL** `jarvis-orb.js` preserved one tap away).

## What's New in v11 → v15 Pro (On Top of v10 Clean Core)
- **v11 Pro — Default Phone Assistant & Quick Settings Tile:** `ACTION_ASSIST` / `ACTION_VOICE_COMMAND` support (launch from power button/corner swipe) + `OmegaQuickTileService` in Android Quick Settings panel.
- **v12 Pro — Live Google Search Grounding:** Built-in `live_web_search` tool using Gemini `google_search` grounding for live weather, cricket scores, news, and real-time facts.
- **v13 Pro — Visual Coordinate Clicking & Screen Typing:** `tap_screen_coordinates(x_norm, y_norm)` on a 0..1000 screen grid after live `capture_screen_vision` screenshots + `type_screen_text` into focused input fields.
- **v14 Pro — Biometric Safety Lock + Gyroscope 3D Parallax + Tactile Haptics:** Zero-dependency Android 9+ `BiometricPrompt` gate, real-time `SensorManager` 3D tilt parallax on the Swirling Orb, and crisp `VibrationEffect` haptics.
- **v15 Pro — Pastel Glassmorphism Mastery + Home Screen Widget + Pro Telemetry:** Animated drifting aura mesh backdrop, exact 2x2 frosted glass action grid, dark audio-waveform chat pills, live ms latency & battery telemetry pill, and `OmegaHomeWidgetProvider` Home Screen Dock Widget (Voice / Vision / Night Routine).

## Build APK on GitHub (No PC Needed)
1. Upload the extracted files from this ZIP to your GitHub repo.
2. Open **Actions → Build OMEGA Pandu v15 Pro APK → Run workflow**.
3. Download **`OMEGA-PANDU-v15-PRO-APK`** from Artifacts and install `app-debug.apk`.
