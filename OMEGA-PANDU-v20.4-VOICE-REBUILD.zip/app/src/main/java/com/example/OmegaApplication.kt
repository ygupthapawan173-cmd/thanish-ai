package com.example

import android.app.Application
import com.example.security.CrashRecoveryHandler

class OmegaApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        CrashRecoveryHandler.install(this)
    }
}
