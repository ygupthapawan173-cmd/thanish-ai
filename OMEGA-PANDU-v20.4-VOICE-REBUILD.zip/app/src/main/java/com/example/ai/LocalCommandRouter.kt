package com.example.ai

import com.example.control.DeviceActionExecutor
import com.example.data.AppDatabase
import org.json.JSONObject

data class LocalRouteResult(val replyText: String, val executedTool: String)

class LocalCommandRouter(
    private val executor: DeviceActionExecutor,
    private val database: AppDatabase
) {
    suspend fun tryHandleInstant(rawPrompt: String): LocalRouteResult? {
        val q = rawPrompt.trim().lowercase()
        if (q.isEmpty()) return null

        val matchedRoutine = database.getAllRoutines().firstOrNull { r ->
            val trig = r.triggerPhrase.lowercase().trim()
            trig.isNotEmpty() && (q == trig || q == "run $trig" || q == "start $trig")
        }
        if (matchedRoutine != null) {
            return LocalRouteResult(executor.executeRoutineByName(matchedRoutine.name), "routine:${matchedRoutine.name}")
        }

        if (q.contains("flashlight") || q.contains("torch") || q.contains("టార్చ్")) {
            val turnOff = q.contains("off") || q.contains("bandh") || q.contains("ఆఫ్") || q.contains("close")
            val turnOn = q.contains("on") || q.contains("veyi") || q.contains("ఆన్") || q.contains("open")
            if (turnOff || turnOn) {
                val out = executor.executeTool("toggle_flashlight", JSONObject().put("enabled", !turnOff))
                return LocalRouteResult(out.responseJson.optString("result"), "toggle_flashlight")
            }
        }

        if (q.contains("volume") || q.contains("sound") || q.contains("వాల్యూమ్")) {
            val num = Regex("(\\d{1,3})").find(q)?.groupValues?.getOrNull(1)?.toIntOrNull()
            val target = when {
                num != null -> num.coerceIn(0, 100)
                q.contains("mute") || q.contains("silent") || q.contains("zero") -> 0
                q.contains("full") || q.contains("max") -> 100
                q.contains("half") || q.contains("medium") -> 50
                else -> null
            }
            if (target != null) {
                val out = executor.executeTool("set_media_volume", JSONObject().put("percent", target))
                return LocalRouteResult(out.responseJson.optString("result"), "set_media_volume")
            }
        }

        if ((q.contains("battery") || q.contains("charge") || q.contains("బ్యాటరీ")) && q.split(" ").size <= 5) {
            val out = executor.executeTool("get_battery_status", JSONObject())
            return LocalRouteResult(out.responseJson.optString("result"), "get_battery_status")
        }

        val openMatch = Regex("^(open|launch)\\s+([a-zA-Z0-9 ]{2,20})$").find(q)
        if (openMatch != null) {
            val appName = openMatch.groupValues[2].trim()
            if (!appName.contains(" and ") && !appName.contains(" chesi ")) {
                val out = executor.executeTool("open_app", JSONObject().put("app_name", appName))
                return LocalRouteResult(out.responseJson.optString("result"), "open_app")
            }
        }

        return null
    }
}
