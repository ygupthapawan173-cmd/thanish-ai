package com.example.autonomous

import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import com.example.BuildConfig
import com.example.data.OmegaPreferences
import com.example.security.VerifiedApkUpdater
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.security.MessageDigest
import java.util.concurrent.TimeUnit

data class ReleaseUpdateInfo(
    val tagName: String,
    val changelog: String,
    val apkDownloadUrl: String,
    val expectedSha256: String?,
    val isNewerThanInstalled: Boolean
)

class SecureSelfUpdater(
    private val context: Context,
    private val preferences: OmegaPreferences
) {
    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build()

    suspend fun checkLatestRelease(repoSlug: String, token: String): Result<ReleaseUpdateInfo> = withContext(Dispatchers.IO) {
        if (repoSlug.isBlank()) return@withContext Result.failure(IllegalArgumentException("Set GitHub Repo (owner/repo) first."))
        runCatching {
            val req = Request.Builder()
                .url("https://api.github.com/repos/$repoSlug/releases/latest")
                .addHeader("Accept", "application/vnd.github+json")
                .apply { if (token.isNotBlank()) addHeader("Authorization", "Bearer ${token.trim()}") }
                .get()
                .build()

            client.newCall(req).execute().use { resp ->
                val raw = resp.body?.string().orEmpty()
                if (!resp.isSuccessful) throw IOException("Release check HTTP ${resp.code}")
                val obj = JSONObject(raw)
                val tag = obj.optString("tag_name", "unknown")
                val body = obj.optString("body", "No changelog provided.")
                val assets = obj.optJSONArray("assets")

                var apkUrl = ""
                var shaAssetUrl = ""
                if (assets != null) {
                    for (i in 0 until assets.length()) {
                        val a = assets.getJSONObject(i)
                        val name = a.optString("name", "")
                        val dl = a.optString("browser_download_url", "")
                        if (name.endsWith(".apk")) apkUrl = dl
                        if (name.endsWith(".sha256")) shaAssetUrl = dl
                    }
                }
                if (apkUrl.isBlank()) throw IOException("Latest release $tag has no .apk asset.")

                var expectedSha = Regex("""SHA256:\s*([a-fA-F0-9]{64})""").find(body)?.groupValues?.getOrNull(1)
                if (expectedSha == null && shaAssetUrl.isNotBlank()) {
                    val shaReq = Request.Builder().url(shaAssetUrl).get().build()
                    client.newCall(shaReq).execute().use { sr ->
                        if (sr.isSuccessful) {
                            expectedSha = Regex("([a-fA-F0-9]{64})").find(sr.body?.string().orEmpty())?.groupValues?.getOrNull(1)
                        }
                    }
                }

                val isNewer = !tag.removePrefix("v").equals(BuildConfig.VERSION_NAME.removeSuffix("-ultra"), ignoreCase = true)
                ReleaseUpdateInfo(tag, body, apkUrl, expectedSha, isNewer)
            }
        }
    }

    /**
     * Downloads APK, creates encrypted settings backup, enforces MANDATORY SHA-256 & Signing Certificate checks,
     * and launches Android's user-approved installation dialog.
     */
    suspend fun downloadVerifyAndPromptInstall(
        release: ReleaseUpdateInfo,
        onProgress: (String) -> Unit
    ): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            // 1. Mandatory pre-update encrypted backup
            onProgress("Creating encrypted pre-update backup...")
            val backupDir = File(context.filesDir, "backups").apply { mkdirs() }
            val backupFile = File(backupDir, "pre_update_${System.currentTimeMillis()}.enc")
            backupFile.writeText(preferences.exportEncryptedBackupJson())

            // 2. Mandatory SHA-256 presence check
            val expectedHash = release.expectedSha256
                ?: throw SecurityException("Update blocked: Release missing mandatory SHA-256 checksum.")

            // 3. Download APK to isolated cache directory
            onProgress("Downloading ${release.tagName} APK...")
            val updateDir = File(context.cacheDir, "updates").apply { mkdirs() }
            val apkFile = File(updateDir, "omega_${release.tagName}.apk")
            val req = Request.Builder().url(release.apkDownloadUrl).get().build()
            client.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) throw IOException("APK download failed HTTP ${resp.code}")
                resp.body?.byteStream()?.use { input ->
                    apkFile.outputStream().use { out -> input.copyTo(out) }
                } ?: throw IOException("Empty APK stream.")
            }

            // 4. Mandatory SHA-256 verification
            onProgress("Verifying SHA-256 integrity...")
            val actualHash = VerifiedApkUpdater.sha256OfFile(apkFile)
            if (!actualHash.equals(expectedHash, ignoreCase = true)) {
                apkFile.delete()
                throw SecurityException("SHA-256 mismatch! Expected ${expectedHash.take(12)}..., got ${actualHash.take(12)}.... Update deleted.")
            }

            // 5. Mandatory APK Signing Certificate verification against currently installed app
            onProgress("Verifying APK signing certificate...")
            val installedCerts = getInstalledAppCertFingerprints()
            val downloadedCerts = getApkArchiveCertFingerprints(apkFile.absolutePath)
            if (downloadedCerts.isEmpty() || installedCerts.intersect(downloadedCerts).isEmpty()) {
                apkFile.delete()
                throw SecurityException("Signing certificate mismatch! APK is not signed with the same certificate as installed app.")
            }

            // 6. Launch Android OS user-approved installation screen
            onProgress("Verified! Launching user-approved installer...")
            VerifiedApkUpdater.verifyAndInstall(context, apkFile, expectedHash)
        }
    }

    private fun getInstalledAppCertFingerprints(): Set<String> {
        val pm = context.packageManager
        val info = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            pm.getPackageInfo(context.packageName, PackageManager.GET_SIGNING_CERTIFICATES)
        } else {
            @Suppress("DEPRECATION")
            pm.getPackageInfo(context.packageName, PackageManager.GET_SIGNATURES)
        }
        return extractCertHashes(info)
    }

    private fun getApkArchiveCertFingerprints(apkPath: String): Set<String> {
        val pm = context.packageManager
        val info = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            pm.getPackageArchiveInfo(apkPath, PackageManager.GET_SIGNING_CERTIFICATES)
        } else {
            @Suppress("DEPRECATION")
            pm.getPackageArchiveInfo(apkPath, PackageManager.GET_SIGNATURES)
        } ?: return emptySet()
        return extractCertHashes(info)
    }

    private fun extractCertHashes(info: android.content.pm.PackageInfo): Set<String> {
        val sigs = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            info.signingInfo?.apkContentsSigners ?: emptyArray()
        } else {
            @Suppress("DEPRECATION")
            info.signatures ?: emptyArray()
        }
        val md = MessageDigest.getInstance("SHA-256")
        return sigs.map { sig ->
            md.digest(sig.toByteArray()).joinToString("") { "%02x".format(it) }
        }.toSet()
    }
}
