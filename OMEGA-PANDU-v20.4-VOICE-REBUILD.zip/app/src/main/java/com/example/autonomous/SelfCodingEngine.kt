package com.example.autonomous

import com.example.ai.PanduAiRepository

data class SecurityScanResult(
    val passed: Boolean,
    val findings: List<String>
)

data class GeneratedCodePatch(
    val targetPath: String,
    val updatedContent: String,
    val commitMessage: String,
    val reviewSummary: String,
    val securityScan: SecurityScanResult
)

/**
 * Self-Coding & Security Scanning Engine (v19 Autonomous):
 * - Scans generated Kotlin/XML code for hardcoded tokens/keys, brace balance, & unsafe calls
 * - Generates minimal, surgical patches using active AI provider (Gemini -> OpenRouter fallback)
 */
class SelfCodingEngine(private val aiRepository: PanduAiRepository) {

    suspend fun generatePatch(
        featureRequest: String,
        targetPath: String,
        existingFileContent: String,
        buildErrorFeedback: String? = null
    ): Result<GeneratedCodePatch> {
        val prompt = buildString {
            append("You are the OMEGA Autonomous Kotlin Android Engineer.\n")
            append("Task: $featureRequest\n")
            append("Target file: $targetPath\n")
            if (!buildErrorFeedback.isNullOrBlank()) {
                append("PREVIOUS GRADLE BUILD FAILED WITH THIS ERROR — FIX IT:\n$buildErrorFeedback\n")
            }
            append("STRICT RULES:\n")
            append("1. Return ONLY the complete valid updated file content inside a single ```kotlin ... ``` or ```xml ... ``` block.\n")
            append("2. NEVER embed API keys, GitHub tokens, or secrets.\n")
            append("3. Preserve package name, existing working features, and Android 16 compatibility.\n\n")
            append("EXISTING FILE CONTENT:\n```\n")
            append(existingFileContent.take(14000))
            append("\n```")
        }

        val aiRes = aiRepository.sendRawEngineeringPrompt(prompt)
        return aiRes.mapCatching { rawText ->
            val extracted = extractCodeBlock(rawText)
                ?: throw IllegalStateException("AI did not return a valid code block.")

            val scan = scanForSecurityAndSyntax(targetPath, extracted)
            if (!scan.passed) {
                throw SecurityException("Patch blocked by Security/Syntax Scanner: ${scan.findings.joinToString("; ")}")
            }

            val review = buildAutoReview(existingFileContent, extracted, targetPath)
            GeneratedCodePatch(
                targetPath = targetPath,
                updatedContent = extracted,
                commitMessage = "omega-auto: ${featureRequest.take(56)}",
                reviewSummary = review,
                securityScan = scan
            )
        }
    }

    companion object {
        fun extractCodeBlock(raw: String): String? {
            val regex = Regex("```(?:kotlin|kt|xml|gradle)?\\s*\n([\\s\\S]*?)```")
            return regex.find(raw)?.groupValues?.getOrNull(1)?.trim()?.ifBlank { null }
        }

        fun scanForSecurityAndSyntax(path: String, code: String): SecurityScanResult {
            val findings = mutableListOf<String>()
            // 1. Secret / Token leak scanner
            if (Regex("ghp_[A-Za-z0-9]{20,}|github_pat_[A-Za-z0-9_]{20,}").containsMatchIn(code)) {
                findings.add("Blocked: Embedded GitHub token detected.")
            }
            if (Regex("""AIza[0-9A-Za-z\-_]{30,}""").containsMatchIn(code)) {
                findings.add("Blocked: Hardcoded Google API key detected.")
            }
            if (Regex("sk-or-v1-[A-Za-z0-9]{20,}").containsMatchIn(code)) {
                findings.add("Blocked: Hardcoded OpenRouter API key detected.")
            }
            if (code.contains("Runtime.getRuntime().exec(")) {
                findings.add("Blocked: Unsafe shell exec detected.")
            }

            // 2. Kotlin structural checks
            if (path.endsWith(".kt")) {
                if (!code.trimStart().startsWith("package ")) {
                    findings.add("Syntax error: Missing package declaration.")
                }
                val openB = code.count { it == '{' }
                val closeB = code.count { it == '}' }
                if (openB != closeB) {
                    findings.add("Syntax error: Unbalanced braces ({=$openB, }=$closeB).")
                }
            }
            return SecurityScanResult(passed = findings.isEmpty(), findings = findings)
        }

        private fun buildAutoReview(oldCode: String, newCode: String, path: String): String {
            val oldLines = oldCode.lines().size
            val newLines = newCode.lines().size
            val delta = newLines - oldLines
            val sign = if (delta >= 0) "+$delta" else "$delta"
            return "Reviewed $path ($oldLines -> $newLines lines, $sign). Zero secrets detected, syntax balanced."
        }
    }
}
