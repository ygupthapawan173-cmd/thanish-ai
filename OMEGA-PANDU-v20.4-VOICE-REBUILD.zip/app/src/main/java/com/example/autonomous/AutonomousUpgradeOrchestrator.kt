package com.example.autonomous

import com.example.data.AppDatabase
import com.example.data.OmegaPreferences
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class AutonomousUpgradeState(
    val isRunning: Boolean = false,
    val currentStage: String = "Idle",
    val progressPercent: Int = 0,
    val activeBranch: String? = null,
    val pullRequestUrl: String? = null,
    val repairAttempt: Int = 0,
    val maxRepairAttempts: Int = 2,
    val stepLogs: List<String> = emptyList(),
    val error: String? = null
)

class AutonomousUpgradeOrchestrator(
    private val preferences: OmegaPreferences,
    private val database: AppDatabase,
    private val selfCoding: SelfCodingEngine,
    private val github: GitHubEngineeringClient
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var activeJob: Job? = null

    private val _state = MutableStateFlow(AutonomousUpgradeState())
    val state: StateFlow<AutonomousUpgradeState> = _state.asStateFlow()

    fun startSelfUpgrade(featureRequest: String, targetFilePath: String) {
        val s = preferences.settings.value
        val repo = s.githubRepoSlug.trim()
        val token = s.githubToken.trim()
        val baseBranch = s.githubBaseBranch.trim().ifEmpty { "main" }

        if (repo.isBlank() || !repo.contains("/") || token.isBlank()) {
            _state.value = AutonomousUpgradeState(
                error = "Configure GitHub Repo (owner/repo) and Encrypted GitHub Token in Settings > System or Autonomous Lab first."
            )
            return
        }

        activeJob?.cancel()
        activeJob = scope.launch {
            val branchName = "omega-auto/upgrade-${System.currentTimeMillis() / 1000}"
            _state.value = AutonomousUpgradeState(
                isRunning = true,
                currentStage = "Planning Upgrade...",
                progressPercent = 10,
                activeBranch = branchName,
                stepLogs = listOf("1. Planned self-upgrade for '$targetFilePath'")
            )
            database.logAudit("SELF_UPGRADE", "Started: ${featureRequest.take(80)}", "RUNNING")

            try {
                // Step 1: Resolve base branch HEAD SHA
                logStep("2. Fetching base branch '$baseBranch' HEAD...", 20)
                val baseSha = github.getBranchHeadSha(repo, baseBranch, token).getOrThrow()

                // Step 2: Create isolated development branch
                logStep("3. Creating isolated branch '$branchName'...", 32)
                github.createIsolatedBranch(repo, branchName, baseSha, token).getOrThrow()

                // Step 3: Fetch existing source code
                logStep("4. Analyzing existing source '$targetFilePath'...", 45)
                var snapshot = github.fetchFileContent(repo, targetFilePath, branchName, token).getOrThrow()

                // Step 4: Generate patch + Security scan + Commit + Bounded CI Verification (max 2 repair attempts)
                var lastBuildError: String? = null
                var ciPassed = false
                var lastReview = ""

                for (attempt in 0..MAX_REPAIR_ATTEMPTS) {
                    _state.update { it.copy(repairAttempt = attempt) }
                    val label = if (attempt == 0) "5. Generating AI patch & scanning security..." else "Repair Attempt #$attempt/$MAX_REPAIR_ATTEMPTS..."
                    logStep(label, 55 + attempt * 10)

                    val patch = selfCoding.generatePatch(featureRequest, targetFilePath, snapshot.content, lastBuildError).getOrThrow()
                    lastReview = patch.reviewSummary
                    logStep("Security Scan PASSED • ${patch.reviewSummary}", 65 + attempt * 8)

                    github.commitFilePatch(
                        repoSlug = repo,
                        path = targetFilePath,
                        branch = branchName,
                        baseFileSha = snapshot.sha,
                        newContent = patch.updatedContent,
                        commitMessage = patch.commitMessage,
                        token = token
                    ).getOrThrow()

                    logStep("Committed patch to $branchName. Waiting for GitHub Actions CI...", 75)
                    val ciResult = pollCiBuild(repo, branchName, token)
                    if (ciResult == null) {
                        logStep("CI run still queued/building in GitHub Actions. Proceeding to draft PR for review.", 88)
                        ciPassed = true
                        break
                    } else if (ciResult.conclusion == "success") {
                        logStep("GitHub Actions Gradle Build & Unit Tests PASSED!", 90)
                        ciPassed = true
                        break
                    } else {
                        lastBuildError = github.fetchFailedJobSummary(repo, ciResult.runId, token)
                        logStep("CI Failed: $lastBuildError", 78)
                        if (attempt < MAX_REPAIR_ATTEMPTS) {
                            snapshot = github.fetchFileContent(repo, targetFilePath, branchName, token).getOrThrow()
                        }
                    }
                }

                // Step 5: Open Pull Request for Human Approval (NEVER auto-merges!)
                logStep("Opening Pull Request for Human Approval...", 95)
                val prBody = buildString {
                    append("### OMEGA Autonomous Self-Upgrade Proposal\n")
                    append("- **Request:** $featureRequest\n")
                    append("- **Target File:** `$targetFilePath`\n")
                    append("- **Auto Review:** $lastReview\n")
                    append("- **CI Status:** ${if (ciPassed) "Verified / Running" else "Needs human review after bounded repair attempts"}\n")
                    append("- **Safety:** Isolated branch `$branchName`. Human approval required before merge.")
                }
                val prUrl = github.createPullRequest(
                    repoSlug = repo,
                    headBranch = branchName,
                    baseBranch = baseBranch,
                    title = "[OMEGA Auto] ${featureRequest.take(60)}",
                    body = prBody,
                    token = token
                ).getOrThrow()

                database.logAudit("SELF_UPGRADE", "PR opened: $prUrl", "AWAITING_APPROVAL")
                _state.update {
                    it.copy(
                        isRunning = false,
                        currentStage = "PR Ready for Human Approval",
                        progressPercent = 100,
                        pullRequestUrl = prUrl,
                        stepLogs = it.stepLogs + "PR Created: $prUrl (Review & Merge on GitHub)"
                    )
                }
            } catch (ce: CancellationException) {
                database.logAudit("SELF_UPGRADE", "Emergency STOP triggered by user", "ABORTED")
                _state.update {
                    it.copy(
                        isRunning = false,
                        currentStage = "Emergency Stopped",
                        error = "Aborted by user."
                    )
                }
            } catch (e: Exception) {
                database.logAudit("SELF_UPGRADE", "Failed: ${e.message}", "FAILED")
                _state.update {
                    it.copy(
                        isRunning = false,
                        currentStage = "Upgrade Halted",
                        error = e.message ?: "Autonomous upgrade failed."
                    )
                }
            }
        }
    }

    private suspend fun pollCiBuild(repo: String, branch: String, token: String): WorkflowRunStatus? {
        delay(6000L)
        repeat(8) {
            val run = github.getLatestWorkflowRunForBranch(repo, branch, token).getOrNull()
            if (run != null && run.status == "completed") return run
            delay(5000L)
        }
        return null
    }

    private fun logStep(msg: String, pct: Int) {
        _state.update { it.copy(currentStage = msg, progressPercent = pct, stepLogs = it.stepLogs + msg) }
    }

    fun emergencyStop() {
        activeJob?.cancel()
        activeJob = null
    }

    companion object {
        const val MAX_REPAIR_ATTEMPTS = 2
    }
}
