package com.example.omega

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.example.MainActivity
import java.util.Calendar

class TimeAutomationReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val routineName = intent?.getStringExtra("routine_name") ?: return
        SmartTriggerBus.emit(SmartTriggerEvent("Scheduled Routine", "Running scheduled routine: $routineName"))
        val launch = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
            putExtra(MainActivity.EXTRA_RUN_ROUTINE, routineName)
        }
        runCatching { context.startActivity(launch) }
    }
}

object TimeAutomationScheduler {
    fun scheduleDailyRoutine(context: Context, routineName: String, hour24: Int, minute: Int): String {
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, hour24.coerceIn(0, 23))
            set(Calendar.MINUTE, minute.coerceIn(0, 59))
            set(Calendar.SECOND, 0)
            if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1)
        }
        val intent = Intent(context, TimeAutomationReceiver::class.java).putExtra("routine_name", routineName)
        val pi = PendingIntent.getBroadcast(
            context,
            routineName.hashCode(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        am.setInexactRepeating(AlarmManager.RTC_WAKEUP, cal.timeInMillis, AlarmManager.INTERVAL_DAY, pi)
        return String.format("Scheduled '%s' daily at %02d:%02d.", routineName, hour24, minute)
    }
}
