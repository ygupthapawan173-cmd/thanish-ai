package com.example.ui.theme

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.SwitchColors
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.TextFieldColors
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.data.OmegaVisualTheme
import com.example.data.OrbColorPreset

object OmegaColors {
    val PureBlack = Color(0xFF000000)
    val CarbonSurface = Color(0xFF121216)
    val CarbonElevated = Color(0xFF18181E)
    val SubtleBorder = Color(0xFF262630)

    val VelvetTop = Color(0xFF1A0F2E)
    val VelvetMid = Color(0xFF0B0714)
    val VelvetBottom = Color(0xFF000000)

    val ElectricCyan = Color(0xFF38BDF8)
    val RoyalIndigo = Color(0xFF7C3AED)
    val CoralRose = Color(0xFFFF3D77)
    val EmeraldLive = Color(0xFF10B981)
    val AmberWarn = Color(0xFFF59E0B)
    val CrimsonErr = Color(0xFFF43F5E)
}

fun OmegaVisualTheme.isDark(): Boolean = true
fun OmegaVisualTheme.primaryText(): Color = Color(0xFFF8FAFC)
fun OmegaVisualTheme.mutedText(): Color = Color(0xFF8E92A4)
fun OmegaVisualTheme.accentColor(preset: OrbColorPreset): Color = Color(preset.primaryHex)

@Composable
fun omegaSwitchColors(theme: OmegaVisualTheme, preset: OrbColorPreset): SwitchColors {
    val accent = Color(preset.primaryHex)
    return SwitchDefaults.colors(
        checkedThumbColor = Color.White,
        checkedTrackColor = accent,
        checkedBorderColor = accent,
        uncheckedThumbColor = Color(0xFF94A3B8),
        uncheckedTrackColor = Color(0xFF1F1F28),
        uncheckedBorderColor = Color(0xFF323240)
    )
}

@Composable
fun omegaTextFieldColors(theme: OmegaVisualTheme, preset: OrbColorPreset): TextFieldColors {
    val accent = Color(preset.primaryHex)
    return OutlinedTextFieldDefaults.colors(
        focusedBorderColor = accent,
        unfocusedBorderColor = Color(0xFF282834),
        focusedContainerColor = Color(0xFF0E0E13),
        unfocusedContainerColor = Color(0xFF0B0B10),
        focusedTextColor = Color(0xFFF8FAFC),
        unfocusedTextColor = Color(0xFFE2E8F0),
        focusedLabelColor = accent,
        unfocusedLabelColor = Color(0xFF8E92A4),
        cursorColor = accent
    )
}

/**
 * Pure AMOLED Pitch Black (#000000) backdrop (or Velvet Violet Studio) — zero muddy blue wash!
 */
@Composable
fun OmegaLiquidBackdrop(
    theme: OmegaVisualTheme,
    preset: OrbColorPreset,
    modifier: Modifier = Modifier,
    content: @Composable BoxScope.() -> Unit
) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(
                if (theme == OmegaVisualTheme.MIDNIGHT_ROYAL) {
                    Brush.verticalGradient(listOf(OmegaColors.VelvetTop, OmegaColors.VelvetMid, OmegaColors.VelvetBottom))
                } else {
                    Brush.verticalGradient(listOf(OmegaColors.PureBlack, OmegaColors.PureBlack))
                }
            )
    ) {
        if (theme == OmegaVisualTheme.MIDNIGHT_ROYAL) {
            val c1 = Color(preset.primaryHex)
            val c2 = Color(preset.accentHex)
            Canvas(modifier = Modifier.fillMaxSize()) {
                drawCircle(
                    brush = Brush.radialGradient(listOf(c2.copy(0.22f), Color.Transparent), Offset(size.width * 0.5f, size.height * 0.12f), size.width * 0.85f),
                    radius = size.width * 0.85f,
                    center = Offset(size.width * 0.5f, size.height * 0.12f)
                )
                drawCircle(
                    brush = Brush.radialGradient(listOf(c1.copy(0.14f), Color.Transparent), Offset(size.width * 0.8f, size.height * 0.75f), size.width * 0.70f),
                    radius = size.width * 0.70f,
                    center = Offset(size.width * 0.8f, size.height * 0.75f)
                )
            }
        }
        content()
    }
}

/**
 * Sleek Matte Carbon Glass Card with ultra-thin border (exact Dola / Apple dark pill aesthetic).
 */
fun Modifier.omegaGlassCard(
    cornerRadius: Dp = 22.dp,
    theme: OmegaVisualTheme,
    preset: OrbColorPreset = OrbColorPreset.SOLAR_NOVA
): Modifier = this
    .clip(RoundedCornerShape(cornerRadius))
    .background(if (theme == OmegaVisualTheme.MIDNIGHT_ROYAL) Color(0xCC161124) else OmegaColors.CarbonSurface)
    .border(
        width = 1.dp,
        color = if (theme == OmegaVisualTheme.MIDNIGHT_ROYAL) Color.White.copy(0.12f) else OmegaColors.SubtleBorder,
        shape = RoundedCornerShape(cornerRadius)
    )
