package com.example.control

import android.graphics.Bitmap
import android.util.Base64
import java.io.ByteArrayOutputStream
import kotlin.math.min

object VisionHelper {
    fun bitmapToBase64Jpeg(bitmap: Bitmap, maxDimension: Int = 1024, quality: Int = 78): String {
        val scale = min(1f, maxDimension.toFloat() / maxOf(bitmap.width, bitmap.height).coerceAtLeast(1))
        val scaled = if (scale < 1f) {
            Bitmap.createScaledBitmap(
                bitmap,
                (bitmap.width * scale).toInt().coerceAtLeast(1),
                (bitmap.height * scale).toInt().coerceAtLeast(1),
                true
            )
        } else bitmap

        val out = ByteArrayOutputStream()
        scaled.compress(Bitmap.CompressFormat.JPEG, quality, out)
        if (scaled !== bitmap) scaled.recycle()
        return Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
    }
}
