package com.example.control

import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.view.Gravity
import android.view.WindowManager
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import com.example.MainActivity
import com.example.data.OrbColorPreset
import com.example.ui.components.ParticleAiOrb
import kotlinx.coroutines.launch

private class ActiveRipple(val x: Float, val y: Float, val progress: Animatable<Float, *> = Animatable(0f))
private class ActiveSwipe(val sx: Float, val sy: Float, val ex: Float, val ey: Float, val progress: Animatable<Float, *> = Animatable(0f))

class AgentOverlayController(private val serviceContext: Context) {

    private val windowManager = serviceContext.getSystemService(WindowManager::class.java)
    private val lifecycleOwner = OverlayLifecycleOwner()

    private var effectsView: ComposeView? = null
    private var pillView: ComposeView? = null
    private var miniOrbView: ComposeView? = null

    fun attachOverlays() {
        lifecycleOwner.onCreate()
        lifecycleOwner.onResume()

        val effectsParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }
        effectsView = createComposeView { FullScreenEffectsHud() }
        windowManager.addView(effectsView, effectsParams)

        val pillParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = 110
        }
        pillView = createComposeView {
            Box(modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp), contentAlignment = Alignment.Center) {
                DynamicIslandStatusPill { AgentHudBus.triggerAbort() }
            }
        }
        windowManager.addView(pillView, pillParams)

        val orbParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = serviceContext.resources.displayMetrics.widthPixels - 172
            y = serviceContext.resources.displayMetrics.heightPixels / 2
        }
        miniOrbView = createComposeView {
            FloatingMiniOrbWidget(
                onTapOrb = {
                    val intent = Intent(serviceContext, MainActivity::class.java).apply {
                        flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
                        putExtra(MainActivity.EXTRA_START_LISTENING, true)
                    }
                    serviceContext.startActivity(intent)
                },
                onDragDelta = { dx, dy ->
                    orbParams.x += dx.toInt()
                    orbParams.y += dy.toInt()
                    miniOrbView?.let { v -> runCatching { windowManager.updateViewLayout(v, orbParams) } }
                }
            )
        }
        windowManager.addView(miniOrbView, orbParams)
    }

    private fun createComposeView(content: @Composable () -> Unit): ComposeView =
        ComposeView(serviceContext).apply {
            setViewTreeLifecycleOwner(lifecycleOwner)
            setViewTreeSavedStateRegistryOwner(lifecycleOwner)
            setContent(content)
        }

    fun detachOverlays() {
        effectsView?.let { runCatching { windowManager.removeViewImmediate(it) } }
        pillView?.let { runCatching { windowManager.removeViewImmediate(it) } }
        miniOrbView?.let { runCatching { windowManager.removeViewImmediate(it) } }
        effectsView = null; pillView = null; miniOrbView = null
        lifecycleOwner.onDestroy()
    }
}

@Composable
private fun FullScreenEffectsHud() {
    val state by AgentHudBus.state.collectAsState()
    val ripples = remember { mutableStateListOf<ActiveRipple>() }
    val swipes = remember { mutableStateListOf<ActiveSwipe>() }

    LaunchedEffect(Unit) {
        AgentHudBus.events.collect { event ->
            when (event) {
                is HudVisualEvent.TapRipple -> {
                    val r = ActiveRipple(event.x, event.y)
                    ripples.add(r)
                    launch { r.progress.animateTo(1f, tween(450, easing = FastOutSlowInEasing)); ripples.remove(r) }
                }
                is HudVisualEvent.SwipeTrail -> {
                    val s = ActiveSwipe(event.startX, event.startY, event.endX, event.endY)
                    swipes.add(s)
                    launch { s.progress.animateTo(1f, tween(500, easing = FastOutSlowInEasing)); swipes.remove(s) }
                }
            }
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        val activeState = state as? AgentHudState.Active
        if (activeState != null) {
            AiEdgeGlowOverlay(audioAmplitude = activeState.audioAmplitude)
        }
        Canvas(modifier = Modifier.fillMaxSize()) {
            ripples.forEach { r ->
                val p = r.progress.value
                val rad = 16.dp.toPx() + 52.dp.toPx() * p
                val alpha = (1f - p).coerceIn(0f, 1f)
                drawCircle(Color(0xFF00E5FF).copy(alpha = alpha * 0.35f), rad, Offset(r.x, r.y))
                drawCircle(Color(0xFF00E5FF).copy(alpha = alpha), rad, Offset(r.x, r.y), style = Stroke(3.dp.toPx()))
            }
            swipes.forEach { s ->
                val p = s.progress.value
                val alpha = (1f - p).coerceIn(0f, 1f)
                val cx = s.sx + (s.ex - s.sx) * p
                val cy = s.sy + (s.ey - s.sy) * p
                drawLine(Color(0xFF00E5FF).copy(alpha = alpha), Offset(s.sx, s.sy), Offset(cx, cy), 6.dp.toPx(), StrokeCap.Round)
                drawCircle(Color.White.copy(alpha = alpha), 9.dp.toPx(), Offset(cx, cy))
            }
            val box = activeState?.highlightBox
            if (box != null) {
                drawRoundRect(
                    color = Color(0xFF00E5FF),
                    topLeft = Offset(box.left.toFloat(), box.top.toFloat()),
                    size = Size(box.width().toFloat(), box.height().toFloat()),
                    cornerRadius = CornerRadius(12f, 12f),
                    style = Stroke(width = 2.dp.toPx())
                )
            }
        }
    }
}

@Composable
private fun DynamicIslandStatusPill(onStopClick: () -> Unit) {
    val state by AgentHudBus.state.collectAsState()
    val inForeground by AgentHudBus.isAppInForeground.collectAsState()
    val active = state as? AgentHudState.Active
    // NEVER overlap OMEGA's own header when app is in foreground!
    AnimatedVisibility(visible = active != null && !inForeground, enter = fadeIn(), exit = fadeOut()) {
        if (active != null) {
            Row(
                modifier = Modifier
                    .widthIn(max = 310.dp)
                    .clip(RoundedCornerShape(28.dp))
                    .background(Color(0xF5070B18))
                    .border(
                        width = 1.2.dp,
                        brush = Brush.horizontalGradient(listOf(Color(0xFF00E5FF), Color(0xFF6366F1), Color(0xFFFF4D94))),
                        shape = RoundedCornerShape(28.dp)
                    )
                    .padding(horizontal = 12.dp, vertical = 7.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(9.dp)
            ) {
                ParticleAiOrb(size = 24.dp, isListening = true, audioAmplitude = active.audioAmplitude, preset = OrbColorPreset.AURORA_CYAN)
                Text(
                    text = active.statusText,
                    color = Color.White,
                    fontSize = 12.5.sp,
                    fontWeight = FontWeight.Medium,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f, fill = false)
                )
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(14.dp))
                        .background(Color(0xFFF43F5E))
                        .clickable { onStopClick() }
                        .padding(horizontal = 10.dp, vertical = 4.dp)
                ) {
                    Text("STOP", color = Color.White, fontSize = 10.5.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun FloatingMiniOrbWidget(onTapOrb: () -> Unit, onDragDelta: (Float, Float) -> Unit) {
    val visible by AgentHudBus.floatingOrbVisible.collectAsState()
    val inForeground by AgentHudBus.isAppInForeground.collectAsState()
    val hudState by AgentHudBus.state.collectAsState()

    if (!visible || inForeground) return

    Box(
        modifier = Modifier
            .size(54.dp)
            .clip(CircleShape)
            .background(Color(0xE0060A16))
            .border(1.4.dp, Color(0xCC00E5FF), CircleShape)
            .pointerInput(Unit) {
                detectDragGestures { change, dragAmount ->
                    change.consume()
                    onDragDelta(dragAmount.x, dragAmount.y)
                }
            }
            .clickable { onTapOrb() },
        contentAlignment = Alignment.Center
    ) {
        ParticleAiOrb(
            size = 42.dp,
            isListening = hudState is AgentHudState.Active,
            audioAmplitude = (hudState as? AgentHudState.Active)?.audioAmplitude ?: 0.18f,
            preset = OrbColorPreset.AURORA_CYAN
        )
    }
}
