package com.example.voice

internal object VoiceRecoveryPolicy {
    fun retryable(code: Int, automatic: Boolean, attempts: Int): Boolean = attempts < 2 &&
        (code in setOf(1,2,3,5,8,11,12,13) || (automatic && code in setOf(6,7)))
    fun nextLocale(locale: String): String = if (locale == "en-IN") "te-IN" else "en-IN"
}
