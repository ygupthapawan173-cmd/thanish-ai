package com.example.data

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class ApiTelemetrySnapshot(
    val totalRequests: Int = 0,
    val failedRequests: Int = 0,
    val estimatedPromptTokens: Int = 0,
    val estimatedOutputTokens: Int = 0,
    val averageLatencyMs: Long = 0L,
    val lastUsedModel: String = ""
) {
    val estimatedCostUsd: Double
        get() = (estimatedPromptTokens * 0.00000015) + (estimatedOutputTokens * 0.00000060)
}

object ApiQuotaTracker {
    private val _snapshot = MutableStateFlow(ApiTelemetrySnapshot())
    val snapshot: StateFlow<ApiTelemetrySnapshot> = _snapshot.asStateFlow()

    fun recordSuccess(model: String, promptChars: Int, replyChars: Int, latencyMs: Long) {
        val cur = _snapshot.value
        val nextCount = cur.totalRequests + 1
        val avgLat = if (cur.totalRequests == 0) latencyMs else ((cur.averageLatencyMs * cur.totalRequests) + latencyMs) / nextCount
        _snapshot.value = cur.copy(
            totalRequests = nextCount,
            estimatedPromptTokens = cur.estimatedPromptTokens + (promptChars / 4).coerceAtLeast(1),
            estimatedOutputTokens = cur.estimatedOutputTokens + (replyChars / 4).coerceAtLeast(1),
            averageLatencyMs = avgLat,
            lastUsedModel = model
        )
    }

    fun recordFailure() {
        val cur = _snapshot.value
        _snapshot.value = cur.copy(
            totalRequests = cur.totalRequests + 1,
            failedRequests = cur.failedRequests + 1
        )
    }

    fun reset() {
        _snapshot.value = ApiTelemetrySnapshot()
    }
}
