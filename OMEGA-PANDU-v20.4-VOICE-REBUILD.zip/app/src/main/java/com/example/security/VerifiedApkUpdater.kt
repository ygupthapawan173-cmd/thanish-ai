package com.example.security

import android.content.Context
import android.content.Intent
import androidx.core.content.FileProvider
import java.io.File
import java.security.MessageDigest

/**
 * Verified APK Self-Update Helper (v18 Supreme):
 * Verifies SHA-256 checksum of a downloaded APK file before launching the Android package installer.
 */
object VerifiedApkUpdater {

    fun sha256OfFile(file: File): String {
        val md = MessageDigest.getInstance("SHA-256")
        file.inputStream().use { input ->
            val buf = ByteArray(8192)
            while (true) {
                val read = input.read(buf)
                if (read <= 0) break
                md.update(buf, 0, read)
            }
        }
        return md.digest().joinToString("") { "%02x".format(it) }
    }

    fun verifyAndInstall(context: Context, apkFile: File, expectedSha256: String? = null): String {
        if (!apkFile.exists()) return "APK file not found."
        if (!expectedSha256.isNullOrBlank()) {
            val actual = sha256OfFile(apkFile)
            if (!actual.equals(expectedSha256.trim(), ignoreCase = true)) {
                return "SHA-256 verification failed! Update blocked for safety."
            }
        }
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", apkFile)
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, "application/vnd.android.package-archive")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
        return "Verified APK launched for installation."
    }
}
