package com.example.ai

import com.example.data.OmegaSettings
import com.example.data.ApiQuotaTracker
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

internal class SmartGatewayClient {
    data class Reply(val text: String, val model: String)
    private data class Catalog(val url: String, val key: String, val expires: Long, val models: List<SmartModelPolicy.Model>)
    @Volatile private var cache: Catalog? = null
    private val client = OkHttpClient.Builder().followRedirects(false).followSslRedirects(false)
        .retryOnConnectionFailure(false).connectTimeout(15, TimeUnit.SECONDS).readTimeout(45, TimeUnit.SECONDS)
        .callTimeout(50, TimeUnit.SECONDS).build()
    private fun endpoint(s: OmegaSettings, suffix: String): String {
        val url = s.gatewayBaseUrl.trim().trimEnd('/').toHttpUrlOrNull() ?: throw IOException("Invalid gateway base URL")
        if (!url.isHttps || url.username.isNotEmpty() || url.password.isNotEmpty() || url.query != null || url.fragment != null) throw IOException("Gateway must be an HTTPS base URL without credentials, query or fragment")
        if (url.encodedPath.endsWith("/chat/completions") || url.encodedPath.endsWith("/models")) throw IOException("Enter the API base URL, not a request endpoint")
        return url.toString().trimEnd('/') + suffix
    }
    private fun request(s: OmegaSettings, suffix: String): Request.Builder {
        val key = s.effectiveOpenRouterKey()
        if (key.isBlank()) throw IOException("Enter and save the Smart API key")
        return Request.Builder().url(endpoint(s, suffix)).header("Authorization", "Bearer $key")
    }
    private fun price(o: JSONObject?, field: String): Double? = o?.optString(field)?.toDoubleOrNull()?.takeIf { it.isFinite() && it >= 0 }
    private fun modalities(o: JSONObject?, field: String): List<String>? = o?.optJSONArray(field)?.let { a -> (0 until a.length()).map { a.optString(it).lowercase() } }
    suspend fun discover(s: OmegaSettings, refresh: Boolean = false): List<SmartModelPolicy.Model> {
        val url = endpoint(s, "/models")
        val key = s.effectiveOpenRouterKey()
        if (!refresh) cache?.let { if (it.url == url && it.key == key && it.expires > System.currentTimeMillis()) return it.models }
        val models = client.newCall(request(s, "/models").get().build()).awaitParsed { r ->
            if (!r.isSuccessful) throw IOException("HTTP ${r.code}: gateway model discovery failed")
            val data = JSONObject(r.body?.string().orEmpty()).optJSONArray("data") ?: throw IOException("Gateway did not return an OpenAI-style data model list")
            (0 until data.length()).mapNotNull { i ->
                val m = data.optJSONObject(i) ?: return@mapNotNull null
                val id = m.optString("id").trim().takeIf { it.isNotEmpty() } ?: return@mapNotNull null
                val arch = m.optJSONObject("architecture")
                val input = modalities(arch, "input_modalities") ?: modalities(m, "input_modalities")
                val output = modalities(arch, "output_modalities") ?: modalities(m, "output_modalities")
                val pricing = m.optJSONObject("pricing")
                SmartModelPolicy.Model(id, input?.contains("image"), output?.contains("text"), price(pricing, "prompt"), price(pricing, "completion"))
            }.distinctBy { it.id }
        }
        cache = Catalog(url, key, System.currentTimeMillis() + 300_000L, models)
        return models
    }
    suspend fun answer(s: OmegaSettings, question: String, system: String, previous: List<Pair<String,String>> = emptyList(), image: String? = null): Reply {
        val task = SmartModelPolicy.task(question, !image.isNullOrBlank())
        val available = discover(s)
        val candidates = SmartModelPolicy.rank(available, task, s.smartMode, s.openRouterModel, s.manualVisionConfirmed).take(3)
        if (candidates.isEmpty()) throw IOException(if (task == SmartModelPolicy.Task.VISION) "No model advertises image input; choose a verified vision model in Manual mode and confirm image support, or use Gemini Direct" else "No eligible discovered model; check provider and model selection")
        val messages = JSONArray().put(JSONObject().put("role", "system").put("content", "$system\nYou are a text assistant; never claim to have executed device actions."))
        previous.takeLast(12).forEach { (role, text) -> messages.put(JSONObject().put("role", role).put("content", text.take(4000))) }
        val content: Any = if (image.isNullOrBlank()) question else JSONArray().put(JSONObject().put("type", "text").put("text", question)).put(JSONObject().put("type", "image_url").put("image_url", JSONObject().put("url", "data:image/jpeg;base64,$image")))
        messages.put(JSONObject().put("role", "user").put("content", content))
        var error = "No response"
        for (m in candidates) {
            val payload = JSONObject().put("model", m.id).put("messages", messages)
            // Bounded automatic fallback only for explicit retryable HTTP responses; don't replay ambiguous timeouts.
            val started = System.currentTimeMillis()
            val reply = try { client.newCall(request(s, "/chat/completions").post(payload.toString().toRequestBody("application/json".toMediaType())).build()).awaitParsed { r ->
                if (!r.isSuccessful) {
                    error = "HTTP ${r.code}: ${m.id} failed"
                    if (!SmartModelPolicy.mayTryAnother(r.code)) throw IOException(error)
                    ApiQuotaTracker.recordFailure()
                    null
                } else {
                    val json = JSONObject(r.body?.string().orEmpty())
                    val text = json.optJSONArray("choices")?.optJSONObject(0)?.optJSONObject("message")?.optString("content")?.trim().orEmpty()
                    val actualModel = json.optString("model", m.id).ifBlank { m.id }
                    val usage = json.optJSONObject("usage")
                    val prompt = usage?.optLong("prompt_tokens", -1)?.takeIf { it >= 0 }
                    val output = usage?.optLong("completion_tokens", -1)?.takeIf { it >= 0 }
                    val knownUnits = endpoint(s, "/models") == "https://openrouter.ai/api/v1/models"
                    val cost = if (knownUnits) usage?.optDouble("cost")?.takeIf { it.isFinite() && it >= 0 } ?: (if (actualModel == m.id && prompt != null && output != null && m.promptPrice != null && m.completionPrice != null) prompt * m.promptPrice + output * m.completionPrice else null) else null
                    if (text.isBlank() || text == "null") throw IOException("Gateway returned no text")
                    ApiQuotaTracker.recordSuccess(actualModel, prompt, output, System.currentTimeMillis() - started, cost)
                    Reply(text, actualModel)
                }
            }
            } catch (e: IOException) { ApiQuotaTracker.recordFailure(); throw e }
            if (reply != null) return reply
        }
        throw IOException(error)
    }
}
