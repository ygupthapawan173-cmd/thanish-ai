package com.example.control

import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.view.Gravity
import android.view.WindowManager
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import com.example.MainActivity
import com.example.data.OrbColorPreset
import com.example.ui.components.ParticleAiOrb
import com.example.ui.components.InfinityRenderQuality
import kotlinx.coroutines.launch

class AgentOverlayController(private val serviceContext: Context) {
    private val windowManager = serviceContext.getSystemService(WindowManager::class.java)
    private var lifecycleOwner: OverlayLifecycleOwner? = null
    private var pillView: ComposeView? = null
    private var prefs: com.example.data.OmegaPreferences? = null

    fun attachOverlays() {
        if (pillView != null) return
        val owner = OverlayLifecycleOwner()
        val preferences = com.example.data.OmegaPreferences(serviceContext)
        prefs = preferences
        lifecycleOwner = owner
        try {
            owner.onCreate(); owner.onResume()
            val params = WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT
            ).apply { gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; y = (56 * serviceContext.resources.displayMetrics.density).toInt() }
            val view = ComposeView(serviceContext).apply {
                setViewTreeLifecycleOwner(owner)
                setViewTreeSavedStateRegistryOwner(owner)
                setContent {
                    val settings by preferences.settings.collectAsState()
                    InfinityRenderQuality(settings.renderQuality) { DynamicIslandStatusPill(settings.orbColorPreset) { AgentHudBus.triggerAbort() } }
                }
            }
            pillView = view
            windowManager.addView(view, params)
        } catch (e: Exception) {
            android.util.Log.w("InfinityOverlay", "Status pill unavailable", e)
            detachOverlays()
        }
    }

    fun detachOverlays() {
        pillView?.let { runCatching { windowManager.removeViewImmediate(it) }; it.disposeComposition() }
        pillView = null
        lifecycleOwner?.let { runCatching { it.onDestroy() } }
        lifecycleOwner = null
        prefs?.close()
        prefs = null
    }
}

@Composable
private fun DynamicIslandStatusPill(preset: OrbColorPreset, onStopClick: () -> Unit) {
    val state by AgentHudBus.state.collectAsState()
    val inForeground by AgentHudBus.isAppInForeground.collectAsState()
    val active = state as? AgentHudState.Active
    // NEVER overlap OMEGA's own header when app is in foreground!
    AnimatedVisibility(visible = active != null && !inForeground, enter = fadeIn(), exit = fadeOut()) {
        if (active != null) {
            Row(
                modifier = Modifier
                    .widthIn(max = 310.dp)
                    .clip(RoundedCornerShape(28.dp))
                    .background(Color(preset.surfaceHex))
                    .border(
                        width = 1.2.dp,
                        brush = Brush.horizontalGradient(listOf(Color(preset.primaryHex), Color(preset.secondaryHex), Color(preset.accentHex))),
                        shape = RoundedCornerShape(28.dp)
                    )
                    .padding(horizontal = 12.dp, vertical = 7.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(9.dp)
            ) {
                ParticleAiOrb(size = 24.dp, isListening = true, audioAmplitude = active.audioAmplitude, preset = preset)
                Text(
                    text = active.statusText,
                    color = Color.White,
                    fontSize = 12.5.sp,
                    fontWeight = FontWeight.Medium,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f, fill = false)
                )
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(14.dp))
                        .background(Color(0xFFF43F5E))
                        .clickable { onStopClick() }
                        .padding(horizontal = 12.dp, vertical = 12.dp)
                ) {
                    Text("STOP", color = Color.White, fontSize = 10.5.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

