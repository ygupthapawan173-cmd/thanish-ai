package com.example.omega

import android.Manifest
import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.os.*
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.example.MainActivity
import com.example.control.AgentHudBus
import com.example.control.AgentHudState
import com.example.control.PhoneControlManager
import com.example.control.DeviceActionExecutor
import com.example.ai.PanduAiRepository
import com.example.data.AppDatabase
import com.example.voice.BackgroundVoicePolicy
import com.example.voice.VoiceInputController
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import com.example.data.OmegaPreferences
import com.example.voice.TeluguTtsController
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.first
import org.json.JSONArray
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.android.RecognitionListener
import org.vosk.android.SpeechService
import org.vosk.android.StorageService

/** User-enabled microphone foreground service with bounded hands-free background turns. */
class OmegaWakeService: Service() {
    private val handler = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(SupervisorJob()+Dispatchers.Main.immediate)
    private lateinit var prefs: OmegaPreferences
    private lateinit var smartTriggers: SmartTriggerManager
    private lateinit var tts: TeluguTtsController
    private var model: Model? = null
    private var rec: Recognizer? = null
    private var speech: SpeechService? = null
    private var loading = false
    private var closed = false
    private var started = false
    private var epoch = 0L
    private var retries = 0
    private var waitForTap = false
    private var wakePhrase = ""
    private var backgroundActive = false
    private var backgroundToken = 0L
    private var backgroundJob: Job? = null
    private var captureJob: Job? = null
    private var backgroundTurns = 0
    private var commandFallback = false
    private var commandCapture = false
    private var commandSpeech: SpeechService? = null
    private var commandRecognizer: Recognizer? = null
    private lateinit var voiceInput: VoiceInputController
    private lateinit var database: AppDatabase
    private lateinit var repository: PanduAiRepository
    private lateinit var phone: PhoneControlManager
    private val readyToSpeak = MutableStateFlow(false)
    private fun backgroundAllowed() = started && !closed && prefs.settings.value.wakeWordEnabled && !prefs.settings.value.micPrivacyMuted && ContextCompat.checkSelfPermission(this,Manifest.permission.RECORD_AUDIO)==PackageManager.PERMISSION_GRANTED

    override fun onCreate() {
        super.onCreate(); instance = this
        prefs = OmegaPreferences(this); smartTriggers = SmartTriggerManager(this); tts = TeluguTtsController(this, backgroundOwned=true)
        database=AppDatabase(this); phone=PhoneControlManager(this)
        repository=PanduAiRepository({ prefs.settings.value }, DeviceActionExecutor(this,database,prefs),database)
        voiceInput=VoiceInputController(this,owner="background-capture") { text -> if(backgroundActive && commandCapture) acceptCommand(text) }
        scope.launch { voiceInput.state.collect { v ->
            if(backgroundActive && commandCapture && !commandFallback) {
                if(v.isListening) { if(status.value != v.diagnosticsNote) publish(v.diagnosticsNote); AgentHudBus.updateState(AgentHudState.Active("Listening…", audioAmplitude=v.audioAmplitude)) }
                else if(v.errorMessage!=null) fallbackCommand(v.errorMessage)
            }
        } }
        scope.launch { AgentHudBus.abortSignal.collect { if(backgroundActive) endBackground("Conversation stopped") } }
        smartTriggers.register()
        getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel(CHANNEL,"OMEGA offline wake",NotificationManager.IMPORTANCE_LOW))
        scope.launch { AgentHudBus.isMainMicBusy.collect { if(it) { if(!backgroundActive) { waitForTap=false; pause() } } else schedule(700) } }
        scope.launch { AgentHudBus.isTtsBusy.collect { if(it) { if(!backgroundActive) pause() } else schedule(700) } }
        scope.launch { prefs.settings.collect { s ->
            if (!s.wakeWordEnabled && started) { endBackground("Wake disabled"); stopSelf(); return@collect }
            if (s.micPrivacyMuted) { endBackground("Microphone muted"); pause() } else { if(wakePhrase != s.wakeWord.trim().lowercase()) { pause(); retries=0 }; schedule(500) }
        } }
        scope.launch { SmartTriggerBus.events.collect { event ->
            val s=prefs.settings.value
            if(!AgentHudBus.isAppInForeground.value && !backgroundActive && !AgentHudBus.isMainMicBusy.value && !AgentHudBus.isTtsBusy.value && s.autoSpeak) { tts.configure(s.languageTag,s.ttsSpeed,s.ttsPitch,s.ttsStyle); tts.speak(event.announcement) }
        } }
    }
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if(intent?.action == END_SESSION) { endBackground("Conversation stopped"); return START_NOT_STICKY }
        if(intent?.action == RESTART && started) { endBackground("Restarting wake engine"); pause(); retries=0; schedule(500); return START_NOT_STICKY }
        if(intent?.action == STOP) { endBackground("Wake disabled"); prefs.update { it.copy(wakeWordEnabled=false) }; stopSelf(); return START_NOT_STICKY }
        if(!prefs.settings.value.wakeWordEnabled || ContextCompat.checkSelfPermission(this,Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED) { stopSelf(); return START_NOT_STICKY }
        try { if(Build.VERSION.SDK_INT>=29) startForeground(ID, notification("Loading offline wake model"),ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE) else startForeground(ID,notification("Loading offline wake model")) }
        catch(_:Exception) { status.value="Microphone foreground service blocked"; stopSelf(); return START_NOT_STICKY }
        started=true
        if(model!=null) schedule(0) else if(!loading) {
            loading=true; publish("Loading offline Vosk model")
            StorageService.unpack(this,"model-en-us","omega-vosk-en",{m -> loading=false; if(closed) m.close() else {model=m; schedule(200)}},{_ -> loading=false; if(!closed) fail("Offline wake model unavailable")})
        }
        return START_NOT_STICKY
    }
    private fun canListen(): Boolean = started && !closed && !waitForTap && !backgroundActive && prefs.settings.value.wakeWordEnabled && !prefs.settings.value.micPrivacyMuted && !AgentHudBus.isMainMicBusy.value && !AgentHudBus.isTtsBusy.value
    private fun schedule(ms:Long) {
        if(!canListen() || model==null || speech!=null) return
        val token=++epoch; handler.postDelayed({if(token==epoch && canListen() && speech==null) arm()},ms)
    }
    private fun pause() {
        ++epoch; val old=speech; speech=null
        runCatching { old?.cancel() }; runCatching { old?.shutdown() }; runCatching { rec?.close() }; rec=null
        if(started&&!closed&&!waitForTap) publish(if(prefs.settings.value.micPrivacyMuted) "Microphone muted" else "Wake paused")
    }
    private fun arm() {
        val m=model?:return
        wakePhrase=prefs.settings.value.wakeWord.lowercase().trim()
        val phrase=wakePhrase.replace(Regex("\\s+")," ")
        if(!phrase.matches(Regex("[a-z]+( [a-z]+){1,5}"))) { fail("Use a 2–6 word English wake phrase"); return }
        try {
            val phrases=if(phrase=="hey jarvis") listOf(phrase,"hey jervis","hey jar vis","hey jar vice") else listOf(phrase)
            val r=Recognizer(m,16000f,JSONArray(phrases+"[unk]").toString()); rec=r; r.setWords(true)
            val service=SpeechService(r,16000f); speech=service; val token=++epoch
            val threshold=(0.85-0.35*prefs.settings.value.wakeSensitivity.coerceIn(0.2f,1f).toDouble()).coerceIn(0.5,0.8)
            fun current()=token==epoch && canListen()
            val listener=object:RecognitionListener {
                override fun onPartialResult(hypothesis:String?)=Unit
                override fun onResult(hypothesis:String?) {
                    if(!current()) return
                    val json=runCatching { JSONObject(hypothesis.orEmpty()) }.getOrNull()?:return
                    val heard=json.optString("text").trim(); val words=json.optJSONArray("result")?:return
                    if(heard !in phrases || words.length()!=heard.split(" ").size || (0 until words.length()).any { (words.optJSONObject(it)?.optDouble("conf",0.0)?:0.0)<threshold }) return
                    waitForTap=true; pause(); retries=0
                    if(AgentHudBus.isAppInForeground.value) {
                        waitForTap=false; AgentHudBus.emitWakeTrigger(""); schedule(1800)
                    } else {
                        waitForTap=false; startBackground()
                    }
                }
                override fun onFinalResult(hypothesis:String?)=onResult(hypothesis)
                override fun onError(exception:Exception?) { if(current()) recover() }
                override fun onTimeout() { if(current()) recover() }
            }
            check(service.startListening(listener)); publish("Offline listening: $phrase")
        } catch(_:Exception) { recover() } catch(_:LinkageError) { fail("Vosk native library unavailable") }
    }
    private fun startBackground() {
        if(!backgroundAllowed() || backgroundActive || AgentHudBus.isMainMicBusy.value || AgentHudBus.isTtsBusy.value) { schedule(700); return }
        backgroundActive=true; backgroundTurns=0; val token=++backgroundToken
        AgentHudBus.setMainMicBusy(true,"background-session")
        publish("Hey JARVIS — preparing command microphone")
        AgentHudBus.updateState(AgentHudState.Active("Hey JARVIS — listening"))
        handler.postDelayed({ if(token==backgroundToken && backgroundActive) listenCommand() }, 500)
    }
    private fun listenCommand() {
        if(!backgroundAllowed() || !backgroundActive) { endBackground("Wake paused"); return }
        commandCapture=true; commandFallback=false
        val s=prefs.settings.value
        publish("Speak now — background command")
        voiceInput.startListening(s.languageTag,preferOffline=s.localBrainMode,timeoutMs=9000L)
        val token=backgroundToken
        captureJob?.cancel(); captureJob=scope.launch { delay(34000); if(token==backgroundToken && commandCapture) endBackground("Command timed out") }
    }
    private fun fallbackCommand(reason:String) {
        if(!backgroundActive || !commandCapture || commandFallback) return
        commandFallback=true; voiceInput.stopListening()
        if(prefs.settings.value.languageTag=="te-IN") { speakReply("Telugu speech recognition is unavailable. Please check your speech language pack.",false); return }
        val m=model ?: run { endBackground(reason); return }
        val token=backgroundToken
        publish("Offline English command fallback — speak again")
        handler.postDelayed({
            if(token!=backgroundToken || !backgroundActive || !commandCapture || !backgroundAllowed()) return@postDelayed
            try {
                val r=Recognizer(m,16000f); commandRecognizer=r
                val service=SpeechService(r,16000f); commandSpeech=service
                fun current()=token==backgroundToken && backgroundActive && commandCapture && commandSpeech===service
                fun result(h:String?) { if(!current()) return; val text=runCatching { JSONObject(h.orEmpty()).optString("text") }.getOrDefault("").trim(); if(text.isNotBlank()) acceptCommand(text) }
                check(service.startListening(object:RecognitionListener {
                    override fun onPartialResult(hypothesis:String?)=Unit
                    override fun onResult(hypothesis:String?)=result(hypothesis)
                    override fun onFinalResult(hypothesis:String?)=result(hypothesis)
                    override fun onError(exception:Exception?) { if(current()) endBackground("Offline command microphone failed") }
                    override fun onTimeout() { if(current()) endBackground("No speech — wake listening resumed") }
                },8000))
            } catch(_:Exception) { endBackground("Offline command unavailable") }
        },450)
    }
    private fun stopCommandCapture() {
        commandCapture=false; captureJob?.cancel(); captureJob=null; voiceInput.stopListening()
        val old=commandSpeech; commandSpeech=null
        runCatching { old?.cancel() }; runCatching { old?.shutdown() }; runCatching { commandRecognizer?.close() }; commandRecognizer=null
    }
    private fun acceptCommand(raw:String) {
        if(!backgroundActive || !commandCapture || !backgroundAllowed()) return
        stopCommandCapture(); backgroundTurns++
        val token=backgroundToken
        val action=BackgroundVoicePolicy.classify(raw)
        if(action==BackgroundVoicePolicy.Action.STOP) { endBackground("Conversation stopped"); return }
        publish("Thinking — background voice")
        AgentHudBus.updateState(AgentHudState.Active("Thinking…",isThinking=true))
        backgroundJob=scope.launch {
            val te=raw.any { it in '\u0C00'..'\u0C7F' }
            val reply=when(action) {
                BackgroundVoicePolicy.Action.TIME -> (if(te) "ఇప్పుడు సమయం " else "The time is ")+SimpleDateFormat("hh:mm a",Locale.getDefault()).format(Date())
                BackgroundVoicePolicy.Action.DATE -> (if(te) "ఈరోజు తేదీ " else "Today is ")+SimpleDateFormat("dd MMM yyyy",Locale.getDefault()).format(Date())
                BackgroundVoicePolicy.Action.BATTERY -> if(te) "బ్యాటరీ ${phone.getBatteryPercent()} శాతం" else "Battery is ${phone.getBatteryPercent()} percent."
                BackgroundVoicePolicy.Action.TORCH_ON, BackgroundVoicePolicy.Action.TORCH_OFF -> runCatching { phone.setFlashlight(action==BackgroundVoicePolicy.Action.TORCH_ON) }.getOrDefault("Flashlight unavailable")
                BackgroundVoicePolicy.Action.GREETING -> if(te) "నమస్తే, చెప్పండి." else "Hello, how can I help?"
                else -> withTimeoutOrNull(35000) { repository.answerBackgroundQuestion(raw).getOrNull() } ?: if(te) "AI సమాధానం అందుబాటులో లేదు. యాప్‌లో సెట్టింగ్స్ చూడండి." else "AI answer unavailable. Check the connection or open the app."
            }
            if(token==backgroundToken && backgroundActive && backgroundAllowed()) speakReply(reply,true)
        }
    }
    private fun speakReply(text:String, allowFollowUp:Boolean) {
        if(!backgroundActive || !backgroundAllowed()) { endBackground("Wake paused"); return }
        stopCommandCapture()
        val s=prefs.settings.value; val token=backgroundToken
        if(!s.autoSpeak) { endBackground("Voice reply disabled in settings"); return }
        publish("Speaking — background voice")
        AgentHudBus.updateState(AgentHudState.Active("Speaking…"))
        readyToSpeak.value=false
        tts.configure(s.languageTag,s.ttsSpeed,s.ttsPitch,s.ttsStyle)
        tts.setOnSpeechFinished { readyToSpeak.value=true }
        tts.speak(text.take(700))
        scope.launch {
            val finished=withTimeoutOrNull(25000) { readyToSpeak.first { it }; true } ?: false
            if(token!=backgroundToken || !backgroundActive) return@launch
            if(!finished) { endBackground("Speaker unavailable or timed out"); return@launch }
            delay(550)
            if(token!=backgroundToken || !backgroundActive) return@launch
            if(allowFollowUp && BackgroundVoicePolicy.followUp(prefs.settings.value.continuousConversation,backgroundTurns)) listenCommand()
            else endBackground("Conversation complete")
        }
    }
    private fun endBackground(message:String) {
        if(!backgroundActive) return
        backgroundActive=false; ++backgroundToken; backgroundJob?.cancel(); backgroundJob=null
        stopCommandCapture(); tts.setOnSpeechFinished(null); tts.stop()
        AgentHudBus.setMainMicBusy(false,"background-session"); AgentHudBus.updateState(AgentHudState.Hidden)
        if(!closed) { publish(message); schedule(700) }
    }
    private fun recover() { pause(); if(++retries>2) fail("Wake microphone failed after two retries") else { publish("Wake recovery $retries/2"); schedule(if(retries==1) 700 else 1800) } }
    private fun fail(message:String) { status.value=message; prefs.update { it.copy(wakeWordEnabled=false) }; stopSelf() }
    private fun publish(message:String,detected:Boolean=false) { status.value=message; runCatching { getSystemService(NotificationManager::class.java).notify(ID,notification(message,detected)) } }
    private fun notification(message:String,detected:Boolean=false):Notification {
        val open=Intent(this,MainActivity::class.java).apply { flags=Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP; putExtra(MainActivity.EXTRA_START_LISTENING,detected) }
        val tap=PendingIntent.getActivity(this,1,open,PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val end=PendingIntent.getService(this,3,Intent(this,OmegaWakeService::class.java).setAction(END_SESSION),PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val restart=PendingIntent.getService(this,4,Intent(this,OmegaWakeService::class.java).setAction(RESTART),PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val stop=PendingIntent.getService(this,2,Intent(this,OmegaWakeService::class.java).setAction(STOP),PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(this,CHANNEL).setSmallIcon(android.R.drawable.ic_btn_speak_now).setContentTitle("OMEGA • Offline Wake").setContentText(message).setContentIntent(tap).setOngoing(true).setVisibility(NotificationCompat.VISIBILITY_PRIVATE).addAction(android.R.drawable.ic_menu_close_clear_cancel,"Stop microphone",stop).addAction(android.R.drawable.ic_media_pause,"End conversation",end).addAction(android.R.drawable.ic_popup_sync,"Restart wake",restart).build()
    }
    override fun onDestroy() { closed=true; endBackground("Stopped"); voiceInput.release(); pause(); handler.removeCallbacksAndMessages(null); scope.cancel(); smartTriggers.unregister(); tts.release(); database.close(); runCatching { model?.close() }; model=null; instance=null; if(!status.value.contains("failed")&&!status.value.contains("unavailable")&&!status.value.contains("blocked")&&!status.value.startsWith("Use a")) status.value="Stopped"; stopForeground(STOP_FOREGROUND_REMOVE); super.onDestroy() }
    override fun onBind(intent:Intent?):IBinder?=null
    companion object {
        private const val CHANNEL="omega_offline_wake_v202"; private const val ID=3191; private const val STOP="com.example.omega.STOP_WAKE"
        private const val END_SESSION="com.example.omega.END_SESSION"; private const val RESTART="com.example.omega.RESTART_WAKE"
        private var instance:OmegaWakeService?=null
        val status=MutableStateFlow("Stopped")
        fun isBackgroundConversationActive() = instance?.backgroundActive == true
        fun stopBackgroundConversation() { instance?.endBackground("Conversation stopped") }
        fun pauseForManual() { instance?.let { it.endBackground("Manual microphone requested"); it.waitForTap=false; it.pause() } }
        fun start(context:Context) { ContextCompat.startForegroundService(context,Intent(context,OmegaWakeService::class.java)) }
        fun stop(context:Context) { context.stopService(Intent(context,OmegaWakeService::class.java)) }
    }
}
