package com.example.ai

import android.annotation.SuppressLint
import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.NoiseSuppressor
import android.util.Base64
import com.example.control.AgentHudBus
import com.example.voice.BluetoothAudioRouter
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay
import android.os.Handler
import android.os.Looper
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import okio.ByteString
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit
import kotlin.math.sqrt

data class LiveDuplexState(
    val isConnected: Boolean = false,
    val isConnecting: Boolean = false,
    val isAiSpeaking: Boolean = false,
    val amplitude: Float = 0f,
    val statusText: String = "Live Voice Idle",
    val error: String? = null
)

class GeminiLiveDuplexEngine(
    context: Context,
    private val apiKeyProvider: () -> String,
    private val liveModelProvider: () -> String,
    private val bluetoothRoutingEnabledProvider: () -> Boolean
) {
    private val btRouter = BluetoothAudioRouter(context)
    private val httpClient = OkHttpClient.Builder()
        .readTimeout(0, TimeUnit.MILLISECONDS)
        .pingInterval(20, TimeUnit.SECONDS)
        .build()

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    @Volatile private var webSocket: WebSocket? = null
    private val main = Handler(Looper.getMainLooper())
    private var session = 0L
    private var setupTimeout: Job? = null
    private var audioRecord: AudioRecord? = null
    private var audioTrack: AudioTrack? = null
    private var aec: AcousticEchoCanceler? = null
    private var ns: NoiseSuppressor? = null
    private var captureJob: Job? = null

    private val _state = MutableStateFlow(LiveDuplexState())
    val state: StateFlow<LiveDuplexState> = _state.asStateFlow()

    @Synchronized fun connect() {
        val apiKey = apiKeyProvider().trim()
        if (apiKey.isBlank()) {
            _state.value = LiveDuplexState(error = "Add your Gemini API key in Settings for Live Voice.")
            return
        }

        disconnect()
        AgentHudBus.setMainMicBusy(true, "live")
        com.example.omega.OmegaWakeService.pauseForManual()
        val token = ++session
        btRouter.routeToBluetoothIfAvailable(bluetoothRoutingEnabledProvider())
        val rawModel = liveModelProvider().trim().ifEmpty { "gemini-3.8-live" }
        val modelPath = if (rawModel.startsWith("models/")) rawModel else "models/$rawModel"
        _state.value = LiveDuplexState(isConnecting = true, statusText = "Connecting Live Voice...")

        val url = "wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContent?key=$apiKey"
        try {
            webSocket = httpClient.newWebSocket(Request.Builder().url(url).build(), object : WebSocketListener() {
                override fun onOpen(webSocket: WebSocket, response: Response) {
                    synchronized(this@GeminiLiveDuplexEngine) {
                        if (token != session || this@GeminiLiveDuplexEngine.webSocket !== webSocket) return
                        val setup = JSONObject().put("setup", JSONObject().put("model", modelPath)
                            .put("generationConfig", JSONObject().put("responseModalities", JSONArray().put("AUDIO"))))
                        if (!webSocket.send(setup.toString())) fail(token,"Live setup send failed")
                    }
                }
                override fun onMessage(webSocket: WebSocket, text: String) = receive(token,webSocket,text)
                override fun onMessage(webSocket: WebSocket, bytes: ByteString) = receive(token,webSocket,bytes.utf8())
                override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                    fail(token, "Live connection failed${response?.let { " (HTTP ${it.code})" }.orEmpty()}")
                }
                override fun onClosed(webSocket: WebSocket, code: Int, reason: String) { fail(token,"Live session closed ($code)") }
                override fun onClosing(webSocket: WebSocket, code: Int, reason: String) { fail(token,"Live server closed session ($code)") }
            })
            setupTimeout = scope.launch { delay(12000); synchronized(this@GeminiLiveDuplexEngine) { if(token==session && !_state.value.isConnected) fail(token,"Live setup timeout") } }
        } catch(_:Exception) { fail(token,"Unable to start Live connection") }
    }

    @Synchronized private fun receive(token:Long, ws:WebSocket, text:String) {
        if(token!=session || webSocket!==ws) return
        val json=runCatching { JSONObject(text) }.getOrNull() ?: return
        if(json.has("error")) { fail(token,"Live API rejected the session"); return }
        if(json.has("setupComplete") && !_state.value.isConnected) {
            setupTimeout?.cancel(); setupTimeout=null
            // Wait for the offline wake recorder to release before opening Live mic.
            main.postDelayed({ synchronized(this@GeminiLiveDuplexEngine) {
                if(token==session && webSocket===ws && !_state.value.isConnected) {
                    runCatching { initPlayback(); startMicStream(ws,token); _state.value=LiveDuplexState(isConnected=true,statusText="Live Voice Active") }
                        .onFailure { fail(token,"Live microphone or audio initialization failed") }
                }
            } },450)
        } else if(_state.value.isConnected) handleMessage(text)
    }

    @Synchronized private fun fail(token:Long, message:String) {
        if(token!=session) return
        disconnect()
        _state.value=LiveDuplexState(error=message,statusText="Disconnected")
    }

    private fun handleMessage(raw: String) {
        try {
            val sc = JSONObject(raw).optJSONObject("serverContent") ?: return
            if (sc.optBoolean("interrupted", false)) {
                audioTrack?.pause(); audioTrack?.flush(); audioTrack?.play()
                _state.value = _state.value.copy(isAiSpeaking = false, statusText = "Listening...")
                return
            }
            val parts = sc.optJSONObject("modelTurn")?.optJSONArray("parts")
            if (parts != null) {
                for (i in 0 until parts.length()) {
                    val inline = parts.getJSONObject(i).optJSONObject("inlineData") ?: continue
                    if (inline.optString("mimeType", "").startsWith("audio/pcm")) {
                        val pcm = Base64.decode(inline.optString("data"), Base64.DEFAULT)
                        _state.value = _state.value.copy(isAiSpeaking = true, statusText = "OMEGA Speaking...")
                        var offset=0
                        while(offset<pcm.size) { val n=audioTrack?.write(pcm,offset,pcm.size-offset) ?: break; if(n<=0) break; offset+=n }
                    }
                }
            }
            if (sc.optBoolean("turnComplete", false)) {
                _state.value = _state.value.copy(isAiSpeaking = false, statusText = "Listening...")
            }
        } catch (_: Exception) {}
    }

    private fun initPlayback() {
        val rate = 24000
        val minBuf = AudioTrack.getMinBufferSize(rate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT).coerceAtLeast(4096)
        audioTrack = AudioTrack.Builder()
            .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
            .setAudioFormat(AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT).setSampleRate(rate).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
            .setBufferSizeInBytes(minBuf)
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build()
        audioTrack?.play()
    }

    @SuppressLint("MissingPermission")
    private fun startMicStream(ws: WebSocket, token: Long) {
        val rate = 16000
        val minBuf = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT).coerceAtLeast(3200)
        val rec = AudioRecord(MediaRecorder.AudioSource.VOICE_COMMUNICATION, rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, minBuf)
        audioRecord = rec
        check(rec.state == AudioRecord.STATE_INITIALIZED)
        val effects = BluetoothAudioRouter.attachAudioEffects(rec.audioSessionId)
        aec = effects.first; ns = effects.second
        rec.startRecording()
        check(rec.recordingState == AudioRecord.RECORDSTATE_RECORDING)

        captureJob?.cancel()
        captureJob = scope.launch {
            val buf = ByteArray(3200)
            while (isActive && rec.recordingState == AudioRecord.RECORDSTATE_RECORDING) {
                val read = rec.read(buf, 0, buf.size)
                if (read > 0) {
                    _state.value = _state.value.copy(amplitude = computeRms(buf, read))
                    val b64 = Base64.encodeToString(buf, 0, read, Base64.NO_WRAP)
                    val payload = JSONObject().put(
                        "realtimeInput",
                        JSONObject().put("audio", JSONObject().put("mimeType", "audio/pcm;rate=16000").put("data", b64))
                    )
                    if(!ws.send(payload.toString())) { main.post { fail(token,"Live audio send failed") }; break }
                } else if(read < 0) { main.post { fail(token,"Live microphone read failed ($read)") }; break }
            }
        }
    }

    private fun computeRms(pcm: ByteArray, len: Int): Float {
        var sum = 0.0; var count = 0; var i = 0
        while (i + 1 < len) {
            val s = ((pcm[i + 1].toInt() shl 8) or (pcm[i].toInt() and 0xFF)).toShort().toDouble()
            sum += s * s; count++; i += 2
        }
        return if (count == 0) 0f else (sqrt(sum / count) / 8000.0).toFloat().coerceIn(0f, 1f)
    }

    @Synchronized fun disconnect() {
        ++session; setupTimeout?.cancel(); setupTimeout=null
        val old=webSocket; webSocket=null; old?.cancel()
        cleanupAudio()
        btRouter.clearRouting()
        AgentHudBus.setMainMicBusy(false, "live")
        _state.value = LiveDuplexState()
    }

    private fun cleanupAudio() {
        captureJob?.cancel(); captureJob = null
        runCatching { aec?.release(); ns?.release() }; aec = null; ns = null
        runCatching { audioRecord?.stop(); audioRecord?.release() }; audioRecord = null
        runCatching { audioTrack?.stop(); audioTrack?.release() }; audioTrack = null
    }

    fun release() { disconnect(); scope.cancel() }
}
