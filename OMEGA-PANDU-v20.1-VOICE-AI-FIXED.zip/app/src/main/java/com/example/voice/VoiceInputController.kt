package com.example.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import com.example.control.AgentHudBus
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class VoiceInputState(
    val isListening: Boolean = false,
    val partialTranscript: String = "",
    val audioAmplitude: Float = 0f,
    val lastErrorCode: Int = 0,
    val errorMessage: String? = null,
    val activeLocale: String = "en-IN",
    val diagnosticsNote: String = "Ready"
)

/**
 * Rock-Solid In-Process Speech Recognizer (v20.1):
 * - Fixes Error 5 (ERROR_CLIENT) & Error 11 (ERROR_SERVER_DISCONNECTED) with clean teardown + retry
 * - Zero hidden/OEM-breaking extras; clean en-IN / te-IN recognition
 */
class VoiceInputController(
    private val context: Context,
    private val onFinalTranscript: (String) -> Unit
) {
    private val appContext = context.applicationContext
    private val mainHandler = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null
    private var retryCount = 0
    private var lastRequestedLanguage = "auto"
    private var lastPreferOffline = false
    private var isStartingOrListening = false

    private val _state = MutableStateFlow(VoiceInputState())
    val state: StateFlow<VoiceInputState> = _state.asStateFlow()

    fun startListening(languageTag: String = "auto", preferOffline: Boolean = false) {
        lastRequestedLanguage = languageTag
        lastPreferOffline = preferOffline
        retryCount = 0
        mainHandler.removeCallbacksAndMessages(null)
        AgentHudBus.setMainMicBusy(true)
        destroyInternal()
        // Wait 280ms so background wake service & previous recognizer release audio hardware cleanly
        mainHandler.postDelayed({ startInternal(languageTag, preferOffline) }, 280L)
    }

    private fun startInternal(languageTag: String, preferOffline: Boolean) {
        if (!SpeechRecognizer.isRecognitionAvailable(appContext)) {
            AgentHudBus.setMainMicBusy(false)
            _state.value = VoiceInputState(
                errorMessage = "Android Speech Recognition unavailable. Enable Google app / Speech Services in Android Settings."
            )
            return
        }

        destroyInternal()
        val effectiveLocale = when (languageTag) {
            "te-IN" -> "te-IN"
            else -> "en-IN"
        }

        val sr = runCatching { SpeechRecognizer.createSpeechRecognizer(appContext) }.getOrNull()
        if (sr == null) {
            AgentHudBus.setMainMicBusy(false)
            _state.value = VoiceInputState(errorMessage = "Could not initialize SpeechRecognizer.")
            return
        }
        recognizer = sr
        isStartingOrListening = true

        sr.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {
                retryCount = 0
                _state.value = VoiceInputState(
                    isListening = true,
                    audioAmplitude = 0.16f,
                    activeLocale = effectiveLocale,
                    diagnosticsNote = "Listening ($effectiveLocale)"
                )
            }

            override fun onBeginningOfSpeech() {
                _state.value = _state.value.copy(isListening = true)
            }

            override fun onRmsChanged(rmsdB: Float) {
                _state.value = _state.value.copy(audioAmplitude = ((rmsdB + 2f) / 12f).coerceIn(0f, 1f))
            }

            override fun onBufferReceived(buffer: ByteArray?) = Unit
            override fun onEndOfSpeech() {
                isStartingOrListening = false
                _state.value = _state.value.copy(isListening = false, audioAmplitude = 0f)
            }

            override fun onError(error: Int) {
                isStartingOrListening = false
                // Auto-recover from Error 5 (ERROR_CLIENT), Error 8 (BUSY), and Error 11 (SERVER_DISCONNECTED)
                val retryable = error == SpeechRecognizer.ERROR_CLIENT ||
                    error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY ||
                    error == 11

                if (retryable && retryCount < 2) {
                    retryCount++
                    _state.value = _state.value.copy(
                        isListening = false,
                        lastErrorCode = error,
                        diagnosticsNote = "Auto-recovering code $error (retry #$retryCount)..."
                    )
                    destroyInternal()
                    mainHandler.postDelayed({ startInternal(lastRequestedLanguage, false) }, 500L)
                    return
                }

                AgentHudBus.setMainMicBusy(false)
                val msg = when (error) {
                    SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Microphone permission required. Allow Mic in Settings."
                    SpeechRecognizer.ERROR_AUDIO -> "Microphone audio error. Close other recording apps."
                    SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Network error during speech recognition."
                    SpeechRecognizer.ERROR_NO_MATCH -> "Didn't catch that. Tap mic to speak again."
                    SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "No speech heard. Tap mic and speak closer."
                    SpeechRecognizer.ERROR_CLIENT -> "Speech client busy (code 5). Turn off Background Wake or check Google Speech Services."
                    SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "Speech recognizer busy. Wait 1 second and tap mic."
                    11 -> "Speech server disconnected (Error 11). Tap mic to reconnect."
                    else -> "Voice recognition code $error"
                }
                _state.value = _state.value.copy(
                    isListening = false,
                    audioAmplitude = 0f,
                    lastErrorCode = error,
                    errorMessage = msg,
                    diagnosticsNote = "Error $error"
                )
            }

            override fun onResults(results: Bundle?) {
                isStartingOrListening = false
                AgentHudBus.setMainMicBusy(false)
                val final = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.trim().orEmpty()
                _state.value = _state.value.copy(
                    isListening = false,
                    partialTranscript = final,
                    audioAmplitude = 0f,
                    errorMessage = null,
                    diagnosticsNote = "Captured (${final.length} chars)"
                )
                if (final.isNotEmpty()) onFinalTranscript(final)
            }

            override fun onPartialResults(partialResults: Bundle?) {
                val p = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.trim().orEmpty()
                if (p.isNotEmpty()) _state.value = _state.value.copy(partialTranscript = p)
            }

            override fun onEvent(eventType: Int, params: Bundle?) = Unit
        })

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, effectiveLocale)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, appContext.packageName)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            if (preferOffline) {
                putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
            }
        }
        runCatching { sr.startListening(intent) }.onFailure {
            isStartingOrListening = false
            AgentHudBus.setMainMicBusy(false)
            _state.value = _state.value.copy(isListening = false, errorMessage = it.message)
        }
    }

    fun stopListening() {
        mainHandler.removeCallbacksAndMessages(null)
        mainHandler.post {
            isStartingOrListening = false
            runCatching { recognizer?.stopListening() }
            AgentHudBus.setMainMicBusy(false)
            _state.value = _state.value.copy(isListening = false, audioAmplitude = 0f)
        }
    }

    fun release() {
        mainHandler.removeCallbacksAndMessages(null)
        mainHandler.post {
            isStartingOrListening = false
            destroyInternal()
            AgentHudBus.setMainMicBusy(false)
        }
    }

    private fun destroyInternal() {
        runCatching { recognizer?.cancel() }
        runCatching { recognizer?.destroy() }
        recognizer = null
    }
}
