package com.example.voice

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioManager
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import com.example.data.TtsEmotionStyle
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale
import java.util.UUID

class TeluguTtsController(context: Context) {

    private val appContext = context.applicationContext
    private var tts: TextToSpeech? = null
    private var isReady = false
    private var pendingUtterance: String? = null
    private var onSpeechFinishedCallback: (() -> Unit)? = null

    private val _isSpeaking = MutableStateFlow(false)
    val isSpeaking: StateFlow<Boolean> = _isSpeaking.asStateFlow()

    private val _ttsStatus = MutableStateFlow("Initializing TTS...")
    val ttsStatus: StateFlow<String> = _ttsStatus.asStateFlow()

    init {
        tts = TextToSpeech(appContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                isReady = true
                tts?.setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build()
                )
                val res = tts?.setLanguage(Locale.forLanguageTag("en-IN"))
                if (res == TextToSpeech.LANG_MISSING_DATA || res == TextToSpeech.LANG_NOT_SUPPORTED) {
                    tts?.language = Locale.US
                }
                _ttsStatus.value = "Speaker TTS Ready"
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) { _isSpeaking.value = true }
                    override fun onDone(utteranceId: String?) {
                        _isSpeaking.value = false
                        onSpeechFinishedCallback?.invoke()
                    }
                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) { _isSpeaking.value = false }
                })
                pendingUtterance?.let { queued ->
                    pendingUtterance = null
                    speak(queued)
                }
            } else {
                _ttsStatus.value = "TTS init failed (code $status). Check Android Text-to-Speech settings."
            }
        }
    }

    fun setOnSpeechFinished(callback: (() -> Unit)?) { onSpeechFinishedCallback = callback }

    fun configure(localeTag: String, speed: Float, pitch: Float, style: TtsEmotionStyle) {
        if (!isReady) return
        val tag = if (localeTag == "auto") "en-IN" else localeTag
        val res = tts?.setLanguage(Locale.forLanguageTag(tag))
        if (res == TextToSpeech.LANG_MISSING_DATA || res == TextToSpeech.LANG_NOT_SUPPORTED) {
            tts?.language = Locale.getDefault()
        }
        tts?.setSpeechRate((speed * style.speedMul).coerceIn(0.5f, 1.8f))
        tts?.setPitch((pitch * style.pitchMul).coerceIn(0.5f, 1.6f))
    }

    fun speak(rawText: String) {
        val clean = rawText.replace("*", "").replace("#", "").replace("`", "").replace("•", ",").trim()
        if (clean.isBlank()) return
        if (!isReady) {
            pendingUtterance = clean
            return
        }
        val hasTeluguChars = clean.any { it in '\u0C00'..'\u0C7F' }
        if (hasTeluguChars) {
            val teRes = tts?.setLanguage(Locale.forLanguageTag("te-IN"))
            if (teRes == TextToSpeech.LANG_MISSING_DATA || teRes == TextToSpeech.LANG_NOT_SUPPORTED) {
                tts?.setLanguage(Locale.forLanguageTag("en-IN"))
            }
        }
        val params = Bundle().apply {
            putInt(TextToSpeech.Engine.KEY_PARAM_STREAM, AudioManager.STREAM_MUSIC)
            putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, 1.0f)
        }
        tts?.speak(clean, TextToSpeech.QUEUE_FLUSH, params, UUID.randomUUID().toString())
    }

    fun stop() {
        pendingUtterance = null
        tts?.stop()
        _isSpeaking.value = false
    }

    fun release() {
        tts?.stop(); tts?.shutdown(); tts = null
    }
}
