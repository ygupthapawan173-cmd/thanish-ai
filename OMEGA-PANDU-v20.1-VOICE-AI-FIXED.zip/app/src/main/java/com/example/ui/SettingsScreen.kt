package com.example.ui

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.example.control.BiometricSafetyGate
import com.example.control.PanduAccessibilityService
import com.example.data.AiProvider
import com.example.data.OmegaSettings
import com.example.data.OmegaVisualTheme
import com.example.data.OrbColorPreset
import com.example.data.TtsEmotionStyle
import com.example.ui.components.ParticleAiOrb
import com.example.ui.theme.OmegaColors
import com.example.ui.theme.OmegaLiquidBackdrop
import com.example.ui.theme.accentColor
import com.example.ui.theme.mutedText
import com.example.ui.theme.omegaGlassCard
import com.example.ui.theme.omegaSwitchColors
import com.example.ui.theme.omegaTextFieldColors
import com.example.ui.theme.primaryText
import java.util.Locale

private enum class SettingsTab(val label: String) {
    AI("AI & Keys"),
    VOICE("Voice"),
    VISUAL("Visual"),
    SYSTEM("System")
}

@Composable
fun SettingsScreen(
    uiState: PanduUiState,
    onBack: () -> Unit,
    onSaveSettings: ((OmegaSettings) -> OmegaSettings) -> Unit,
    onRunConnectionTest: (AiProvider) -> Unit,
    onDiscoverModels: () -> Unit,
    onTestSpeaker: () -> Unit,
    onToggleWakeService: (Boolean) -> Unit,
    onExportBackup: () -> String,
    onImportBackup: (String) -> Unit,
    onClearCrashLogs: () -> Unit,
    onClearHistory: () -> Unit
) {
    val context = LocalContext.current
    val settings = uiState.settings
    val theme = settings.visualTheme
    val preset = settings.orbColorPreset
    val accent = theme.accentColor(preset)
    val tfColors = omegaTextFieldColors(theme, preset)

    var selectedTab by remember { mutableStateOf(SettingsTab.AI) }
    var userNameDraft by remember(settings.userName) { mutableStateOf(settings.userName) }
    var geminiKeyDraft by remember(settings.geminiApiKey) { mutableStateOf(settings.geminiApiKey) }
    var openRouterKeyDraft by remember(settings.openRouterApiKey) { mutableStateOf(settings.openRouterApiKey) }
    var geminiChatModelDraft by remember(settings.geminiChatModel) { mutableStateOf(settings.geminiChatModel) }
    var geminiLiveModelDraft by remember(settings.geminiLiveVoiceModel) { mutableStateOf(settings.geminiLiveVoiceModel) }
    var openRouterModelDraft by remember(settings.openRouterModel) { mutableStateOf(settings.openRouterModel) }
    var wakeWordDraft by remember(settings.wakeWord) { mutableStateOf(settings.wakeWord) }
    var showGeminiKey by remember { mutableStateOf(false) }
    var showOrKey by remember { mutableStateOf(false) }
    var savedBanner by remember { mutableStateOf(false) }
    var showCrashLogs by remember { mutableStateOf(false) }

    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {}

    val hasMic = ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
    val hasContacts = ContextCompat.checkSelfPermission(context, Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED
    val hasCamera = ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
    val hasCalendar = ContextCompat.checkSelfPermission(context, Manifest.permission.READ_CALENDAR) == PackageManager.PERMISSION_GRANTED
    val hasAcc = PanduAccessibilityService.instance != null
    val hasNotif = NotificationManagerCompat.getEnabledListenerPackages(context).contains(context.packageName)

    fun persistDrafts() {
        onSaveSettings {
            it.copy(
                userName = userNameDraft,
                geminiApiKey = geminiKeyDraft,
                openRouterApiKey = openRouterKeyDraft,
                geminiChatModel = geminiChatModelDraft,
                geminiLiveVoiceModel = geminiLiveModelDraft,
                openRouterModel = openRouterModelDraft,
                wakeWord = wakeWordDraft
            )
        }
        savedBanner = true
    }

    OmegaLiquidBackdrop(theme = theme, preset = preset) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(horizontal = 18.dp, vertical = 12.dp)
        ) {
            // Top Bar
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                GlassCircleButton(Icons.AutoMirrored.Rounded.ArrowBack, theme = theme, preset = preset, onClick = onBack)
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("Control Center", color = theme.primaryText(), fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Text("OMEGA 19 ULTRA", color = accent, fontSize = 10.5.sp, fontWeight = FontWeight.Bold)
                }
                GlassCircleButton(Icons.Rounded.Check, theme = theme, preset = preset, onClick = { persistDrafts() })
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Segmented Ultra Glass Tab Bar
            Row(
                modifier = Modifier.fillMaxWidth().omegaGlassCard(18.dp, theme, preset).padding(4.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                SettingsTab.entries.forEach { tab ->
                    val isSel = selectedTab == tab
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(14.dp))
                            .background(if (isSel) accent else Color.Transparent)
                            .clickable { selectedTab = tab }
                            .padding(vertical = 9.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = tab.label,
                            color = if (isSel) Color(0xFF040814) else theme.mutedText(),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            Column(
                modifier = Modifier.weight(1f).verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                when (selectedTab) {
                    SettingsTab.AI -> {
                        SectionCard(theme, preset, Icons.Rounded.Key, "2 Encrypted API Key Slots", "AES-256") {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                AiProvider.entries.forEach { p ->
                                    AccentChip(p.displayName, settings.activeProvider == p, accent, Modifier.weight(1f)) {
                                        onSaveSettings { it.copy(activeProvider = p) }
                                    }
                                }
                            }

                            OutlinedTextField(userNameDraft, { userNameDraft = it; savedBanner = false }, label = { Text("Your Name") }, singleLine = true, shape = RoundedCornerShape(16.dp), colors = tfColors, modifier = Modifier.fillMaxWidth())

                            OutlinedTextField(
                                value = geminiKeyDraft,
                                onValueChange = { geminiKeyDraft = it; savedBanner = false },
                                label = { Text("Slot 1: Google Gemini Key") },
                                singleLine = true,
                                shape = RoundedCornerShape(16.dp),
                                colors = tfColors,
                                visualTransformation = if (showGeminiKey) VisualTransformation.None else PasswordVisualTransformation(),
                                trailingIcon = {
                                    IconButton(onClick = { showGeminiKey = !showGeminiKey }) {
                                        Icon(if (showGeminiKey) Icons.Rounded.VisibilityOff else Icons.Rounded.Visibility, null, tint = theme.mutedText())
                                    }
                                },
                                modifier = Modifier.fillMaxWidth()
                            )

                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedTextField(geminiChatModelDraft, { geminiChatModelDraft = it; savedBanner = false }, label = { Text("Gemini Chat") }, singleLine = true, shape = RoundedCornerShape(16.dp), colors = tfColors, modifier = Modifier.weight(1f))
                                OutlinedTextField(geminiLiveModelDraft, { geminiLiveModelDraft = it; savedBanner = false }, label = { Text("Live Voice") }, singleLine = true, shape = RoundedCornerShape(16.dp), colors = tfColors, modifier = Modifier.weight(1f))
                            }

                            OutlinedTextField(
                                value = openRouterKeyDraft,
                                onValueChange = { openRouterKeyDraft = it; savedBanner = false },
                                label = { Text("Slot 2: OpenRouter Key") },
                                singleLine = true,
                                shape = RoundedCornerShape(16.dp),
                                colors = tfColors,
                                visualTransformation = if (showOrKey) VisualTransformation.None else PasswordVisualTransformation(),
                                trailingIcon = {
                                    IconButton(onClick = { showOrKey = !showOrKey }) {
                                        Icon(if (showOrKey) Icons.Rounded.VisibilityOff else Icons.Rounded.Visibility, null, tint = theme.mutedText())
                                    }
                                },
                                modifier = Modifier.fillMaxWidth()
                            )

                            OutlinedTextField(openRouterModelDraft, { openRouterModelDraft = it; savedBanner = false }, label = { Text("OpenRouter Model (Avoid :batch)") }, singleLine = true, shape = RoundedCornerShape(16.dp), colors = tfColors, modifier = Modifier.fillMaxWidth())

                            if (openRouterModelDraft.contains(":batch", ignoreCase = true)) {
                                Text("Warning: ':batch' models are slow/async. Use google/gemini-2.5-flash or openai/gpt-4o-mini.", color = OmegaColors.AmberWarn, fontSize = 11.5.sp)
                            }

                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(onClick = { persistDrafts() }, shape = RoundedCornerShape(14.dp), colors = ButtonDefaults.buttonColors(containerColor = accent), modifier = Modifier.weight(1f)) {
                                    Text(if (savedBanner) "Saved" else "Save", color = Color(0xFF040814), fontWeight = FontWeight.Bold)
                                }
                                Button(onClick = { persistDrafts(); onDiscoverModels() }, enabled = !uiState.isDiscoveringModels, shape = RoundedCornerShape(14.dp), colors = ButtonDefaults.buttonColors(containerColor = OmegaColors.RoyalIndigo), modifier = Modifier.weight(1.1f)) {
                                    Text(if (uiState.isDiscoveringModels) "Scanning" else "Fetch Models", color = Color.White, fontSize = 12.sp)
                                }
                                Button(onClick = { persistDrafts(); onRunConnectionTest(settings.activeProvider) }, enabled = !uiState.isTestingConnection, shape = RoundedCornerShape(14.dp), colors = ButtonDefaults.buttonColors(containerColor = OmegaColors.EmeraldLive), modifier = Modifier.weight(0.9f)) {
                                    Text(if (uiState.isTestingConnection) "..." else "Ping", color = Color.White, fontWeight = FontWeight.Bold)
                                }
                            }

                            if (uiState.discoveryStatus != null) Text(uiState.discoveryStatus, color = theme.mutedText(), fontSize = 11.5.sp)

                            if (uiState.discoveredChatModels.isNotEmpty()) {
                                Row(modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    uiState.discoveredChatModels.filterNot { it.contains(":batch") }.take(10).forEach { mId ->
                                        val isSel = (settings.activeProvider == AiProvider.GEMINI && geminiChatModelDraft == mId) ||
                                            (settings.activeProvider == AiProvider.OPENROUTER && openRouterModelDraft == mId)
                                        AccentChip(mId, isSel, accent) {
                                            if (settings.activeProvider == AiProvider.GEMINI) {
                                                geminiChatModelDraft = mId; onSaveSettings { it.copy(geminiChatModel = mId) }
                                            } else {
                                                openRouterModelDraft = mId; onSaveSettings { it.copy(openRouterModel = mId) }
                                            }
                                        }
                                    }
                                }
                            }

                            if (uiState.diagnosticResult != null) {
                                val d = uiState.diagnosticResult
                                Box(
                                    modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp))
                                        .background(if (d.isSuccess) OmegaColors.EmeraldLive.copy(0.18f) else OmegaColors.CrimsonErr.copy(0.18f))
                                        .border(1.dp, if (d.isSuccess) OmegaColors.EmeraldLive.copy(0.5f) else OmegaColors.CrimsonErr.copy(0.5f), RoundedCornerShape(14.dp))
                                        .padding(12.dp)
                                ) {
                                    Text(d.summary, color = if (d.isSuccess) OmegaColors.EmeraldLive else OmegaColors.CrimsonErr, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                                }
                            }
                        }

                        SectionCard(theme, preset, Icons.Rounded.AutoAwesome, "Intelligence Features", "PRO") {
                            ProSwitchRow(theme, preset, "100% On-Device Local Brain", "Zero internet, zero API cost (Math, Memory, Commands, Local LLM)", settings.localBrainMode) { on -> onSaveSettings { it.copy(localBrainMode = on) } }
                            ProSwitchRow(theme, preset, "Offline Instant Commands", "Local torch, volume, battery & routines (<15ms)", settings.offlineFastCommands) { on -> onSaveSettings { it.copy(offlineFastCommands = on) } }
                            ProSwitchRow(theme, preset, "Live Google Search Grounding", "Real-time weather, scores & web info", settings.webSearchGrounding) { on -> onSaveSettings { it.copy(webSearchGrounding = on) } }
                        }
                    }

                    SettingsTab.VOICE -> {
                        SectionCard(theme, preset, Icons.Rounded.GraphicEq, "Voice & Hey Jarvis Diagnostics", if (settings.micPrivacyMuted) "MUTED" else "ACTIVE") {
                            if (settings.micPrivacyMuted) {
                                Button(
                                    onClick = { onSaveSettings { it.copy(micPrivacyMuted = false) } },
                                    colors = ButtonDefaults.buttonColors(containerColor = OmegaColors.CrimsonErr),
                                    shape = RoundedCornerShape(14.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) { Text("MIC IS MUTED — TAP TO UNMUTE NOW", color = Color.White, fontWeight = FontWeight.Bold) }
                            }

                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(onClick = onTestSpeaker, colors = ButtonDefaults.buttonColors(containerColor = accent), shape = RoundedCornerShape(14.dp), modifier = Modifier.weight(1f)) {
                                    Text("Test Speaker Voice", color = Color(0xFF040814), fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                }
                                OutlinedButton(
                                    onClick = {
                                        val p = buildList {
                                            add(Manifest.permission.RECORD_AUDIO)
                                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) add(Manifest.permission.POST_NOTIFICATIONS)
                                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) add(Manifest.permission.BLUETOOTH_CONNECT)
                                        }.toTypedArray()
                                        permLauncher.launch(p)
                                    },
                                    shape = RoundedCornerShape(14.dp),
                                    modifier = Modifier.weight(1f)
                                ) { Text(if (hasMic) "Mic Granted" else "Allow Mic", color = if (hasMic) OmegaColors.EmeraldLive else OmegaColors.AmberWarn, fontSize = 12.sp) }
                            }

                            Text("TTS: ${uiState.ttsStatusNote} • Mic: ${uiState.voiceDiagNote}", color = theme.mutedText(), fontSize = 11.5.sp)

                            OutlinedTextField(wakeWordDraft, { wakeWordDraft = it; savedBanner = false }, label = { Text("Wake Word (e.g. hey jarvis)") }, singleLine = true, shape = RoundedCornerShape(16.dp), colors = tfColors, modifier = Modifier.fillMaxWidth())

                            Text("Wake Sensitivity: ${(settings.wakeSensitivity * 100).toInt()}% (Higher = Easier to trigger)", color = theme.mutedText(), fontSize = 11.5.sp)
                            Slider(settings.wakeSensitivity, { v -> onSaveSettings { it.copy(wakeSensitivity = v) } }, valueRange = 0.2f..1.0f, colors = SliderDefaults.colors(thumbColor = accent, activeTrackColor = accent))

                            ProSwitchRow(theme, preset, "Hey Jarvis Background Wake", "Listens continuously in background", settings.wakeWordEnabled) { on ->
                                if (on && !hasMic) permLauncher.launch(arrayOf(Manifest.permission.RECORD_AUDIO))
                                else onToggleWakeService(on)
                            }
                            ProSwitchRow(theme, preset, "Auto-Speak All Replies (TTS)", "Speaks answers on Home, Chat & Voice screens", settings.autoSpeak) { on -> onSaveSettings { it.copy(autoSpeak = on) } }
                            ProSwitchRow(theme, preset, "Continuous Conversation", "Auto-rearm mic after OMEGA finishes speaking", settings.continuousConversation) { on -> onSaveSettings { it.copy(continuousConversation = on) } }
                            ProSwitchRow(theme, preset, "Gemini Live Duplex Voice (WS)", "Requires Gemini API Key (auto-falls back if OpenRouter)", settings.useGeminiLiveAudio) { on -> onSaveSettings { it.copy(useGeminiLiveAudio = on) } }
                            ProSwitchRow(theme, preset, "Bluetooth Headset Voice Routing", "Route mic & audio to BT earbuds", settings.bluetoothVoiceRouting) { on -> onSaveSettings { it.copy(bluetoothVoiceRouting = on) } }
                            ProSwitchRow(theme, preset, "Microphone Privacy Mute", "Temporarily block all mic access", settings.micPrivacyMuted) { on -> onSaveSettings { it.copy(micPrivacyMuted = on) } }
                        }

                        SectionCard(theme, preset, Icons.Rounded.RecordVoiceOver, "Language, Speed & Emotion", settings.languageTag.uppercase()) {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                AccentChip("AUTO (TE+EN)", settings.languageTag == "auto", accent, Modifier.weight(1f)) { onSaveSettings { it.copy(languageTag = "auto") } }
                                AccentChip("తెలుగు", settings.languageTag == "te-IN", accent, Modifier.weight(1f)) { onSaveSettings { it.copy(languageTag = "te-IN") } }
                                AccentChip("English", settings.languageTag == "en-IN", accent, Modifier.weight(1f)) { onSaveSettings { it.copy(languageTag = "en-IN") } }
                            }
                            Text("Speed: ${String.format(Locale.US, "%.2fx", settings.ttsSpeed)} • Pitch: ${String.format(Locale.US, "%.2fx", settings.ttsPitch)}", color = theme.mutedText(), fontSize = 11.5.sp)
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                Slider(settings.ttsSpeed, { v -> onSaveSettings { it.copy(ttsSpeed = v) } }, valueRange = 0.7f..1.5f, modifier = Modifier.weight(1f), colors = SliderDefaults.colors(thumbColor = accent, activeTrackColor = accent))
                                Slider(settings.ttsPitch, { v -> onSaveSettings { it.copy(ttsPitch = v) } }, valueRange = 0.7f..1.4f, modifier = Modifier.weight(1f), colors = SliderDefaults.colors(thumbColor = accent, activeTrackColor = accent))
                            }
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                TtsEmotionStyle.entries.forEach { st ->
                                    AccentChip(st.label, settings.ttsStyle == st, accent, Modifier.weight(1f)) { onSaveSettings { it.copy(ttsStyle = st) } }
                                }
                            }
                        }
                    }

                    SettingsTab.VISUAL -> {
                        SectionCard(theme, preset, Icons.Rounded.Palette, "Live 3D Orb Color Studio", preset.label.uppercase()) {
                            Box(modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp), contentAlignment = Alignment.Center) {
                                ParticleAiOrb(size = 128.dp, isListening = true, audioAmplitude = 0.35f, preset = preset)
                            }
                            Row(modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                OrbColorPreset.entries.forEach { p ->
                                    val isSel = preset == p
                                    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.clickable { onSaveSettings { it.copy(orbColorPreset = p) } }) {
                                        Box(
                                            modifier = Modifier.size(40.dp).clip(CircleShape)
                                                .background(Brush.linearGradient(listOf(Color(p.primaryHex), Color(p.secondaryHex), Color(p.accentHex))))
                                                .border(if (isSel) 2.5.dp else 1.dp, if (isSel) Color.White else Color.Transparent, CircleShape)
                                        )
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(p.label, color = if (isSel) accent else theme.mutedText(), fontSize = 10.5.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }

                        SectionCard(theme, preset, Icons.Rounded.Layers, "Surface Theme & Motion", theme.label.uppercase()) {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OmegaVisualTheme.entries.forEach { t ->
                                    AccentChip(t.label, theme == t, accent, Modifier.weight(1f)) { onSaveSettings { it.copy(visualTheme = t) } }
                                }
                            }
                            ProSwitchRow(theme, preset, "3D Hologram Gyroscope Parallax", "Tilt phone for subtle 3D orb depth", settings.gyroscopeParallax) { on -> onSaveSettings { it.copy(gyroscopeParallax = on) } }
                            ProSwitchRow(theme, preset, "Floating Mini-Orb (Outside App)", "Auto-hides inside OMEGA, floats over other apps", settings.floatingOrbEnabled) { on -> onSaveSettings { it.copy(floatingOrbEnabled = on) } }
                        }
                    }

                    SettingsTab.SYSTEM -> {
                        SectionCard(theme, preset, Icons.Rounded.Security, "Permissions & Privacy", "ANDROID 16") {
                            PermRow(theme, "Default Assistant (Power Button)", false) { context.startActivity(Intent(Settings.ACTION_VOICE_INPUT_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
                            PermRow(theme, "Cross-App Automation & HUD", hasAcc) { context.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
                            PermRow(theme, "Notification Reader & Reply", hasNotif) { context.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
                            PermRow(theme, "Mic, Contacts, Calendar, Camera & BT", hasMic && hasContacts && hasCamera && hasCalendar) {
                                val p = buildList {
                                    add(Manifest.permission.RECORD_AUDIO); add(Manifest.permission.READ_CONTACTS); add(Manifest.permission.READ_CALENDAR)
                                    add(Manifest.permission.CAMERA); add(Manifest.permission.CALL_PHONE)
                                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) add(Manifest.permission.BLUETOOTH_CONNECT)
                                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) add(Manifest.permission.POST_NOTIFICATIONS)
                                }.toTypedArray()
                                permLauncher.launch(p)
                            }
                            ProSwitchRow(theme, preset, "Confirm Notification Replies", "Show confirmation before sending", settings.confirmNotifReply) { on -> onSaveSettings { it.copy(confirmNotifReply = on) } }
                            ProSwitchRow(theme, preset, "Biometric Protection (Optional)", "Fingerprint/Face check for sensitive tools", settings.biometricSafetyLock) { on ->
                                if (on) BiometricSafetyGate.authenticate(context, onSuccess = { onSaveSettings { it.copy(biometricSafetyLock = true) } }, onError = {})
                                else onSaveSettings { it.copy(biometricSafetyLock = false) }
                            }
                        }

                        SectionCard(theme, preset, Icons.Rounded.Speed, "Telemetry, Backup & Crash Logs", "${uiState.apiTelemetry.averageLatencyMs}ms") {
                            val snap = uiState.apiTelemetry
                            Text("Requests: ${snap.totalRequests} (Fail: ${snap.failedRequests}) • Tokens: ${snap.estimatedPromptTokens + snap.estimatedOutputTokens} • Est: $${String.format(Locale.US, "%.4f", snap.estimatedCostUsd)}", color = theme.mutedText(), fontSize = 12.sp)
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedButton(onClick = {
                                    val blob = onExportBackup()
                                    (context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("OMEGA_BACKUP", blob))
                                }, shape = RoundedCornerShape(12.dp), modifier = Modifier.weight(1f)) { Text("Backup", color = theme.primaryText(), fontSize = 12.sp) }
                                OutlinedButton(onClick = {
                                    val clip = (context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).primaryClip?.getItemAt(0)?.coerceToText(context)?.toString().orEmpty()
                                    onImportBackup(clip)
                                }, shape = RoundedCornerShape(12.dp), modifier = Modifier.weight(1f)) { Text("Restore", color = theme.primaryText(), fontSize = 12.sp) }
                                OutlinedButton(onClick = { showCrashLogs = !showCrashLogs }, shape = RoundedCornerShape(12.dp), modifier = Modifier.weight(1f)) { Text("Logs", color = theme.primaryText(), fontSize = 12.sp) }
                            }
                            if (uiState.backupStatusText != null) Text(uiState.backupStatusText, color = OmegaColors.EmeraldLive, fontSize = 11.5.sp)
                            if (showCrashLogs) {
                                Box(modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Color(0x99000000)).padding(10.dp)) {
                                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                        Text(uiState.crashLogText.takeLast(1200), color = Color(0xFFE2E8F0), fontSize = 11.sp)
                                        TextButton(onClick = onClearCrashLogs) { Text("Clear Logs", color = OmegaColors.CrimsonErr) }
                                    }
                                }
                            }
                            OutlinedButton(onClick = onClearHistory, shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()) {
                                Text("Clear Chat History", color = OmegaColors.CrimsonErr)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SectionCard(
    theme: OmegaVisualTheme,
    preset: OrbColorPreset,
    icon: ImageVector,
    title: String,
    badge: String,
    content: @Composable ColumnScope.() -> Unit
) {
    val accent = theme.accentColor(preset)
    Column(
        modifier = Modifier.fillMaxWidth().omegaGlassCard(22.dp, theme, preset).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Box(modifier = Modifier.size(30.dp).clip(CircleShape).background(accent.copy(0.18f)), contentAlignment = Alignment.Center) {
                    Icon(icon, null, tint = accent, modifier = Modifier.size(16.dp))
                }
                Text(title, color = theme.primaryText(), fontWeight = FontWeight.Bold, fontSize = 14.5.sp)
            }
            Box(modifier = Modifier.clip(RoundedCornerShape(10.dp)).background(accent.copy(0.16f)).padding(horizontal = 8.dp, vertical = 3.dp)) {
                Text(badge, color = accent, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            }
        }
        content()
    }
}

@Composable
private fun ProSwitchRow(
    theme: OmegaVisualTheme,
    preset: OrbColorPreset,
    title: String,
    sub: String,
    checked: Boolean,
    onChange: (Boolean) -> Unit
) {
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Column(modifier = Modifier.weight(1f).padding(end = 8.dp)) {
            Text(title, color = theme.primaryText(), fontWeight = FontWeight.Medium, fontSize = 13.5.sp)
            Text(sub, color = theme.mutedText(), fontSize = 11.5.sp)
        }
        Switch(checked = checked, onCheckedChange = onChange, colors = omegaSwitchColors(theme, preset))
    }
}

@Composable
private fun AccentChip(
    label: String,
    selected: Boolean,
    accent: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(if (selected) accent else Color.White.copy(0.08f))
            .border(1.dp, if (selected) accent else Color.White.copy(0.16f), RoundedCornerShape(12.dp))
            .clickable { onClick() }
            .padding(vertical = 8.dp, horizontal = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(label, color = if (selected) Color(0xFF040814) else Color(0xFFE2E8F0), fontWeight = FontWeight.Bold, fontSize = 11.5.sp, maxLines = 1)
    }
}

@Composable
private fun PermRow(theme: OmegaVisualTheme, title: String, granted: Boolean, onClick: () -> Unit) {
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.weight(1f)) {
            Icon(if (granted) Icons.Rounded.CheckCircle else Icons.Rounded.ErrorOutline, null, tint = if (granted) OmegaColors.EmeraldLive else OmegaColors.AmberWarn, modifier = Modifier.size(18.dp))
            Text(title, color = theme.primaryText(), fontSize = 13.sp)
        }
        TextButton(onClick = onClick) { Text(if (granted) "Active" else "Open", fontWeight = FontWeight.Bold) }
    }
}
