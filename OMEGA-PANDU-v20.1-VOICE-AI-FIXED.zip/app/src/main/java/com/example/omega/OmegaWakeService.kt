package com.example.omega

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.example.MainActivity
import com.example.control.AgentHudBus
import com.example.control.AgentHudState
import com.example.data.OmegaPreferences
import com.example.voice.TeluguTtsController
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * Reliable Continuous Wake-Word Service (v19.1 Voice Fix):
 * - Listens directly with SpeechRecognizer so "Hey Jarvis" is NEVER clipped off
 * - Reacts in real time to Mic Privacy Mute & Main App Mic Busy state
 * - Zero mic conflict with main app
 */
class OmegaWakeService : Service() {

    private val mainHandler = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private lateinit var preferences: OmegaPreferences
    private lateinit var smartTriggers: SmartTriggerManager
    private lateinit var tts: TeluguTtsController

    private var recognizer: SpeechRecognizer? = null
    private var restartJob: Job? = null
    private var running = false
    private var isListeningNow = false

    override fun onCreate() {
        super.onCreate()
        preferences = OmegaPreferences(this)
        smartTriggers = SmartTriggerManager(this)
        tts = TeluguTtsController(this)
        smartTriggers.register()

        createChannel()
        startForegroundSafely()
        running = true

        // Pause immediately when main app opens mic; resume when main app finishes
        scope.launch {
            AgentHudBus.isMainMicBusy.collect { busy ->
                if (busy) pauseListening() else if (running) scheduleListen(450L)
            }
        }

        // React immediately if user toggles Mic Privacy Mute ON/OFF in Settings
        scope.launch {
            preferences.settings.collect { s ->
                if (s.micPrivacyMuted) pauseListening()
                else if (running && !AgentHudBus.isMainMicBusy.value && !isListeningNow) scheduleListen(350L)
            }
        }

        scope.launch {
            SmartTriggerBus.events.collect { event ->
                val s = preferences.settings.value
                if (s.autoSpeak) {
                    tts.configure(s.languageTag, s.ttsSpeed, s.ttsPitch, s.ttsStyle)
                    tts.speak(event.announcement)
                }
                delay(4500L)
                AgentHudBus.updateState(AgentHudState.Hidden)
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) { stopSelf(); return START_NOT_STICKY }
        startForegroundSafely()
        if (!AgentHudBus.isMainMicBusy.value && !preferences.settings.value.micPrivacyMuted) {
            scheduleListen(300L)
        }
        return START_STICKY
    }

    private fun startForegroundSafely() {
        val wakeWord = preferences.settings.value.wakeWord
        val pi = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
                putExtra(MainActivity.EXTRA_START_LISTENING, true)
            },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val notif: Notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("OMEGA 19.1 Listening")
            .setContentText("Say \"$wakeWord\" anytime")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true)
            .setContentIntent(pi)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(NOTIF_ID, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(NOTIF_ID, notif)
        }
    }

    private fun pauseListening() {
        restartJob?.cancel(); restartJob = null
        isListeningNow = false
        destroyRecognizerSync()
    }

    private fun scheduleListen(delayMs: Long) {
        restartJob?.cancel()
        restartJob = scope.launch {
            delay(delayMs)
            val s = preferences.settings.value
            if (!running || AgentHudBus.isMainMicBusy.value || s.micPrivacyMuted) return@launch
            startWakeRecognizer()
        }
    }

    private fun startWakeRecognizer() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) return
        destroyRecognizerSync()

        val sr = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer = sr
        isListeningNow = true

        sr.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) = Unit
            override fun onBeginningOfSpeech() = Unit
            override fun onRmsChanged(rmsdB: Float) = Unit
            override fun onBufferReceived(buffer: ByteArray?) = Unit
            override fun onEndOfSpeech() = Unit

            override fun onPartialResults(partialResults: Bundle?) {
                if (checkMatches(partialResults)) {
                    pauseListening()
                }
            }

            override fun onResults(results: Bundle?) {
                val hit = checkMatches(results)
                isListeningNow = false
                destroyRecognizerSync()
                if (!hit && running && !AgentHudBus.isMainMicBusy.value) {
                    scheduleListen(350L)
                }
            }

            override fun onError(error: Int) {
                isListeningNow = false
                destroyRecognizerSync()
                if (running && !AgentHudBus.isMainMicBusy.value) {
                    val backoff = if (error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY || error == 11) 1200L else 550L
                    scheduleListen(backoff)
                }
            }

            override fun onEvent(eventType: Int, params: Bundle?) = Unit
        })

        val lang = preferences.settings.value.languageTag.let { if (it == "auto") "en-IN" else it }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 2200L)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 2000L)
        }
        runCatching { sr.startListening(intent) }.onFailure {
            isListeningNow = false
            scheduleListen(1500L)
        }
    }

    private fun checkMatches(bundle: Bundle?): Boolean {
        val candidates = bundle?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION).orEmpty()
        if (candidates.isEmpty()) return false
        val customWake = preferences.settings.value.wakeWord.lowercase().trim()
        val wakeAliases = buildList {
            if (customWake.isNotEmpty()) add(customWake)
            if (customWake.contains("jarvis")) {
                add("jarvis"); add("hey jarvis"); add("hai jarvis"); add("hi jarvis"); add("ok jarvis"); add("service"); add("javis")
            }
            add("hey pandu"); add("hey omega"); add("omega")
        }.distinct()

        for (raw in candidates) {
            val spoken = raw.lowercase().trim()
            val matchedAlias = wakeAliases.firstOrNull { alias -> spoken.contains(alias) }
            if (matchedAlias != null) {
                val inlineCmd = spoken.substringAfter(matchedAlias).trim()
                AgentHudBus.updateState(AgentHudState.Active(inlineCmd.ifBlank { "OMEGA Awake" }, audioAmplitude = 0.75f))
                AgentHudBus.emitWakeTrigger(inlineCmd)
                startActivity(
                    Intent(this, MainActivity::class.java).apply {
                        flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
                        putExtra(MainActivity.EXTRA_START_LISTENING, true)
                        if (inlineCmd.isNotBlank()) putExtra(MainActivity.EXTRA_WAKE_COMMAND, inlineCmd)
                    }
                )
                return true
            }
        }
        return false
    }

    private fun destroyRecognizerSync() {
        if (Looper.myLooper() == Looper.getMainLooper()) {
            runCatching { recognizer?.cancel(); recognizer?.destroy() }
            recognizer = null
        } else {
            mainHandler.post {
                runCatching { recognizer?.cancel(); recognizer?.destroy() }
                recognizer = null
            }
        }
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel(CHANNEL_ID, "OMEGA Wake & Triggers", NotificationManager.IMPORTANCE_LOW))
        }
    }

    override fun onDestroy() {
        running = false; pauseListening(); smartTriggers.unregister(); tts.release()
        mainHandler.removeCallbacksAndMessages(null); scope.cancel()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        private const val CHANNEL_ID = "omega_pandu_v19_1_voice"
        private const val NOTIF_ID = 3191
        private const val ACTION_STOP = "com.example.omega.STOP_WAKE"

        fun start(context: Context) {
            ContextCompat.startForegroundService(context, Intent(context, OmegaWakeService::class.java))
        }
        fun stop(context: Context) {
            context.startService(Intent(context, OmegaWakeService::class.java).apply { action = ACTION_STOP })
        }
    }
}
