package com.example.omega

import android.annotation.SuppressLint
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import com.example.voice.BluetoothAudioRouter
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.isActive
import kotlinx.coroutines.withContext
import kotlin.math.sqrt

/**
 * High-sensitivity local Voice Activity Detector (VAD) using AudioSource.MIC
 * so far-field "Hey Jarvis" speech triggers reliably without attenuation.
 */
class SilentAudioGate(
    private val thresholdProvider: () -> Double = { 550.0 },
    private val requiredFrames: Int = 2
) {
    @SuppressLint("MissingPermission")
    suspend fun waitForSpeechBurst(): Boolean = withContext(Dispatchers.IO) {
        val sampleRate = 16000
        val minBuf = AudioRecord.getMinBufferSize(sampleRate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT).coerceAtLeast(3200)
        val rec = runCatching {
            AudioRecord(MediaRecorder.AudioSource.MIC, sampleRate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, minBuf)
        }.getOrNull() ?: return@withContext false

        if (rec.state != AudioRecord.STATE_INITIALIZED) { rec.release(); return@withContext false }
        val (aec, ns) = BluetoothAudioRouter.attachAudioEffects(rec.audioSessionId)

        val shorts = ShortArray(1600)
        var hits = 0
        return@withContext try {
            rec.startRecording()
            while (isActive) {
                val read = rec.read(shorts, 0, shorts.size)
                if (read > 0) {
                    var sum = 0.0
                    for (i in 0 until read) { val s = shorts[i].toDouble(); sum += s * s }
                    if (sqrt(sum / read) >= thresholdProvider()) {
                        hits++
                        if (hits >= requiredFrames) return@withContext true
                    } else hits = 0
                }
            }
            false
        } catch (_: Exception) { false } finally {
            runCatching { aec?.release(); ns?.release() }
            runCatching { rec.stop(); rec.release() }
        }
    }
}
