package com.example.voice

import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import com.example.control.AgentHudBus
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale

data class VoiceInputState(
    val isListening: Boolean = false,
    val partialTranscript: String = "",
    val audioAmplitude: Float = 0f,
    val lastErrorCode: Int = 0,
    val errorMessage: String? = null,
    val activeLocale: String = "en-IN",
    val diagnosticsNote: String = "Ready"
)

/**
 * Silent In-Process Speech Recognizer (NO Google voice popup!)
 * Features:
 * - Automatic Error 11 (ERROR_SERVER_DISCONNECTED) recovery with recognizer rebuild
 * - Telugu + English AUTO recognition mode
 * - Offline/Online speech switching
 */
class VoiceInputController(
    private val context: Context,
    private val onFinalTranscript: (String) -> Unit
) {
    private val mainHandler = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null
    private var error11Retries = 0
    private var lastRequestedLanguage = "auto"
    private var lastPreferOffline = false

    private val _state = MutableStateFlow(VoiceInputState())
    val state: StateFlow<VoiceInputState> = _state.asStateFlow()

    fun startListening(languageTag: String = "auto", preferOffline: Boolean = false) {
        lastRequestedLanguage = languageTag
        lastPreferOffline = preferOffline
        error11Retries = 0
        startInternal(languageTag, preferOffline)
    }

    private fun startInternal(languageTag: String, preferOffline: Boolean) {
        mainHandler.post {
            if (!SpeechRecognizer.isRecognitionAvailable(context)) {
                _state.value = VoiceInputState(errorMessage = "Speech recognition service unavailable on device.")
                return@post
            }
            AgentHudBus.setMainMicBusy(true)
            destroyInternal()

            val effectiveLocale = when (languageTag) {
                "auto" -> "en-IN" // en-IN handles Indian English + Tenglish/Telugu code-mixing cleanly
                else -> languageTag
            }

            val sr = if (preferOffline && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S &&
                SpeechRecognizer.isOnDeviceRecognitionAvailable(context)
            ) {
                SpeechRecognizer.createOnDeviceSpeechRecognizer(context)
            } else {
                SpeechRecognizer.createSpeechRecognizer(context)
            }
            recognizer = sr

            sr.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {
                    error11Retries = 0
                    _state.value = VoiceInputState(
                        isListening = true,
                        audioAmplitude = 0.14f,
                        activeLocale = effectiveLocale,
                        diagnosticsNote = if (preferOffline) "On-device listening ($effectiveLocale)" else "Listening ($effectiveLocale)"
                    )
                }

                override fun onBeginningOfSpeech() {
                    _state.value = _state.value.copy(isListening = true)
                }

                override fun onRmsChanged(rmsdB: Float) {
                    _state.value = _state.value.copy(audioAmplitude = ((rmsdB + 2f) / 12f).coerceIn(0f, 1f))
                }

                override fun onBufferReceived(buffer: ByteArray?) = Unit
                override fun onEndOfSpeech() {
                    _state.value = _state.value.copy(isListening = false, audioAmplitude = 0f)
                }

                override fun onError(error: Int) {
                    // Automatic Error 11 (ERROR_SERVER_DISCONNECTED) recovery!
                    if (error == 11 && error11Retries < 2) {
                        error11Retries++
                        _state.value = _state.value.copy(
                            isListening = false,
                            lastErrorCode = 11,
                            diagnosticsNote = "Recovered Error 11 (retry #$error11Retries)..."
                        )
                        destroyInternal()
                        mainHandler.postDelayed({ startInternal(lastRequestedLanguage, lastPreferOffline) }, 450L)
                        return
                    }

                    AgentHudBus.setMainMicBusy(false)
                    val msg = when (error) {
                        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Microphone permission required"
                        SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Network unavailable (switched offline ready)"
                        SpeechRecognizer.ERROR_NO_MATCH -> "Didn't catch that. Tap orb to speak again."
                        SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "No speech detected."
                        11 -> "Speech server disconnected (Error 11). Tap orb to reconnect."
                        else -> "Voice recognition code $error"
                    }
                    _state.value = _state.value.copy(
                        isListening = false,
                        audioAmplitude = 0f,
                        lastErrorCode = error,
                        errorMessage = msg,
                        diagnosticsNote = "Last error: $error"
                    )
                }

                override fun onResults(results: Bundle?) {
                    AgentHudBus.setMainMicBusy(false)
                    val final = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.trim().orEmpty()
                    _state.value = _state.value.copy(
                        isListening = false,
                        partialTranscript = final,
                        audioAmplitude = 0f,
                        errorMessage = null,
                        diagnosticsNote = "Captured (${final.length} chars)"
                    )
                    if (final.isNotEmpty()) onFinalTranscript(final)
                }

                override fun onPartialResults(partialResults: Bundle?) {
                    val p = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.trim().orEmpty()
                    if (p.isNotEmpty()) _state.value = _state.value.copy(partialTranscript = p)
                }

                override fun onEvent(eventType: Int, params: Bundle?) = Unit
            })

            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, effectiveLocale)
                if (languageTag == "auto") {
                    putExtra("android.speech.extra.EXTRA_ADDITIONAL_LANGUAGES", arrayOf("te-IN", "en-IN"))
                }
                if (preferOffline) {
                    putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
                }
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            }
            runCatching { sr.startListening(intent) }.onFailure {
                AgentHudBus.setMainMicBusy(false)
                _state.value = _state.value.copy(isListening = false, errorMessage = it.message)
            }
        }
    }

    fun stopListening() {
        mainHandler.post {
            recognizer?.stopListening()
            AgentHudBus.setMainMicBusy(false)
            _state.value = _state.value.copy(isListening = false, audioAmplitude = 0f)
        }
    }

    fun release() {
        mainHandler.post { destroyInternal(); AgentHudBus.setMainMicBusy(false) }
    }

    private fun destroyInternal() {
        runCatching { recognizer?.cancel(); recognizer?.destroy() }
        recognizer = null
    }
}
