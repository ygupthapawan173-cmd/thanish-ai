package com.example.ui.theme

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.SwitchColors
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.TextFieldColors
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.data.OmegaVisualTheme
import com.example.data.OrbColorPreset
import kotlin.math.cos
import kotlin.math.sin

object OmegaColors {
    // Aurora Obsidian (Ultra Dark Premium)
    val ObsidianTop = Color(0xFF050914)
    val ObsidianMid = Color(0xFF0C1631)
    val ObsidianBottom = Color(0xFF13112E)

    // Pearl Liquid Glass (Crisp Luxury Light)
    val PearlTop = Color(0xFFE9F0FF)
    val PearlMid = Color(0xFFF3F6FF)
    val PearlBottom = Color(0xFFE1E8FF)

    // Accents
    val ElectricCyan = Color(0xFF00E5FF)
    val RoyalIndigo = Color(0xFF6366F1)
    val CoralRose = Color(0xFFFF5E9C)
    val EmeraldLive = Color(0xFF10B981)
    val AmberWarn = Color(0xFFF59E0B)
    val CrimsonErr = Color(0xFFF43F5E)

    val InkDark = Color(0xFF0F172A)
    val InkMuted = Color(0xFF475569)
    val DarkPill = Color(0xFF0B1120)
}

fun OmegaVisualTheme.isDark(): Boolean = this != OmegaVisualTheme.PEARL_LIQUID_GLASS
fun OmegaVisualTheme.primaryText(): Color = if (isDark()) Color(0xFFF1F5FF) else OmegaColors.InkDark
fun OmegaVisualTheme.mutedText(): Color = if (isDark()) Color(0xFF94A9CE) else OmegaColors.InkMuted
fun OmegaVisualTheme.accentColor(preset: OrbColorPreset): Color = Color(preset.primaryHex)

@Composable
fun omegaSwitchColors(theme: OmegaVisualTheme, preset: OrbColorPreset): SwitchColors {
    val accent = Color(preset.primaryHex)
    return SwitchDefaults.colors(
        checkedThumbColor = Color.White,
        checkedTrackColor = accent,
        checkedBorderColor = accent,
        uncheckedThumbColor = if (theme.isDark()) Color(0xFF94A3B8) else Color.White,
        uncheckedTrackColor = if (theme.isDark()) Color(0xFF1E293B) else Color(0xFFCBD5E1),
        uncheckedBorderColor = Color.Transparent
    )
}

@Composable
fun omegaTextFieldColors(theme: OmegaVisualTheme, preset: OrbColorPreset): TextFieldColors {
    val accent = Color(preset.primaryHex)
    return OutlinedTextFieldDefaults.colors(
        focusedBorderColor = accent,
        unfocusedBorderColor = if (theme.isDark()) Color.White.copy(0.16f) else Color(0xFF94A3B8).copy(0.45f),
        focusedContainerColor = if (theme.isDark()) Color(0x66060B18) else Color.White.copy(0.75f),
        unfocusedContainerColor = if (theme.isDark()) Color(0x44060B18) else Color.White.copy(0.55f),
        focusedTextColor = theme.primaryText(),
        unfocusedTextColor = theme.primaryText(),
        focusedLabelColor = accent,
        unfocusedLabelColor = theme.mutedText(),
        cursorColor = accent
    )
}

fun Modifier.omegaBackground(theme: OmegaVisualTheme): Modifier = this.background(
    brush = if (theme.isDark()) {
        Brush.linearGradient(
            listOf(OmegaColors.ObsidianTop, OmegaColors.ObsidianMid, OmegaColors.ObsidianBottom),
            Offset(0f, 0f), Offset(950f, 2000f)
        )
    } else {
        Brush.linearGradient(
            listOf(OmegaColors.PearlTop, OmegaColors.PearlMid, OmegaColors.PearlBottom),
            Offset(0f, 0f), Offset(950f, 2000f)
        )
    }
)

@Composable
fun OmegaLiquidBackdrop(
    theme: OmegaVisualTheme,
    preset: OrbColorPreset,
    modifier: Modifier = Modifier,
    content: @Composable BoxScope.() -> Unit
) {
    val inf = rememberInfiniteTransition(label = "liquidMesh")
    val phase by inf.animateFloat(
        initialValue = 0f,
        targetValue = (2 * Math.PI).toFloat(),
        animationSpec = infiniteRepeatable(tween(16000, easing = LinearEasing)),
        label = "meshPhase"
    )
    val cPrimary = Color(preset.primaryHex)
    val cSecondary = Color(preset.secondaryHex)
    val cAccent = Color(preset.accentHex)

    Box(modifier = modifier.fillMaxSize().omegaBackground(theme)) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            val p1 = Offset(w * (0.18f + 0.09f * cos(phase)), h * (0.14f + 0.05f * sin(phase)))
            val p2 = Offset(w * (0.85f + 0.08f * sin(phase)), h * (0.78f + 0.06f * cos(phase)))
            val p3 = Offset(w * (0.50f + 0.06f * sin(phase * 1.4f)), h * (0.44f + 0.04f * cos(phase)))

            val a1 = if (theme.isDark()) 0.20f else 0.16f
            val a2 = if (theme.isDark()) 0.22f else 0.14f
            val a3 = if (theme.isDark()) 0.14f else 0.10f

            drawCircle(Brush.radialGradient(listOf(cPrimary.copy(a1), Color.Transparent), p1, w * 0.78f), w * 0.78f, p1)
            drawCircle(Brush.radialGradient(listOf(cSecondary.copy(a2), Color.Transparent), p2, w * 0.74f), w * 0.74f, p2)
            drawCircle(Brush.radialGradient(listOf(cAccent.copy(a3), Color.Transparent), p3, w * 0.64f), w * 0.64f, p3)
        }
        content()
    }
}

fun Modifier.omegaGlassCard(
    cornerRadius: Dp = 24.dp,
    theme: OmegaVisualTheme,
    preset: OrbColorPreset = OrbColorPreset.AURORA_CYAN
): Modifier {
    val cPrimary = Color(preset.primaryHex)
    val cSecondary = Color(preset.secondaryHex)
    return this
        .shadow(
            elevation = if (theme.isDark()) 12.dp else 7.dp,
            shape = RoundedCornerShape(cornerRadius),
            ambientColor = if (theme.isDark()) cPrimary.copy(0.22f) else cSecondary.copy(0.18f),
            spotColor = if (theme.isDark()) cSecondary.copy(0.24f) else cPrimary.copy(0.16f)
        )
        .clip(RoundedCornerShape(cornerRadius))
        .background(
            brush = if (theme.isDark()) {
                Brush.linearGradient(listOf(Color(0xD9101C38), Color(0xCC0A1228)))
            } else {
                Brush.linearGradient(listOf(Color.White.copy(0.86f), Color.White.copy(0.66f)))
            }
        )
        .border(
            width = 1.15.dp,
            brush = if (theme.isDark()) {
                Brush.linearGradient(listOf(cPrimary.copy(0.45f), cSecondary.copy(0.22f), Color.White.copy(0.08f)))
            } else {
                Brush.linearGradient(listOf(Color.White.copy(0.95f), cPrimary.copy(0.28f)))
            },
            shape = RoundedCornerShape(cornerRadius)
        )
}
