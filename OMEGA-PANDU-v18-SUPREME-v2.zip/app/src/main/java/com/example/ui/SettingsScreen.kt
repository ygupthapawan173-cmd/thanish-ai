package com.example.ui

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.example.control.BiometricSafetyGate
import com.example.control.PanduAccessibilityService
import com.example.data.AiProvider
import com.example.data.OmegaSettings
import com.example.data.OmegaVisualTheme
import com.example.data.OrbColorPreset
import com.example.data.TtsEmotionStyle
import com.example.ui.theme.OmegaColors
import com.example.ui.theme.OmegaLiquidBackdrop
import com.example.ui.theme.accentColor
import com.example.ui.theme.isDark
import com.example.ui.theme.mutedText
import com.example.ui.theme.omegaGlassCard
import com.example.ui.theme.omegaSwitchColors
import com.example.ui.theme.omegaTextFieldColors
import com.example.ui.theme.primaryText
import java.util.Locale

@Composable
fun SettingsScreen(
    uiState: PanduUiState,
    onBack: () -> Unit,
    onSaveSettings: ((OmegaSettings) -> OmegaSettings) -> Unit,
    onRunConnectionTest: (AiProvider) -> Unit,
    onDiscoverModels: () -> Unit,
    onToggleWakeService: (Boolean) -> Unit,
    onExportBackup: () -> String,
    onImportBackup: (String) -> Unit,
    onClearCrashLogs: () -> Unit,
    onClearHistory: () -> Unit
) {
    val context = LocalContext.current
    val settings = uiState.settings
    val theme = settings.visualTheme
    val preset = settings.orbColorPreset
    val accent = theme.accentColor(preset)
    val tfColors = omegaTextFieldColors(theme, preset)

    var userNameDraft by remember(settings.userName) { mutableStateOf(settings.userName) }
    var geminiKeyDraft by remember(settings.geminiApiKey) { mutableStateOf(settings.geminiApiKey) }
    var openRouterKeyDraft by remember(settings.openRouterApiKey) { mutableStateOf(settings.openRouterApiKey) }
    var geminiChatModelDraft by remember(settings.geminiChatModel) { mutableStateOf(settings.geminiChatModel) }
    var geminiLiveModelDraft by remember(settings.geminiLiveVoiceModel) { mutableStateOf(settings.geminiLiveVoiceModel) }
    var openRouterModelDraft by remember(settings.openRouterModel) { mutableStateOf(settings.openRouterModel) }
    var wakeWordDraft by remember(settings.wakeWord) { mutableStateOf(settings.wakeWord) }
    var showGeminiKey by remember { mutableStateOf(false) }
    var showOrKey by remember { mutableStateOf(false) }
    var savedBanner by remember { mutableStateOf(false) }
    var showCrashLogs by remember { mutableStateOf(false) }

    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {}

    val hasMic = ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
    val hasContacts = ContextCompat.checkSelfPermission(context, Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED
    val hasCamera = ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
    val hasCalendar = ContextCompat.checkSelfPermission(context, Manifest.permission.READ_CALENDAR) == PackageManager.PERMISSION_GRANTED
    val hasAcc = PanduAccessibilityService.instance != null
    val hasNotif = NotificationManagerCompat.getEnabledListenerPackages(context).contains(context.packageName)

    fun persistDrafts() {
        onSaveSettings {
            it.copy(
                userName = userNameDraft,
                geminiApiKey = geminiKeyDraft,
                openRouterApiKey = openRouterKeyDraft,
                geminiChatModel = geminiChatModelDraft,
                geminiLiveVoiceModel = geminiLiveModelDraft,
                openRouterModel = openRouterModelDraft,
                wakeWord = wakeWordDraft
            )
        }
        savedBanner = true
    }

    OmegaLiquidBackdrop(theme = theme, preset = preset) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(horizontal = 18.dp, vertical = 12.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                GlassCircleButton(Icons.AutoMirrored.Rounded.ArrowBack, theme = theme, preset = preset, onClick = onBack)
                Text("OMEGA 18 Supreme", color = theme.primaryText(), fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.size(42.dp))
            }

            // 1. ULTRA VISUAL ENGINE & ORB COLOR STUDIO
            Column(modifier = Modifier.fillMaxWidth().omegaGlassCard(22.dp, theme, preset).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Visual Engine & Orb Color Studio", fontWeight = FontWeight.Bold, color = theme.primaryText(), fontSize = 15.sp)

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OmegaVisualTheme.entries.forEach { t ->
                        AccentChip(
                            label = t.label,
                            selected = theme == t,
                            accent = accent,
                            theme = theme,
                            modifier = Modifier.weight(1f),
                            onClick = { onSaveSettings { it.copy(visualTheme = t) } }
                        )
                    }
                }

                Text("Orb Color Palette", color = theme.mutedText(), fontSize = 12.sp, fontWeight = FontWeight.Medium)
                Row(
                    modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OrbColorPreset.entries.forEach { p ->
                        val isSel = preset == p
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.clickable { onSaveSettings { it.copy(orbColorPreset = p) } }
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(38.dp)
                                    .clip(CircleShape)
                                    .background(Brush.linearGradient(listOf(Color(p.primaryHex), Color(p.secondaryHex), Color(p.accentHex))))
                                    .border(if (isSel) 2.5.dp else 1.dp, if (isSel) Color.White else Color.Transparent, CircleShape)
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(p.label.split(" ").first(), color = if (isSel) accent else theme.mutedText(), fontSize = 10.5.sp, fontWeight = FontWeight.SemiBold)
                        }
                    }
                }

                ProSwitchRow(theme, preset, "3D Hologram Gyroscope Parallax", "Subtle 3D tilt depth on central orb", settings.gyroscopeParallax) { on ->
                    onSaveSettings { it.copy(gyroscopeParallax = on) }
                }
            }

            // 2. 2-SLOT ENCRYPTED API KEYS (GEMINI + OPENROUTER ONLY!)
            Column(modifier = Modifier.fillMaxWidth().omegaGlassCard(22.dp, theme, preset).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text("AI Engine (2 Encrypted Slots)", fontWeight = FontWeight.Bold, color = theme.primaryText(), fontSize = 15.sp)
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        Icon(Icons.Rounded.Lock, null, tint = OmegaColors.EmeraldLive, modifier = Modifier.size(14.dp))
                        Text("AES-256", color = OmegaColors.EmeraldLive, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                    }
                }

                // Active Provider Selector (ONLY Gemini & OpenRouter)
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    AiProvider.entries.forEach { p ->
                        AccentChip(
                            label = p.displayName,
                            selected = settings.activeProvider == p,
                            accent = accent,
                            theme = theme,
                            modifier = Modifier.weight(1f),
                            onClick = { onSaveSettings { it.copy(activeProvider = p) } }
                        )
                    }
                }

                OutlinedTextField(
                    value = userNameDraft,
                    onValueChange = { userNameDraft = it; savedBanner = false },
                    label = { Text("Your Name") },
                    singleLine = true,
                    shape = RoundedCornerShape(16.dp),
                    colors = tfColors,
                    modifier = Modifier.fillMaxWidth()
                )

                // SLOT 1: GOOGLE GEMINI
                OutlinedTextField(
                    value = geminiKeyDraft,
                    onValueChange = { geminiKeyDraft = it; savedBanner = false },
                    label = { Text("Slot 1: Google Gemini API Key") },
                    singleLine = true,
                    shape = RoundedCornerShape(16.dp),
                    colors = tfColors,
                    visualTransformation = if (showGeminiKey) VisualTransformation.None else PasswordVisualTransformation(),
                    trailingIcon = {
                        IconButton(onClick = { showGeminiKey = !showGeminiKey }) {
                            Icon(if (showGeminiKey) Icons.Rounded.VisibilityOff else Icons.Rounded.Visibility, null, tint = theme.mutedText())
                        }
                    },
                    modifier = Modifier.fillMaxWidth()
                )

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = geminiChatModelDraft,
                        onValueChange = { geminiChatModelDraft = it; savedBanner = false },
                        label = { Text("Gemini Chat Model") },
                        singleLine = true,
                        shape = RoundedCornerShape(16.dp),
                        colors = tfColors,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = geminiLiveModelDraft,
                        onValueChange = { geminiLiveModelDraft = it; savedBanner = false },
                        label = { Text("Live Voice Model") },
                        singleLine = true,
                        shape = RoundedCornerShape(16.dp),
                        colors = tfColors,
                        modifier = Modifier.weight(1f)
                    )
                }

                // SLOT 2: OPENROUTER
                OutlinedTextField(
                    value = openRouterKeyDraft,
                    onValueChange = { openRouterKeyDraft = it; savedBanner = false },
                    label = { Text("Slot 2: OpenRouter API Key (Backup/Primary)") },
                    singleLine = true,
                    shape = RoundedCornerShape(16.dp),
                    colors = tfColors,
                    visualTransformation = if (showOrKey) VisualTransformation.None else PasswordVisualTransformation(),
                    trailingIcon = {
                        IconButton(onClick = { showOrKey = !showOrKey }) {
                            Icon(if (showOrKey) Icons.Rounded.VisibilityOff else Icons.Rounded.Visibility, null, tint = theme.mutedText())
                        }
                    },
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = openRouterModelDraft,
                    onValueChange = { openRouterModelDraft = it; savedBanner = false },
                    label = { Text("OpenRouter Model ID") },
                    singleLine = true,
                    shape = RoundedCornerShape(16.dp),
                    colors = tfColors,
                    modifier = Modifier.fillMaxWidth()
                )

                // Save, Discover Real Models, & Test Connection Buttons
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = { persistDrafts() },
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = accent),
                        modifier = Modifier.weight(1f)
                    ) { Text(if (savedBanner) "Saved" else "Save", color = Color(0xFF060A16), fontWeight = FontWeight.Bold) }

                    Button(
                        onClick = { persistDrafts(); onDiscoverModels() },
                        enabled = !uiState.isDiscoveringModels,
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = OmegaColors.RoyalIndigo),
                        modifier = Modifier.weight(1.1f)
                    ) { Text(if (uiState.isDiscoveringModels) "Scanning..." else "Fetch Models", color = Color.White, fontSize = 12.sp) }

                    Button(
                        onClick = { persistDrafts(); onRunConnectionTest(settings.activeProvider) },
                        enabled = !uiState.isTestingConnection,
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = OmegaColors.EmeraldLive),
                        modifier = Modifier.weight(1f)
                    ) { Text(if (uiState.isTestingConnection) "Ping..." else "Test", color = Color.White, fontWeight = FontWeight.Bold) }
                }

                // Real Discovered Model Chips
                if (uiState.discoveryStatus != null) {
                    Text(uiState.discoveryStatus, color = theme.mutedText(), fontSize = 11.5.sp)
                }
                if (uiState.discoveredChatModels.isNotEmpty()) {
                    Row(
                        modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        uiState.discoveredChatModels.take(10).forEach { mId ->
                            val selected = (settings.activeProvider == AiProvider.GEMINI && geminiChatModelDraft == mId) ||
                                (settings.activeProvider == AiProvider.OPENROUTER && openRouterModelDraft == mId)
                            AccentChip(label = mId, selected = selected, accent = accent, theme = theme) {
                                if (settings.activeProvider == AiProvider.GEMINI) {
                                    geminiChatModelDraft = mId
                                    onSaveSettings { it.copy(geminiChatModel = mId) }
                                } else {
                                    openRouterModelDraft = mId
                                    onSaveSettings { it.copy(openRouterModel = mId) }
                                }
                            }
                        }
                    }
                }

                if (uiState.diagnosticResult != null) {
                    val diag = uiState.diagnosticResult
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .background(if (diag.isSuccess) OmegaColors.EmeraldLive.copy(0.18f) else OmegaColors.CrimsonErr.copy(0.18f))
                            .border(1.dp, if (diag.isSuccess) OmegaColors.EmeraldLive.copy(0.5f) else OmegaColors.CrimsonErr.copy(0.5f), RoundedCornerShape(14.dp))
                            .padding(12.dp)
                    ) {
                        Text(
                            text = diag.summary,
                            color = if (diag.isSuccess) OmegaColors.EmeraldLive else OmegaColors.CrimsonErr,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }

            // 3. VOICE ENGINE, SENSITIVITY, TTS SPEED/PITCH & PRIVACY
            Column(modifier = Modifier.fillMaxWidth().omegaGlassCard(22.dp, theme, preset).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Next-Gen Voice & Audio", fontWeight = FontWeight.Bold, color = theme.primaryText(), fontSize = 15.sp)

                OutlinedTextField(
                    value = wakeWordDraft,
                    onValueChange = { wakeWordDraft = it; savedBanner = false },
                    label = { Text("Custom Wake Word") },
                    singleLine = true,
                    shape = RoundedCornerShape(16.dp),
                    colors = tfColors,
                    modifier = Modifier.fillMaxWidth()
                )

                Text("Wake-Word Sensitivity: ${(settings.wakeSensitivity * 100).toInt()}%", color = theme.mutedText(), fontSize = 12.sp)
                Slider(
                    value = settings.wakeSensitivity,
                    onValueChange = { v -> onSaveSettings { it.copy(wakeSensitivity = v) } },
                    valueRange = 0.1f..1.0f,
                    colors = SliderDefaults.colors(thumbColor = accent, activeTrackColor = accent)
                )

                Text("TTS Speed: ${String.format(Locale.US, "%.2fx", settings.ttsSpeed)} • Pitch: ${String.format(Locale.US, "%.2fx", settings.ttsPitch)}", color = theme.mutedText(), fontSize = 12.sp)
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Slider(
                        value = settings.ttsSpeed,
                        onValueChange = { v -> onSaveSettings { it.copy(ttsSpeed = v) } },
                        valueRange = 0.7f..1.5f,
                        modifier = Modifier.weight(1f),
                        colors = SliderDefaults.colors(thumbColor = accent, activeTrackColor = accent)
                    )
                    Slider(
                        value = settings.ttsPitch,
                        onValueChange = { v -> onSaveSettings { it.copy(ttsPitch = v) } },
                        valueRange = 0.7f..1.4f,
                        modifier = Modifier.weight(1f),
                        colors = SliderDefaults.colors(thumbColor = accent, activeTrackColor = accent)
                    )
                }

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    TtsEmotionStyle.entries.forEach { st ->
                        AccentChip(st.label, settings.ttsStyle == st, accent, theme, Modifier.weight(1f)) {
                            onSaveSettings { it.copy(ttsStyle = st) }
                        }
                    }
                }

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    AccentChip("AUTO (TE+EN)", settings.languageTag == "auto", accent, theme, Modifier.weight(1f)) { onSaveSettings { it.copy(languageTag = "auto") } }
                    AccentChip("తెలుగు", settings.languageTag == "te-IN", accent, theme, Modifier.weight(1f)) { onSaveSettings { it.copy(languageTag = "te-IN") } }
                    AccentChip("English", settings.languageTag == "en-IN", accent, theme, Modifier.weight(1f)) { onSaveSettings { it.copy(languageTag = "en-IN") } }
                }

                ProSwitchRow(theme, preset, "Background Wake & Smart Triggers", "Silent VAD gate + BT/Battery triggers", settings.wakeWordEnabled) { on ->
                    if (on && !hasMic) {
                        val p = buildList {
                            add(Manifest.permission.RECORD_AUDIO)
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) add(Manifest.permission.POST_NOTIFICATIONS)
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) add(Manifest.permission.BLUETOOTH_CONNECT)
                        }.toTypedArray()
                        permLauncher.launch(p)
                    } else onToggleWakeService(on)
                }
                ProSwitchRow(theme, preset, "Gemini Live Duplex Voice", "Real-time WebSocket audio streaming", settings.useGeminiLiveAudio) { on ->
                    onSaveSettings { it.copy(useGeminiLiveAudio = on) }
                }
                ProSwitchRow(theme, preset, "Continuous Conversation", "Auto-listen again after OMEGA speaks", settings.continuousConversation) { on ->
                    onSaveSettings { it.copy(continuousConversation = on) }
                }
                ProSwitchRow(theme, preset, "Bluetooth Headset Voice Routing", "Route mic & audio to BT earbuds", settings.bluetoothVoiceRouting) { on ->
                    onSaveSettings { it.copy(bluetoothVoiceRouting = on) }
                }
                ProSwitchRow(theme, preset, "Microphone Privacy Mute", "Block all mic capture until turned off", settings.micPrivacyMuted) { on ->
                    onSaveSettings { it.copy(micPrivacyMuted = on) }
                }
                ProSwitchRow(theme, preset, "Offline Instant Commands", "Local torch, volume, battery & routines", settings.offlineFastCommands) { on ->
                    onSaveSettings { it.copy(offlineFastCommands = on) }
                }
                ProSwitchRow(theme, preset, "Live Google Search Grounding", "Real-time weather, scores & web info", settings.webSearchGrounding) { on ->
                    onSaveSettings { it.copy(webSearchGrounding = on) }
                }
                ProSwitchRow(theme, preset, "Floating Mini-Orb (Outside App)", "Auto-hides inside OMEGA, floats over other apps", settings.floatingOrbEnabled) { on ->
                    onSaveSettings { it.copy(floatingOrbEnabled = on) }
                }
                ProSwitchRow(theme, preset, "Confirm Notification Replies", "Ask before sending WhatsApp/SMS replies", settings.confirmNotifReply) { on ->
                    onSaveSettings { it.copy(confirmNotifReply = on) }
                }
                ProSwitchRow(theme, preset, "Biometric Protection (Optional)", "Fingerprint/Face check for sensitive tools", settings.biometricSafetyLock) { on ->
                    if (on) {
                        BiometricSafetyGate.authenticate(context, onSuccess = { onSaveSettings { it.copy(biometricSafetyLock = true) } }, onError = {})
                    } else onSaveSettings { it.copy(biometricSafetyLock = false) }
                }
            }

            // 4. SYSTEM HEALTH, API QUOTA, CRASH ANALYZER & ENCRYPTED BACKUP
            Column(modifier = Modifier.fillMaxWidth().omegaGlassCard(22.dp, theme, preset).padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("System Health, Quota & Backup", fontWeight = FontWeight.Bold, color = theme.primaryText(), fontSize = 15.sp)
                val snap = uiState.apiTelemetry
                Text(
                    text = "Requests: ${snap.totalRequests} (Fail: ${snap.failedRequests}) • Avg Latency: ${snap.averageLatencyMs}ms",
                    color = theme.primaryText(), fontSize = 12.5.sp
                )
                Text(
                    text = "Est. Tokens: ${snap.estimatedPromptTokens + snap.estimatedOutputTokens} • Est. Cost: $${String.format(Locale.US, "%.4f", snap.estimatedCostUsd)}",
                    color = theme.mutedText(), fontSize = 12.sp
                )
                Text("Voice Diagnostics: ${uiState.voiceDiagNote}", color = accent, fontSize = 12.sp)

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(
                        onClick = {
                            val blob = onExportBackup()
                            val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            cm.setPrimaryClip(ClipData.newPlainText("OMEGA_BACKUP", blob))
                        },
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.weight(1f)
                    ) { Text("Copy Backup", color = theme.primaryText(), fontSize = 12.sp) }

                    OutlinedButton(
                        onClick = {
                            val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            val clip = cm.primaryClip?.getItemAt(0)?.coerceToText(context)?.toString().orEmpty()
                            onImportBackup(clip)
                        },
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.weight(1f)
                    ) { Text("Restore Clip", color = theme.primaryText(), fontSize = 12.sp) }

                    OutlinedButton(
                        onClick = { showCrashLogs = !showCrashLogs },
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.weight(1f)
                    ) { Text("Crash Logs", color = theme.primaryText(), fontSize = 12.sp) }
                }

                if (uiState.backupStatusText != null) {
                    Text(uiState.backupStatusText, color = OmegaColors.EmeraldLive, fontSize = 11.5.sp)
                }

                if (showCrashLogs) {
                    Box(
                        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Color(0x88000000)).padding(10.dp)
                    ) {
                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text(uiState.crashLogText.takeLast(1200), color = Color(0xFFE2E8F0), fontSize = 11.sp)
                            TextButton(onClick = onClearCrashLogs) { Text("Clear Crash Logs", color = OmegaColors.CrimsonErr) }
                        }
                    }
                }
            }

            // 5. PERMISSIONS DASHBOARD
            Column(modifier = Modifier.fillMaxWidth().omegaGlassCard(22.dp, theme, preset).padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Permissions Dashboard", fontWeight = FontWeight.Bold, color = theme.primaryText(), fontSize = 15.sp)
                PermRow(theme, "Default Assistant (Power Button)", false) {
                    context.startActivity(Intent(Settings.ACTION_VOICE_INPUT_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                }
                PermRow(theme, "Cross-App Automation & Dynamic HUD", hasAcc) {
                    context.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                }
                PermRow(theme, "Notification Reader & Reply", hasNotif) {
                    context.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                }
                PermRow(theme, "Mic, Contacts, Calendar, Camera & BT", hasMic && hasContacts && hasCamera && hasCalendar) {
                    val p = buildList {
                        add(Manifest.permission.RECORD_AUDIO)
                        add(Manifest.permission.READ_CONTACTS)
                        add(Manifest.permission.READ_CALENDAR)
                        add(Manifest.permission.CAMERA)
                        add(Manifest.permission.CALL_PHONE)
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) add(Manifest.permission.BLUETOOTH_CONNECT)
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) add(Manifest.permission.POST_NOTIFICATIONS)
                    }.toTypedArray()
                    permLauncher.launch(p)
                }
            }

            OutlinedButton(onClick = onClearHistory, shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
                Text("Clear Chat History", color = OmegaColors.CrimsonErr)
            }
        }
    }
}

@Composable
private fun ProSwitchRow(
    theme: OmegaVisualTheme,
    preset: OrbColorPreset,
    title: String,
    sub: String,
    checked: Boolean,
    onChange: (Boolean) -> Unit
) {
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Column(modifier = Modifier.weight(1f).padding(end = 8.dp)) {
            Text(title, color = theme.primaryText(), fontWeight = FontWeight.Medium, fontSize = 13.5.sp)
            Text(sub, color = theme.mutedText(), fontSize = 11.5.sp)
        }
        Switch(checked = checked, onCheckedChange = onChange, colors = omegaSwitchColors(theme, preset))
    }
}

@Composable
private fun AccentChip(
    label: String,
    selected: Boolean,
    accent: Color,
    theme: OmegaVisualTheme,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(if (selected) accent else if (theme.isDark()) Color.White.copy(0.08f) else Color.White.copy(0.75f))
            .border(1.dp, if (selected) accent else Color.White.copy(0.18f), RoundedCornerShape(12.dp))
            .clickable { onClick() }
            .padding(vertical = 8.dp, horizontal = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            color = if (selected) Color(0xFF060A16) else theme.primaryText(),
            fontWeight = FontWeight.SemiBold,
            fontSize = 11.5.sp,
            maxLines = 1
        )
    }
}

@Composable
private fun PermRow(theme: OmegaVisualTheme, title: String, granted: Boolean, onClick: () -> Unit) {
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.weight(1f)) {
            Icon(if (granted) Icons.Rounded.CheckCircle else Icons.Rounded.ErrorOutline, null, tint = if (granted) OmegaColors.EmeraldLive else OmegaColors.AmberWarn, modifier = Modifier.size(18.dp))
            Text(title, color = theme.primaryText(), fontSize = 13.sp)
        }
        TextButton(onClick = onClick) { Text(if (granted) "Active" else "Open", fontWeight = FontWeight.SemiBold) }
    }
}
