package com.example.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.data.OrbColorPreset
import kotlin.math.cos
import kotlin.math.sin

/**
 * Real-Time Particle & Liquid Core 3D AI Orb (v18 Supreme):
 * Combines glowing liquid plasma ribbons, orbiting energy particles, and reactive audio scaling.
 */
@Composable
fun ParticleAiOrb(
    size: Dp = 175.dp,
    isListening: Boolean = false,
    audioAmplitude: Float = 0f,
    preset: OrbColorPreset = OrbColorPreset.AURORA_CYAN,
    modifier: Modifier = Modifier
) {
    val inf = rememberInfiniteTransition(label = "particleOrb")
    val smoothAmp by animateFloatAsState(
        targetValue = audioAmplitude.coerceIn(0f, 1f),
        animationSpec = spring(stiffness = Spring.StiffnessMediumLow),
        label = "orbAmp"
    )
    val rotation by inf.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(if (isListening) 4600 else 12000, easing = LinearEasing)),
        label = "rot"
    )
    val waveShift by inf.animateFloat(
        initialValue = 0f,
        targetValue = (2 * Math.PI).toFloat(),
        animationSpec = infiniteRepeatable(tween(2600, easing = LinearEasing)),
        label = "wave"
    )
    val idlePulse by inf.animateFloat(
        initialValue = 0.97f,
        targetValue = 1.03f,
        animationSpec = infiniteRepeatable(tween(2000, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "pulse"
    )

    val c1 = Color(preset.primaryHex)
    val c2 = Color(preset.secondaryHex)
    val c3 = Color(preset.accentHex)
    val scale = if (isListening) 1f + smoothAmp * 0.13f else idlePulse

    Canvas(
        modifier = modifier
            .size(size * scale)
            .shadow(
                elevation = (22 + smoothAmp * 16).dp,
                shape = CircleShape,
                ambientColor = c1,
                spotColor = c2
            )
            .clip(CircleShape)
    ) {
        val radius = this.size.minDimension / 2f
        val center = Offset(this.size.width / 2f, this.size.height / 2f)

        // Deep glowing core gradient
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(Color.White, c1, c2, c3.copy(alpha = 0.92f), Color(0xFF070B18)),
                center = Offset(center.x - radius * 0.22f, center.y - radius * 0.24f),
                radius = radius * 1.42f
            )
        )

        // Liquid energy ribbons
        rotate(degrees = -26f + rotation * 0.18f, pivot = center) {
            val stripes = 9
            val spacing = this.size.height / (stripes - 1)
            val intensity = 8f + smoothAmp * 18f
            for (i in -1..stripes) {
                val y = i * spacing
                val off = sin(waveShift + i * 0.65f) * intensity
                val path = Path().apply {
                    moveTo(-radius * 0.4f, y + off)
                    cubicTo(center.x * 0.45f, y - 28f + off, center.x * 1.55f, y + 28f - off, this@Canvas.size.width + radius * 0.4f, y + off)
                }
                drawPath(
                    path = path,
                    brush = Brush.horizontalGradient(listOf(c2.copy(0.55f), c3.copy(0.60f), c1.copy(0.55f))),
                    style = Stroke(width = spacing * 0.46f, cap = StrokeCap.Round)
                )
                drawPath(
                    path = path,
                    brush = Brush.horizontalGradient(listOf(Color.White.copy(0.80f), c1.copy(0.90f), Color.White.copy(0.65f))),
                    style = Stroke(width = spacing * 0.16f, cap = StrokeCap.Round)
                )
            }
        }

        // Orbiting glowing micro-particles
        val particleCount = 18
        for (i in 0 until particleCount) {
            val angle = (rotation * (Math.PI / 180.0)) * (if (i % 2 == 0) 1.0 else -0.75) + (i * 0.35)
            val orbitR = radius * (0.42f + (i % 4) * 0.13f) * (1f + smoothAmp * 0.08f)
            val px = center.x + (cos(angle) * orbitR).toFloat()
            val py = center.y + (sin(angle * 1.15) * orbitR * 0.85).toFloat()
            val pSize = (1.8f + (i % 3) * 1.1f).dp.toPx() * (0.45f + (size.value / 180f).coerceIn(0.35f, 1.2f))
            drawCircle(
                color = if (i % 3 == 0) Color.White.copy(0.88f) else c1.copy(0.75f),
                radius = pSize,
                center = Offset(px, py)
            )
        }

        // Specular top-left glass reflection
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(Color.White.copy(0.60f), Color.Transparent),
                center = Offset(center.x - radius * 0.36f, center.y - radius * 0.38f),
                radius = radius * 0.52f
            )
        )
    }
}
