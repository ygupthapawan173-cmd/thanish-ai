package com.example.ui

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.BackHandler
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.graphics.Brush
import com.example.BuildConfig
import com.example.omega.OmegaWakeService
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.example.control.BiometricSafetyGate
import com.example.control.PanduAccessibilityService
import com.example.data.AiProvider
import com.example.ai.SmartModelPolicy
import com.example.data.OmegaSettings
import com.example.data.OmegaVisualTheme
import com.example.data.OrbColorPreset
import com.example.data.TtsEmotionStyle
import com.example.ui.components.ParticleAiOrb
import com.example.ui.theme.OmegaColors
import com.example.ui.theme.OmegaLiquidBackdrop
import com.example.ui.theme.accentColor
import com.example.ui.theme.mutedText
import com.example.ui.theme.omegaSwitchColors
import com.example.ui.theme.omegaTextFieldColors
import com.example.ui.theme.primaryText
import java.util.Locale

/**
 * Premium Grouped List Settings UI (v21.1):
 * Pure AMOLED black, zero aura light, clean grouped list rows with icon plates & hairline dividers.
 */
@Composable
fun SettingsScreen(
    uiState: PanduUiState,
    onBack: () -> Unit,
    onSaveSettings: ((OmegaSettings) -> OmegaSettings) -> Boolean,
    onRunConnectionTest: (AiProvider) -> Unit,
    onDiscoverModels: () -> Unit,
    onTestSpeaker: () -> Unit,
    onRefreshVoiceCatalog: () -> Unit,
    onVoicePreview: (String) -> Unit,
    onToggleWakeService: (Boolean) -> Unit,
    onExportBackup: () -> String,
    onImportBackup: (String) -> Unit,
    onClearCrashLogs: () -> Unit,
    onClearHistory: () -> Unit,
    onOpenMemory: () -> Unit,
    onOpenLab: () -> Unit
) {
    val context = LocalContext.current
    val settings = uiState.settings
    val theme = settings.visualTheme
    val preset = settings.orbColorPreset
    val accent = ObsidianAccent
    val tfColors = OutlinedTextFieldDefaults.colors(focusedTextColor = ObsidianText, unfocusedTextColor = ObsidianText, focusedBorderColor = ObsidianAccent, unfocusedBorderColor = ObsidianBorder, focusedLabelColor = ObsidianAccent, unfocusedLabelColor = ObsidianMuted, cursorColor = ObsidianAccent)

    var assistantNameDraft by remember(settings.assistantName) { mutableStateOf(settings.assistantName) }
    var userNameDraft by remember(settings.userName) { mutableStateOf(settings.userName) }
    var geminiKeyDraft by remember(settings.geminiApiKey) { mutableStateOf(settings.geminiApiKey) }
    var openRouterKeyDraft by remember(settings.openRouterApiKey) { mutableStateOf(settings.openRouterApiKey) }
    var geminiChatModelDraft by remember(settings.geminiChatModel) { mutableStateOf(settings.geminiChatModel) }
    var geminiLiveModelDraft by remember(settings.geminiLiveVoiceModel) { mutableStateOf(settings.geminiLiveVoiceModel) }
    var openRouterModelDraft by remember(settings.openRouterModel) { mutableStateOf(settings.openRouterModel) }
    var gatewayUrlDraft by remember(settings.gatewayBaseUrl) { mutableStateOf(settings.gatewayBaseUrl) }
    var providerDraft by remember(settings.activeProvider) { mutableStateOf(settings.activeProvider) }
    var wakeWordDraft by remember(settings.wakeWord) { mutableStateOf(settings.wakeWord) }
    var showGeminiKey by remember { mutableStateOf(false) }
    var showOrKey by remember { mutableStateOf(false) }
    var savedBanner by remember { mutableStateOf(false) }
    var showCrashLogs by remember { mutableStateOf(false) }

    var pendingWakePermission by remember { mutableStateOf(false) }
    var permissionRefresh by remember { mutableStateOf(0) }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { grants ->
        permissionRefresh++
        if (pendingWakePermission) {
            pendingWakePermission = false
            onToggleWakeService(grants[Manifest.permission.RECORD_AUDIO] == true)
        }
    }

    val hasMic = remember(permissionRefresh, settings.wakeWordEnabled) { ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED }
    val hasContacts = ContextCompat.checkSelfPermission(context, Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED
    val hasCamera = ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
    val hasCalendar = ContextCompat.checkSelfPermission(context, Manifest.permission.READ_CALENDAR) == PackageManager.PERMISSION_GRANTED
    val hasAcc = PanduAccessibilityService.instance != null
    val hasNotif = NotificationManagerCompat.getEnabledListenerPackages(context).contains(context.packageName)

    fun persistDrafts(): Boolean {
        val ok = onSaveSettings {
            it.copy(
                userName = userNameDraft,
                assistantName = assistantNameDraft,
                geminiApiKey = geminiKeyDraft,
                openRouterApiKey = openRouterKeyDraft,
                geminiChatModel = geminiChatModelDraft,
                geminiLiveVoiceModel = geminiLiveModelDraft,
                openRouterModel = openRouterModelDraft,
                gatewayBaseUrl = gatewayUrlDraft,
                activeProvider = providerDraft,
                wakeWord = wakeWordDraft
            )
        }
        savedBanner = ok
        return ok
    }

    var page by rememberSaveable { mutableStateOf(-1) }
    var search by rememberSaveable { mutableStateOf("") }
    var confirmHistory by remember { mutableStateOf(false) }
    var confirmOwner by remember { mutableStateOf(false) }
    val wakeStatus by OmegaWakeService.status.collectAsState()
    val categories = listOf(
        Triple("AI & API Engine", "Universal Smart API, model routing, Gemini Live", Icons.Rounded.Memory),
        Triple("Voice & Audio", "Telugu English voice packs, speed, pitch, preview", Icons.Rounded.Mic),
        Triple("Wake Word", "Hey JARVIS, sensitivity, phrase", Icons.Rounded.RecordVoiceOver),
        Triple("Owner Voice", "Voice training, profile, owner filter", Icons.Rounded.Person),
        Triple("Conversation", "Continuous conversation, Gemini Live", Icons.Rounded.Loop),
        Triple("Background & Battery", "Wake service, Bluetooth, battery", Icons.Rounded.BluetoothAudio),
        Triple("Device Control", "Accessibility, phone permissions", Icons.Rounded.AccessibilityNew),
        Triple("Assistant Personality", "Assistant name, owner name, reply style", Icons.Rounded.Person),
        Triple("Appearance", "Home theme, orb colors, animation", Icons.Rounded.BubbleChart),
        Triple("Personal Memory", "History, memories, routines", Icons.Rounded.Memory),
        Triple("Privacy & Security", "Microphone mute, biometric, reply confirmation", Icons.Rounded.Security),
        Triple("Diagnostics", "API health, crash logs, voice diagnostics", Icons.Rounded.BugReport),
        Triple("System Updates", "Release checks, encrypted backup, restore", Icons.Rounded.Restore),
        Triple("About OMEGA", "Version, creator, Android compatibility", Icons.Rounded.Info)
    )
    fun goBack() { if(page in listOf(0,2,7) && !persistDrafts()) return; savedBanner=false; if(page == -1) onBack() else page=-1 }
    BackHandler { goBack() }
    if(confirmHistory) AlertDialog(onDismissRequest={confirmHistory=false},title={Text("Clear chat history?")},text={Text("This permanently removes saved chat messages.")},confirmButton={TextButton(onClick={confirmHistory=false;onClearHistory()}) { Text("Clear") }},dismissButton={TextButton(onClick={confirmHistory=false}) { Text("Cancel") }})
    if(confirmOwner) AlertDialog(onDismissRequest={confirmOwner=false},title={Text("Delete owner voice profile?")},confirmButton={TextButton(onClick={confirmOwner=false;OmegaWakeService.ownerAction(context,"clear")}) { Text("Delete") }},dismissButton={TextButton(onClick={confirmOwner=false}) { Text("Cancel") }})
    MaterialTheme(colorScheme = darkColorScheme(primary=ObsidianAccent,onPrimary=Color(0xFF10252C),surface=ObsidianPanel,onSurface=ObsidianText,background=Color(0xFF030609),onBackground=ObsidianText,secondary=ObsidianAccent,onSecondary=Color.Black,outline=ObsidianBorder, onSurfaceVariant=ObsidianMuted, secondaryContainer=Color(0xFF1B343E), onSecondaryContainer=ObsidianText)) {
    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF030609),Color(0xFF0B171E),Color(0xFF030609))))) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
        ) {
            // Minimalist Top Header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick={goBack()},modifier=Modifier.size(48.dp).background(ObsidianPanel,CircleShape)) { Icon(Icons.AutoMirrored.Rounded.ArrowBack,"Back",tint=ObsidianAccent) }
                Column(modifier=Modifier.weight(1f).padding(horizontal=8.dp),horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(if(page == -1) "Settings" else categories[page].first, color = ObsidianText, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                    Text("OMEGA ${BuildConfig.VERSION_NAME.substringBefore('-')} • Obsidian Glass", color = ObsidianMuted, fontSize = 11.sp)
                }
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .background(accent)
                        .clickable { persistDrafts() }
                        .padding(horizontal = 14.dp, vertical = 8.dp)
                ) {
                    Text("Save", color = Color.Black, fontSize = 12.5.sp, fontWeight = FontWeight.Bold)
                }
            }

            if (savedBanner) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 4.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(OmegaColors.EmeraldLive.copy(alpha = 0.14f))
                        .border(1.dp, OmegaColors.EmeraldLive.copy(alpha = 0.35f), RoundedCornerShape(12.dp))
                        .padding(horizontal = 12.dp, vertical = 8.dp)
                ) {
                    Text("Settings saved locally.", color = OmegaColors.EmeraldLive, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                }
            }

            // Settings index and individual submenu contents
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(key(page) { rememberScrollState() })
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(20.dp)
            ) {
                // ==========================================================
                // SECTION 1: AI & API KEYS
                // ==========================================================
                if (page == -1) {
                    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(Brush.verticalGradient(listOf(Color(0xFF16323D), Color(0xFF0C1C24)))).border(1.dp,ObsidianBorder,RoundedCornerShape(24.dp)).padding(22.dp),horizontalAlignment=Alignment.CenterHorizontally) {
                        Box(Modifier.size(76.dp).background(Color(0xFF173942),CircleShape).border(2.dp,ObsidianAccent,CircleShape),contentAlignment=Alignment.Center) { Text("Ω",color=ObsidianAccent,fontSize=40.sp) }
                        Spacer(Modifier.height(12.dp)); Text("Control Center",color=ObsidianText,fontSize=22.sp,fontWeight=FontWeight.Bold)
                        Text(BuildConfig.VERSION_NAME,color=ObsidianMuted,fontSize=12.sp)
                    }
                    OutlinedTextField(search,{search=it},label={Text("Search settings")},leadingIcon={Icon(Icons.Rounded.Search,null,tint=ObsidianAccent)},singleLine=true,colors=tfColors,modifier=Modifier.fillMaxWidth())
                    categories.forEachIndexed { index, category ->
                        if((category.first+" "+category.second).contains(search,true)) {
                            SettingsGroupSection(title="") { SettingsActionRow(category.third,category.first,category.second,theme) { page=index } }
                        }
                    }
                } else when(page) {
                    0 -> SettingsGroupSection(title = categories[0].first.uppercase()) {

                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("1 · UNIVERSAL SMART API", color = accent, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                        Text("One gateway key, models selected for each question. Native Gemini remains an optional compatibility mode using the Gemini key below.", color = ObsidianMuted, fontSize = 12.sp)
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf(AiProvider.OPENROUTER to "Smart Gateway", AiProvider.GEMINI to "Gemini Direct").forEach { (prov, label) ->
                                FilterChip(selected = providerDraft == prov, onClick = { providerDraft = prov; savedBanner = false }, label = { Text(label) }, modifier = Modifier.weight(1f))
                            }
                        }
                        if (providerDraft == AiProvider.OPENROUTER) {
                            Text("OpenAI-compatible gateway (AICredits, AIRouter, Velona, Yantra, TokenRex, OpenRouter or custom). Enter its official HTTPS API base URL.", color = ObsidianMuted, fontSize = 12.sp)
                            OutlinedTextField(value = gatewayUrlDraft, onValueChange = { newUrl ->
                                if (newUrl.trim().trimEnd('/') != gatewayUrlDraft.trim().trimEnd('/')) openRouterKeyDraft = ""
                                gatewayUrlDraft = newUrl; savedBanner = false
                            }, label = { Text("Gateway HTTPS base URL") }, singleLine = true, colors = tfColors, modifier = Modifier.fillMaxWidth())
                            OutlinedTextField(value = openRouterKeyDraft, onValueChange = { openRouterKeyDraft = it; savedBanner = false },
                                label = { Text("Smart API key (encrypted)") }, singleLine = true,
                                visualTransformation = if (showOrKey) VisualTransformation.None else PasswordVisualTransformation(),
                                trailingIcon = { IconButton(onClick = { showOrKey = !showOrKey }) { Icon(if (showOrKey) Icons.Rounded.VisibilityOff else Icons.Rounded.Visibility, null, tint = ObsidianMuted) } },
                                colors = tfColors, modifier = Modifier.fillMaxWidth())
                            Text("Model routing mode", color = ObsidianMuted, fontSize = 12.sp)
                            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                listOf(SmartModelPolicy.Mode.ECONOMY to "Economy", SmartModelPolicy.Mode.SMART to "Smart Auto", SmartModelPolicy.Mode.ULTRA to "Ultra Performance", SmartModelPolicy.Mode.MANUAL to "Manual model").forEach { (mode, label) ->
                                    FilterChip(selected = settings.smartMode == mode, onClick = { onSaveSettings { it.copy(smartMode = mode) } }, label = { Text(label) })
                                }
                            }
                            Text("Auto ranking uses published model metadata when available and model-name hints. Price and access are not guaranteed; set a hard spending cap in the provider dashboard.", color = ObsidianMuted, fontSize = 11.5.sp)
                            if (settings.smartMode == SmartModelPolicy.Mode.MANUAL) {
                                OutlinedTextField(value = openRouterModelDraft, onValueChange = { openRouterModelDraft = it; savedBanner = false }, label = { Text("Exact discovered model ID") }, singleLine = true, colors = tfColors, modifier = Modifier.fillMaxWidth())
                            }
                        } else {
                            OutlinedTextField(value = geminiChatModelDraft, onValueChange = { geminiChatModelDraft = it; savedBanner = false }, label = { Text("Gemini Direct chat model") }, singleLine = true, colors = tfColors, modifier = Modifier.fillMaxWidth())
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick = { if (persistDrafts()) onRunConnectionTest(providerDraft) }, enabled = !uiState.isTestingConnection, modifier = Modifier.weight(1f)) { Text("Test Chat API", color = ObsidianText, fontSize = 12.sp) }
                            OutlinedButton(onClick = { if (persistDrafts()) onDiscoverModels() }, enabled = !uiState.isDiscoveringModels, modifier = Modifier.weight(1f)) { Text("Discover Models", color = accent, fontSize = 12.sp) }
                        }
                        if (!savedBanner) uiState.discoveryStatus?.takeIf { it.contains("not saved", true) }?.let { Text(it, color = OmegaColors.CrimsonErr, fontSize = 12.sp) }
                        if (savedBanner && providerDraft == settings.activeProvider) {
                            uiState.discoveryStatus?.let { Text(it, color = ObsidianMuted, fontSize = 11.5.sp) }
                            if (uiState.discoveredChatModels.isNotEmpty()) {
                                Text("Discovered chat models", color = ObsidianMuted, fontSize = 11.5.sp)
                                Row(modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    uiState.discoveredChatModels.take(100).forEach { id ->
                                        AssistChip(onClick = {
                                            if (providerDraft == AiProvider.GEMINI) { geminiChatModelDraft = id; onSaveSettings { it.copy(geminiChatModel = id) } }
                                            else { openRouterModelDraft = id; onSaveSettings { it.copy(openRouterModel = id, smartMode = SmartModelPolicy.Mode.MANUAL) } }
                                        }, label = { Text(id) })
                                    }
                                }
                            }
                            uiState.diagnosticResult?.takeIf { it.provider == providerDraft }?.let { result ->
                                Text(result.summary, color = if (result.isSuccess) OmegaColors.EmeraldLive else OmegaColors.CrimsonErr, fontSize = 12.sp)
                            }
                        }
                        Text("Last successful model: ${uiState.apiTelemetry.lastUsedModel.ifBlank { "Not used yet" }}", color = ObsidianMuted, fontSize = 12.sp)
                        SettingsHairlineDivider()
                        Text("2 · GEMINI LIVE VOICE", color = accent, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                        Text("Independent Google key for Live voice/camera. When Live is enabled, its conversation uses Gemini Live instead of the Smart Gateway. Turn Live off to route speech-to-text questions through the gateway.", color = ObsidianMuted, fontSize = 12.sp)
                        OutlinedTextField(value = geminiKeyDraft, onValueChange = { geminiKeyDraft = it; savedBanner = false },
                            label = { Text("Gemini API key (encrypted)") }, singleLine = true,
                            visualTransformation = if (showGeminiKey) VisualTransformation.None else PasswordVisualTransformation(),
                            trailingIcon = { IconButton(onClick = { showGeminiKey = !showGeminiKey }) { Icon(if (showGeminiKey) Icons.Rounded.VisibilityOff else Icons.Rounded.Visibility, null, tint = ObsidianMuted) } },
                            colors = tfColors, modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(value = geminiLiveModelDraft, onValueChange = { geminiLiveModelDraft = it; savedBanner = false }, label = { Text("Gemini Live model") }, singleLine = true, colors = tfColors, modifier = Modifier.fillMaxWidth())
                        if (savedBanner && providerDraft == AiProvider.GEMINI && uiState.discoveredLiveModels.isNotEmpty()) {
                            Row(modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                uiState.discoveredLiveModels.take(20).forEach { id -> AssistChip(onClick = { geminiLiveModelDraft = id; onSaveSettings { it.copy(geminiLiveVoiceModel = id) } }, label = { Text(id) }) }
                            }
                        }
                        SettingsSwitchRow(Icons.Rounded.Mic, "Gemini Live duplex", "Separate real-time voice session", settings.useGeminiLiveAudio, theme, preset) { v -> onSaveSettings { it.copy(useGeminiLiveAudio = v) } }
                        OutlinedButton(onClick = { persistDrafts() }, modifier = Modifier.fillMaxWidth()) { Text("Save API settings", color = accent) }
                    }

                    SettingsHairlineDivider()
                    SettingsSwitchRow(
                        icon = Icons.Rounded.Memory,
                        title = "Local Brain Mode",
                        subtitle = "Local commands and memory without cloud API",
                        checked = settings.localBrainMode,
                        theme = theme,
                        preset = preset,
                        onCheckedChange = { v -> onSaveSettings { it.copy(localBrainMode = v) } }
                    )
                    SettingsHairlineDivider()
                    SettingsSwitchRow(Icons.Rounded.FlashOn, "Offline Instant Commands", "Local torch, volume, battery and routines", settings.offlineFastCommands, theme, preset) { v -> onSaveSettings { it.copy(offlineFastCommands = v) } }
                    SettingsHairlineDivider()
                    SettingsSwitchRow(Icons.Rounded.Search, "Google Search Grounding", "Use web grounding on compatible cloud models", settings.webSearchGrounding, theme, preset) { v -> onSaveSettings { it.copy(webSearchGrounding = v) } }
                    }
                    1 -> SettingsGroupSection(title = categories[1].first.uppercase()) {
                    SettingsSwitchRow(Icons.Rounded.Mic, "Prefer offline speech recognition", "Use bundled Telugu recognition or offline English without disabling cloud chat", settings.preferOfflineSpeech, theme,preset) { v -> onSaveSettings { it.copy(preferOfflineSpeech=v) } }
                    SettingsHairlineDivider()
Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Mic: ${uiState.voiceDiagNote} • TTS: ${uiState.ttsStatusNote}", color = ObsidianMuted, fontSize = 12.sp)
                        OutlinedButton(onClick = onTestSpeaker, modifier = Modifier.fillMaxWidth()) { Text("Test Speaker Voice") }
                    }

                    SettingsSwitchRow(
                        icon = Icons.Rounded.VolumeUp,
                        title = "Auto-Speak All Replies (TTS)",
                        subtitle = "Speak assistant replies using the selected voice engine",
                        checked = settings.autoSpeak,
                        theme = theme,
                        preset = preset,
                        onCheckedChange = { v -> onSaveSettings { it.copy(autoSpeak = v) } }
                    )



                    VoicePackPanel(uiState, onRefreshVoiceCatalog, onVoicePreview)



                    // Language & TTS Speed Row
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Voice Language", color = ObsidianMuted, fontSize = 11.5.sp, fontWeight = FontWeight.Medium)
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf("auto" to "Auto (TE+EN)", "te-IN" to "తెలుగు", "en-IN" to "English").forEach { (tag, label) ->
                                val sel = settings.languageTag == tag
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(if (sel) accent else Color(0xFF1B343E))
                                        .clickable { onSaveSettings { it.copy(languageTag = tag) } }
                                        .padding(vertical = 8.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(label, color = if (sel) Color.Black else ObsidianText, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                                }
                            }
                        }
                        Text(
                            "TTS Speed: ${String.format(Locale.US, "%.2fx", settings.ttsSpeed)} • Pitch: ${String.format(Locale.US, "%.2fx", settings.ttsPitch)}",
                            color = ObsidianMuted,
                            fontSize = 11.5.sp
                        )
                        Slider(
                            value = settings.ttsSpeed,
                            onValueChange = { v -> onSaveSettings { it.copy(ttsSpeed = v) } },
                            valueRange = 0.7f..1.5f
                        )
                        Text("Pitch", color = ObsidianMuted, fontSize = 11.5.sp)
                        Slider(settings.ttsPitch, { v -> onSaveSettings { it.copy(ttsPitch = v) } }, valueRange = 0.7f..1.4f)
                        Text("Voice style", color = ObsidianMuted, fontSize = 11.5.sp)
                        Row(modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            TtsEmotionStyle.entries.forEach { st ->
                                FilterChip(selected = settings.ttsStyle == st, onClick = { onSaveSettings { it.copy(ttsStyle = st) } }, label = { Text(st.label) })
                            }
                        }
                    }
                    }
                    2 -> SettingsGroupSection(title = categories[2].first.uppercase()) {
Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedTextField(wakeWordDraft, { wakeWordDraft = it; savedBanner = false }, label = { Text("Wake Word Phrase") }, singleLine = true, colors = tfColors, modifier = Modifier.fillMaxWidth())
                        Text("Wake sensitivity: ${(settings.wakeSensitivity * 100).toInt()}%", color = ObsidianMuted, fontSize = 12.sp)
                        Slider(settings.wakeSensitivity, { v -> onSaveSettings { it.copy(wakeSensitivity = v) } }, valueRange = 0.2f..1.0f)
                    }
                    SettingsHairlineDivider()

                    SettingsSwitchRow(
                        icon = Icons.Rounded.RecordVoiceOver,
                        title = "Hey Jarvis Background Wake",
                        subtitle = "Listen continuously in background",
                        checked = settings.wakeWordEnabled,
                        theme = theme,
                        preset = preset,
                        onCheckedChange = { on ->
                            if (on && !hasMic) { pendingWakePermission = true; permLauncher.launch(if (Build.VERSION.SDK_INT >= 33) arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.POST_NOTIFICATIONS) else arrayOf(Manifest.permission.RECORD_AUDIO)) }
                            else onToggleWakeService(on)
                        }
                    )

                    }
                    3 -> SettingsGroupSection(title = categories[3].first.uppercase()) {
Column(Modifier.padding(14.dp),verticalArrangement=Arrangement.spacedBy(10.dp)) {
                        Text("Wake service: $wakeStatus", color=ObsidianMuted)
                        Text(if(!OmegaWakeService.isRunning()) "Start wake service to inspect profile" else if(OmegaWakeService.ownerEnrolled()) "Owner profile enrolled" else "No enrolled owner profile", color=ObsidianText)
                        Text("Owner filtering currently supports English recognition; requires active wake service and unlocked phone.",color=ObsidianMuted,fontSize=12.sp)
                        if(!OmegaWakeService.isRunning()) OutlinedButton(onClick={page=2}) { Text("Open wake settings") }
                        else {
                            if(!OmegaWakeService.ownerEnrolled()) OutlinedButton(onClick={OmegaWakeService.ownerAction(context,"train")}) { Text("Train owner voice (3 samples)") }
                            else {
                                OutlinedButton(onClick={OmegaWakeService.ownerAction(context,"filter")}) { Text(if(OmegaWakeService.ownerFilterEnabled()) "Disable owner filter" else "Enable owner filter") }
                                OutlinedButton(onClick={confirmOwner=true}) { Text("Delete owner profile") }
                            }
                        }
                    }
                    }
                    4 -> SettingsGroupSection(title = categories[4].first.uppercase()) {

                    SettingsSwitchRow(
                        icon = Icons.Rounded.Loop,
                        title = "Continuous Conversation",
                        subtitle = "Auto-rearm mic after OMEGA finishes speaking",
                        checked = settings.continuousConversation,
                        theme = theme,
                        preset = preset,
                        onCheckedChange = { v -> onSaveSettings { it.copy(continuousConversation = v) } }
                    )

SettingsHairlineDivider()

                    SettingsSwitchRow(
                        icon = Icons.Rounded.GraphicEq,
                        title = "Gemini Live Duplex Voice (WS)",
                        subtitle = "Low-latency WebSocket audio (Gemini key required)",
                        checked = settings.useGeminiLiveAudio,
                        theme = theme,
                        preset = preset,
                        onCheckedChange = { v -> onSaveSettings { it.copy(useGeminiLiveAudio = v) } }
                    )

                    }
                    5 -> SettingsGroupSection(title = categories[5].first.uppercase()) {

                    SettingsSwitchRow(
                        icon = Icons.Rounded.RecordVoiceOver,
                        title = "Hey Jarvis Background Wake",
                        subtitle = "Listen continuously in background",
                        checked = settings.wakeWordEnabled,
                        theme = theme,
                        preset = preset,
                        onCheckedChange = { on ->
                            if (on && !hasMic) { pendingWakePermission = true; permLauncher.launch(if (Build.VERSION.SDK_INT >= 33) arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.POST_NOTIFICATIONS) else arrayOf(Manifest.permission.RECORD_AUDIO)) }
                            else onToggleWakeService(on)
                        }
                    )

SettingsHairlineDivider()

                    SettingsSwitchRow(
                        icon = Icons.Rounded.BluetoothAudio,
                        title = "Bluetooth Headset Routing",
                        subtitle = "Route mic & audio to BT earbuds",
                        checked = settings.bluetoothVoiceRouting,
                        theme = theme,
                        preset = preset,
                        onCheckedChange = { v -> onSaveSettings { it.copy(bluetoothVoiceRouting = v) } }
                    )

SettingsActionRow(Icons.Rounded.Settings, "Battery settings", "Android controls background restrictions", theme) { runCatching { context.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) } }
                    Text("Wake service: $wakeStatus", color = ObsidianMuted, modifier = Modifier.padding(14.dp), fontSize = 12.sp)
                    }
                    6 -> SettingsGroupSection(title = categories[6].first.uppercase()) {

                    SettingsActionRow(
                        icon = Icons.Rounded.Mic,
                        title = "App Permissions (Mic, Camera, Contacts, Calendar, Bluetooth)",
                        subtitle = "Mic: ${if (hasMic) "OK" else "Denied"} • Cam: ${if (hasCamera) "OK" else "Denied"} • Contacts: ${if (hasContacts) "OK" else "Denied"}",
                        theme = theme,
                        onClick = {
                            val perms = buildList {
                                add(Manifest.permission.RECORD_AUDIO)
                                add(Manifest.permission.CAMERA)
                                add(Manifest.permission.READ_CONTACTS)
                                add(Manifest.permission.READ_CALENDAR)
                                add(Manifest.permission.CALL_PHONE)
                                if (Build.VERSION.SDK_INT >= 31) add(Manifest.permission.BLUETOOTH_CONNECT)
                                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) add(Manifest.permission.POST_NOTIFICATIONS)
                            }
                            permLauncher.launch(perms.toTypedArray())
                        }
                    )

SettingsHairlineDivider()

                    SettingsActionRow(
                        icon = Icons.Rounded.AccessibilityNew,
                        title = "Accessibility Service",
                        subtitle = if (hasAcc) "Active — UI automation ready" else "Tap to enable in Android Settings",
                        theme = theme,
                        onClick = { runCatching { context.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) } }
                    )

SettingsHairlineDivider()

                    SettingsActionRow(
                        icon = Icons.Rounded.NotificationsActive,
                        title = "Notification Listener",
                        subtitle = if (hasNotif) "Active — Can read & reply alerts" else "Tap to grant notification access",
                        theme = theme,
                        onClick = { runCatching { context.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) } }
                    )

SettingsHairlineDivider()

                    SettingsActionRow(Icons.Rounded.Settings, "Default Assistant", "Open Android voice input settings", theme) {
                        runCatching { context.startActivity(Intent(Settings.ACTION_VOICE_INPUT_SETTINGS)) }
                    }

                    }
                    7 -> SettingsGroupSection(title = categories[7].first.uppercase()) {
                    Column(Modifier.padding(14.dp),verticalArrangement=Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(assistantNameDraft,{assistantNameDraft=it.take(40)},label={Text("Assistant name (chat identity)")},singleLine=true,colors=tfColors,modifier=Modifier.fillMaxWidth())
                        Text("Reply style",color=ObsidianMuted,fontSize=12.sp)
                        Row(Modifier.horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(6.dp)) {
                            listOf("Natural","Professional","Friendly","Concise").forEach { style -> FilterChip(selected=settings.replyStyle==style,onClick={onSaveSettings { it.copy(replyStyle=style) }},label={Text(style)}) }
                        }
                    }

                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = userNameDraft,
                            onValueChange = { userNameDraft = it; savedBanner = false },
                            label = { Text("Your Name") },
                            singleLine = true,
                            colors = tfColors,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }

                    }
                    8 -> SettingsGroupSection(title = categories[8].first.uppercase()) {

                    Column(
                        modifier = Modifier.fillMaxWidth().padding(14.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        ParticleAiOrb(size = 110.dp, isListening = true, audioAmplitude = 0.25f, preset = preset)
                        Row(modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            OrbColorPreset.entries.forEach { p ->
                                val sel = preset == p
                                Column(
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    modifier = Modifier.clickable { onSaveSettings { it.copy(orbColorPreset = p) } }
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(34.dp)
                                            .clip(CircleShape)
                                            .background(Color(p.primaryHex))
                                            .border(if (sel) 2.5.dp else 1.dp, if (sel) Color.White else ObsidianBorder, CircleShape)
                                    )
                                    Spacer(Modifier.height(4.dp))
                                    Text(p.label, color = if (sel) Color.White else ObsidianMuted, fontSize = 10.5.sp)
                                }
                            }
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OmegaVisualTheme.entries.forEach { t ->
                                val sel = theme == t
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(if (sel) accent else Color(0xFF1B343E))
                                        .clickable { onSaveSettings { it.copy(visualTheme = t) } }
                                        .padding(vertical = 8.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(t.label, color = if (sel) Color.Black else ObsidianText, fontSize = 11.5.sp, fontWeight = FontWeight.SemiBold)
                                }
                            }
                        }
                    }
                    SettingsHairlineDivider()
                    SettingsSwitchRow(
                        icon = Icons.Rounded.ScreenRotation,
                        title = "3D Gyroscope Parallax",
                        subtitle = "Subtle depth tilt on Home Orb",
                        checked = settings.gyroscopeParallax,
                        theme = theme,
                        preset = preset,
                        onCheckedChange = { v -> onSaveSettings { it.copy(gyroscopeParallax = v) } }
                    )
                    SettingsHairlineDivider()
                    SettingsSwitchRow(
                        icon = Icons.Rounded.BubbleChart,
                        title = "Floating Mini-Orb",
                        subtitle = "Float over other apps (requires overlay)",
                        checked = settings.floatingOrbEnabled,
                        theme = theme,
                        preset = preset,
                        onCheckedChange = { v -> onSaveSettings { it.copy(floatingOrbEnabled = v) } }
                    )
                    }
                    9 -> SettingsGroupSection(title = categories[9].first.uppercase()) {
SettingsActionRow(Icons.Rounded.Memory,"Saved memories & routines","${uiState.memories.size} saved memories",theme,onClick=onOpenMemory)
                    SettingsActionRow(Icons.Rounded.DeleteOutline,"Clear chat history","Permanently remove saved chat messages",theme,titleColor=OmegaColors.CrimsonErr) { confirmHistory=true }
                    }
                    10 -> SettingsGroupSection(title = categories[10].first.uppercase()) {

                    SettingsSwitchRow(
                        icon = Icons.Rounded.MicOff,
                        title = "Microphone Privacy Mute",
                        subtitle = "Temporarily block all microphone access",
                        checked = settings.micPrivacyMuted,
                        theme = theme,
                        preset = preset,
                        onCheckedChange = { v -> onSaveSettings { it.copy(micPrivacyMuted = v) } }
                    )


                    SettingsSwitchRow(Icons.Rounded.Notifications, "Confirm Notification Replies", "Require confirmation before sending", settings.confirmNotifReply, theme, preset) { v -> onSaveSettings { it.copy(confirmNotifReply = v) } }

SettingsHairlineDivider()

                    SettingsSwitchRow(Icons.Rounded.Security, "Biometric Protection (Optional)", "Authenticate sensitive tools", settings.biometricSafetyLock, theme, preset) { v -> if (v) BiometricSafetyGate.authenticate(context, onSuccess = { onSaveSettings { it.copy(biometricSafetyLock = true) } }, onError = {}) else onSaveSettings { it.copy(biometricSafetyLock = false) } }
                    }
                    11 -> SettingsGroupSection(title = categories[11].first.uppercase()) {

                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        val snap = uiState.apiTelemetry
                        Text("API requests: ${snap.totalRequests} • Failed: ${snap.failedRequests} • Average: ${snap.averageLatencyMs} ms", color = ObsidianMuted, fontSize = 12.sp)
                        uiState.backupStatusText?.let { Text(it, color = ObsidianMuted, fontSize = 11.5.sp) }
                    }

SettingsHairlineDivider()

                    SettingsActionRow(
                        icon = Icons.Rounded.BugReport,
                        title = "Crash Logs",
                        subtitle = if (showCrashLogs) "Tap to hide logs" else "Tap to view or clear crash logs",
                        theme = theme,
                        onClick = { showCrashLogs = !showCrashLogs }
                    )
                    if (showCrashLogs) {
                        Column(modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text(
                                text = uiState.crashLogText.ifBlank { "No crash logs recorded." }.takeLast(4000),
                                color = ObsidianMuted,
                                fontSize = 11.sp
                            )
                            TextButton(onClick = onClearCrashLogs) {
                                Text("Clear Crash Logs", color = OmegaColors.CrimsonErr, fontSize = 12.sp)
                            }
                        }
                    }

SettingsActionRow(Icons.Rounded.GraphicEq,"Voice diagnostics","${uiState.voiceDiagNote} • ${uiState.ttsStatusNote}",theme) { page=1 }
                    SettingsActionRow(Icons.Rounded.BugReport,"System health report","Open existing diagnostic laboratory",theme,onClick=onOpenLab)
                    SettingsActionRow(Icons.Rounded.Cloud,"API connection test","Test actual chat model",theme) { onRunConnectionTest(settings.activeProvider) }
                    uiState.diagnosticResult?.let { Text(it.summary,color=ObsidianText,modifier=Modifier.padding(14.dp)) }
                    }
                    12 -> SettingsGroupSection(title = categories[12].first.uppercase()) {

                    SettingsActionRow(Icons.Rounded.Restore, "Restore Backup", "Read backup from clipboard", theme) {
                        val clip = (context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).primaryClip?.getItemAt(0)?.coerceToText(context)?.toString().orEmpty()
                        onImportBackup(clip)
                    }

SettingsHairlineDivider()

                    SettingsActionRow(
                        icon = Icons.Rounded.ContentCopy,
                        title = "Export Encrypted Backup",
                        subtitle = "Copies settings backup to clipboard",
                        theme = theme,
                        onClick = {
                            val data = onExportBackup()
                            val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            cm.setPrimaryClip(ClipData.newPlainText("OMEGA_BACKUP", data))
                            savedBanner = true
                        }
                    )

SettingsActionRow(Icons.Rounded.Refresh,"Release updates","Open existing verified update controls",theme,onClick=onOpenLab)
                    }
                    13 -> SettingsGroupSection(title = categories[13].first.uppercase()) {
Column(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)) {
                       Text("OMEGA PANDU",color=ObsidianText,fontSize=20.sp,fontWeight=FontWeight.Bold)
                       Text("Obsidian Glass • ${BuildConfig.VERSION_NAME}",color=ObsidianAccent)
                       Text("Package: ${context.packageName}",color=ObsidianMuted)
                       Text("Android ${Build.VERSION.RELEASE} • Target SDK 36",color=ObsidianMuted)
                       Text("Creator: Guptha",color=ObsidianMuted)
                       Text("Offline recognition: Vosk • Android TTS for spoken replies",color=ObsidianMuted)
                    }
                    }
                }
                Spacer(Modifier.height(24.dp))
            }
        }
    }
}

}

private val ObsidianAccent = Color(0xFF68E7ED)
private val ObsidianText = Color(0xFFEDFAFF)
private val ObsidianMuted = Color(0xFF91ADB7)
private val ObsidianPanel = Color(0xFF121E25)
private val ObsidianBorder = Color(0xFF28434B)

@Composable
private fun SettingsGroupSection(
    title: String,
    content: @Composable ColumnScope.() -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        if(title.isNotBlank()) Text(
            text = title,
            color = ObsidianMuted,
            fontSize = 11.5.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.sp,
            modifier = Modifier.padding(start = 6.dp)
        )
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(18.dp))
                .background(ObsidianPanel)
                .border(1.dp, ObsidianBorder, RoundedCornerShape(18.dp)),
            content = content
        )
    }
}

@Composable
private fun SettingsHairlineDivider() {
    HorizontalDivider(
        modifier = Modifier.padding(start = 54.dp),
        thickness = 1.dp,
        color = ObsidianBorder
    )
}

@Composable
private fun SettingsSwitchRow(
    icon: ImageVector,
    title: String,
    subtitle: String,
    checked: Boolean,
    theme: OmegaVisualTheme,
    preset: OrbColorPreset,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onCheckedChange(!checked) }
            .padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Box(
            modifier = Modifier
                .size(32.dp)
                .clip(RoundedCornerShape(9.dp))
                .background(Color(0xFF1B343E)),
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, null, tint = ObsidianAccent, modifier = Modifier.size(18.dp))
        }
        Column(modifier = Modifier.weight(1f)) {
            Text(title, color = ObsidianText, fontSize = 14.sp, fontWeight = FontWeight.Medium)
            Text(subtitle, color = ObsidianMuted, fontSize = 11.5.sp, lineHeight = 15.sp)
        }
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(checkedTrackColor=ObsidianAccent,checkedThumbColor=Color(0xFF10252C),uncheckedTrackColor=Color(0xFF34474E),uncheckedThumbColor=ObsidianMuted)
        )
    }
}

@Composable
private fun SettingsActionRow(
    icon: ImageVector,
    title: String,
    subtitle: String,
    theme: OmegaVisualTheme,
    titleColor: Color = ObsidianText,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Box(
            modifier = Modifier
                .size(32.dp)
                .clip(RoundedCornerShape(9.dp))
                .background(Color(0xFF1B343E)),
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, null, tint = if (titleColor == OmegaColors.CrimsonErr) OmegaColors.CrimsonErr else ObsidianAccent, modifier = Modifier.size(18.dp))
        }
        Column(modifier = Modifier.weight(1f)) {
            Text(title, color = titleColor, fontSize = 14.sp, fontWeight = FontWeight.Medium)
            Text(subtitle, color = ObsidianMuted, fontSize = 11.5.sp, lineHeight = 15.sp)
        }
        Icon(Icons.Rounded.ChevronRight, null, tint = ObsidianMuted, modifier = Modifier.size(20.dp))
    }
}
