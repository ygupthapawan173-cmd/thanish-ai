-keepattributes *Annotation*
-keep class com.example.ai.** { *; }
-keep class com.example.control.** { *; }
-keep class com.example.omega.** { *; }
-keep class com.example.security.** { *; }
-dontwarn okhttp3.**
-dontwarn okio.**

-keep class ai.onnxruntime.** { *; }
