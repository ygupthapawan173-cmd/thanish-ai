package com.example.omega

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.net.Uri
import com.example.data.AppDatabase
import com.example.data.OmegaPreferences
import com.example.control.PhoneControlManager
import org.json.JSONArray
import org.json.JSONObject
import java.time.ZoneId
import java.time.LocalDate
import java.util.Locale
import java.util.UUID
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicLong

private data class DailySchedule(val name: String, val hour: Int, val minute: Int, val fingerprint: String, val token: String)

class TimeAutomationReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val name = intent?.getStringExtra("routine_name") ?: return
        val token = intent.getStringExtra("schedule_token") ?: run {
            TimeAutomationScheduler.cancelLegacy(context.applicationContext, name)
            return // old alarms must be explicitly reapproved
        }
        val pending = goAsync()
        TimeAutomationScheduler.dispatch(context.applicationContext, name, token, pending::finish)
    }
}

class ScheduleRestoreReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action !in setOf(Intent.ACTION_BOOT_COMPLETED, Intent.ACTION_MY_PACKAGE_REPLACED, Intent.ACTION_TIME_CHANGED, Intent.ACTION_TIMEZONE_CHANGED)) return
        TimeAutomationScheduler.restore(context.applicationContext)
    }
}

object TimeAutomationScheduler {
    private val executor = Executors.newSingleThreadExecutor()
    private val stopEpoch = AtomicLong()
    private fun store(context: Context) = context.getSharedPreferences("infinity_daily_schedules_v1", Context.MODE_PRIVATE)
    private fun alarm(context: Context) = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
    private fun decode(name: String, raw: String?): DailySchedule? = runCatching {
        val j = JSONObject(requireNotNull(raw))
        DailySchedule(name, j.getInt("hour"), j.getInt("minute"), j.getString("fingerprint"), j.getString("token"))
    }.getOrNull()
    private fun read(context: Context, name: String) = decode(name, store(context).getString(name, null))
    private fun intent(context: Context, name: String) = Intent(context, TimeAutomationReceiver::class.java)
        .setData(Uri.Builder().scheme("infinity").authority("daily").appendPath(name).build())
        .putExtra("routine_name", name)
    internal fun cancelLegacy(context: Context, name: String) {
        val oldIntent = Intent(context, TimeAutomationReceiver::class.java).putExtra("routine_name", name)
        PendingIntent.getBroadcast(context, name.hashCode(), oldIntent, PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE)?.let { alarm(context).cancel(it); it.cancel() }
    }
    private fun arm(context: Context, s: DailySchedule) {
        val pi = PendingIntent.getBroadcast(context, 0, intent(context, s.name).putExtra("schedule_token", s.token), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val next = DailySchedulePolicy.nextMillis(System.currentTimeMillis(), s.hour, s.minute, ZoneId.systemDefault())
        alarm(context).set(AlarmManager.RTC_WAKEUP, next, pi) // inexact; Android may defer
    }
    private fun validated(steps: String): List<Pair<String, Any>> {
        val array = JSONArray(steps)
        require(array.length() in 1..8) { "Use 1–8 background steps" }
        return (0 until array.length()).map { i ->
            val step = array.getJSONObject(i)
            val tool = step.getString("tool")
            val args = step.getJSONObject("args")
            val value = args.opt(if (tool == "toggle_flashlight") "enabled" else "percent")
            require(DailySchedulePolicy.eligible(tool, value)) { "$tool requires foreground execution or valid arguments" }
            tool to requireNotNull(value)
        }
    }
    @Synchronized fun scheduleDailyRoutine(context: Context, routineName: String, hour24: Int, minute: Int): String {
        require(routineName.isNotBlank() && hour24 in 0..23 && minute in 0..59)
        val routine = AppDatabase(context).use { db -> db.getAllRoutines().firstOrNull { it.name == routineName } }
            ?: error("Routine not found")
        validated(routine.stepsJson)
        val prefs = OmegaPreferences(context)
        try { require(!prefs.settings.value.biometricSafetyLock) { "Biometric protection requires foreground approval" } } finally { prefs.close() }
        val s = DailySchedule(routineName, hour24, minute, DailySchedulePolicy.fingerprint(routine.stepsJson), UUID.randomUUID().toString())
        val json = JSONObject().put("hour", s.hour).put("minute", s.minute).put("fingerprint", s.fingerprint).put("token", s.token)
        check(store(context).edit().putString(s.name, json.toString()).commit()) { "Schedule could not be saved" }
        cancelLegacy(context, s.name)
        try { arm(context, s) } catch (e: Exception) { store(context).edit().remove(s.name).commit(); throw e }
        return String.format(Locale.ROOT, "Scheduled '%s' around %02d:%02d daily (inexact; may be delayed).", routineName, hour24, minute)
    }
    @Synchronized fun cancel(context: Context, name: String): String {
        check(store(context).edit().remove(name).commit()) { "Could not cancel saved schedule" }
        PendingIntent.getBroadcast(context, 0, intent(context, name), PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE)?.let { alarm(context).cancel(it); it.cancel() }
        cancelLegacy(context, name)
        return "Daily schedule cancelled: $name"
    }
    fun stopRunning() { stopEpoch.incrementAndGet() }
    @Synchronized fun restore(context: Context) {
        store(context).all.forEach { (name, raw) -> decode(name, raw as? String)?.let { runCatching { arm(context, it) } } }
    }
    fun status(context: Context, name: String): String? = read(context, name)?.let { String.format(Locale.ROOT, "%02d:%02d daily · inexact", it.hour, it.minute) }
    internal fun dispatch(context: Context, name: String, token: String, finish: () -> Unit) {
        val epoch = stopEpoch.get()
        executor.execute {
            try {
                val s = read(context, name)?.takeIf { it.token == token } ?: return@execute
                val claimed = synchronized(this) {
                    val raw = store(context).getString(name, null) ?: return@synchronized false
                    val entry = JSONObject(raw)
                    if (entry.optString("token") != token) return@synchronized false
                    arm(context, s)
                    val day = LocalDate.now(ZoneId.systemDefault()).toString()
                    if (entry.optString("lastRunDay") == day) return@synchronized false
                    check(store(context).edit().putString(name, entry.put("lastRunDay", day).toString()).commit()) { "Could not persist run claim" }
                    true
                }
                if (!claimed) return@execute
                AppDatabase(context).use { db ->
                    val prefs = OmegaPreferences(context)
                    try {
                        require(!prefs.settings.value.biometricSafetyLock) { "Biometric protection requires foreground approval" }
                        val routine = db.getAllRoutines().firstOrNull { it.name == name } ?: error("Routine removed")
                        require(DailySchedulePolicy.fingerprint(routine.stepsJson) == s.fingerprint) { "Routine changed; schedule again to approve" }
                        val steps = validated(routine.stepsJson)
                        val phone = PhoneControlManager(context)
                        val results = mutableListOf<String>()
                        for ((tool, value) in steps) {
                            check(stopEpoch.get() == epoch && read(context, name)?.token == token) { "Stopped or cancelled" }
                            val result = if (tool == "toggle_flashlight") phone.setFlashlight(value as Boolean) else phone.setMediaVolume(value as Int, showSystemUi = false)
                            results += result
                            db.logAudit("Scheduled step", "$name: $result", "RESULT")
                            check(!result.contains("error:", ignoreCase = true) && !result.startsWith("No rear flashlight")) { result }
                        }
                        db.logAudit("Scheduled Routine", "$name: ${results.joinToString(" | ")}", "DISPATCHED")
                        SmartTriggerBus.emit(SmartTriggerEvent("Scheduled Routine", results.joinToString(" | ")))
                    } finally { prefs.close() }
                }
            } catch (e: Exception) {
                runCatching { AppDatabase(context).use { it.logAudit("Scheduled Routine", "$name: ${e.message}", "BLOCKED_OR_FAILED") } }
                SmartTriggerBus.emit(SmartTriggerEvent("Scheduled Routine", "Not completed: ${e.message}"))
            } finally { finish() }
        }
    }
}
