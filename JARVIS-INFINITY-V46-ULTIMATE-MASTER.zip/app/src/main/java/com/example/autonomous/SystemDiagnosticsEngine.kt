package com.example.autonomous

import android.Manifest
import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.BatteryManager
import android.speech.SpeechRecognizer
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.example.control.PanduAccessibilityService
import com.example.data.ApiQuotaTracker
import com.example.data.OmegaSettings
import com.example.security.CrashRecoveryHandler

data class DiagnosticIssue(
    val severity: String, // "CRITICAL" | "WARN" | "INFO"
    val category: String,
    val title: String,
    val repairSuggestion: String
)

data class SystemHealthReport(
    val score: Int,
    val batteryPercent: Int,
    val batteryTempC: Float,
    val ramUsedPercent: Int,
    val avgApiLatencyMs: Long,
    val crashCount: Int,
    val issues: List<DiagnosticIssue>,
    val generatedAtMs: Long = System.currentTimeMillis()
)

class SystemDiagnosticsEngine(private val context: Context) {

    fun runFullDiagnostics(settings: OmegaSettings, ttsStatus: String, voiceDiag: String): SystemHealthReport {
        val issues = mutableListOf<DiagnosticIssue>()
        var score = 100

        // 1. Crash Log Analysis
        val rawLogs = CrashRecoveryHandler.readLogs(context)
        val crashCount = Regex("""=== CRASH \[""").findAll(rawLogs).count()
        if (crashCount > 0) {
            score -= (crashCount * 8).coerceAtMost(24)
            val hint = when {
                rawLogs.contains("NullPointerException") -> "Null safety check needed in recent crash trace."
                rawLogs.contains("OutOfMemoryError") -> "Reduce bitmap/cache allocation."
                rawLogs.contains("SecurityException") -> "Missing runtime permission guard."
                else -> "Inspect crash stack trace in System Logs or run Self-Coding bug-fix."
            }
            issues.add(DiagnosticIssue("WARN", "Crash Analyzer", "$crashCount crash(es) recorded", hint))
        }

        // 2. Voice Engine Health
        val hasMic = ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        if (!hasMic) {
            score -= 18
            issues.add(DiagnosticIssue("CRITICAL", "Voice", "Microphone permission missing", "Grant RECORD_AUDIO in System > Permissions."))
        }
        if (settings.micPrivacyMuted) {
            score -= 10
            issues.add(DiagnosticIssue("WARN", "Voice", "Microphone Privacy Mute is ON", "Turn off Mic Mute so voice & Hey Jarvis can listen."))
        }
        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            score -= 12
            issues.add(DiagnosticIssue("WARN", "Voice", "SpeechRecognizer service unavailable", "Enable Google Speech Services in Android Settings."))
        }
        if (ttsStatus.contains("unavailable", ignoreCase = true)) {
            score -= 10
            issues.add(DiagnosticIssue("WARN", "Voice", "TTS speaker engine unavailable", "Install/enable Android Text-to-Speech output."))
        }

        // 3. API Error & Model Diagnosis
        val hasGemini = settings.effectiveGeminiKey().isNotBlank()
        val hasOr = settings.effectiveOpenRouterKey().isNotBlank()
        if (!settings.localBrainMode && !hasGemini && !hasOr) {
            score -= 20
            issues.add(DiagnosticIssue("CRITICAL", "AI API", "No cloud API key configured", "Add Gemini or Smart Gateway key, or enable 100% Local Brain Mode."))
        }
        if (settings.openRouterModel.contains(":batch", ignoreCase = true)) {
            score -= 12
            issues.add(DiagnosticIssue("CRITICAL", "AI API", "Async ':batch' gateway model selected", "Select a discovered synchronous chat model."))
        }
        val telemetry = ApiQuotaTracker.snapshot.value
        if (telemetry.totalRequests >= 3 && telemetry.failedRequests * 2 >= telemetry.totalRequests) {
            score -= 10
            issues.add(DiagnosticIssue("WARN", "AI API", "High API failure rate (${telemetry.failedRequests}/${telemetry.totalRequests})", "Run Ping test or tap Fetch Models in AI & Keys."))
        }

        // 4. Permission Audit
        val hasAcc = PanduAccessibilityService.instance != null
        val hasNotif = NotificationManagerCompat.getEnabledListenerPackages(context).contains(context.packageName)
        if (!hasAcc) {
            issues.add(DiagnosticIssue("INFO", "Permissions", "Cross-App Automation Service OFF", "Enable in Accessibility for HUD & screen actions."))
        }
        if (!hasNotif) {
            issues.add(DiagnosticIssue("INFO", "Permissions", "Notification Listener OFF", "Enable to read/reply to WhatsApp & SMS hands-free."))
        }

        // 5. Battery, Thermal & Memory Bottlenecks
        val bm = context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        val batPct = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY).coerceIn(0, 100)
        val batIntent = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val tempC = (batIntent?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 300) ?: 300) / 10f

        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val memInfo = ActivityManager.MemoryInfo()
        am.getMemoryInfo(memInfo)
        val ramUsedPct = if (memInfo.totalMem > 0) {
            (((memInfo.totalMem - memInfo.availMem).toDouble() / memInfo.totalMem.toDouble()) * 100.0).toInt().coerceIn(0, 100)
        } else 0

        if (tempC >= 43f) {
            score -= 8
            issues.add(DiagnosticIssue("WARN", "Thermal", "Device running warm (${tempC}°C)", "Pause background wake-word until temperature drops."))
        }
        if (ramUsedPct >= 88) {
            score -= 8
            issues.add(DiagnosticIssue("WARN", "Memory", "High system RAM usage ($ramUsedPct%)", "Clear chat history or close heavy background apps."))
        }
        if (telemetry.averageLatencyMs > 4500L) {
            score -= 5
            issues.add(DiagnosticIssue("INFO", "Performance", "Slow API latency (${telemetry.averageLatencyMs}ms)", "Switch to a faster flash model or Local Brain Mode."))
        }

        if (issues.isEmpty()) {
            issues.add(DiagnosticIssue("INFO", "Health", "All systems nominal", "Voice ($voiceDiag), API, Memory, and Battery are healthy."))
        }

        return SystemHealthReport(
            score = score.coerceIn(10, 100),
            batteryPercent = batPct,
            batteryTempC = tempC,
            ramUsedPercent = ramUsedPct,
            avgApiLatencyMs = telemetry.averageLatencyMs,
            crashCount = crashCount,
            issues = issues
        )
    }
}
