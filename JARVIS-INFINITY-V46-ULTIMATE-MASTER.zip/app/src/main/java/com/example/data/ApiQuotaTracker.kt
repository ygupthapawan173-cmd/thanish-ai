package com.example.data

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class ApiTelemetrySnapshot(
    val totalRequests: Int = 0,
    val failedRequests: Int = 0,
    val reportedPromptTokens: Long = 0,
    val reportedOutputTokens: Long = 0,
    val requestsWithoutUsage: Int = 0,
    val knownCostUsd: Double = 0.0,
    val requestsWithoutCost: Int = 0,
    val averageLatencyMs: Long = 0L,
    val lastUsedModel: String = "",
    val persistenceHealthy: Boolean = false
)

/** Persistent HTTP chat telemetry, not a billing statement; Live audio excluded. */
interface ApiTelemetryStore {
    fun load(): ApiTelemetrySnapshot
    fun save(snapshot: ApiTelemetrySnapshot): Boolean
}

object ApiQuotaTracker {
    private val _snapshot = MutableStateFlow(ApiTelemetrySnapshot())
    val snapshot: StateFlow<ApiTelemetrySnapshot> = _snapshot.asStateFlow()
    private var store: ApiTelemetryStore? = null
    @Synchronized fun attach(storage: ApiTelemetryStore) {
        _snapshot.value = runCatching { storage.load() }.getOrElse { ApiTelemetrySnapshot() }
        store = storage
    }
    private fun publish(value: ApiTelemetrySnapshot) {
        // Keep live counters even if disk write fails; do not claim persistence on failure.
        _snapshot.value = value.copy(persistenceHealthy = runCatching { store?.save(value) ?: false }.getOrDefault(false))
    }
    @Synchronized fun recordSuccess(model: String, promptTokens: Long?, outputTokens: Long?, latencyMs: Long, costUsd: Double? = null) {
        val cur = _snapshot.value
        val successes = cur.totalRequests - cur.failedRequests
        val prompt = promptTokens?.takeIf { it >= 0 }
        val output = outputTokens?.takeIf { it >= 0 }
        val cost = costUsd?.takeIf { it.isFinite() && it >= 0 }
        publish(cur.copy(totalRequests = cur.totalRequests + 1,
            reportedPromptTokens = cur.reportedPromptTokens + (prompt ?: 0),
            reportedOutputTokens = cur.reportedOutputTokens + (output ?: 0),
            requestsWithoutUsage = cur.requestsWithoutUsage + if (prompt == null || output == null) 1 else 0,
            knownCostUsd = cur.knownCostUsd + (cost ?: 0.0),
            requestsWithoutCost = cur.requestsWithoutCost + if (cost == null) 1 else 0,
            averageLatencyMs = (cur.averageLatencyMs * successes + latencyMs) / (successes + 1), lastUsedModel = model))
    }
    @Synchronized fun recordFailure() { val cur = _snapshot.value; publish(cur.copy(totalRequests = cur.totalRequests + 1, failedRequests = cur.failedRequests + 1)) }
    @Synchronized fun reset() { publish(ApiTelemetrySnapshot()) }
}
