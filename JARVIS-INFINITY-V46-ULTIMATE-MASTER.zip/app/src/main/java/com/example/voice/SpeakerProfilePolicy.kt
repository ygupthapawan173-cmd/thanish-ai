package com.example.voice

import kotlin.math.sqrt

internal object SpeakerProfilePolicy {
    const val sampleCount = 3
    const val minFrames = 80
    const val threshold = 0.72 // provisional; calibrate on real phone, not a security boundary
    fun similarity(a: DoubleArray, b: DoubleArray): Double {
        if (a.isEmpty() || a.size != b.size || a.any { !it.isFinite() } || b.any { !it.isFinite() }) return -1.0
        var dot=0.0; var aa=0.0; var bb=0.0
        for(i in a.indices) { dot+=a[i]*b[i]; aa+=a[i]*a[i]; bb+=b[i]*b[i] }
        return if(aa<=0 || bb<=0) -1.0 else (dot/sqrt(aa*bb)).coerceIn(-1.0,1.0)
    }
    fun matches(samples: List<DoubleArray>, candidate: DoubleArray): Boolean =
        samples.size == sampleCount && samples.count { similarity(it,candidate)>=threshold } >= 2
}
