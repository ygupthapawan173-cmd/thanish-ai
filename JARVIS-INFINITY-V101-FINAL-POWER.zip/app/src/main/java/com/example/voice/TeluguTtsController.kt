package com.example.voice

import android.content.Context
import com.example.control.AgentHudBus
import android.os.Handler
import android.os.Looper
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.AudioFocusRequest
import android.util.Log
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import com.example.data.TtsEmotionStyle
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale
import java.util.UUID
import android.media.MediaPlayer
import android.media.MediaDataSource
import com.example.data.OmegaSettings
import com.example.data.AiProvider
import com.example.ai.SmartModelPolicy
import kotlinx.coroutines.*

class TeluguTtsController(context: Context, private val backgroundOwned: Boolean = false, private val cloudSettings: (() -> OmegaSettings)? = null) {

    private val appContext = context.applicationContext
    private var tts: TextToSpeech? = null
    private var isReady = false
    private var localOnly = false
    private val _voices = MutableStateFlow<List<TtsVoiceChoice>>(emptyList())
    val voices: StateFlow<List<TtsVoiceChoice>> = _voices.asStateFlow()
    fun refreshVoices() { if(isReady) tts?.let { _voices.value=VoicePackCatalog.choices(it) } }
    private var initFailed = false
    private var released = false
    var lastSpeechSucceeded = false
        private set
    private val audio = appContext.getSystemService(AudioManager::class.java)
    private var focus: AudioFocusRequest? = null
    private fun abandonFocus() { focus?.let { runCatching { audio.abandonAudioFocusRequest(it) } }; focus=null }
    private fun complete(id: String?, error: String? = null) {
        if (id == null || id !in utteranceIds) return
        if (error == null && id != finalUtteranceId) { utteranceIds.remove(id); return }
        val canRetry = utteranceIds.size == initialUtteranceCount
        utteranceIds.clear(); finalUtteranceId = null
        if (error != null) runCatching { tts?.stop() }
        cancelWatchdog()
        val retryText=activeText
        val failedVoice=activeVoice
        activeId=null; activeText=null; activeVoice=null; lastSpeechSucceeded=error==null; _isSpeaking.value=false; abandonFocus(); AgentHudBus.setTtsBusy(this,false)
        if (error != null) { _ttsStatus.value=error; Log.w("OmegaVoice", "TTS_ERROR $error") }
        else Log.i("OmegaVoice", "TTS_DONE")
        if(canRetry && error != null && (error.startsWith("TTS error") || error == "TTS playback failed") && excludedVoice==null && failedVoice!=null && retryText!=null) {
            excludedVoice=failedVoice
            speakInternal(retryText)
            return
        }
        excludedVoice=null
        onSpeechFinishedCallback?.invoke()
    }
    private var pendingUtterance: String? = null
    private var pendingConfig: (() -> Unit)? = null
    private var activeId: String? = null
    private val utteranceIds = linkedSetOf<String>()
    private var initialUtteranceCount = 0
    private var finalUtteranceId: String? = null
    private var playbackWatchdog: Runnable? = null
    private fun cancelWatchdog() { playbackWatchdog?.let { main.removeCallbacks(it) }; playbackWatchdog = null }
    private var activeText: String? = null
    private var activeVoice: String? = null
    private var excludedVoice: String? = null
    private val main = Handler(Looper.getMainLooper())
    private var onSpeechFinishedCallback: (() -> Unit)? = null

    private val _isSpeaking = MutableStateFlow(false)
    val isSpeaking: StateFlow<Boolean> = _isSpeaking.asStateFlow()

    private val _ttsStatus = MutableStateFlow("Initializing TTS...")
    val ttsStatus: StateFlow<String> = _ttsStatus.asStateFlow()

    init {
        tts = TextToSpeech(appContext) { status -> main.post {
            if (released) return@post
            if (status == TextToSpeech.SUCCESS) {
                isReady = true
                tts?.setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build()
                )
                val res = tts?.setLanguage(Locale.forLanguageTag("en-IN"))
                if (res == TextToSpeech.LANG_MISSING_DATA || res == TextToSpeech.LANG_NOT_SUPPORTED) {
                    tts?.language = Locale.US
                }
                _ttsStatus.value = "Speaker TTS Ready"
                refreshVoices()
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) { main.post { if (utteranceId != null && utteranceId in utteranceIds) _isSpeaking.value = true } }
                    override fun onDone(utteranceId: String?) {
                        main.post { complete(utteranceId) }
                    }
                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) { main.post { complete(utteranceId, "TTS playback failed") } }
                    override fun onError(utteranceId: String?, errorCode: Int) { main.post { complete(utteranceId, "TTS error $errorCode") } }
                    override fun onStop(utteranceId: String?, interrupted: Boolean) { main.post { complete(utteranceId, "TTS interrupted") } }
                })
                pendingConfig?.invoke(); pendingConfig=null
                pendingUtterance?.let { queued ->
                    pendingUtterance = null
                    speak(queued)
                }
            } else {
                initFailed=true
                _ttsStatus.value = "TTS init failed (code $status). Check Android Text-to-Speech settings."
                if (pendingUtterance != null) { pendingUtterance=null; onSpeechFinishedCallback?.invoke() }
            }
        } }
    }

    fun setOnSpeechFinished(callback: (() -> Unit)?) { onSpeechFinishedCallback = callback }

    fun configure(localeTag: String, speed: Float, pitch: Float, style: TtsEmotionStyle, localOnly: Boolean = false) {
        this.localOnly=localOnly
        if (!isReady) { pendingConfig={ configure(localeTag,speed,pitch,style,localOnly) }; return }
        val tag = if (localeTag == "auto") "en-IN" else localeTag
        val res = tts?.setLanguage(Locale.forLanguageTag(tag))
        if (res == TextToSpeech.LANG_MISSING_DATA || res == TextToSpeech.LANG_NOT_SUPPORTED) {
            tts?.language = Locale.getDefault()
        }
        tts?.setSpeechRate(style.speed(speed))
        tts?.setPitch(style.pitch(pitch))
    }

    private val cloudScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var cloudJob: Job? = null
    private var cloudPlayer: MediaPlayer? = null
    private var cloudGeneration = 0L
    private var cloudCooldownUntil = 0L
    private var cloudPrivacyCheck: Runnable? = null
    private fun cloudAllowed(s: OmegaSettings, length: Int): Boolean = CloudVoicePolicy.allowed(
        s.gatewayBaseUrl, CloudVoicePreferences.enabled(appContext), s.activeProvider == AiProvider.OPENROUTER,
        s.smartMode == SmartModelPolicy.Mode.FREE, s.providerBudgetUsd,
        localOnly || s.micPrivacyMuted || appContext.getSystemService(android.app.KeyguardManager::class.java).isDeviceLocked,
        !backgroundOwned && AgentHudBus.isAppInForeground.value && !AgentHudBus.isMainMicBusy.value,
        s.effectiveOpenRouterKey().isNotBlank(), length)
    private fun stopCloud() {
        ++cloudGeneration
        cloudPrivacyCheck?.let { main.removeCallbacks(it) }; cloudPrivacyCheck = null
        cloudJob?.cancel(); cloudJob = null
        cloudPlayer?.let { runCatching { it.release() } }; cloudPlayer = null
    }
    private fun startCloud(raw: String): Boolean {
        val s = cloudSettings?.invoke() ?: return false
        val clean = raw.replace("*", "").replace("#", "").replace("`", "").trim()
        if (released || android.os.SystemClock.elapsedRealtime() < cloudCooldownUntil || !cloudAllowed(s, clean.length)) return false
        val generation = ++cloudGeneration
        val choice = CloudVoicePolicy.select(clean, CloudVoicePreferences.voice(appContext, "en"), CloudVoicePreferences.voice(appContext, "te"), CloudVoicePreferences.hd(appContext))
        lastSpeechSucceeded = false
        _isSpeaking.value = true; AgentHudBus.setTtsBusy(this,true)
        _ttsStatus.value = "Cloud voice: requesting ${choice.voice}"
        var started = false
        fun stillAllowed(): Boolean = cloudSettings?.invoke()?.let { cloudAllowed(it, clean.length) && it.effectiveOpenRouterKey() == s.effectiveOpenRouterKey() } == true
        fun finish(success: Boolean, fallback: Boolean) {
            if (generation != cloudGeneration) return
            stopCloud(); cancelWatchdog(); abandonFocus()
            _isSpeaking.value = false; AgentHudBus.setTtsBusy(this,false)
            lastSpeechSucceeded = success
            if (success) { _ttsStatus.value = "Cloud voice: ${choice.voice} • completed"; onSpeechFinishedCallback?.invoke() }
            else {
                _ttsStatus.value = "Cloud speech unavailable"
                if (fallback && !started && stillAllowed()) { cloudCooldownUntil = android.os.SystemClock.elapsedRealtime() + 30_000L; speakInternal(clean) }
                else onSpeechFinishedCallback?.invoke()
            }
        }
        val privacyCheck = object : Runnable {
            override fun run() {
                if (generation != cloudGeneration) return
                if (!stillAllowed()) finish(false,false) else main.postDelayed(this,250L)
            }
        }
        cloudPrivacyCheck = privacyCheck; main.postDelayed(privacyCheck,250L)
        cloudJob = cloudScope.launch {
            try {
                val bytes = CloudVoiceClient.synthesize(s.effectiveOpenRouterKey(), clean, choice)
                if (generation != cloudGeneration) return@launch
                if (!stillAllowed()) { finish(false,false); return@launch }
                val attrs = AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build()
                val request = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK).setAudioAttributes(attrs)
                    .setOnAudioFocusChangeListener({ change -> if (change == AudioManager.AUDIOFOCUS_LOSS || change == AudioManager.AUDIOFOCUS_LOSS_TRANSIENT) finish(false,false) }, main).build()
                focus = request
                if (audio.requestAudioFocus(request) != AudioManager.AUDIOFOCUS_REQUEST_GRANTED) { finish(false,false); return@launch }
                val player = MediaPlayer(); cloudPlayer = player
                player.setAudioAttributes(attrs)
                player.setDataSource(object : MediaDataSource() {
                    override fun getSize(): Long = bytes.size.toLong()
                    override fun readAt(position: Long, buffer: ByteArray, offset: Int, size: Int): Int {
                        if (position < 0 || position >= bytes.size) return -1
                        val n = minOf(size, bytes.size - position.toInt())
                        bytes.copyInto(buffer, offset, position.toInt(), position.toInt()+n)
                        return n
                    }
                    override fun close() { }
                })
                player.setOnPreparedListener {
                    if (generation == cloudGeneration) {
                        if (!stillAllowed()) finish(false,false)
                        else runCatching { it.start(); started = true; runCatching { it.playbackParams = it.playbackParams.setSpeed(s.ttsSpeed.coerceIn(0.75f,1.5f)) }; _ttsStatus.value = "Cloud voice: ${choice.voice} • playing" }.onFailure { finish(false,true) }
                    }
                }
                player.setOnCompletionListener { finish(true,false) }
                player.setOnErrorListener { _, _, _ -> finish(false,true); true }
                val watchdog = Runnable { finish(false, !started) }
                playbackWatchdog = watchdog; main.postDelayed(watchdog, VoiceSessionPolicy.ttsTimeoutMs(clean.length))
                player.prepareAsync()
            } catch (e: CancellationException) { throw e }
            catch (_: Exception) { finish(false,true) }
        }
        return true
    }
    fun speak(rawText: String) {
        stop()
        excludedVoice=null
        if (!startCloud(rawText)) speakInternal(rawText)
    }

    private fun speakInternal(rawText: String) {
        lastSpeechSucceeded=false
        val clean = rawText.replace("*", "").replace("#", "").replace("`", "").replace("•", ",").trim()
        if (clean.isBlank() || initFailed || released) { onSpeechFinishedCallback?.invoke(); return }
        if (!isReady) {
            pendingUtterance = clean
            main.postDelayed({ if (!isReady && pendingUtterance == clean) { pendingUtterance=null; _ttsStatus.value="TTS initialization timed out"; onSpeechFinishedCallback?.invoke() } }, 15000L)
            return
        }
        val hasTeluguChars = clean.any { it in '\u0C00'..'\u0C7F' }
        val language = if(hasTeluguChars) "te" else "en"
        val locked = appContext.getSystemService(android.app.KeyguardManager::class.java).isDeviceLocked
        val allowNetwork=VoicePackPolicy.allowNetworkVoice(localOnly,locked)
        val engine=tts ?: run { onSpeechFinishedCallback?.invoke(); return }
        val preferred=VoicePackCatalog.selected(appContext,language)
        val candidates=runCatching { engine.voices.orEmpty().filter { it.locale.language==language && it.name!=excludedVoice && !VoicePackCatalog.needsData(it) && (allowNetwork || !it.isNetworkConnectionRequired) } }.getOrDefault(emptyList())
            .sortedWith(compareByDescending<android.speech.tts.Voice> { it.name==preferred }.thenBy { it.isNetworkConnectionRequired }.thenByDescending { it.locale.country=="IN" }.thenByDescending { it.quality })
        val chosen=candidates.firstOrNull { runCatching { engine.setVoice(it)==TextToSpeech.SUCCESS }.getOrDefault(false) } ?: if(excludedVoice==null && candidates.isEmpty()) {
            runCatching {
                engine.setLanguage(Locale.forLanguageTag(if(hasTeluguChars) "te-IN" else "en-IN"))
                engine.voice?.takeIf { it.locale.language==language && !VoicePackCatalog.needsData(it) && (allowNetwork || !it.isNetworkConnectionRequired) }
            }.getOrNull()
        } else null
        if(chosen==null) {
            _ttsStatus.value="${if(hasTeluguChars) "Telugu" else "English"} voice unavailable; install voice data in Voice Packs"
            onSpeechFinishedCallback?.invoke()
            return
        }
        _ttsStatus.value="${chosen.locale.toLanguageTag()} • ${chosen.name} • ${if(chosen.isNetworkConnectionRequired) "Online" else "Offline"}"
        val params = Bundle().apply {
            putInt(TextToSpeech.Engine.KEY_PARAM_STREAM, AudioManager.STREAM_MUSIC)
            putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, 1.0f)
        }
        val chunks=TtsChunkPolicy.split(clean, TextToSpeech.getMaxSpeechInputLength().coerceAtLeast(2))
        val ids=chunks.map { UUID.randomUUID().toString() }
        val id=ids.last(); activeId=id; activeText=clean; activeVoice=chosen.name
        utteranceIds.addAll(ids); initialUtteranceCount=ids.size; finalUtteranceId=id
        AgentHudBus.setTtsBusy(this,true)
        if (!backgroundOwned) com.example.omega.OmegaWakeService.pauseForManual()
        abandonFocus()
        val request = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
            .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
            .setOnAudioFocusChangeListener({ change -> if (change == AudioManager.AUDIOFOCUS_LOSS || change == AudioManager.AUDIOFOCUS_LOSS_TRANSIENT) main.post { if (activeId==id) { tts?.stop(); complete(id,"TTS audio focus lost") } } }, main).build()
        focus=request
        if (runCatching { audio.requestAudioFocus(request) }.getOrDefault(AudioManager.AUDIOFOCUS_REQUEST_FAILED) != AudioManager.AUDIOFOCUS_REQUEST_GRANTED) { complete(id,"TTS audio focus denied"); return }
        val watchdog = Runnable { if (activeId == id) { runCatching { tts?.stop() }; complete(id, "TTS playback timed out") } }
        playbackWatchdog = watchdog
        main.postDelayed(watchdog, VoiceSessionPolicy.ttsTimeoutMs(clean.length))
        main.postDelayed({ if(activeId==id) {
            Log.i("OmegaVoice", "TTS_START")
            for ((index, chunk) in chunks.withIndex()) {
                if (!VoicePackPolicy.allowNetworkVoice(localOnly, appContext.getSystemService(android.app.KeyguardManager::class.java).isDeviceLocked) && chosen.isNetworkConnectionRequired) { complete(id,"TTS privacy policy blocked network voice"); break }
                if(runCatching { tts?.speak(chunk, if(index==0) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD, params, ids[index]) }.getOrNull()!=TextToSpeech.SUCCESS) { complete(id,"TTS playback failed"); break }
            }
        } }, 150)
    }

    fun stop() {
        stopCloud()
        cancelWatchdog()
        pendingUtterance = null
        utteranceIds.clear(); finalUtteranceId=null; activeId=null; activeText=null; activeVoice=null; excludedVoice=null; abandonFocus(); AgentHudBus.setTtsBusy(this,false)
        tts?.stop()
        _isSpeaking.value = false
    }

    fun release() {
        released=true; stop(); cloudScope.cancel(); tts?.shutdown(); tts = null
    }
}
