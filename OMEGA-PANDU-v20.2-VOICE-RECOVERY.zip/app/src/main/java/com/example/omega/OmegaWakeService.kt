package com.example.omega

import android.Manifest
import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.os.*
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.example.MainActivity
import com.example.control.AgentHudBus
import com.example.data.OmegaPreferences
import com.example.voice.TeluguTtsController
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import org.json.JSONArray
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.android.RecognitionListener
import org.vosk.android.SpeechService
import org.vosk.android.StorageService

/** Offline English wake phrase; only a visible UI or user-tapped notification starts command capture. */
class OmegaWakeService: Service() {
    private val handler = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(SupervisorJob()+Dispatchers.Main.immediate)
    private lateinit var prefs: OmegaPreferences
    private lateinit var smartTriggers: SmartTriggerManager
    private lateinit var tts: TeluguTtsController
    private var model: Model? = null
    private var rec: Recognizer? = null
    private var speech: SpeechService? = null
    private var loading = false
    private var closed = false
    private var started = false
    private var epoch = 0L
    private var retries = 0
    private var waitForTap = false
    private var wakePhrase = ""
    override fun onCreate() {
        super.onCreate(); instance = this
        prefs = OmegaPreferences(this); smartTriggers = SmartTriggerManager(this); tts = TeluguTtsController(this)
        smartTriggers.register()
        getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel(CHANNEL,"OMEGA offline wake",NotificationManager.IMPORTANCE_LOW))
        scope.launch { AgentHudBus.isMainMicBusy.collect { if(it) { waitForTap=false; pause() } else schedule(700) } }
        scope.launch { AgentHudBus.isTtsBusy.collect { if(it) pause() else schedule(700) } }
        scope.launch { prefs.settings.collect { s ->
            if (!s.wakeWordEnabled && started) { stopSelf(); return@collect }
            if (s.micPrivacyMuted) pause() else { if(wakePhrase != s.wakeWord.trim().lowercase()) { pause(); retries=0 }; schedule(500) }
        } }
        scope.launch { SmartTriggerBus.events.collect { event ->
            val s=prefs.settings.value
            if(!AgentHudBus.isAppInForeground.value && !AgentHudBus.isMainMicBusy.value && s.autoSpeak) { tts.configure(s.languageTag,s.ttsSpeed,s.ttsPitch,s.ttsStyle); tts.speak(event.announcement) }
        } }
    }
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if(intent?.action == STOP) { prefs.update { it.copy(wakeWordEnabled=false) }; stopSelf(); return START_NOT_STICKY }
        if(!prefs.settings.value.wakeWordEnabled || ContextCompat.checkSelfPermission(this,Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED) { stopSelf(); return START_NOT_STICKY }
        try { if(Build.VERSION.SDK_INT>=29) startForeground(ID, notification("Loading offline wake model"),ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE) else startForeground(ID,notification("Loading offline wake model")) }
        catch(_:Exception) { status.value="Microphone foreground service blocked"; stopSelf(); return START_NOT_STICKY }
        started=true
        if(model!=null) schedule(0) else if(!loading) {
            loading=true; publish("Loading offline Vosk model")
            StorageService.unpack(this,"model-en-us","omega-vosk-en",{m -> loading=false; if(closed) m.close() else {model=m; schedule(200)}},{_ -> loading=false; if(!closed) fail("Offline wake model unavailable")})
        }
        return START_NOT_STICKY
    }
    private fun canListen(): Boolean = started && !closed && !waitForTap && prefs.settings.value.wakeWordEnabled && !prefs.settings.value.micPrivacyMuted && !AgentHudBus.isMainMicBusy.value && !AgentHudBus.isTtsBusy.value
    private fun schedule(ms:Long) {
        if(!canListen() || model==null || speech!=null) return
        val token=++epoch; handler.postDelayed({if(token==epoch && canListen() && speech==null) arm()},ms)
    }
    private fun pause() {
        ++epoch; val old=speech; speech=null
        runCatching { old?.cancel() }; runCatching { old?.shutdown() }; runCatching { rec?.close() }; rec=null
        if(started&&!closed&&!waitForTap) publish(if(prefs.settings.value.micPrivacyMuted) "Microphone muted" else "Wake paused")
    }
    private fun arm() {
        val m=model?:return
        wakePhrase=prefs.settings.value.wakeWord.lowercase().trim()
        val phrase=wakePhrase.replace(Regex("\\s+")," ")
        if(!phrase.matches(Regex("[a-z]+( [a-z]+){1,5}"))) { fail("Use a 2–6 word English wake phrase"); return }
        try {
            val phrases=if(phrase=="hey jarvis") listOf(phrase,"hey jervis","hey jar vis","hey jar vice") else listOf(phrase)
            val r=Recognizer(m,16000f,JSONArray(phrases+"[unk]").toString()); rec=r; r.setWords(true)
            val service=SpeechService(r,16000f); speech=service; val token=++epoch
            val threshold=(0.85-0.35*prefs.settings.value.wakeSensitivity.coerceIn(0.2f,1f).toDouble()).coerceIn(0.5,0.8)
            fun current()=token==epoch && canListen()
            val listener=object:RecognitionListener {
                override fun onPartialResult(hypothesis:String?)=Unit
                override fun onResult(hypothesis:String?) {
                    if(!current()) return
                    val json=runCatching { JSONObject(hypothesis.orEmpty()) }.getOrNull()?:return
                    val heard=json.optString("text").trim(); val words=json.optJSONArray("result")?:return
                    if(heard !in phrases || words.length()!=heard.split(" ").size || (0 until words.length()).any { (words.optJSONObject(it)?.optDouble("conf",0.0)?:0.0)<threshold }) return
                    waitForTap=true; pause(); retries=0
                    if(AgentHudBus.isAppInForeground.value) {
                        waitForTap=false; AgentHudBus.emitWakeTrigger(""); schedule(1800)
                    } else {
                        publish("Wake detected — tap to speak",true); val hold=epoch
                        handler.postDelayed({ if(hold==epoch && !closed) { waitForTap=false; schedule(0) } },15000)
                    }
                }
                override fun onFinalResult(hypothesis:String?)=onResult(hypothesis)
                override fun onError(exception:Exception?) { if(current()) recover() }
                override fun onTimeout() { if(current()) recover() }
            }
            check(service.startListening(listener)); publish("Offline listening: $phrase")
        } catch(_:Exception) { recover() } catch(_:LinkageError) { fail("Vosk native library unavailable") }
    }
    private fun recover() { pause(); if(++retries>2) fail("Wake microphone failed after two retries") else { publish("Wake recovery $retries/2"); schedule(if(retries==1) 700 else 1800) } }
    private fun fail(message:String) { status.value=message; prefs.update { it.copy(wakeWordEnabled=false) }; stopSelf() }
    private fun publish(message:String,detected:Boolean=false) { status.value=message; runCatching { getSystemService(NotificationManager::class.java).notify(ID,notification(message,detected)) } }
    private fun notification(message:String,detected:Boolean=false):Notification {
        val open=Intent(this,MainActivity::class.java).apply { flags=Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP; putExtra(MainActivity.EXTRA_START_LISTENING,detected) }
        val tap=PendingIntent.getActivity(this,1,open,PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val stop=PendingIntent.getService(this,2,Intent(this,OmegaWakeService::class.java).setAction(STOP),PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(this,CHANNEL).setSmallIcon(android.R.drawable.ic_btn_speak_now).setContentTitle("OMEGA • Offline Wake").setContentText(message).setContentIntent(tap).setOngoing(true).setVisibility(NotificationCompat.VISIBILITY_PRIVATE).addAction(android.R.drawable.ic_menu_close_clear_cancel,"Stop microphone",stop).build()
    }
    override fun onDestroy() { closed=true; pause(); handler.removeCallbacksAndMessages(null); scope.cancel(); smartTriggers.unregister(); tts.release(); runCatching { model?.close() }; model=null; instance=null; if(!status.value.contains("failed")&&!status.value.contains("unavailable")&&!status.value.contains("blocked")&&!status.value.startsWith("Use a")) status.value="Stopped"; stopForeground(STOP_FOREGROUND_REMOVE); super.onDestroy() }
    override fun onBind(intent:Intent?):IBinder?=null
    companion object {
        private const val CHANNEL="omega_offline_wake_v202"; private const val ID=3191; private const val STOP="com.example.omega.STOP_WAKE"
        private var instance:OmegaWakeService?=null
        val status=MutableStateFlow("Stopped")
        fun pauseForManual() { instance?.let { it.waitForTap=false; it.pause() } }
        fun start(context:Context) { ContextCompat.startForegroundService(context,Intent(context,OmegaWakeService::class.java)) }
        fun stop(context:Context) { context.stopService(Intent(context,OmegaWakeService::class.java)) }
    }
}
