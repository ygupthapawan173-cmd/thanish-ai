package com.example.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import com.example.control.AgentHudBus
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class VoiceInputState(
    val isListening: Boolean = false,
    val partialTranscript: String = "",
    val audioAmplitude: Float = 0f,
    val lastErrorCode: Int = 0,
    val errorMessage: String? = null,
    val activeLocale: String = "en-IN",
    val diagnosticsNote: String = "Ready"
)

/** One in-process recognizer session; stale callbacks cannot release a newer session. */
class VoiceInputController(private val context: Context, private val onFinalTranscript: (String) -> Unit) {
    private val appContext = context.applicationContext
    private val handler = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null
    private var generation = 0L
    private var attempts = 0
    private var language = "auto"
    private var offline = false
    private var lastLocale = "en-IN"
    private val _state = MutableStateFlow(VoiceInputState())
    val state: StateFlow<VoiceInputState> = _state.asStateFlow()
    fun startListening(languageTag: String = "auto", preferOffline: Boolean = false) {
        handler.post {
            stopInternal(); language = languageTag; offline = preferOffline; attempts = 0
            if (androidx.core.content.ContextCompat.checkSelfPermission(appContext, android.Manifest.permission.RECORD_AUDIO) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                _state.value = VoiceInputState(errorMessage = "Allow microphone permission first", diagnosticsNote = "Permission denied"); return@post
            }
            AgentHudBus.setMainMicBusy(true)
            com.example.omega.OmegaWakeService.pauseForManual()
            val token = generation
            _state.value = VoiceInputState(isListening = true, diagnosticsNote = "Preparing microphone")
            handler.postDelayed({ if (token == generation) begin() }, 450)
        }
    }
    private fun begin() {
        destroyRecognizer()
        val token = ++generation
        val locale = if (language == "auto") lastLocale else language
        lastLocale = locale
        val localAvailable = android.os.Build.VERSION.SDK_INT >= 31 && SpeechRecognizer.isOnDeviceRecognitionAvailable(appContext)
        if (offline && !localAvailable) { finishError(12, "Offline speech engine unavailable. Install on-device language packs."); return }
        if (!offline && !SpeechRecognizer.isRecognitionAvailable(appContext) && !localAvailable) { finishError(5, "Speech recognition service unavailable. Enable Android Speech Services."); return }
        val useLocal = offline || (attempts == 1 && localAvailable) || (!SpeechRecognizer.isRecognitionAvailable(appContext) && localAvailable)
        val sr = runCatching { if (useLocal && android.os.Build.VERSION.SDK_INT >= 31) SpeechRecognizer.createOnDeviceSpeechRecognizer(appContext) else SpeechRecognizer.createSpeechRecognizer(appContext) }.getOrElse { retry(5); return }
        recognizer = sr
        fun current() = token == generation && recognizer === sr
        sr.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { if (current()) _state.value = VoiceInputState(isListening = true, activeLocale = locale, diagnosticsNote = "Listening (${if (useLocal) "on-device" else "system"}, $locale)") }
            override fun onBeginningOfSpeech() { if (current()) _state.value = _state.value.copy(isListening = true) }
            override fun onRmsChanged(rmsdB: Float) { if (current()) _state.value = _state.value.copy(audioAmplitude = ((rmsdB + 2f)/12f).coerceIn(0f,1f)) }
            override fun onBufferReceived(buffer: ByteArray?) = Unit
            override fun onEndOfSpeech() { if (current()) _state.value = _state.value.copy(audioAmplitude = 0f, diagnosticsNote = "Processing speech") }
            override fun onError(error: Int) { if (current()) retry(error) }
            override fun onResults(results: Bundle?) {
                if (!current()) return
                val final = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.trim().orEmpty()
                stopInternal()
                _state.value = VoiceInputState(partialTranscript = final, activeLocale = lastLocale, diagnosticsNote = "Captured (${final.length} chars)", errorMessage = if(final.isBlank()) "No speech recognized" else null)
                if (final.isNotEmpty()) onFinalTranscript(final)
            }
            override fun onPartialResults(partialResults: Bundle?) { if (current()) _state.value = _state.value.copy(partialTranscript = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()) }
            override fun onLanguageDetection(results: Bundle) {
                if (!current() || language != "auto" || android.os.Build.VERSION.SDK_INT < 34) return
                val detected = results.getString(SpeechRecognizer.DETECTED_LANGUAGE).orEmpty()
                if (detected.startsWith("te")) lastLocale = "te-IN" else if (detected.startsWith("en")) lastLocale = "en-IN"
                _state.value = _state.value.copy(activeLocale = lastLocale, diagnosticsNote = "Detected $detected")
            }
            override fun onEvent(eventType: Int, params: Bundle?) = Unit
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, locale)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            if (offline) putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
            if (language == "auto" && android.os.Build.VERSION.SDK_INT >= 34 && attempts == 0) {
                putExtra(RecognizerIntent.EXTRA_ENABLE_LANGUAGE_DETECTION, true)
                putExtra(RecognizerIntent.EXTRA_ENABLE_LANGUAGE_SWITCH, RecognizerIntent.LANGUAGE_SWITCH_BALANCED)
                putStringArrayListExtra(RecognizerIntent.EXTRA_LANGUAGE_DETECTION_ALLOWED_LANGUAGES, arrayListOf("te-IN", "en-IN"))
                putStringArrayListExtra(RecognizerIntent.EXTRA_LANGUAGE_SWITCH_ALLOWED_LANGUAGES, arrayListOf("te-IN", "en-IN"))
            }
        }
        runCatching { sr.startListening(intent) }.onFailure { retry(5) }
        handler.postDelayed({ if(current()) retry(6) }, 30000)
    }
    private fun retry(code: Int) {
        ++generation; destroyRecognizer(); handler.removeCallbacksAndMessages(null)
        if (VoiceRecoveryPolicy.retryable(code, language == "auto", attempts)) {
            attempts++
            if(language == "auto") lastLocale = VoiceRecoveryPolicy.nextLocale(lastLocale)
            val token = generation
            _state.value = _state.value.copy(isListening = true, audioAmplitude = 0f, lastErrorCode = code, diagnosticsNote = "Recovery $attempts/2 (error $code); speak again")
            handler.postDelayed({ if(token == generation) begin() }, if(attempts == 1) 650 else 1400)
        } else finishError(code, when(code) { 9 -> "Microphone permission denied"; 12,13 -> "Language model unavailable; install speech language pack"; 6,7 -> "No speech recognized. Tap mic again."; else -> "Speech recognition error $code. Check speech service and microphone." })
    }
    private fun finishError(code: Int, message: String) { stopInternal(); _state.value = VoiceInputState(lastErrorCode = code, errorMessage = message, diagnosticsNote = "Error $code") }
    fun stopListening() { if (Looper.myLooper() == Looper.getMainLooper()) stopInternal() else handler.post { stopInternal() } }
    fun release() = stopListening()
    private fun stopInternal() { ++generation; handler.removeCallbacksAndMessages(null); destroyRecognizer(); AgentHudBus.setMainMicBusy(false); _state.value = _state.value.copy(isListening = false, audioAmplitude = 0f) }
    private fun destroyRecognizer() { val old = recognizer; recognizer = null; runCatching { old?.cancel() }; runCatching { old?.destroy() } }
}
