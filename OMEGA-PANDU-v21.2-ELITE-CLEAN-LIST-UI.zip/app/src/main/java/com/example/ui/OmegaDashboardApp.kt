package com.example.ui

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.Send
import androidx.compose.material.icons.automirrored.rounded.VolumeOff
import androidx.compose.material.icons.automirrored.rounded.VolumeUp
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.data.OmegaVisualTheme
import com.example.data.OrbColorPreset
import com.example.ui.components.OmegaHorizonOrb
import com.example.ui.components.ParticleAiOrb
import com.example.ui.components.ParticleRibbonWaveform
import com.example.ui.components.rememberParallaxOffset
import com.example.ui.theme.OmegaColors
import com.example.ui.theme.OmegaLiquidBackdrop
import com.example.ui.theme.accentColor
import com.example.ui.theme.mutedText
import com.example.ui.theme.omegaGlassCard
import com.example.ui.theme.primaryText
import kotlinx.coroutines.delay

@Composable
fun OmegaDashboardApp(viewModel: PanduViewModel) {
    val uiState by viewModel.uiState.collectAsState()
    val context = LocalContext.current

    val micLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) viewModel.startVoiceListening()
    }
    val camPreview = rememberLauncherForActivityResult(ActivityResultContracts.TakePicturePreview()) { bmp ->
        if (bmp != null) viewModel.analyzeCameraBitmap(bmp)
    }
    val camPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) camPreview.launch(null)
    }

    fun launchVoice() {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            viewModel.startVoiceListening()
        } else micLauncher.launch(Manifest.permission.RECORD_AUDIO)
    }

    fun launchCamera() {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            camPreview.launch(null)
        } else camPerm.launch(Manifest.permission.CAMERA)
    }

    LaunchedEffect(uiState.pendingWidgetCameraLaunch) {
        if (uiState.pendingWidgetCameraLaunch) {
            viewModel.consumeWidgetCameraLaunch()
            launchCamera()
        }
    }

    Crossfade(targetState = uiState.currentScreen, label = "nav") { screen ->
        when (screen) {
            OmegaScreen.HOME -> HomeScreen(
                uiState = uiState,
                onVoiceClick = { launchVoice() },
                onUnmuteClick = { viewModel.unmuteMicAndListen() },
                onStopClick = { viewModel.stopAllActivity() },
                onToggleAutoSpeak = { viewModel.toggleAutoSpeak() },
                onChatClick = { viewModel.navigateTo(OmegaScreen.CHAT) },
                onRoutinesClick = { viewModel.navigateTo(OmegaScreen.ROUTINES) },
                onCameraClick = { launchCamera() },
                onSettingsClick = { viewModel.navigateTo(OmegaScreen.SETTINGS) },
                onLabClick = { viewModel.navigateTo(OmegaScreen.AUTONOMOUS_LAB) },
                onToggleLocalBrain = { viewModel.toggleLocalBrainMode() },
                onDailyBriefing = { viewModel.runDailyBriefing() },
                onDismissTrigger = { viewModel.dismissTriggerBanner() },
                onQuickPrompt = { viewModel.sendTextPrompt(it, openChat = true) }
            )
            OmegaScreen.LISTENING -> ListeningScreen(
                uiState = uiState,
                onBack = { viewModel.stopAllActivity(); viewModel.navigateTo(OmegaScreen.HOME) },
                onChat = { viewModel.navigateTo(OmegaScreen.CHAT) },
                onUnmuteClick = { viewModel.unmuteMicAndListen() },
                onToggleMic = {
                    if (uiState.isListening || uiState.liveDuplexState.isConnected) viewModel.stopVoiceListening()
                    else launchVoice()
                },
                onCycleLang = { viewModel.cycleVoiceLanguage() },
                onToggleAutoSpeak = { viewModel.toggleAutoSpeak() },
                onToggleLiveMode = { viewModel.toggleLiveDuplexMode() }
            )
            OmegaScreen.CHAT -> ChatScreen(
                uiState = uiState,
                onBack = { viewModel.navigateTo(OmegaScreen.HOME) },
                onMic = { launchVoice() },
                onCamera = { launchCamera() },
                onSummarize = { viewModel.summarizeConversation() },
                onConfirmReply = { viewModel.confirmPendingNotifReply() },
                onCancelReply = { viewModel.cancelPendingNotifReply() },
                onSend = { viewModel.sendTextPrompt(it, openChat = false) },
                onSpeak = { viewModel.speakMessage(it) }
            )
            OmegaScreen.ROUTINES -> RoutinesAndMemoryScreen(
                settings = uiState.settings,
                routines = uiState.routines,
                memories = uiState.memories,
                locationReminders = uiState.locationReminders,
                onBack = { viewModel.navigateTo(OmegaScreen.HOME) },
                onUpdateSettings = { viewModel.updateSettings(it) },
                onTestTrigger = { viewModel.testSmartTrigger(it) },
                onScheduleRoutine = { name, h, m -> viewModel.scheduleDailyRoutine(name, h, m) },
                onRunRoutine = { viewModel.runRoutineNow(it) },
                onAddRoutine = { n, t, s, j -> viewModel.saveCustomRoutine(n, t, s, j) },
                onDeleteRoutine = { viewModel.deleteRoutine(it) },
                onDeleteMemory = { viewModel.deleteMemory(it) }
            )
            OmegaScreen.AUTONOMOUS_LAB -> AutonomousLabScreen(
                uiState = uiState,
                onBack = { viewModel.navigateTo(OmegaScreen.HOME) },
                onSaveSettings = { viewModel.updateSettings(it) },
                onRunDiagnostics = { viewModel.runSystemDiagnostics() },
                onStartSelfUpgrade = { req, path -> viewModel.startSelfUpgrade(req, path) },
                onEmergencyStop = { viewModel.emergencyStopUpgrade() },
                onCheckReleaseUpdate = { viewModel.checkReleaseUpdate() },
                onApproveAndInstallUpdate = { viewModel.approveAndInstallRelease() }
            )
            OmegaScreen.SETTINGS -> SettingsScreen(
                uiState = uiState,
                onBack = { viewModel.navigateTo(OmegaScreen.HOME) },
                onSaveSettings = { viewModel.updateSettings(it) },
                onRunConnectionTest = { viewModel.runConnectionTest(it) },
                onDiscoverModels = { viewModel.discoverRealModels() },
                onTestSpeaker = { viewModel.testSpeakerVoice() },
                onToggleWakeService = { viewModel.setWakeWordEnabled(it) },
                onExportBackup = { viewModel.exportEncryptedBackup() },
                onImportBackup = { viewModel.importEncryptedBackup(it) },
                onClearCrashLogs = { viewModel.clearCrashLogs() },
                onClearHistory = { viewModel.clearChatHistory() }
            )
        }
    }
}

// ------------------------------------------------------------
// SCREEN 1: PURE AMOLED DOLA-INSPIRED FLAGSHIP HOME
// ------------------------------------------------------------
@Composable
private fun HomeScreen(
    uiState: PanduUiState,
    onVoiceClick: () -> Unit,
    onUnmuteClick: () -> Unit,
    onStopClick: () -> Unit,
    onToggleAutoSpeak: () -> Unit,
    onChatClick: () -> Unit,
    onRoutinesClick: () -> Unit,
    onCameraClick: () -> Unit,
    onSettingsClick: () -> Unit,
    onLabClick: () -> Unit,
    onToggleLocalBrain: () -> Unit,
    onDailyBriefing: () -> Unit,
    onDismissTrigger: () -> Unit,
    onQuickPrompt: (String) -> Unit
) {
    val theme = uiState.settings.visualTheme
    val preset = uiState.settings.orbColorPreset
    val accent = theme.accentColor(preset)
    val tilt by rememberParallaxOffset(enabled = uiState.settings.gyroscopeParallax, maxDpShift = 10f)
    var promptText by remember { mutableStateOf("") }

    OmegaLiquidBackdrop(theme = theme, preset = preset) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(horizontal = 18.dp, vertical = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Top Minimalist Header: [Menu/Settings]  [✦ OMEGA • AI Assistant]  [Speaker]
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                GlassCircleButton(Icons.Rounded.Menu, size = 46.dp, theme = theme, preset = preset, onClick = onSettingsClick)

                Row(
                    modifier = Modifier
                        .omegaGlassCard(26.dp, theme, preset)
                        .clickable { if (uiState.settings.micPrivacyMuted) onUnmuteClick() else onSettingsClick() }
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(22.dp)
                            .clip(CircleShape)
                            .background(Brush.linearGradient(listOf(Color(preset.primaryHex), Color(preset.secondaryHex), Color(preset.accentHex)))),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Rounded.AutoAwesome, null, tint = Color.White, modifier = Modifier.size(13.dp))
                    }
                    Column {
                        Text(
                            text = if (uiState.settings.micPrivacyMuted) "MIC MUTED" else "OMEGA",
                            color = if (uiState.settings.micPrivacyMuted) OmegaColors.CrimsonErr else theme.primaryText(),
                            fontSize = 13.5.sp,
                            fontWeight = FontWeight.Bold,
                            lineHeight = 15.sp
                        )
                        Text(
                            text = when {
                                uiState.isThinking -> "Thinking..."
                                uiState.isSpeaking -> "Speaking..."
                                uiState.settings.localBrainMode -> "Local Brain • ${uiState.batteryPercent}%"
                                else -> "AI Assistant • ${uiState.batteryPercent}%"
                            },
                            color = theme.mutedText(),
                            fontSize = 10.5.sp,
                            lineHeight = 13.sp
                        )
                    }
                }

                if (uiState.isThinking || uiState.isSpeaking) {
                    GlassCircleButton(Icons.Rounded.Stop, size = 46.dp, theme = theme, preset = preset, onClick = onStopClick)
                } else {
                    GlassCircleButton(
                        icon = if (uiState.settings.autoSpeak) Icons.AutoMirrored.Rounded.VolumeUp else Icons.AutoMirrored.Rounded.VolumeOff,
                        size = 46.dp,
                        theme = theme,
                        preset = preset,
                        onClick = onToggleAutoSpeak
                    )
                }
            }

            AnimatedVisibility(visible = uiState.lastTriggerBanner != null) {
                if (uiState.lastTriggerBanner != null) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(top = 10.dp).omegaGlassCard(16.dp, theme, preset).clickable { onDismissTrigger() }.padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(uiState.lastTriggerBanner, color = theme.primaryText(), fontSize = 12.sp, maxLines = 2, modifier = Modifier.weight(1f))
                        Icon(Icons.Rounded.Close, "Dismiss", tint = theme.mutedText(), modifier = Modifier.size(16.dp))
                    }
                }
            }

            Spacer(modifier = Modifier.weight(0.55f))

            // BORDERLESS 3D DOTTED PARTICLE SPHERE (FLOATING DIRECTLY ON PURE BLACK!)
            Box(
                modifier = Modifier
                    .offset(x = tilt.x.dp, y = tilt.y.dp)
                    .clickable { if (uiState.settings.micPrivacyMuted) onUnmuteClick() else onVoiceClick() },
                contentAlignment = Alignment.Center
            ) {
                if (theme == OmegaVisualTheme.CYBER_HORIZON_WEBGL) {
                    OmegaHorizonOrb(
                        orbState = if (uiState.isThinking) "thinking" else if (uiState.isSpeaking) "speaking" else "idle",
                        audioLevel = if (uiState.isThinking || uiState.isSpeaking) 0.55f else 0.14f,
                        size = 246.dp
                    )
                } else {
                    ParticleAiOrb(
                        size = 246.dp,
                        isListening = uiState.isThinking || uiState.isSpeaking,
                        audioAmplitude = if (uiState.isThinking || uiState.isSpeaking) 0.55f else 0.12f,
                        preset = preset
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Clean Typography Greeting (Exact Dola Hierarchy)
            Text(
                text = "Hi ${uiState.settings.userName}, I'm OMEGA!",
                color = theme.mutedText(),
                fontSize = 14.sp,
                fontWeight = FontWeight.Medium
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "How can I help\nyou today?",
                color = theme.primaryText(),
                fontSize = 27.sp,
                fontWeight = FontWeight.SemiBold,
                textAlign = TextAlign.Center,
                lineHeight = 34.sp
            )

            Spacer(modifier = Modifier.weight(0.75f))

            // 2-Row Sleek Dark Pill Action Chips (Matches Reference Layout)
            Row(
                modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                IconPillChip(theme, preset, Icons.Rounded.Memory, if (uiState.settings.localBrainMode) "Local Brain ON" else "Local Brain") { onToggleLocalBrain() }
                IconPillChip(theme, preset, Icons.Rounded.AutoFixHigh, "Self-Upgrade") { onLabClick() }
                IconPillChip(theme, preset, Icons.Rounded.WbSunny, "Daily Briefing") { onDailyBriefing() }
                IconPillChip(theme, preset, Icons.Rounded.Cloud, "Live Weather") { onQuickPrompt("Current weather right now") }
            }
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                IconPillChip(theme, preset, Icons.Rounded.ChatBubbleOutline, "Supreme Chat") { onChatClick() }
                IconPillChip(theme, preset, Icons.Rounded.CenterFocusWeak, "Vision Scan") { onCameraClick() }
                IconPillChip(theme, preset, Icons.Rounded.Bolt, "Automations") { onRoutinesClick() }
                IconPillChip(theme, preset, Icons.Rounded.FlashlightOn, "Torch ON") { onQuickPrompt("Turn on flashlight") }
                if (uiState.unreadNotifCount > 0) {
                    IconPillChip(theme, preset, Icons.Rounded.Notifications, "Unread (${uiState.unreadNotifCount})") {
                        onQuickPrompt("Read my latest notifications.")
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Bottom Composer Bar + Standalone Glowing Gradient Mic Orb (Exact Dola Footer)
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    modifier = Modifier.weight(1f).omegaGlassCard(28.dp, theme, preset).padding(horizontal = 6.dp, vertical = 2.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onLabClick, modifier = Modifier.size(38.dp)) {
                        Icon(Icons.Rounded.Add, "Lab", tint = theme.mutedText(), modifier = Modifier.size(21.dp))
                    }
                    TextField(
                        value = promptText,
                        onValueChange = { promptText = it },
                        placeholder = { Text("Message...", color = theme.mutedText(), fontSize = 14.5.sp) },
                        colors = TextFieldDefaults.colors(
                            focusedContainerColor = Color.Transparent, unfocusedContainerColor = Color.Transparent,
                            focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent,
                            focusedTextColor = theme.primaryText(), unfocusedTextColor = theme.primaryText()
                        ),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    IconButton(onClick = onCameraClick, modifier = Modifier.size(38.dp)) {
                        Icon(Icons.Rounded.CameraAlt, "Camera Vision", tint = theme.mutedText(), modifier = Modifier.size(20.dp))
                    }
                }

                // Glowing Gradient Circular Action Button (Mic when empty, Send when typing)
                Box(
                    modifier = Modifier
                        .size(54.dp)
                        .clip(CircleShape)
                        .background(
                            Brush.linearGradient(
                                listOf(Color(preset.accentHex), Color(preset.secondaryHex), Color(preset.primaryHex))
                            )
                        )
                        .clickable {
                            if (promptText.isNotBlank()) {
                                onQuickPrompt(promptText); promptText = ""
                            } else if (uiState.settings.micPrivacyMuted) {
                                onUnmuteClick()
                            } else {
                                onVoiceClick()
                            }
                        },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (promptText.isNotBlank()) Icons.AutoMirrored.Rounded.Send else Icons.Rounded.Mic,
                        contentDescription = "Voice or Send",
                        tint = Color.White,
                        modifier = Modifier.size(24.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun IconPillChip(
    theme: OmegaVisualTheme,
    preset: OrbColorPreset,
    icon: ImageVector,
    label: String,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .omegaGlassCard(20.dp, theme, preset)
            .clickable { onClick() }
            .padding(horizontal = 13.dp, vertical = 9.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(7.dp)
    ) {
        Icon(icon, null, tint = Color(preset.primaryHex), modifier = Modifier.size(15.dp))
        Text(label, color = theme.primaryText(), fontSize = 12.5.sp, fontWeight = FontWeight.Medium)
    }
}

// ------------------------------------------------------------
// SCREEN 2: DOLA-STYLE VOICE CALL SCREEN (3D RIBBON WAVE + BOTTOM AURORA GLOW)
// ------------------------------------------------------------
@Composable
private fun ListeningScreen(
    uiState: PanduUiState,
    onBack: () -> Unit,
    onChat: () -> Unit,
    onUnmuteClick: () -> Unit,
    onToggleMic: () -> Unit,
    onCycleLang: () -> Unit,
    onToggleAutoSpeak: () -> Unit,
    onToggleLiveMode: () -> Unit
) {
    val theme = uiState.settings.visualTheme
    val preset = uiState.settings.orbColorPreset
    val accent = theme.accentColor(preset)
    val isLive = uiState.settings.useGeminiLiveAudio
    val activeAmp = if (isLive) uiState.liveDuplexState.amplitude else uiState.audioAmplitude
    val isActive = if (isLive) uiState.liveDuplexState.isConnected else uiState.isListening

    var elapsedSeconds by remember { mutableIntStateOf(0) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(1000L)
            elapsedSeconds++
        }
    }
    val timerText = String.format("%02d:%02d", elapsedSeconds / 60, elapsedSeconds % 60)

    val subtitle = when {
        uiState.settings.micPrivacyMuted -> "Microphone Privacy Mute is ON. Tap Unmute below."
        isLive && uiState.liveDuplexState.error != null -> uiState.liveDuplexState.error
        isLive -> uiState.liveDuplexState.statusText
        uiState.voiceError != null -> uiState.voiceError
        uiState.liveTranscript.isNotBlank() && uiState.isListening -> "\"${uiState.liveTranscript}\""
        uiState.isThinking -> uiState.liveToolStatus ?: "Thinking..."
        uiState.lastAiReply.isNotBlank() -> uiState.lastAiReply
        else -> "Listening... Speak in Telugu or English"
    }

    Box(modifier = Modifier.fillMaxSize().background(OmegaColors.PureBlack)) {
        // Clean List UI: pure AMOLED black voice interface

        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(horizontal = 20.dp, vertical = 14.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Top Bar: Back + Language/Mode pills + Speaker
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                GlassCircleButton(Icons.AutoMirrored.Rounded.ArrowBack, 46.dp, theme, preset, onBack)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Box(modifier = Modifier.omegaGlassCard(18.dp, theme, preset).clickable { onToggleLiveMode() }.padding(horizontal = 12.dp, vertical = 8.dp)) {
                        Text(if (isLive) "Live WS" else "Voice", color = accent, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                    if (!isLive) {
                        val langLabel = when (uiState.settings.languageTag) { "te-IN" -> "తెలుగు"; "en-IN" -> "EN-IN"; else -> "AUTO" }
                        Box(modifier = Modifier.omegaGlassCard(18.dp, theme, preset).clickable { onCycleLang() }.padding(horizontal = 12.dp, vertical = 8.dp)) {
                            Text(langLabel, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                        }
                    }
                }
                GlassCircleButton(
                    if (uiState.settings.autoSpeak) Icons.AutoMirrored.Rounded.VolumeUp else Icons.AutoMirrored.Rounded.VolumeOff,
                    46.dp, theme, preset, onToggleAutoSpeak
                )
            }

            Spacer(modifier = Modifier.height(34.dp))

            // 3D Flowing Particle Ribbon Wave
            ParticleRibbonWaveform(
                isActive = isActive || uiState.isSpeaking || uiState.isThinking || uiState.liveDuplexState.isAiSpeaking,
                audioAmplitude = if (uiState.isThinking || uiState.isSpeaking) 0.65f else activeAmp,
                preset = preset,
                height = 175.dp
            )

            Spacer(modifier = Modifier.height(14.dp))

            // Crisp Timer (00:00)
            Text(timerText, color = Color.White.copy(0.68f), fontSize = 19.sp, fontWeight = FontWeight.Medium)

            Spacer(modifier = Modifier.height(18.dp))

            // Clean Floating Transcript / Reply
            Text(
                text = subtitle,
                color = if (uiState.voiceError != null || uiState.settings.micPrivacyMuted) Color(0xFFFF8A80) else Color.White.copy(0.92f),
                fontSize = 15.sp,
                textAlign = TextAlign.Center,
                lineHeight = 22.sp,
                modifier = Modifier.padding(horizontal = 14.dp).heightIn(max = 150.dp)
            )

            if (uiState.settings.micPrivacyMuted) {
                Spacer(modifier = Modifier.height(12.dp))
                Button(onClick = onUnmuteClick, colors = ButtonDefaults.buttonColors(containerColor = OmegaColors.EmeraldLive), shape = RoundedCornerShape(16.dp)) {
                    Text("Unmute Mic & Listen", color = Color.White, fontWeight = FontWeight.Bold)
                }
            }

            Spacer(modifier = Modifier.weight(1f))

            // Bottom Controls: [Pause/Chat]  [Glowing Concentric Mic Orb]  [Close X]
            Row(
                modifier = Modifier.fillMaxWidth().padding(bottom = 18.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier.size(52.dp).clip(CircleShape).background(Color.White.copy(0.14f)).clickable { onChat() },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Rounded.ChatBubbleOutline, "Chat", tint = Color.White, modifier = Modifier.size(22.dp))
                }

                // Concentric Glowing Mic Button
                Box(
                    modifier = Modifier
                        .size(92.dp)
                        .clip(CircleShape)
                        .background(Color.White.copy(0.16f))
                        .clickable { if (uiState.settings.micPrivacyMuted) onUnmuteClick() else onToggleMic() },
                    contentAlignment = Alignment.Center
                ) {
                    Box(
                        modifier = Modifier
                            .size(72.dp)
                            .clip(CircleShape)
                            .background(
                                Brush.linearGradient(
                                    if (isActive) listOf(Color(0xFFF43F5E), Color(0xFFFF6B35))
                                    else listOf(Color(preset.accentHex), Color(preset.secondaryHex))
                                )
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(if (isActive) Icons.Rounded.Stop else Icons.Rounded.Mic, "Mic", tint = Color.White, modifier = Modifier.size(30.dp))
                    }
                }

                Box(
                    modifier = Modifier.size(52.dp).clip(CircleShape).background(Color.White.copy(0.14f)).clickable { onBack() },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Rounded.Close, "Close", tint = Color.White, modifier = Modifier.size(22.dp))
                }
            }
        }
    }
}

// ------------------------------------------------------------
// SCREEN 3: PURE AMOLED CHAT SCREEN
// ------------------------------------------------------------
@Composable
private fun ChatScreen(
    uiState: PanduUiState,
    onBack: () -> Unit,
    onMic: () -> Unit,
    onCamera: () -> Unit,
    onSummarize: () -> Unit,
    onConfirmReply: () -> Unit,
    onCancelReply: () -> Unit,
    onSend: (String) -> Unit,
    onSpeak: (String) -> Unit
) {
    val theme = uiState.settings.visualTheme
    val preset = uiState.settings.orbColorPreset
    val accent = theme.accentColor(preset)
    var text by remember { mutableStateOf("") }
    val listState = rememberLazyListState()

    LaunchedEffect(uiState.messages.size, uiState.isThinking) {
        if (uiState.messages.isNotEmpty()) listState.animateScrollToItem(uiState.messages.lastIndex)
    }

    OmegaLiquidBackdrop(theme = theme, preset = preset) {
        Column(modifier = Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(horizontal = 16.dp, vertical = 12.dp)) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                GlassCircleButton(Icons.AutoMirrored.Rounded.ArrowBack, theme = theme, preset = preset, onClick = onBack)
                Text(if (uiState.lastLatencyMs > 0) "OMEGA Chat (${uiState.lastLatencyMs}ms)" else "OMEGA Chat", color = theme.primaryText(), fontSize = 16.sp, fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    GlassCircleButton(Icons.Rounded.Summarize, theme = theme, preset = preset, onClick = onSummarize)
                    GlassCircleButton(Icons.Rounded.CameraAlt, theme = theme, preset = preset, onClick = onCamera)
                }
            }

            AnimatedVisibility(visible = uiState.pendingNotifReply != null) {
                val p = uiState.pendingNotifReply
                if (p != null) {
                    Column(modifier = Modifier.fillMaxWidth().padding(top = 10.dp).omegaGlassCard(18.dp, theme, preset).padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("Confirm Reply to ${p.resolvedTitle} (${p.appName})", color = accent, fontSize = 12.5.sp, fontWeight = FontWeight.Bold)
                        Text("\"${p.replyText}\"", color = theme.primaryText(), fontSize = 13.sp)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = onConfirmReply, colors = ButtonDefaults.buttonColors(containerColor = OmegaColors.EmeraldLive), shape = RoundedCornerShape(12.dp)) { Text("Send", color = Color.White, fontSize = 12.sp) }
                            OutlinedButton(onClick = onCancelReply, shape = RoundedCornerShape(12.dp)) { Text("Cancel", color = theme.primaryText(), fontSize = 12.sp) }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))
            LazyColumn(state = listState, modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                items(uiState.messages, key = { it.id }) { m ->
                    if (m.isFromUser) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                            Column(
                                modifier = Modifier.widthIn(max = 280.dp).clip(RoundedCornerShape(20.dp))
                                    .background(Brush.linearGradient(listOf(Color(preset.accentHex), Color(preset.secondaryHex))))
                                    .padding(horizontal = 14.dp, vertical = 10.dp)
                            ) {
                                if (m.isVoiceInput) Text("Voice • ${m.audioDuration}", color = Color.White.copy(0.85f), fontSize = 10.5.sp, fontWeight = FontWeight.SemiBold)
                                if (m.hasImageAttachment) Text("Vision Image Attached", color = Color.White.copy(0.9f), fontSize = 10.5.sp, fontWeight = FontWeight.SemiBold)
                                Text(m.text, color = Color.White, fontSize = 13.5.sp, lineHeight = 19.sp)
                            }
                        }
                    } else {
                        Row(modifier = Modifier.fillMaxWidth(0.92f), verticalAlignment = Alignment.Top, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            ParticleAiOrb(size = 28.dp, preset = preset)
                            Column(modifier = Modifier.omegaGlassCard(18.dp, theme, preset).padding(horizontal = 14.dp, vertical = 11.dp)) {
                                if (m.executedTools.isNotEmpty()) {
                                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.padding(bottom = 5.dp)) {
                                        m.executedTools.distinct().take(3).forEach { tool ->
                                            Box(modifier = Modifier.clip(RoundedCornerShape(10.dp)).background(accent.copy(0.16f)).padding(horizontal = 8.dp, vertical = 2.dp)) {
                                                Text(tool, color = accent, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                            }
                                        }
                                    }
                                }
                                Text(m.text, color = if (m.isError) OmegaColors.CrimsonErr else theme.primaryText(), fontSize = 13.5.sp, lineHeight = 19.sp)
                                if (!m.isError) {
                                    Spacer(modifier = Modifier.height(5.dp))
                                    Row(modifier = Modifier.clickable { onSpeak(m.text) }, verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                        Icon(Icons.AutoMirrored.Rounded.VolumeUp, null, tint = accent, modifier = Modifier.size(14.dp))
                                        Text("Listen", color = accent, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                                    }
                                }
                            }
                        }
                    }
                }
                if (uiState.isThinking) {
                    item {
                        Box(modifier = Modifier.omegaGlassCard(16.dp, theme, preset).padding(horizontal = 14.dp, vertical = 10.dp)) {
                            Text(uiState.liveToolStatus ?: "OMEGA thinking...", color = accent, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))
            Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(modifier = Modifier.weight(1f).omegaGlassCard(28.dp, theme, preset).padding(horizontal = 6.dp, vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onCamera) { Icon(Icons.Rounded.Add, "Camera Vision", tint = theme.mutedText()) }
                    TextField(
                        value = text,
                        onValueChange = { text = it },
                        placeholder = { Text("Message...", color = theme.mutedText(), fontSize = 14.sp) },
                        colors = TextFieldDefaults.colors(
                            focusedContainerColor = Color.Transparent, unfocusedContainerColor = Color.Transparent,
                            focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent,
                            focusedTextColor = theme.primaryText(), unfocusedTextColor = theme.primaryText()
                        ),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    IconButton(onClick = onMic) { Icon(Icons.Rounded.Mic, "Voice", tint = theme.mutedText()) }
                }
                Box(
                    modifier = Modifier.size(48.dp).clip(CircleShape)
                        .background(Brush.linearGradient(listOf(Color(preset.accentHex), Color(preset.secondaryHex), Color(preset.primaryHex))))
                        .clickable { if (text.isNotBlank() && !uiState.isThinking) { onSend(text); text = "" } else onMic() },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(if (text.isNotBlank()) Icons.AutoMirrored.Rounded.Send else Icons.Rounded.Mic, "Send", tint = Color.White, modifier = Modifier.size(20.dp))
                }
            }
        }
    }
}

@Composable
fun GlassCircleButton(
    icon: ImageVector,
    size: Dp = 42.dp,
    theme: OmegaVisualTheme,
    preset: OrbColorPreset = OrbColorPreset.SOLAR_NOVA,
    onClick: () -> Unit
) {
    IconButton(onClick = onClick, modifier = Modifier.size(size).omegaGlassCard(size / 2, theme, preset)) {
        Icon(icon, contentDescription = null, tint = theme.primaryText(), modifier = Modifier.size(20.dp))
    }
}
