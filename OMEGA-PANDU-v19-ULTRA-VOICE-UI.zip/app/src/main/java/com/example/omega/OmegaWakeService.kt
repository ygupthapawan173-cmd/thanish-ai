package com.example.omega

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.example.MainActivity
import com.example.control.AgentHudBus
import com.example.control.AgentHudState
import com.example.data.OmegaPreferences
import com.example.voice.TeluguTtsController
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class OmegaWakeService : Service() {

    private val mainHandler = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private lateinit var preferences: OmegaPreferences
    private lateinit var smartTriggers: SmartTriggerManager
    private lateinit var tts: TeluguTtsController
    private lateinit var audioGate: SilentAudioGate

    private var recognizer: SpeechRecognizer? = null
    private var gateJob: Job? = null
    private var running = false

    override fun onCreate() {
        super.onCreate()
        preferences = OmegaPreferences(this)
        audioGate = SilentAudioGate(thresholdProvider = { preferences.settings.value.rmsGateThreshold() })
        smartTriggers = SmartTriggerManager(this)
        tts = TeluguTtsController(this)
        smartTriggers.register()

        createChannel()
        startForegroundSafely()
        running = true

        scope.launch {
            AgentHudBus.isMainMicBusy.collect { busy ->
                if (busy) pauseAll() else if (running) armGate(600L)
            }
        }

        scope.launch {
            SmartTriggerBus.events.collect { event ->
                val s = preferences.settings.value
                if (s.autoSpeak) {
                    tts.configure(s.languageTag, s.ttsSpeed, s.ttsPitch, s.ttsStyle)
                    tts.speak(event.announcement)
                }
                delay(4500L)
                AgentHudBus.updateState(AgentHudState.Hidden)
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) { stopSelf(); return START_NOT_STICKY }
        startForegroundSafely()
        if (!AgentHudBus.isMainMicBusy.value) armGate(250L)
        return START_STICKY
    }

    private fun startForegroundSafely() {
        val wakeWord = preferences.settings.value.wakeWord
        val pi = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
                putExtra(MainActivity.EXTRA_START_LISTENING, true)
            },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val notif: Notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("OMEGA 19 Ultra Listening")
            .setContentText("Say \"$wakeWord\" anytime")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true)
            .setContentIntent(pi)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(NOTIF_ID, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(NOTIF_ID, notif)
        }
    }

    private fun pauseAll() {
        gateJob?.cancel(); gateJob = null
        destroyRecognizer()
    }

    private fun armGate(delayMs: Long) {
        gateJob?.cancel()
        gateJob = scope.launch {
            delay(delayMs)
            val s = preferences.settings.value
            if (!running || AgentHudBus.isMainMicBusy.value || s.micPrivacyMuted) return@launch
            if (audioGate.waitForSpeechBurst() && running && !AgentHudBus.isMainMicBusy.value) {
                verifyWakePhrase()
            }
        }
    }

    private fun verifyWakePhrase() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) return
        destroyRecognizer()
        val sr = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer = sr
        sr.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) = Unit
            override fun onBeginningOfSpeech() = Unit
            override fun onRmsChanged(rmsdB: Float) = Unit
            override fun onBufferReceived(buffer: ByteArray?) = Unit
            override fun onEndOfSpeech() = Unit
            override fun onPartialResults(partialResults: Bundle?) { checkMatches(partialResults) }
            override fun onResults(results: Bundle?) {
                val hit = checkMatches(results)
                destroyRecognizer()
                if (!hit) armGate(400L)
            }
            override fun onError(error: Int) { destroyRecognizer(); armGate(850L) }
            override fun onEvent(eventType: Int, params: Bundle?) = Unit
        })

        val lang = preferences.settings.value.languageTag.let { if (it == "auto") "en-IN" else it }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
        }
        runCatching { sr.startListening(intent) }.onFailure { armGate(1200L) }
    }

    private fun checkMatches(bundle: Bundle?): Boolean {
        val candidates = bundle?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION).orEmpty()
        if (candidates.isEmpty()) return false
        val customWake = preferences.settings.value.wakeWord.lowercase().trim()
        val wakeAliases = buildList {
            if (customWake.isNotEmpty()) add(customWake)
            if (customWake.contains("jarvis")) {
                add("jarvis"); add("hey jarvis"); add("hai jarvis"); add("hi jarvis"); add("ok jarvis"); add("service")
            }
            add("hey pandu"); add("hey omega")
        }.distinct()

        for (raw in candidates) {
            val spoken = raw.lowercase().trim()
            val matchedAlias = wakeAliases.firstOrNull { alias -> spoken.contains(alias) }
            if (matchedAlias != null) {
                val inlineCmd = spoken.substringAfter(matchedAlias).trim()
                pauseAll()
                AgentHudBus.updateState(AgentHudState.Active(inlineCmd.ifBlank { "OMEGA Awake" }, audioAmplitude = 0.75f))
                AgentHudBus.emitWakeTrigger(inlineCmd)
                startActivity(
                    Intent(this, MainActivity::class.java).apply {
                        flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
                        putExtra(MainActivity.EXTRA_START_LISTENING, true)
                        if (inlineCmd.isNotBlank()) putExtra(MainActivity.EXTRA_WAKE_COMMAND, inlineCmd)
                    }
                )
                return true
            }
        }
        return false
    }

    private fun destroyRecognizer() {
        mainHandler.post { runCatching { recognizer?.cancel(); recognizer?.destroy() }; recognizer = null }
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel(CHANNEL_ID, "OMEGA Wake & Triggers", NotificationManager.IMPORTANCE_LOW))
        }
    }

    override fun onDestroy() {
        running = false; pauseAll(); smartTriggers.unregister(); tts.release()
        mainHandler.removeCallbacksAndMessages(null); scope.cancel()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        private const val CHANNEL_ID = "omega_pandu_v19_ultra"
        private const val NOTIF_ID = 3190
        private const val ACTION_STOP = "com.example.omega.STOP_WAKE"

        fun start(context: Context) {
            ContextCompat.startForegroundService(context, Intent(context, OmegaWakeService::class.java))
        }
        fun stop(context: Context) {
            context.startService(Intent(context, OmegaWakeService::class.java).apply { action = ACTION_STOP })
        }
    }
}
