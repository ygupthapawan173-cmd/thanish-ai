package com.example.ui

import android.app.Application
import android.graphics.Bitmap
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.ai.ConnectionDiagnosticResult
import com.example.ai.GeminiLiveDuplexEngine
import com.example.ai.LiveDuplexState
import com.example.ai.PanduAiRepository
import com.example.control.AgentHudBus
import com.example.control.AgentHudState
import com.example.control.DeviceActionExecutor
import com.example.control.HapticFeedbackHelper
import com.example.control.NotificationInbox
import com.example.control.PendingNotificationReply
import com.example.control.VisionHelper
import com.example.data.AiProvider
import com.example.data.ApiQuotaTracker
import com.example.data.ApiTelemetrySnapshot
import com.example.data.AppDatabase
import com.example.data.ChatMessageEntity
import com.example.data.LocationReminder
import com.example.data.MemoryFact
import com.example.data.OmegaPreferences
import com.example.data.OmegaSettings
import com.example.data.VoiceRoutine
import com.example.omega.OmegaWakeService
import com.example.omega.SmartTriggerBus
import com.example.omega.SmartTriggerManager
import com.example.omega.TimeAutomationScheduler
import com.example.security.CrashRecoveryHandler
import com.example.voice.BluetoothAudioRouter
import com.example.voice.TeluguTtsController
import com.example.voice.VoiceInputController
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

enum class OmegaScreen { HOME, LISTENING, CHAT, ROUTINES, SETTINGS }

data class PanduUiState(
    val currentScreen: OmegaScreen = OmegaScreen.HOME,
    val settings: OmegaSettings = OmegaSettings(),
    val messages: List<ChatMessageEntity> = emptyList(),
    val memories: List<MemoryFact> = emptyList(),
    val routines: List<VoiceRoutine> = emptyList(),
    val locationReminders: List<LocationReminder> = emptyList(),
    val pendingNotifReply: PendingNotificationReply? = null,
    val unreadNotifCount: Int = 0,
    val lastTriggerBanner: String? = null,
    val isListening: Boolean = false,
    val isThinking: Boolean = false,
    val isSpeaking: Boolean = false,
    val liveDuplexState: LiveDuplexState = LiveDuplexState(),
    val liveToolStatus: String? = null,
    val liveTranscript: String = "",
    val voiceDiagNote: String = "Voice Ready",
    val ttsStatusNote: String = "TTS Ready",
    val lastAiReply: String = "",
    val lastLatencyMs: Long = 0L,
    val batteryPercent: Int = 100,
    val audioAmplitude: Float = 0f,
    val voiceError: String? = null,
    val isTestingConnection: Boolean = false,
    val diagnosticResult: ConnectionDiagnosticResult? = null,
    val isDiscoveringModels: Boolean = false,
    val discoveredChatModels: List<String> = emptyList(),
    val discoveredLiveModels: List<String> = emptyList(),
    val discoveryStatus: String? = null,
    val apiTelemetry: ApiTelemetrySnapshot = ApiTelemetrySnapshot(),
    val crashLogText: String = "",
    val backupStatusText: String? = null,
    val pendingWidgetCameraLaunch: Boolean = false
)

class PanduViewModel(application: Application) : AndroidViewModel(application) {

    private val appContext = application.applicationContext
    private val preferences = OmegaPreferences(appContext)
    private val database = AppDatabase(appContext)
    private val actionExecutor = DeviceActionExecutor(appContext, database, preferences)
    private val haptics = HapticFeedbackHelper(appContext)
    private val smartTriggers = SmartTriggerManager(appContext)
    private val btRouter = BluetoothAudioRouter(appContext)

    private val aiRepository = PanduAiRepository(
        settingsProvider = { preferences.settings.value },
        actionExecutor = actionExecutor,
        database = database
    )

    private val liveDuplex = GeminiLiveDuplexEngine(
        context = appContext,
        apiKeyProvider = { preferences.settings.value.effectiveGeminiKey() },
        liveModelProvider = { preferences.settings.value.geminiLiveVoiceModel },
        bluetoothRoutingEnabledProvider = { preferences.settings.value.bluetoothVoiceRouting }
    )

    private val ttsController = TeluguTtsController(appContext)
    private var activeJob: Job? = null

    private val _uiState = MutableStateFlow(
        PanduUiState(
            settings = preferences.settings.value,
            batteryPercent = actionExecutor.getBatteryPercent(),
            crashLogText = CrashRecoveryHandler.readLogs(appContext)
        )
    )
    val uiState: StateFlow<PanduUiState> = _uiState.asStateFlow()

    private val voiceInput = VoiceInputController(appContext) { finalTranscript ->
        dispatchToAi(finalTranscript, isVoiceInput = true)
    }

    init {
        aiRepository.seedHistoryFromDatabase()
        smartTriggers.register()
        refreshDbState()
        AgentHudBus.setFloatingOrbVisible(preferences.settings.value.floatingOrbEnabled)

        ttsController.setOnSpeechFinished {
            if (_uiState.value.settings.continuousConversation &&
                _uiState.value.currentScreen == OmegaScreen.LISTENING &&
                !_uiState.value.settings.useGeminiLiveAudio &&
                !_uiState.value.settings.micPrivacyMuted
            ) {
                viewModelScope.launch {
                    delay(380L)
                    if (_uiState.value.currentScreen == OmegaScreen.LISTENING && !_uiState.value.isThinking) {
                        voiceInput.startListening(_uiState.value.settings.languageTag)
                    }
                }
            }
        }

        if (_uiState.value.messages.isEmpty()) {
            database.insertMessage(
                ChatMessageEntity(
                    text = "OMEGA 19 Ultra online! Voice, Hey Jarvis wake-word, Volumetric 3D HUD Orb & 2-slot encrypted AI ready.",
                    isFromUser = false
                )
            )
            refreshDbState()
        }

        viewModelScope.launch {
            preferences.settings.collect { s ->
                ttsController.configure(s.languageTag, s.ttsSpeed, s.ttsPitch, s.ttsStyle)
                AgentHudBus.setFloatingOrbVisible(s.floatingOrbEnabled)
                _uiState.update { it.copy(settings = s) }
            }
        }
        viewModelScope.launch { NotificationInbox.items.collect { list -> _uiState.update { it.copy(unreadNotifCount = list.size) } } }
        viewModelScope.launch { NotificationInbox.pendingReply.collect { p -> _uiState.update { it.copy(pendingNotifReply = p) } } }
        viewModelScope.launch { ApiQuotaTracker.snapshot.collect { snap -> _uiState.update { it.copy(apiTelemetry = snap) } } }
        viewModelScope.launch { ttsController.ttsStatus.collect { st -> _uiState.update { it.copy(ttsStatusNote = st) } } }
        viewModelScope.launch {
            SmartTriggerBus.events.collect { ev ->
                _uiState.update { it.copy(lastTriggerBanner = "${ev.title}: ${ev.announcement}") }
                if (_uiState.value.settings.autoSpeak) ttsController.speak(ev.announcement)
            }
        }
        viewModelScope.launch {
            voiceInput.state.collect { v ->
                _uiState.update { cur ->
                    cur.copy(
                        isListening = v.isListening,
                        liveTranscript = if (v.partialTranscript.isNotBlank()) v.partialTranscript else cur.liveTranscript,
                        audioAmplitude = v.audioAmplitude,
                        voiceError = v.errorMessage,
                        voiceDiagNote = v.diagnosticsNote
                    )
                }
                if (v.isListening) {
                    AgentHudBus.updateState(AgentHudState.Active(v.partialTranscript.ifBlank { "Listening..." }, audioAmplitude = v.audioAmplitude))
                } else if (!_uiState.value.isThinking && !_uiState.value.liveDuplexState.isConnected) {
                    AgentHudBus.updateState(AgentHudState.Hidden)
                }
            }
        }
        viewModelScope.launch {
            liveDuplex.state.collect { ls ->
                _uiState.update { it.copy(liveDuplexState = ls) }
                if (ls.isConnected) AgentHudBus.updateState(AgentHudState.Active(ls.statusText, audioAmplitude = ls.amplitude))
            }
        }
        viewModelScope.launch { ttsController.isSpeaking.collect { sp -> _uiState.update { it.copy(isSpeaking = sp) } } }
        viewModelScope.launch { AgentHudBus.abortSignal.collect { stopAllActivity() } }
        viewModelScope.launch {
            AgentHudBus.wakeTriggers.collect { cmd ->
                if (cmd.isNotBlank()) handleInlineWakeCommand(cmd) else startVoiceListening()
            }
        }
    }

    private fun refreshDbState() {
        _uiState.update {
            it.copy(
                messages = database.getRecentMessages(80),
                memories = database.getAllMemories(),
                routines = database.getAllRoutines(),
                locationReminders = database.getLocationReminders(),
                batteryPercent = actionExecutor.getBatteryPercent()
            )
        }
    }

    fun testSpeakerVoice() {
        haptics.softTap()
        val name = _uiState.value.settings.userName
        ttsController.speak("Hello $name! OMEGA 19 Ultra voice system is online and loud and clear.")
    }

    fun unmuteMicAndListen() {
        preferences.update { it.copy(micPrivacyMuted = false) }
        startVoiceListening()
    }

    fun confirmPendingNotifReply() {
        val pending = _uiState.value.pendingNotifReply ?: return
        val result = NotificationInbox.sendDirectReply(appContext, pending.senderOrApp, pending.replyText)
        database.insertMessage(ChatMessageEntity(text = result, isFromUser = false, executedTools = listOf("reply_notification")))
        refreshDbState()
    }

    fun cancelPendingNotifReply() = NotificationInbox.clearPendingReply()
    fun dismissTriggerBanner() = _uiState.update { it.copy(lastTriggerBanner = null) }
    fun testSmartTrigger(type: String) { haptics.softTap(); smartTriggers.triggerManualTest(type) }
    fun requestCameraLaunchFromWidget() = _uiState.update { it.copy(pendingWidgetCameraLaunch = true) }
    fun consumeWidgetCameraLaunch() = _uiState.update { it.copy(pendingWidgetCameraLaunch = false) }

    fun navigateTo(screen: OmegaScreen) {
        haptics.softTap()
        if (screen != OmegaScreen.LISTENING) {
            voiceInput.stopListening()
            btRouter.clearRouting()
            if (_uiState.value.liveDuplexState.isConnected || _uiState.value.liveDuplexState.isConnecting) liveDuplex.disconnect()
        }
        _uiState.update {
            it.copy(
                currentScreen = screen,
                voiceError = null,
                batteryPercent = actionExecutor.getBatteryPercent(),
                crashLogText = if (screen == OmegaScreen.SETTINGS) CrashRecoveryHandler.readLogs(appContext) else it.crashLogText
            )
        }
    }

    fun updateSettings(transform: (OmegaSettings) -> OmegaSettings) = preferences.update(transform)

    fun setWakeWordEnabled(enabled: Boolean) {
        preferences.update { it.copy(wakeWordEnabled = enabled, micPrivacyMuted = if (enabled) false else it.micPrivacyMuted) }
        if (enabled) OmegaWakeService.start(appContext) else OmegaWakeService.stop(appContext)
    }

    fun runConnectionTest(provider: AiProvider) {
        viewModelScope.launch {
            _uiState.update { it.copy(isTestingConnection = true, diagnosticResult = null) }
            val result = aiRepository.runConnectionDiagnostic(provider)
            _uiState.update { it.copy(isTestingConnection = false, diagnosticResult = result) }
        }
    }

    fun discoverRealModels() {
        viewModelScope.launch {
            _uiState.update { it.copy(isDiscoveringModels = true, discoveryStatus = "Querying live API models...") }
            val res = aiRepository.discoverModelsForActiveProvider()
            res.onSuccess { found ->
                _uiState.update {
                    it.copy(isDiscoveringModels = false, discoveredChatModels = found.chatModels, discoveredLiveModels = found.liveVoiceModels, discoveryStatus = found.message)
                }
            }.onFailure { err ->
                _uiState.update { it.copy(isDiscoveringModels = false, discoveryStatus = "Discovery failed: ${err.message}") }
            }
        }
    }

    fun exportEncryptedBackup(): String {
        val blob = preferences.exportEncryptedBackupJson()
        _uiState.update { it.copy(backupStatusText = "Encrypted backup copied (${blob.length} chars).") }
        return blob
    }

    fun importEncryptedBackup(blob: String) {
        val ok = preferences.importEncryptedBackupJson(blob)
        _uiState.update { it.copy(backupStatusText = if (ok) "Settings restored!" else "Invalid backup payload.") }
    }

    fun clearCrashLogs() {
        CrashRecoveryHandler.clearLogs(appContext)
        _uiState.update { it.copy(crashLogText = CrashRecoveryHandler.readLogs(appContext)) }
    }

    fun scheduleDailyRoutine(routineName: String, hour24: Int, minute: Int) {
        val msg = TimeAutomationScheduler.scheduleDailyRoutine(appContext, routineName, hour24, minute)
        _uiState.update { it.copy(lastTriggerBanner = msg) }
    }

    fun runDailyBriefing() {
        val cal = actionExecutor.readCalendarSummary(1)
        val notifs = NotificationInbox.formatForAgent(5)
        val prompt = "Give me a crisp Daily Briefing using battery (${actionExecutor.getBatteryPercent()}%), calendar:\n$cal\nand notifications:\n$notifs"
        sendTextPrompt(prompt, openChat = true)
    }

    fun summarizeConversation() {
        sendTextPrompt("Summarize our recent conversation in 3 short bullet points and save key facts to memory.", openChat = false)
    }

    fun startVoiceListening() {
        val s = _uiState.value.settings
        if (s.micPrivacyMuted) {
            _uiState.update { it.copy(currentScreen = OmegaScreen.LISTENING, voiceError = "Microphone Privacy Mute is ON. Tap 'Unmute Mic' below.") }
            return
        }
        haptics.wakePulse()
        ttsController.stop()
        btRouter.routeToBluetoothIfAvailable(s.bluetoothVoiceRouting)
        _uiState.update { it.copy(currentScreen = OmegaScreen.LISTENING, liveTranscript = "", liveToolStatus = null, voiceError = null) }

        // Smart fallback: Live WebSocket requires a Gemini key; otherwise automatically use Agent Voice!
        val canUseLiveWs = s.useGeminiLiveAudio && s.effectiveGeminiKey().isNotBlank() && s.activeProvider == AiProvider.GEMINI
        if (canUseLiveWs) {
            liveDuplex.connect()
        } else {
            if (s.useGeminiLiveAudio) {
                preferences.update { it.copy(useGeminiLiveAudio = false) }
            }
            voiceInput.startListening(s.languageTag)
        }
    }

    fun stopVoiceListening() {
        haptics.softTap()
        btRouter.clearRouting()
        if (_uiState.value.settings.useGeminiLiveAudio) liveDuplex.disconnect() else voiceInput.stopListening()
    }

    fun toggleLiveDuplexMode() {
        val next = !_uiState.value.settings.useGeminiLiveAudio
        stopAllActivity()
        preferences.update { it.copy(useGeminiLiveAudio = next) }
    }

    fun toggleAutoSpeak() {
        val next = !_uiState.value.settings.autoSpeak
        if (!next) ttsController.stop()
        preferences.update { it.copy(autoSpeak = next) }
    }

    fun cycleVoiceLanguage() {
        val next = when (_uiState.value.settings.languageTag) {
            "auto" -> "te-IN"
            "te-IN" -> "en-IN"
            else -> "auto"
        }
        preferences.update { it.copy(languageTag = next) }
    }

    fun handleInlineWakeCommand(command: String) {
        haptics.wakePulse()
        ttsController.stop()
        _uiState.update { it.copy(currentScreen = OmegaScreen.LISTENING, liveTranscript = command, voiceError = null) }
        dispatchToAi(command, isVoiceInput = true)
    }

    fun analyzeCameraBitmap(bitmap: Bitmap, prompt: String = "Describe what you see and extract any useful text.") {
        val b64 = VisionHelper.bitmapToBase64Jpeg(bitmap)
        _uiState.update { it.copy(currentScreen = OmegaScreen.CHAT) }
        dispatchToAi(prompt, isVoiceInput = false, imageBase64 = b64)
    }

    fun sendTextPrompt(prompt: String, openChat: Boolean = true) {
        val trimmed = prompt.trim()
        if (trimmed.isEmpty()) return
        haptics.softTap()
        ttsController.stop()
        if (openChat) _uiState.update { it.copy(currentScreen = OmegaScreen.CHAT) }
        dispatchToAi(trimmed, isVoiceInput = false)
    }

    fun runRoutineByName(name: String) { database.findRoutineByNameOrTrigger(name)?.let { runRoutineNow(it) } }

    fun runRoutineNow(routine: VoiceRoutine) {
        haptics.wakePulse()
        viewModelScope.launch {
            _uiState.update { it.copy(isThinking = true, liveToolStatus = "Running ${routine.name}...") }
            val summary = actionExecutor.executeRoutineByName(routine.name) { st -> _uiState.update { it.copy(liveToolStatus = st) } }
            database.insertMessage(ChatMessageEntity(text = summary, isFromUser = false, executedTools = listOf("routine:${routine.name}")))
            refreshDbState()
            _uiState.update { it.copy(isThinking = false, liveToolStatus = null, lastAiReply = summary) }
            AgentHudBus.updateState(AgentHudState.Hidden)
            if (_uiState.value.settings.autoSpeak) ttsController.speak(summary)
        }
    }

    fun saveCustomRoutine(name: String, trigger: String, summary: String, stepsJson: String) {
        if (name.isBlank() || trigger.isBlank()) return
        database.saveRoutine(VoiceRoutine(name = name, triggerPhrase = trigger, actionsSummary = summary, stepsJson = stepsJson))
        refreshDbState()
    }

    fun deleteRoutine(id: Long) { database.deleteRoutine(id); refreshDbState() }
    fun deleteMemory(key: String) { database.deleteMemory(key); refreshDbState() }
    fun speakMessage(text: String) { ttsController.speak(text) }

    fun clearChatHistory() {
        aiRepository.clearHistory()
        database.clearMessages()
        database.insertMessage(ChatMessageEntity(text = "Chat cleared. Encrypted personal memories remain safe.", isFromUser = false))
        refreshDbState()
        _uiState.update { it.copy(lastAiReply = "") }
    }

    fun stopAllActivity() {
        haptics.abortPulse()
        voiceInput.stopListening()
        btRouter.clearRouting()
        liveDuplex.disconnect()
        ttsController.stop()
        activeJob?.cancel(); activeJob = null
        _uiState.update { it.copy(isThinking = false, isListening = false, liveToolStatus = null, audioAmplitude = 0f) }
        AgentHudBus.updateState(AgentHudState.Hidden)
    }

    private fun dispatchToAi(prompt: String, isVoiceInput: Boolean, imageBase64: String? = null) {
        val dur = String.format("0:%02d", (prompt.split(" ").size / 2).coerceIn(2, 59))
        database.insertMessage(
            ChatMessageEntity(text = prompt, isFromUser = true, isVoiceInput = isVoiceInput, audioDuration = dur, hasImageAttachment = imageBase64 != null)
        )
        refreshDbState()
        _uiState.update { it.copy(isThinking = true, liveToolStatus = null, voiceError = null) }
        AgentHudBus.updateState(AgentHudState.Active(if (imageBase64 != null) "Analyzing vision..." else "OMEGA thinking...", isThinking = true, audioAmplitude = 0.45f))

        activeJob?.cancel()
        activeJob = viewModelScope.launch {
            val res = aiRepository.sendMessage(prompt, imageBase64) { status -> _uiState.update { it.copy(liveToolStatus = status) } }
            res.onSuccess { reply ->
                database.insertMessage(ChatMessageEntity(text = reply.replyText, isFromUser = false, executedTools = reply.executedTools))
                refreshDbState()
                _uiState.update { it.copy(isThinking = false, liveToolStatus = null, lastAiReply = reply.replyText, lastLatencyMs = reply.latencyMs) }
                // FIX: Speak reply across ALL screens whenever autoSpeak is ON!
                if (_uiState.value.settings.autoSpeak) {
                    ttsController.speak(reply.replyText)
                }
            }.onFailure { err ->
                val msg = err.message ?: "Request failed."
                database.insertMessage(ChatMessageEntity(text = msg, isFromUser = false, isError = true))
                refreshDbState()
                _uiState.update { it.copy(isThinking = false, liveToolStatus = null, voiceError = msg) }
            }
            AgentHudBus.updateState(AgentHudState.Hidden)
        }
    }

    override fun onCleared() {
        smartTriggers.unregister()
        voiceInput.release(); btRouter.clearRouting(); liveDuplex.release(); ttsController.release(); database.close()
        super.onCleared()
    }
}
