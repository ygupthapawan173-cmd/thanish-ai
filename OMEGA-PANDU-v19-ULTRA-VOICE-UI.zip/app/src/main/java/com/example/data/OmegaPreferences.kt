package com.example.data

import android.content.Context
import com.example.BuildConfig
import com.example.security.KeystoreCryptoManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONObject

/**
 * Strictly 2 AI Providers: Google Gemini and OpenRouter.
 */
enum class AiProvider(val displayName: String, val defaultChatModel: String) {
    GEMINI("Google Gemini", "gemini-3.8-flash"),
    OPENROUTER("OpenRouter", "google/gemini-2.5-flash")
}

enum class OmegaVisualTheme(val label: String) {
    AURORA_OBSIDIAN("Obsidian"),
    MIDNIGHT_ROYAL("Royal Glass"),
    CYBER_HORIZON_WEBGL("Cyber WebGL")
}

enum class OrbColorPreset(val label: String, val primaryHex: Long, val secondaryHex: Long, val accentHex: Long) {
    AURORA_CYAN("Aurora", 0xFF00E5FF, 0xFF6366F1, 0xFFFF4D94),
    ROYAL_EMERALD("Emerald", 0xFF10B981, 0xFF06B6D4, 0xFF3B82F6),
    SOLAR_GOLD("Solar", 0xFFF59E0B, 0xFFEC4899, 0xFF8B5CF6),
    CRIMSON_NOVA("Crimson", 0xFFF43F5E, 0xFFFB7185, 0xFF6366F1),
    NEBULA_VIOLET("Nebula", 0xFF38BDF8, 0xFFA855F7, 0xFFF472B6),
    ARCTIC_ICE("Arctic", 0xFF67E8F9, 0xFF3B82F6, 0xFFE0F2FE)
}

enum class TtsEmotionStyle(val label: String, val speedMul: Float, val pitchMul: Float) {
    NATURAL("Natural", 1.0f, 1.0f),
    WARM("Warm", 0.94f, 0.96f),
    CRISP("Crisp Pro", 1.08f, 1.04f),
    CALM("Calm", 0.88f, 0.92f)
}

data class OmegaSettings(
    val userName: String = "Pandu",
    val activeProvider: AiProvider = AiProvider.GEMINI,
    val geminiApiKey: String = "",
    val openRouterApiKey: String = "",
    val geminiChatModel: String = "gemini-3.8-flash",
    val geminiLiveVoiceModel: String = "gemini-2.5-flash-native-audio-preview",
    val openRouterModel: String = "google/gemini-2.5-flash",
    val wakeWord: String = "hey jarvis",
    val wakeSensitivity: Float = 0.70f,
    val languageTag: String = "auto",
    val autoSpeak: Boolean = true,
    val continuousConversation: Boolean = false,
    val ttsSpeed: Float = 1.0f,
    val ttsPitch: Float = 1.0f,
    val ttsStyle: TtsEmotionStyle = TtsEmotionStyle.NATURAL,
    val wakeWordEnabled: Boolean = false,
    val bluetoothVoiceRouting: Boolean = true,
    val micPrivacyMuted: Boolean = false,
    val floatingOrbEnabled: Boolean = true,
    val useGeminiLiveAudio: Boolean = false,
    val webSearchGrounding: Boolean = true,
    val biometricSafetyLock: Boolean = false,
    val confirmNotifReply: Boolean = true,
    val gyroscopeParallax: Boolean = true,
    val offlineFastCommands: Boolean = true,
    val triggerBluetoothBriefing: Boolean = true,
    val triggerChargingAlert: Boolean = true,
    val triggerLowBatterySaver: Boolean = true,
    val visualTheme: OmegaVisualTheme = OmegaVisualTheme.AURORA_OBSIDIAN,
    val orbColorPreset: OrbColorPreset = OrbColorPreset.AURORA_CYAN
) {
    fun effectiveGeminiKey(): String = geminiApiKey.trim().ifEmpty { BuildConfig.GEMINI_API_KEY.trim() }
    fun effectiveOpenRouterKey(): String = openRouterApiKey.trim().ifEmpty { BuildConfig.OPENROUTER_API_KEY.trim() }

    fun activeChatModel(): String = when (activeProvider) {
        AiProvider.GEMINI -> geminiChatModel.trim().ifEmpty { AiProvider.GEMINI.defaultChatModel }
        AiProvider.OPENROUTER -> openRouterModel.trim().ifEmpty { AiProvider.OPENROUTER.defaultChatModel }
    }

    fun rmsGateThreshold(): Double {
        // Tuned for real far-field "Hey Jarvis" voice detection (320..1150)
        return 1150.0 - (wakeSensitivity.coerceIn(0.1f, 1.0f) * 830.0)
    }
}

class OmegaPreferences(context: Context) {

    private val prefs = context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    private val _settings = MutableStateFlow(load())
    val settings: StateFlow<OmegaSettings> = _settings.asStateFlow()

    private fun load(): OmegaSettings {
        val provider = runCatching {
            AiProvider.valueOf(prefs.getString(KEY_PROVIDER, AiProvider.GEMINI.name) ?: "")
        }.getOrDefault(AiProvider.GEMINI)

        val theme = runCatching {
            OmegaVisualTheme.valueOf(prefs.getString(KEY_THEME, OmegaVisualTheme.AURORA_OBSIDIAN.name) ?: "")
        }.getOrDefault(OmegaVisualTheme.AURORA_OBSIDIAN)

        val orbColor = runCatching {
            OrbColorPreset.valueOf(prefs.getString(KEY_ORB_COLOR, OrbColorPreset.AURORA_CYAN.name) ?: "")
        }.getOrDefault(OrbColorPreset.AURORA_CYAN)

        val ttsStyle = runCatching {
            TtsEmotionStyle.valueOf(prefs.getString(KEY_TTS_STYLE, TtsEmotionStyle.NATURAL.name) ?: "")
        }.getOrDefault(TtsEmotionStyle.NATURAL)

        return OmegaSettings(
            userName = prefs.getString(KEY_USER_NAME, "Pandu") ?: "Pandu",
            activeProvider = provider,
            geminiApiKey = KeystoreCryptoManager.decrypt(prefs.getString(KEY_GEMINI_KEY, "") ?: ""),
            openRouterApiKey = KeystoreCryptoManager.decrypt(prefs.getString(KEY_OPENROUTER_KEY, "") ?: ""),
            geminiChatModel = prefs.getString(KEY_GEMINI_CHAT_MODEL, "gemini-3.8-flash") ?: "gemini-3.8-flash",
            geminiLiveVoiceModel = prefs.getString(KEY_GEMINI_LIVE_MODEL, "gemini-2.5-flash-native-audio-preview")
                ?: "gemini-2.5-flash-native-audio-preview",
            openRouterModel = prefs.getString(KEY_OPENROUTER_MODEL, "google/gemini-2.5-flash")
                ?: "google/gemini-2.5-flash",
            wakeWord = prefs.getString(KEY_WAKE_WORD, "hey jarvis") ?: "hey jarvis",
            wakeSensitivity = prefs.getFloat(KEY_WAKE_SENS, 0.70f),
            languageTag = prefs.getString(KEY_LANGUAGE, "auto") ?: "auto",
            autoSpeak = prefs.getBoolean(KEY_AUTO_SPEAK, true),
            continuousConversation = prefs.getBoolean(KEY_CONTINUOUS, false),
            ttsSpeed = prefs.getFloat(KEY_TTS_SPEED, 1.0f),
            ttsPitch = prefs.getFloat(KEY_TTS_PITCH, 1.0f),
            ttsStyle = ttsStyle,
            wakeWordEnabled = prefs.getBoolean(KEY_WAKE_ENABLED, false),
            bluetoothVoiceRouting = prefs.getBoolean(KEY_BT_ROUTING, true),
            micPrivacyMuted = prefs.getBoolean(KEY_MIC_MUTED, false),
            floatingOrbEnabled = prefs.getBoolean(KEY_FLOATING_ORB, true),
            useGeminiLiveAudio = prefs.getBoolean(KEY_LIVE_AUDIO, false),
            webSearchGrounding = prefs.getBoolean(KEY_WEB_GROUNDING, true),
            biometricSafetyLock = prefs.getBoolean(KEY_BIOMETRIC_LOCK, false),
            confirmNotifReply = prefs.getBoolean(KEY_CONFIRM_REPLY, true),
            gyroscopeParallax = prefs.getBoolean(KEY_PARALLAX, true),
            offlineFastCommands = prefs.getBoolean(KEY_OFFLINE_FAST, true),
            triggerBluetoothBriefing = prefs.getBoolean(KEY_TRIG_BT, true),
            triggerChargingAlert = prefs.getBoolean(KEY_TRIG_CHARGE, true),
            triggerLowBatterySaver = prefs.getBoolean(KEY_TRIG_LOWBAT, true),
            visualTheme = theme,
            orbColorPreset = orbColor
        )
    }

    fun update(transform: (OmegaSettings) -> OmegaSettings) {
        val u = transform(_settings.value)
        _settings.value = u
        prefs.edit()
            .putString(KEY_USER_NAME, u.userName.trim().ifEmpty { "Pandu" })
            .putString(KEY_PROVIDER, u.activeProvider.name)
            .putString(KEY_GEMINI_KEY, KeystoreCryptoManager.encrypt(u.geminiApiKey.trim()))
            .putString(KEY_OPENROUTER_KEY, KeystoreCryptoManager.encrypt(u.openRouterApiKey.trim()))
            .putString(KEY_GEMINI_CHAT_MODEL, u.geminiChatModel.trim().ifEmpty { "gemini-3.8-flash" })
            .putString(KEY_GEMINI_LIVE_MODEL, u.geminiLiveVoiceModel.trim().ifEmpty { "gemini-2.5-flash-native-audio-preview" })
            .putString(KEY_OPENROUTER_MODEL, u.openRouterModel.trim().ifEmpty { "google/gemini-2.5-flash" })
            .putString(KEY_WAKE_WORD, u.wakeWord.trim().lowercase().ifEmpty { "hey jarvis" })
            .putFloat(KEY_WAKE_SENS, u.wakeSensitivity.coerceIn(0.1f, 1.0f))
            .putString(KEY_LANGUAGE, u.languageTag)
            .putBoolean(KEY_AUTO_SPEAK, u.autoSpeak)
            .putBoolean(KEY_CONTINUOUS, u.continuousConversation)
            .putFloat(KEY_TTS_SPEED, u.ttsSpeed.coerceIn(0.6f, 1.6f))
            .putFloat(KEY_TTS_PITCH, u.ttsPitch.coerceIn(0.6f, 1.5f))
            .putString(KEY_TTS_STYLE, u.ttsStyle.name)
            .putBoolean(KEY_WAKE_ENABLED, u.wakeWordEnabled)
            .putBoolean(KEY_BT_ROUTING, u.bluetoothVoiceRouting)
            .putBoolean(KEY_MIC_MUTED, u.micPrivacyMuted)
            .putBoolean(KEY_FLOATING_ORB, u.floatingOrbEnabled)
            .putBoolean(KEY_LIVE_AUDIO, u.useGeminiLiveAudio)
            .putBoolean(KEY_WEB_GROUNDING, u.webSearchGrounding)
            .putBoolean(KEY_BIOMETRIC_LOCK, u.biometricSafetyLock)
            .putBoolean(KEY_CONFIRM_REPLY, u.confirmNotifReply)
            .putBoolean(KEY_PARALLAX, u.gyroscopeParallax)
            .putBoolean(KEY_OFFLINE_FAST, u.offlineFastCommands)
            .putBoolean(KEY_TRIG_BT, u.triggerBluetoothBriefing)
            .putBoolean(KEY_TRIG_CHARGE, u.triggerChargingAlert)
            .putBoolean(KEY_TRIG_LOWBAT, u.triggerLowBatterySaver)
            .putString(KEY_THEME, u.visualTheme.name)
            .putString(KEY_ORB_COLOR, u.orbColorPreset.name)
            .apply()
    }

    fun exportEncryptedBackupJson(): String {
        val s = _settings.value
        val obj = JSONObject().apply {
            put("userName", s.userName)
            put("activeProvider", s.activeProvider.name)
            put("geminiChatModel", s.geminiChatModel)
            put("geminiLiveVoiceModel", s.geminiLiveVoiceModel)
            put("openRouterModel", s.openRouterModel)
            put("wakeWord", s.wakeWord)
            put("languageTag", s.languageTag)
            put("visualTheme", s.visualTheme.name)
            put("orbColorPreset", s.orbColorPreset.name)
        }
        return KeystoreCryptoManager.encrypt(obj.toString())
    }

    fun importEncryptedBackupJson(encryptedBlob: String): Boolean {
        val plain = KeystoreCryptoManager.decrypt(encryptedBlob.trim())
        if (plain.isBlank()) return false
        return runCatching {
            val obj = JSONObject(plain)
            update { cur ->
                cur.copy(
                    userName = obj.optString("userName", cur.userName),
                    geminiChatModel = obj.optString("geminiChatModel", cur.geminiChatModel),
                    geminiLiveVoiceModel = obj.optString("geminiLiveVoiceModel", cur.geminiLiveVoiceModel),
                    openRouterModel = obj.optString("openRouterModel", cur.openRouterModel),
                    wakeWord = obj.optString("wakeWord", cur.wakeWord),
                    languageTag = obj.optString("languageTag", cur.languageTag)
                )
            }
            true
        }.getOrDefault(false)
    }

    companion object {
        private const val PREFS_NAME = "omega_pandu_v19_ultra_prefs"
        private const val KEY_USER_NAME = "user_name"
        private const val KEY_PROVIDER = "active_provider"
        private const val KEY_GEMINI_KEY = "enc_gemini_key"
        private const val KEY_OPENROUTER_KEY = "enc_openrouter_key"
        private const val KEY_GEMINI_CHAT_MODEL = "gemini_chat_model"
        private const val KEY_GEMINI_LIVE_MODEL = "gemini_live_model"
        private const val KEY_OPENROUTER_MODEL = "openrouter_model"
        private const val KEY_WAKE_WORD = "wake_word"
        private const val KEY_WAKE_SENS = "wake_sens"
        private const val KEY_LANGUAGE = "language_tag"
        private const val KEY_AUTO_SPEAK = "auto_speak"
        private const val KEY_CONTINUOUS = "continuous_conv"
        private const val KEY_TTS_SPEED = "tts_speed"
        private const val KEY_TTS_PITCH = "tts_pitch"
        private const val KEY_TTS_STYLE = "tts_style"
        private const val KEY_WAKE_ENABLED = "wake_word_enabled"
        private const val KEY_BT_ROUTING = "bt_routing"
        private const val KEY_MIC_MUTED = "mic_muted"
        private const val KEY_FLOATING_ORB = "floating_orb_enabled"
        private const val KEY_LIVE_AUDIO = "use_live_audio"
        private const val KEY_WEB_GROUNDING = "web_grounding"
        private const val KEY_BIOMETRIC_LOCK = "biometric_lock"
        private const val KEY_CONFIRM_REPLY = "confirm_notif_reply"
        private const val KEY_PARALLAX = "gyro_parallax"
        private const val KEY_OFFLINE_FAST = "offline_fast_cmd"
        private const val KEY_TRIG_BT = "trig_bt"
        private const val KEY_TRIG_CHARGE = "trig_charge"
        private const val KEY_TRIG_LOWBAT = "trig_lowbat"
        private const val KEY_THEME = "visual_theme"
        private const val KEY_ORB_COLOR = "orb_color"
    }
}
