package com.example.voice

import android.content.Context
import android.media.AudioAttributes
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import com.example.data.TtsEmotionStyle
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale
import java.util.UUID

class TeluguTtsController(context: Context) {

    private var tts: TextToSpeech? = null
    private var isReady = false
    private var onSpeechFinishedCallback: (() -> Unit)? = null

    private val _isSpeaking = MutableStateFlow(false)
    val isSpeaking: StateFlow<Boolean> = _isSpeaking.asStateFlow()

    private val _ttsStatus = MutableStateFlow("Initializing TTS...")
    val ttsStatus: StateFlow<String> = _ttsStatus.asStateFlow()

    init {
        tts = TextToSpeech(context.applicationContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                isReady = true
                tts?.setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ASSISTANT)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build()
                )
                tts?.language = Locale.forLanguageTag("en-IN")
                _ttsStatus.value = "Speaker TTS Ready"
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) { _isSpeaking.value = true }
                    override fun onDone(utteranceId: String?) {
                        _isSpeaking.value = false
                        onSpeechFinishedCallback?.invoke()
                    }
                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) { _isSpeaking.value = false }
                })
            } else {
                _ttsStatus.value = "TTS Engine unavailable (check Android Text-to-Speech)"
            }
        }
    }

    fun setOnSpeechFinished(callback: (() -> Unit)?) { onSpeechFinishedCallback = callback }

    fun configure(localeTag: String, speed: Float, pitch: Float, style: TtsEmotionStyle) {
        if (!isReady) return
        val tag = if (localeTag == "auto") "en-IN" else localeTag
        val res = tts?.setLanguage(Locale.forLanguageTag(tag))
        if (res == TextToSpeech.LANG_MISSING_DATA || res == TextToSpeech.LANG_NOT_SUPPORTED) {
            tts?.language = Locale.getDefault()
        }
        tts?.setSpeechRate((speed * style.speedMul).coerceIn(0.5f, 1.8f))
        tts?.setPitch((pitch * style.pitchMul).coerceIn(0.5f, 1.6f))
    }

    fun speak(rawText: String) {
        if (!isReady || rawText.isBlank()) return
        val hasTeluguChars = rawText.any { it in 'ఀ'..'౿' }
        if (hasTeluguChars) {
            tts?.setLanguage(Locale.forLanguageTag("te-IN"))
        }
        val clean = rawText.replace("*", "").replace("#", "").replace("`", "").replace("•", ",").trim()
        tts?.speak(clean, TextToSpeech.QUEUE_FLUSH, null, UUID.randomUUID().toString())
    }

    fun stop() {
        tts?.stop()
        _isSpeaking.value = false
    }

    fun release() {
        tts?.stop(); tts?.shutdown(); tts = null
    }
}
