package com.example.voice

import android.content.Context
import com.example.control.AgentHudBus
import android.os.Handler
import android.os.Looper
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.AudioFocusRequest
import android.util.Log
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import com.example.data.TtsEmotionStyle
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale
import java.util.UUID

class TeluguTtsController(context: Context, private val backgroundOwned: Boolean = false) {

    private val appContext = context.applicationContext
    private var tts: TextToSpeech? = null
    private var isReady = false
    private var localOnly = false
    private val _voices = MutableStateFlow<List<TtsVoiceChoice>>(emptyList())
    val voices: StateFlow<List<TtsVoiceChoice>> = _voices.asStateFlow()
    fun refreshVoices() { if(isReady) tts?.let { _voices.value=VoicePackCatalog.choices(it) } }
    private var initFailed = false
    private var released = false
    var lastSpeechSucceeded = false
        private set
    private val audio = appContext.getSystemService(AudioManager::class.java)
    private var focus: AudioFocusRequest? = null
    private fun abandonFocus() { focus?.let { runCatching { audio.abandonAudioFocusRequest(it) } }; focus=null }
    private fun complete(id: String?, error: String? = null) {
        if (id == null || activeId != id) return
        val retryText=activeText
        val failedVoice=activeVoice
        activeId=null; activeText=null; activeVoice=null; lastSpeechSucceeded=error==null; _isSpeaking.value=false; abandonFocus(); AgentHudBus.setTtsBusy(this,false)
        if (error != null) { _ttsStatus.value=error; Log.w("OmegaVoice", "TTS_ERROR $error") }
        else Log.i("OmegaVoice", "TTS_DONE")
        if(error != null && error.startsWith("TTS error") && excludedVoice==null && failedVoice!=null && retryText!=null) {
            excludedVoice=failedVoice
            speakInternal(retryText)
            return
        }
        excludedVoice=null
        if (error==null || backgroundOwned) onSpeechFinishedCallback?.invoke()
    }
    private var pendingUtterance: String? = null
    private var pendingConfig: (() -> Unit)? = null
    private var activeId: String? = null
    private var activeText: String? = null
    private var activeVoice: String? = null
    private var excludedVoice: String? = null
    private val main = Handler(Looper.getMainLooper())
    private var onSpeechFinishedCallback: (() -> Unit)? = null

    private val _isSpeaking = MutableStateFlow(false)
    val isSpeaking: StateFlow<Boolean> = _isSpeaking.asStateFlow()

    private val _ttsStatus = MutableStateFlow("Initializing TTS...")
    val ttsStatus: StateFlow<String> = _ttsStatus.asStateFlow()

    init {
        tts = TextToSpeech(appContext) { status -> main.post {
            if (released) return@post
            if (status == TextToSpeech.SUCCESS) {
                isReady = true
                tts?.setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build()
                )
                val res = tts?.setLanguage(Locale.forLanguageTag("en-IN"))
                if (res == TextToSpeech.LANG_MISSING_DATA || res == TextToSpeech.LANG_NOT_SUPPORTED) {
                    tts?.language = Locale.US
                }
                _ttsStatus.value = "Speaker TTS Ready"
                refreshVoices()
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) { main.post { if (activeId == utteranceId) _isSpeaking.value = true } }
                    override fun onDone(utteranceId: String?) {
                        main.post { complete(utteranceId) }
                    }
                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) { main.post { complete(utteranceId, "TTS playback failed") } }
                    override fun onError(utteranceId: String?, errorCode: Int) { main.post { complete(utteranceId, "TTS error $errorCode") } }
                    override fun onStop(utteranceId: String?, interrupted: Boolean) { main.post { complete(utteranceId, "TTS interrupted") } }
                })
                pendingConfig?.invoke(); pendingConfig=null
                pendingUtterance?.let { queued ->
                    pendingUtterance = null
                    speak(queued)
                }
            } else {
                initFailed=true
                _ttsStatus.value = "TTS init failed (code $status). Check Android Text-to-Speech settings."
                if (pendingUtterance != null) { pendingUtterance=null; if(backgroundOwned) onSpeechFinishedCallback?.invoke() }
            }
        } }
    }

    fun setOnSpeechFinished(callback: (() -> Unit)?) { onSpeechFinishedCallback = callback }

    fun configure(localeTag: String, speed: Float, pitch: Float, style: TtsEmotionStyle, localOnly: Boolean = false) {
        this.localOnly=localOnly
        if (!isReady) { pendingConfig={ configure(localeTag,speed,pitch,style,localOnly) }; return }
        val tag = if (localeTag == "auto") "en-IN" else localeTag
        val res = tts?.setLanguage(Locale.forLanguageTag(tag))
        if (res == TextToSpeech.LANG_MISSING_DATA || res == TextToSpeech.LANG_NOT_SUPPORTED) {
            tts?.language = Locale.getDefault()
        }
        tts?.setSpeechRate((speed * style.speedMul).coerceIn(0.5f, 1.8f))
        tts?.setPitch((pitch * style.pitchMul).coerceIn(0.5f, 1.6f))
    }

    fun speak(rawText: String) {
        excludedVoice=null
        speakInternal(rawText)
    }

    private fun speakInternal(rawText: String) {
        lastSpeechSucceeded=false
        val clean = rawText.replace("*", "").replace("#", "").replace("`", "").replace("•", ",").trim()
        if (clean.isBlank() || initFailed || released) { if(backgroundOwned) onSpeechFinishedCallback?.invoke(); return }
        if (!isReady) {
            pendingUtterance = clean
            return
        }
        val hasTeluguChars = clean.any { it in '\u0C00'..'\u0C7F' }
        val language = if(hasTeluguChars) "te" else "en"
        val locked = appContext.getSystemService(android.app.KeyguardManager::class.java).isDeviceLocked
        val allowNetwork=VoicePackPolicy.allowNetworkVoice(localOnly,locked)
        val engine=tts ?: return
        val preferred=VoicePackCatalog.selected(appContext,language)
        val candidates=runCatching { engine.voices.orEmpty().filter { it.locale.language==language && it.name!=excludedVoice && !VoicePackCatalog.needsData(it) && (allowNetwork || !it.isNetworkConnectionRequired) } }.getOrDefault(emptyList())
            .sortedWith(compareByDescending<android.speech.tts.Voice> { it.name==preferred }.thenBy { it.isNetworkConnectionRequired }.thenByDescending { it.locale.country=="IN" }.thenByDescending { it.quality })
        val chosen=candidates.firstOrNull { runCatching { engine.setVoice(it)==TextToSpeech.SUCCESS }.getOrDefault(false) } ?: if(excludedVoice==null && candidates.isEmpty()) {
            runCatching {
                engine.setLanguage(Locale.forLanguageTag(if(hasTeluguChars) "te-IN" else "en-IN"))
                engine.voice?.takeIf { it.locale.language==language && !VoicePackCatalog.needsData(it) && (allowNetwork || !it.isNetworkConnectionRequired) }
            }.getOrNull()
        } else null
        if(chosen==null) {
            _ttsStatus.value="${if(hasTeluguChars) "Telugu" else "English"} voice unavailable; install voice data in Voice Packs"
            if(backgroundOwned) onSpeechFinishedCallback?.invoke()
            return
        }
        _ttsStatus.value="${chosen.locale.toLanguageTag()} • ${chosen.name} • ${if(chosen.isNetworkConnectionRequired) "Online" else "Offline"}"
        val params = Bundle().apply {
            putInt(TextToSpeech.Engine.KEY_PARAM_STREAM, AudioManager.STREAM_MUSIC)
            putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, 1.0f)
        }
        val id=UUID.randomUUID().toString(); activeId=id; activeText=clean; activeVoice=chosen.name
        AgentHudBus.setTtsBusy(this,true)
        if (!backgroundOwned) com.example.omega.OmegaWakeService.pauseForManual()
        abandonFocus()
        val request = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
            .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
            .setOnAudioFocusChangeListener({ change -> if (change == AudioManager.AUDIOFOCUS_LOSS || change == AudioManager.AUDIOFOCUS_LOSS_TRANSIENT) main.post { if (activeId==id) { tts?.stop(); complete(id,"TTS audio focus lost") } } }, main).build()
        focus=request
        if (runCatching { audio.requestAudioFocus(request) }.getOrDefault(AudioManager.AUDIOFOCUS_REQUEST_FAILED) != AudioManager.AUDIOFOCUS_REQUEST_GRANTED) { complete(id,"TTS audio focus denied"); return }
        main.postDelayed({ if(activeId==id) { Log.i("OmegaVoice", "TTS_START"); if(tts?.speak(clean, TextToSpeech.QUEUE_FLUSH, params, id)!=TextToSpeech.SUCCESS) complete(id,"TTS playback failed") } }, 150)
    }

    fun stop() {
        pendingUtterance = null
        activeId=null; activeText=null; activeVoice=null; excludedVoice=null; abandonFocus(); AgentHudBus.setTtsBusy(this,false)
        tts?.stop()
        _isSpeaking.value = false
    }

    fun release() {
        released=true; stop(); tts?.shutdown(); tts = null
    }
}
