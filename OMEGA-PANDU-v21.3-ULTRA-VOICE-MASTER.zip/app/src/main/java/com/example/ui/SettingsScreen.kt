package com.example.ui

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.example.control.BiometricSafetyGate
import com.example.control.PanduAccessibilityService
import com.example.data.AiProvider
import com.example.data.OmegaSettings
import com.example.data.OmegaVisualTheme
import com.example.data.OrbColorPreset
import com.example.data.TtsEmotionStyle
import com.example.ui.components.ParticleAiOrb
import com.example.ui.theme.OmegaColors
import com.example.ui.theme.OmegaLiquidBackdrop
import com.example.ui.theme.accentColor
import com.example.ui.theme.mutedText
import com.example.ui.theme.omegaSwitchColors
import com.example.ui.theme.omegaTextFieldColors
import com.example.ui.theme.primaryText
import java.util.Locale

/**
 * Premium Grouped List Settings UI (v21.1):
 * Pure AMOLED black, zero aura light, clean grouped list rows with icon plates & hairline dividers.
 */
@Composable
fun SettingsScreen(
    uiState: PanduUiState,
    onBack: () -> Unit,
    onSaveSettings: ((OmegaSettings) -> OmegaSettings) -> Unit,
    onRunConnectionTest: (AiProvider) -> Unit,
    onDiscoverModels: () -> Unit,
    onTestSpeaker: () -> Unit,
    onRefreshVoiceCatalog: () -> Unit,
    onVoicePreview: (String) -> Unit,
    onToggleWakeService: (Boolean) -> Unit,
    onExportBackup: () -> String,
    onImportBackup: (String) -> Unit,
    onClearCrashLogs: () -> Unit,
    onClearHistory: () -> Unit
) {
    val context = LocalContext.current
    val settings = uiState.settings
    val theme = settings.visualTheme
    val preset = settings.orbColorPreset
    val accent = theme.accentColor(preset)
    val tfColors = omegaTextFieldColors(theme, preset)

    var userNameDraft by remember(settings.userName) { mutableStateOf(settings.userName) }
    var geminiKeyDraft by remember(settings.geminiApiKey) { mutableStateOf(settings.geminiApiKey) }
    var openRouterKeyDraft by remember(settings.openRouterApiKey) { mutableStateOf(settings.openRouterApiKey) }
    var geminiChatModelDraft by remember(settings.geminiChatModel) { mutableStateOf(settings.geminiChatModel) }
    var geminiLiveModelDraft by remember(settings.geminiLiveVoiceModel) { mutableStateOf(settings.geminiLiveVoiceModel) }
    var openRouterModelDraft by remember(settings.openRouterModel) { mutableStateOf(settings.openRouterModel) }
    var wakeWordDraft by remember(settings.wakeWord) { mutableStateOf(settings.wakeWord) }
    var showGeminiKey by remember { mutableStateOf(false) }
    var showOrKey by remember { mutableStateOf(false) }
    var savedBanner by remember { mutableStateOf(false) }
    var showCrashLogs by remember { mutableStateOf(false) }

    var pendingWakePermission by remember { mutableStateOf(false) }
    var permissionRefresh by remember { mutableStateOf(0) }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { grants ->
        permissionRefresh++
        if (pendingWakePermission) {
            pendingWakePermission = false
            onToggleWakeService(grants[Manifest.permission.RECORD_AUDIO] == true)
        }
    }

    val hasMic = remember(permissionRefresh, settings.wakeWordEnabled) { ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED }
    val hasContacts = ContextCompat.checkSelfPermission(context, Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED
    val hasCamera = ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
    val hasCalendar = ContextCompat.checkSelfPermission(context, Manifest.permission.READ_CALENDAR) == PackageManager.PERMISSION_GRANTED
    val hasAcc = PanduAccessibilityService.instance != null
    val hasNotif = NotificationManagerCompat.getEnabledListenerPackages(context).contains(context.packageName)

    fun persistDrafts() {
        onSaveSettings {
            it.copy(
                userName = userNameDraft,
                geminiApiKey = geminiKeyDraft,
                openRouterApiKey = openRouterKeyDraft,
                geminiChatModel = geminiChatModelDraft,
                geminiLiveVoiceModel = geminiLiveModelDraft,
                openRouterModel = openRouterModelDraft,
                wakeWord = wakeWordDraft
            )
        }
        savedBanner = true
    }

    OmegaLiquidBackdrop(theme = theme, preset = preset) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
        ) {
            // Minimalist Top Header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                GlassCircleButton(Icons.AutoMirrored.Rounded.ArrowBack, size = 40.dp, theme = theme, preset = preset, onClick = {
                    onBack()
                })
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("Settings", color = theme.primaryText(), fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                    Text("OMEGA 21.2 • Pure AMOLED", color = theme.mutedText(), fontSize = 11.sp)
                }
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .background(accent)
                        .clickable { persistDrafts() }
                        .padding(horizontal = 14.dp, vertical = 8.dp)
                ) {
                    Text("Save", color = Color.Black, fontSize = 12.5.sp, fontWeight = FontWeight.Bold)
                }
            }

            if (savedBanner) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 4.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(OmegaColors.EmeraldLive.copy(alpha = 0.14f))
                        .border(1.dp, OmegaColors.EmeraldLive.copy(alpha = 0.35f), RoundedCornerShape(12.dp))
                        .padding(horizontal = 12.dp, vertical = 8.dp)
                ) {
                    Text("Settings saved locally.", color = OmegaColors.EmeraldLive, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                }
            }

            // Single-Scroll Premium Grouped Settings List
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(20.dp)
            ) {
                // ==========================================================
                // SECTION 1: AI & API KEYS
                // ==========================================================
                SettingsGroupSection(title = "AI ENGINE & API KEYS") {
                    // Provider Segmented Row
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Active Cloud Provider", color = theme.mutedText(), fontSize = 11.5.sp, fontWeight = FontWeight.Medium)
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf(AiProvider.GEMINI to "Google Gemini", AiProvider.OPENROUTER to "OpenRouter").forEach { (prov, label) ->
                                val selected = settings.activeProvider == prov
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(if (selected) accent else OmegaColors.CarbonElevated)
                                        .clickable { onSaveSettings { it.copy(activeProvider = prov) } }
                                        .padding(vertical = 10.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        label,
                                        color = if (selected) Color.Black else theme.primaryText(),
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }
                            }
                        }

                        OutlinedTextField(
                            value = geminiKeyDraft,
                            onValueChange = { geminiKeyDraft = it; savedBanner = false },
                            label = { Text("Gemini API Key (Encrypted)") },
                            singleLine = true,
                            visualTransformation = if (showGeminiKey) VisualTransformation.None else PasswordVisualTransformation(),
                            trailingIcon = {
                                IconButton(onClick = { showGeminiKey = !showGeminiKey }) {
                                    Icon(if (showGeminiKey) Icons.Rounded.VisibilityOff else Icons.Rounded.Visibility, null, tint = theme.mutedText())
                                }
                            },
                            colors = tfColors,
                            modifier = Modifier.fillMaxWidth()
                        )

                        OutlinedTextField(
                            value = geminiChatModelDraft,
                            onValueChange = { geminiChatModelDraft = it; savedBanner = false },
                            label = { Text("Gemini Model") },
                            singleLine = true,
                            colors = tfColors,
                            modifier = Modifier.fillMaxWidth()
                        )

                        OutlinedTextField(
                            value = geminiLiveModelDraft,
                            onValueChange = { geminiLiveModelDraft = it; savedBanner = false },
                            label = { Text("Gemini Live model") }, singleLine = true,
                            colors = tfColors, modifier = Modifier.fillMaxWidth()
                        )

                        OutlinedTextField(
                            value = openRouterKeyDraft,
                            onValueChange = { openRouterKeyDraft = it; savedBanner = false },
                            label = { Text("OpenRouter API Key (Encrypted)") },
                            singleLine = true,
                            visualTransformation = if (showOrKey) VisualTransformation.None else PasswordVisualTransformation(),
                            trailingIcon = {
                                IconButton(onClick = { showOrKey = !showOrKey }) {
                                    Icon(if (showOrKey) Icons.Rounded.VisibilityOff else Icons.Rounded.Visibility, null, tint = theme.mutedText())
                                }
                            },
                            colors = tfColors,
                            modifier = Modifier.fillMaxWidth()
                        )

                        OutlinedTextField(
                            value = openRouterModelDraft,
                            onValueChange = { openRouterModelDraft = it; savedBanner = false },
                            label = { Text("OpenRouter Model") },
                            singleLine = true,
                            colors = tfColors,
                            modifier = Modifier.fillMaxWidth()
                        )

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(
                                onClick = { persistDrafts(); onRunConnectionTest(settings.activeProvider) },
                                enabled = !uiState.isTestingConnection,
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Text("Ping API", color = theme.primaryText(), fontSize = 12.5.sp)
                            }
                            OutlinedButton(
                                onClick = { persistDrafts(); onDiscoverModels() },
                                enabled = !uiState.isDiscoveringModels,
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Text("Discover Models", color = accent, fontSize = 12.5.sp)
                            }
                        }

                        if (openRouterModelDraft.contains(":batch", ignoreCase = true)) {
                            Text("Batch models may not support realtime voice.", color = OmegaColors.AmberWarn, fontSize = 11.5.sp)
                        }
                        uiState.discoveryStatus?.let { Text(it, color = theme.mutedText(), fontSize = 11.5.sp) }
                        if (uiState.discoveredChatModels.isNotEmpty()) {
                            Text("Discovered chat models", color = theme.mutedText(), fontSize = 11.5.sp)
                            Row(modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                uiState.discoveredChatModels.filterNot { it.contains(":batch") }.take(20).forEach { id ->
                                    AssistChip(onClick = {
                                        if (settings.activeProvider == AiProvider.GEMINI) {
                                            geminiChatModelDraft = id; onSaveSettings { it.copy(geminiChatModel = id) }
                                        } else {
                                            openRouterModelDraft = id; onSaveSettings { it.copy(openRouterModel = id) }
                                        }
                                    }, label = { Text(id) })
                                }
                            }
                        }
                        if (settings.activeProvider == AiProvider.GEMINI && uiState.discoveredLiveModels.isNotEmpty()) {
                            Text("Discovered Live models", color = theme.mutedText(), fontSize = 11.5.sp)
                            Row(modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                uiState.discoveredLiveModels.take(20).forEach { id ->
                                    AssistChip(onClick = { geminiLiveModelDraft = id; onSaveSettings { it.copy(geminiLiveVoiceModel = id) } }, label = { Text(id) })
                                }
                            }
                        }
                        uiState.diagnosticResult?.let { result ->
                            Text(result.summary, color = if (result.isSuccess) OmegaColors.EmeraldLive else OmegaColors.CrimsonErr, fontSize = 12.sp)
                        }
                    }

                    SettingsHairlineDivider()
                    SettingsSwitchRow(
                        icon = Icons.Rounded.Memory,
                        title = "Local Brain Mode",
                        subtitle = "Local commands and memory without cloud API",
                        checked = settings.localBrainMode,
                        theme = theme,
                        preset = preset,
                        onCheckedChange = { v -> onSaveSettings { it.copy(localBrainMode = v) } }
                    )
                    SettingsHairlineDivider()
                    SettingsSwitchRow(Icons.Rounded.FlashOn, "Offline Instant Commands", "Local torch, volume, battery and routines", settings.offlineFastCommands, theme, preset) { v -> onSaveSettings { it.copy(offlineFastCommands = v) } }
                    SettingsHairlineDivider()
                    SettingsSwitchRow(Icons.Rounded.Search, "Google Search Grounding", "Use web grounding on compatible cloud models", settings.webSearchGrounding, theme, preset) { v -> onSaveSettings { it.copy(webSearchGrounding = v) } }
                }

                // ==========================================================
                // SECTION 2: VOICE & AUDIO
                // ==========================================================
                SettingsGroupSection(title = "VOICE & AUDIO") {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedTextField(
                            value = wakeWordDraft,
                            onValueChange = { wakeWordDraft = it; savedBanner = false },
                            label = { Text("Wake Word Phrase") },
                            singleLine = true,
                            colors = tfColors,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Text(
                            "Mic: ${uiState.voiceDiagNote} • TTS: ${uiState.ttsStatusNote}",
                            color = theme.mutedText(),
                            fontSize = 11.5.sp
                        )
                        OutlinedButton(
                            onClick = onTestSpeaker,
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(Icons.Rounded.VolumeUp, null, tint = accent, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Test Speaker Voice", color = theme.primaryText(), fontSize = 13.sp)
                        }
                        OutlinedButton(onClick = {
                            permLauncher.launch(if (Build.VERSION.SDK_INT >= 33) arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.POST_NOTIFICATIONS, Manifest.permission.BLUETOOTH_CONNECT) else if (Build.VERSION.SDK_INT >= 31) arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.BLUETOOTH_CONNECT) else arrayOf(Manifest.permission.RECORD_AUDIO))
                        }, modifier = Modifier.fillMaxWidth()) { Text(if (hasMic) "Mic Granted / Permissions" else "Allow Microphone") }
                        Text("Wake sensitivity: ${(settings.wakeSensitivity * 100).toInt()}%", color = theme.mutedText(), fontSize = 11.5.sp)
                        Slider(settings.wakeSensitivity, { v -> onSaveSettings { it.copy(wakeSensitivity = v) } }, valueRange = 0.2f..1.0f)
                        Text("Owner voice training, profile reset and optional filter: use the active wake notification controls.", color = theme.mutedText(), fontSize = 11.5.sp)
                    }

                    SettingsHairlineDivider()
                    SettingsSwitchRow(
                        icon = Icons.Rounded.RecordVoiceOver,
                        title = "Hey Jarvis Background Wake",
                        subtitle = "Listen continuously in background",
                        checked = settings.wakeWordEnabled,
                        theme = theme,
                        preset = preset,
                        onCheckedChange = { on ->
                            if (on && !hasMic) { pendingWakePermission = true; permLauncher.launch(if (Build.VERSION.SDK_INT >= 33) arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.POST_NOTIFICATIONS) else arrayOf(Manifest.permission.RECORD_AUDIO)) }
                            else onToggleWakeService(on)
                        }
                    )
                    SettingsHairlineDivider()
                    SettingsSwitchRow(
                        icon = Icons.Rounded.VolumeUp,
                        title = "Auto-Speak All Replies (TTS)",
                        subtitle = "Speak assistant replies using the selected voice engine",
                        checked = settings.autoSpeak,
                        theme = theme,
                        preset = preset,
                        onCheckedChange = { v -> onSaveSettings { it.copy(autoSpeak = v) } }
                    )
                    SettingsHairlineDivider()
                    SettingsSwitchRow(
                        icon = Icons.Rounded.Loop,
                        title = "Continuous Conversation",
                        subtitle = "Auto-rearm mic after OMEGA finishes speaking",
                        checked = settings.continuousConversation,
                        theme = theme,
                        preset = preset,
                        onCheckedChange = { v -> onSaveSettings { it.copy(continuousConversation = v) } }
                    )
                    SettingsHairlineDivider()
                    SettingsSwitchRow(
                        icon = Icons.Rounded.GraphicEq,
                        title = "Gemini Live Duplex Voice (WS)",
                        subtitle = "Low-latency WebSocket audio (Gemini key required)",
                        checked = settings.useGeminiLiveAudio,
                        theme = theme,
                        preset = preset,
                        onCheckedChange = { v -> onSaveSettings { it.copy(useGeminiLiveAudio = v) } }
                    )
                    SettingsHairlineDivider()
                    SettingsSwitchRow(
                        icon = Icons.Rounded.BluetoothAudio,
                        title = "Bluetooth Headset Routing",
                        subtitle = "Route mic & audio to BT earbuds",
                        checked = settings.bluetoothVoiceRouting,
                        theme = theme,
                        preset = preset,
                        onCheckedChange = { v -> onSaveSettings { it.copy(bluetoothVoiceRouting = v) } }
                    )
                    SettingsHairlineDivider()
                    SettingsSwitchRow(
                        icon = Icons.Rounded.MicOff,
                        title = "Microphone Privacy Mute",
                        subtitle = "Temporarily block all microphone access",
                        checked = settings.micPrivacyMuted,
                        theme = theme,
                        preset = preset,
                        onCheckedChange = { v -> onSaveSettings { it.copy(micPrivacyMuted = v) } }
                    )
                    SettingsHairlineDivider()

                    VoicePackPanel(uiState, onRefreshVoiceCatalog, onVoicePreview)
                    SettingsHairlineDivider()

                    // Language & TTS Speed Row
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Voice Language", color = theme.mutedText(), fontSize = 11.5.sp, fontWeight = FontWeight.Medium)
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf("auto" to "Auto (TE+EN)", "te-IN" to "తెలుగు", "en-IN" to "English").forEach { (tag, label) ->
                                val sel = settings.languageTag == tag
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(if (sel) accent else OmegaColors.CarbonElevated)
                                        .clickable { onSaveSettings { it.copy(languageTag = tag) } }
                                        .padding(vertical = 8.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(label, color = if (sel) Color.Black else theme.primaryText(), fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                                }
                            }
                        }
                        Text(
                            "TTS Speed: ${String.format(Locale.US, "%.2fx", settings.ttsSpeed)} • Pitch: ${String.format(Locale.US, "%.2fx", settings.ttsPitch)}",
                            color = theme.mutedText(),
                            fontSize = 11.5.sp
                        )
                        Slider(
                            value = settings.ttsSpeed,
                            onValueChange = { v -> onSaveSettings { it.copy(ttsSpeed = v) } },
                            valueRange = 0.7f..1.5f
                        )
                        Text("Pitch", color = theme.mutedText(), fontSize = 11.5.sp)
                        Slider(settings.ttsPitch, { v -> onSaveSettings { it.copy(ttsPitch = v) } }, valueRange = 0.7f..1.4f)
                        Text("Voice style", color = theme.mutedText(), fontSize = 11.5.sp)
                        Row(modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            TtsEmotionStyle.entries.forEach { st ->
                                FilterChip(selected = settings.ttsStyle == st, onClick = { onSaveSettings { it.copy(ttsStyle = st) } }, label = { Text(st.label) })
                            }
                        }
                    }
                }

                // ==========================================================
                // SECTION 3: APPEARANCE & ORB
                // ==========================================================
                SettingsGroupSection(title = "APPEARANCE & ORB") {
                    Column(
                        modifier = Modifier.fillMaxWidth().padding(14.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        ParticleAiOrb(size = 110.dp, isListening = true, audioAmplitude = 0.25f, preset = preset)
                        Row(modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            OrbColorPreset.entries.forEach { p ->
                                val sel = preset == p
                                Column(
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    modifier = Modifier.clickable { onSaveSettings { it.copy(orbColorPreset = p) } }
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(34.dp)
                                            .clip(CircleShape)
                                            .background(Color(p.primaryHex))
                                            .border(if (sel) 2.5.dp else 1.dp, if (sel) Color.White else OmegaColors.SubtleBorder, CircleShape)
                                    )
                                    Spacer(Modifier.height(4.dp))
                                    Text(p.label, color = if (sel) Color.White else theme.mutedText(), fontSize = 10.5.sp)
                                }
                            }
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OmegaVisualTheme.entries.forEach { t ->
                                val sel = theme == t
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(if (sel) accent else OmegaColors.CarbonElevated)
                                        .clickable { onSaveSettings { it.copy(visualTheme = t) } }
                                        .padding(vertical = 8.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(t.label, color = if (sel) Color.Black else theme.primaryText(), fontSize = 11.5.sp, fontWeight = FontWeight.SemiBold)
                                }
                            }
                        }
                    }
                    SettingsHairlineDivider()
                    SettingsSwitchRow(
                        icon = Icons.Rounded.ScreenRotation,
                        title = "3D Gyroscope Parallax",
                        subtitle = "Subtle depth tilt on Home Orb",
                        checked = settings.gyroscopeParallax,
                        theme = theme,
                        preset = preset,
                        onCheckedChange = { v -> onSaveSettings { it.copy(gyroscopeParallax = v) } }
                    )
                    SettingsHairlineDivider()
                    SettingsSwitchRow(
                        icon = Icons.Rounded.BubbleChart,
                        title = "Floating Mini-Orb",
                        subtitle = "Float over other apps (requires overlay)",
                        checked = settings.floatingOrbEnabled,
                        theme = theme,
                        preset = preset,
                        onCheckedChange = { v -> onSaveSettings { it.copy(floatingOrbEnabled = v) } }
                    )
                }

                // ==========================================================
                // SECTION 4: SYSTEM & PERMISSIONS
                // ==========================================================
                SettingsGroupSection(title = "SYSTEM & PERMISSIONS") {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = userNameDraft,
                            onValueChange = { userNameDraft = it; savedBanner = false },
                            label = { Text("Your Name") },
                            singleLine = true,
                            colors = tfColors,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                    SettingsHairlineDivider()
                    SettingsActionRow(
                        icon = Icons.Rounded.Mic,
                        title = "App Permissions (Mic, Camera, Contacts, Calendar, Bluetooth)",
                        subtitle = "Mic: ${if (hasMic) "OK" else "Denied"} • Cam: ${if (hasCamera) "OK" else "Denied"} • Contacts: ${if (hasContacts) "OK" else "Denied"}",
                        theme = theme,
                        onClick = {
                            val perms = buildList {
                                add(Manifest.permission.RECORD_AUDIO)
                                add(Manifest.permission.CAMERA)
                                add(Manifest.permission.READ_CONTACTS)
                                add(Manifest.permission.READ_CALENDAR)
                                add(Manifest.permission.CALL_PHONE)
                                if (Build.VERSION.SDK_INT >= 31) add(Manifest.permission.BLUETOOTH_CONNECT)
                                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) add(Manifest.permission.POST_NOTIFICATIONS)
                            }
                            permLauncher.launch(perms.toTypedArray())
                        }
                    )
                    SettingsHairlineDivider()
                    SettingsActionRow(
                        icon = Icons.Rounded.AccessibilityNew,
                        title = "Accessibility Service",
                        subtitle = if (hasAcc) "Active — UI automation ready" else "Tap to enable in Android Settings",
                        theme = theme,
                        onClick = { runCatching { context.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) } }
                    )
                    SettingsHairlineDivider()
                    SettingsActionRow(
                        icon = Icons.Rounded.NotificationsActive,
                        title = "Notification Listener",
                        subtitle = if (hasNotif) "Active — Can read & reply alerts" else "Tap to grant notification access",
                        theme = theme,
                        onClick = { runCatching { context.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) } }
                    )
                    SettingsHairlineDivider()
                    SettingsActionRow(Icons.Rounded.Settings, "Default Assistant", "Open Android voice input settings", theme) {
                        runCatching { context.startActivity(Intent(Settings.ACTION_VOICE_INPUT_SETTINGS)) }
                    }
                    SettingsHairlineDivider()
                    SettingsSwitchRow(Icons.Rounded.Notifications, "Confirm Notification Replies", "Require confirmation before sending", settings.confirmNotifReply, theme, preset) { v -> onSaveSettings { it.copy(confirmNotifReply = v) } }
                    SettingsHairlineDivider()
                    SettingsSwitchRow(Icons.Rounded.Security, "Biometric Protection (Optional)", "Authenticate sensitive tools", settings.biometricSafetyLock, theme, preset) { v -> if (v) BiometricSafetyGate.authenticate(context, onSuccess = { onSaveSettings { it.copy(biometricSafetyLock = true) } }, onError = {}) else onSaveSettings { it.copy(biometricSafetyLock = false) } }
                }

                // ==========================================================
                // SECTION 5: DATA & DIAGNOSTICS
                // ==========================================================
                SettingsGroupSection(title = "DATA & DIAGNOSTICS") {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        val snap = uiState.apiTelemetry
                        Text("API requests: ${snap.totalRequests} • Failed: ${snap.failedRequests} • Average: ${snap.averageLatencyMs} ms", color = theme.mutedText(), fontSize = 12.sp)
                        uiState.backupStatusText?.let { Text(it, color = theme.mutedText(), fontSize = 11.5.sp) }
                    }
                    SettingsHairlineDivider()
                    SettingsActionRow(Icons.Rounded.Restore, "Restore Backup", "Read backup from clipboard", theme) {
                        val clip = (context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).primaryClip?.getItemAt(0)?.coerceToText(context)?.toString().orEmpty()
                        onImportBackup(clip)
                    }
                    SettingsHairlineDivider()
                    SettingsActionRow(
                        icon = Icons.Rounded.ContentCopy,
                        title = "Export Encrypted Backup",
                        subtitle = "Copies settings backup to clipboard",
                        theme = theme,
                        onClick = {
                            val data = onExportBackup()
                            val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            cm.setPrimaryClip(ClipData.newPlainText("OMEGA_BACKUP", data))
                            savedBanner = true
                        }
                    )
                    SettingsHairlineDivider()
                    SettingsActionRow(
                        icon = Icons.Rounded.BugReport,
                        title = "Crash Logs",
                        subtitle = if (showCrashLogs) "Tap to hide logs" else "Tap to view or clear crash logs",
                        theme = theme,
                        onClick = { showCrashLogs = !showCrashLogs }
                    )
                    if (showCrashLogs) {
                        Column(modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text(
                                text = uiState.crashLogText.ifBlank { "No crash logs recorded." }.takeLast(4000),
                                color = theme.mutedText(),
                                fontSize = 11.sp
                            )
                            TextButton(onClick = onClearCrashLogs) {
                                Text("Clear Crash Logs", color = OmegaColors.CrimsonErr, fontSize = 12.sp)
                            }
                        }
                    }
                    SettingsHairlineDivider()
                    SettingsActionRow(
                        icon = Icons.Rounded.DeleteOutline,
                        title = "Clear Chat History",
                        subtitle = "Permanently remove saved local chat messages",
                        theme = theme,
                        titleColor = OmegaColors.CrimsonErr,
                        onClick = onClearHistory
                    )
                }

                Spacer(Modifier.height(24.dp))
            }
        }
    }
}

@Composable
private fun SettingsGroupSection(
    title: String,
    content: @Composable ColumnScope.() -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(
            text = title,
            color = Color(0xFF717688),
            fontSize = 11.5.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.sp,
            modifier = Modifier.padding(start = 6.dp)
        )
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(18.dp))
                .background(OmegaColors.CarbonSurface)
                .border(1.dp, OmegaColors.SubtleBorder, RoundedCornerShape(18.dp)),
            content = content
        )
    }
}

@Composable
private fun SettingsHairlineDivider() {
    HorizontalDivider(
        modifier = Modifier.padding(start = 54.dp),
        thickness = 1.dp,
        color = OmegaColors.HairlineDivider
    )
}

@Composable
private fun SettingsSwitchRow(
    icon: ImageVector,
    title: String,
    subtitle: String,
    checked: Boolean,
    theme: OmegaVisualTheme,
    preset: OrbColorPreset,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onCheckedChange(!checked) }
            .padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Box(
            modifier = Modifier
                .size(32.dp)
                .clip(RoundedCornerShape(9.dp))
                .background(OmegaColors.CarbonElevated),
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, null, tint = Color(preset.primaryHex), modifier = Modifier.size(18.dp))
        }
        Column(modifier = Modifier.weight(1f)) {
            Text(title, color = theme.primaryText(), fontSize = 14.sp, fontWeight = FontWeight.Medium)
            Text(subtitle, color = theme.mutedText(), fontSize = 11.5.sp, lineHeight = 15.sp)
        }
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = omegaSwitchColors(theme, preset)
        )
    }
}

@Composable
private fun SettingsActionRow(
    icon: ImageVector,
    title: String,
    subtitle: String,
    theme: OmegaVisualTheme,
    titleColor: Color = theme.primaryText(),
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Box(
            modifier = Modifier
                .size(32.dp)
                .clip(RoundedCornerShape(9.dp))
                .background(OmegaColors.CarbonElevated),
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, null, tint = if (titleColor == OmegaColors.CrimsonErr) OmegaColors.CrimsonErr else Color(0xFFB4B9C9), modifier = Modifier.size(18.dp))
        }
        Column(modifier = Modifier.weight(1f)) {
            Text(title, color = titleColor, fontSize = 14.sp, fontWeight = FontWeight.Medium)
            Text(subtitle, color = theme.mutedText(), fontSize = 11.5.sp, lineHeight = 15.sp)
        }
        Icon(Icons.Rounded.ChevronRight, null, tint = Color(0xFF565B6C), modifier = Modifier.size(20.dp))
    }
}
