package com.example.data

import android.content.Context
import android.content.SharedPreferences
import com.example.BuildConfig
import com.example.security.KeystoreCryptoManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONObject

/**
 * Strictly 2 Cloud AI Providers: Google Gemini and OpenRouter.
 * Plus 100% On-Device Local Brain (Zero Internet, Zero API Cost).
 */
enum class AiProvider(val displayName: String, val defaultChatModel: String) {
    GEMINI("Google Gemini", "gemini-3.8-flash"),
    OPENROUTER("OpenRouter", "google/gemini-2.5-flash")
}

enum class OmegaVisualTheme(val label: String) {
    AURORA_OBSIDIAN("Pure AMOLED"),
    MIDNIGHT_ROYAL("Velvet Violet"),
    CYBER_HORIZON_WEBGL("Cyber WebGL")
}

enum class OrbColorPreset(val label: String, val primaryHex: Long, val secondaryHex: Long, val accentHex: Long) {
    SOLAR_NOVA("Solar Nova", 0xFFFF8A00, 0xFFFF3D77, 0xFF5B3DF5),
    AURORA_CYAN("Arctic Blue", 0xFF38BDF8, 0xFF60A5FA, 0xFFC084FC),
    ROYAL_EMERALD("Emerald", 0xFF10B981, 0xFF06B6D4, 0xFF6366F1),
    CRIMSON_NOVA("Crimson", 0xFFF43F5E, 0xFFFF6B35, 0xFF7C3AED),
    NEBULA_VIOLET("Nebula", 0xFFA855F7, 0xFFEC4899, 0xFF38BDF8),
    ARCTIC_ICE("Silver Ice", 0xFFE2E8F0, 0xFF38BDF8, 0xFF818CF8)
}

enum class TtsEmotionStyle(val label: String, val speedMul: Float, val pitchMul: Float) {
    NATURAL("Natural", 1.0f, 1.0f),
    WARM("Warm", 0.94f, 0.96f),
    CRISP("Crisp Pro", 1.08f, 1.04f),
    CALM("Calm", 0.88f, 0.92f),
    DEEP("Deep JARVIS (pitch)", 0.92f, 0.78f)
}

data class OmegaSettings(
    val userName: String = "Pandu",
    val activeProvider: AiProvider = AiProvider.GEMINI,
    val geminiApiKey: String = "",
    val openRouterApiKey: String = "",
    val geminiChatModel: String = "gemini-3.8-flash",
    val geminiLiveVoiceModel: String = "gemini-3.8-live",
    val openRouterModel: String = "google/gemini-2.5-flash",
    // 100% On-Device Local Brain (Zero Internet, Zero API Cost)
    val localBrainMode: Boolean = false,
    val localLlmEndpoint: String = "http://127.0.0.1:8080/v1/chat/completions",
    // Least-privilege GitHub Engineering config (NEVER embedded; stored encrypted in Keystore)
    val githubRepoSlug: String = "",
    val githubToken: String = "",
    val githubBaseBranch: String = "main",
    // Voice & Wake
    val wakeWord: String = "hey jarvis",
    val wakeSensitivity: Float = 0.72f,
    val languageTag: String = "auto",
    val autoSpeak: Boolean = true,
    val continuousConversation: Boolean = false,
    val ttsSpeed: Float = 1.0f,
    val ttsPitch: Float = 1.0f,
    val ttsStyle: TtsEmotionStyle = TtsEmotionStyle.NATURAL,
    val wakeWordEnabled: Boolean = false,
    val bluetoothVoiceRouting: Boolean = true,
    val micPrivacyMuted: Boolean = false,
    val floatingOrbEnabled: Boolean = true,
    val useGeminiLiveAudio: Boolean = false,
    val webSearchGrounding: Boolean = true,
    val biometricSafetyLock: Boolean = false,
    val confirmNotifReply: Boolean = true,
    val gyroscopeParallax: Boolean = true,
    val offlineFastCommands: Boolean = true,
    val triggerBluetoothBriefing: Boolean = true,
    val triggerChargingAlert: Boolean = true,
    val triggerLowBatterySaver: Boolean = true,
    val visualTheme: OmegaVisualTheme = OmegaVisualTheme.AURORA_OBSIDIAN,
    val orbColorPreset: OrbColorPreset = OrbColorPreset.SOLAR_NOVA
) {
    fun effectiveGeminiKey(): String = geminiApiKey.trim().ifEmpty { BuildConfig.GEMINI_API_KEY.trim() }
    fun effectiveOpenRouterKey(): String = openRouterApiKey.trim().ifEmpty { BuildConfig.OPENROUTER_API_KEY.trim() }

    fun activeChatModel(): String = when {
        localBrainMode -> "on-device-local-brain"
        activeProvider == AiProvider.GEMINI -> geminiChatModel.trim().ifEmpty { AiProvider.GEMINI.defaultChatModel }
        else -> openRouterModel.trim().ifEmpty { AiProvider.OPENROUTER.defaultChatModel }
    }

    fun rmsGateThreshold(): Double = 1150.0 - (wakeSensitivity.coerceIn(0.1f, 1.0f) * 830.0)
}

class OmegaPreferences(context: Context) {

    private val prefs = context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    private val _settings = MutableStateFlow(load())
    val settings: StateFlow<OmegaSettings> = _settings.asStateFlow()

    private val changeListener = SharedPreferences.OnSharedPreferenceChangeListener { _, _ ->
        _settings.value = load()
    }

    init {
        prefs.registerOnSharedPreferenceChangeListener(changeListener)
    }

    private fun load(): OmegaSettings {
        val provider = runCatching { AiProvider.valueOf(prefs.getString(KEY_PROVIDER, AiProvider.GEMINI.name) ?: "") }.getOrDefault(AiProvider.GEMINI)
        val theme = runCatching { OmegaVisualTheme.valueOf(prefs.getString(KEY_THEME, OmegaVisualTheme.AURORA_OBSIDIAN.name) ?: "") }.getOrDefault(OmegaVisualTheme.AURORA_OBSIDIAN)
        val orbColor = runCatching { OrbColorPreset.valueOf(prefs.getString(KEY_ORB_COLOR, OrbColorPreset.SOLAR_NOVA.name) ?: "") }.getOrDefault(OrbColorPreset.SOLAR_NOVA)
        val ttsStyle = runCatching { TtsEmotionStyle.valueOf(prefs.getString(KEY_TTS_STYLE, TtsEmotionStyle.NATURAL.name) ?: "") }.getOrDefault(TtsEmotionStyle.NATURAL)

        return OmegaSettings(
            userName = prefs.getString(KEY_USER_NAME, "Pandu") ?: "Pandu",
            activeProvider = provider,
            geminiApiKey = KeystoreCryptoManager.decrypt(prefs.getString(KEY_GEMINI_KEY, "") ?: ""),
            openRouterApiKey = KeystoreCryptoManager.decrypt(prefs.getString(KEY_OPENROUTER_KEY, "") ?: ""),
            geminiChatModel = prefs.getString(KEY_GEMINI_CHAT_MODEL, "gemini-3.8-flash") ?: "gemini-3.8-flash",
            geminiLiveVoiceModel = (prefs.getString(KEY_GEMINI_LIVE_MODEL, "gemini-3.8-live") ?: "gemini-3.8-live").let { if (it == "gemini-2.5-flash-native-audio-preview") "gemini-3.8-live" else it },
            openRouterModel = prefs.getString(KEY_OPENROUTER_MODEL, "google/gemini-2.5-flash") ?: "google/gemini-2.5-flash",
            localBrainMode = prefs.getBoolean(KEY_LOCAL_BRAIN, false),
            localLlmEndpoint = prefs.getString(KEY_LOCAL_LLM_URL, "http://127.0.0.1:8080/v1/chat/completions") ?: "http://127.0.0.1:8080/v1/chat/completions",
            githubRepoSlug = prefs.getString(KEY_GH_REPO, "") ?: "",
            githubToken = KeystoreCryptoManager.decrypt(prefs.getString(KEY_GH_TOKEN, "") ?: ""),
            githubBaseBranch = prefs.getString(KEY_GH_BRANCH, "main") ?: "main",
            wakeWord = prefs.getString(KEY_WAKE_WORD, "hey jarvis") ?: "hey jarvis",
            wakeSensitivity = prefs.getFloat(KEY_WAKE_SENS, 0.72f),
            languageTag = prefs.getString(KEY_LANGUAGE, "auto") ?: "auto",
            autoSpeak = prefs.getBoolean(KEY_AUTO_SPEAK, true),
            continuousConversation = prefs.getBoolean(KEY_CONTINUOUS, false),
            ttsSpeed = prefs.getFloat(KEY_TTS_SPEED, 1.0f),
            ttsPitch = prefs.getFloat(KEY_TTS_PITCH, 1.0f),
            ttsStyle = ttsStyle,
            wakeWordEnabled = prefs.getBoolean(KEY_WAKE_ENABLED, false),
            bluetoothVoiceRouting = prefs.getBoolean(KEY_BT_ROUTING, true),
            micPrivacyMuted = prefs.getBoolean(KEY_MIC_MUTED, false),
            floatingOrbEnabled = prefs.getBoolean(KEY_FLOATING_ORB, true),
            useGeminiLiveAudio = prefs.getBoolean(KEY_LIVE_AUDIO, false),
            webSearchGrounding = prefs.getBoolean(KEY_WEB_GROUNDING, true),
            biometricSafetyLock = prefs.getBoolean(KEY_BIOMETRIC_LOCK, false),
            confirmNotifReply = prefs.getBoolean(KEY_CONFIRM_REPLY, true),
            gyroscopeParallax = prefs.getBoolean(KEY_PARALLAX, true),
            offlineFastCommands = prefs.getBoolean(KEY_OFFLINE_FAST, true),
            triggerBluetoothBriefing = prefs.getBoolean(KEY_TRIG_BT, true),
            triggerChargingAlert = prefs.getBoolean(KEY_TRIG_CHARGE, true),
            triggerLowBatterySaver = prefs.getBoolean(KEY_TRIG_LOWBAT, true),
            visualTheme = theme,
            orbColorPreset = orbColor
        )
    }

    fun update(transform: (OmegaSettings) -> OmegaSettings) {
        val u = transform(_settings.value)
        _settings.value = u
        prefs.edit()
            .putString(KEY_USER_NAME, u.userName.trim().ifEmpty { "Pandu" })
            .putString(KEY_PROVIDER, u.activeProvider.name)
            .putString(KEY_GEMINI_KEY, KeystoreCryptoManager.encrypt(u.geminiApiKey.trim()))
            .putString(KEY_OPENROUTER_KEY, KeystoreCryptoManager.encrypt(u.openRouterApiKey.trim()))
            .putString(KEY_GEMINI_CHAT_MODEL, u.geminiChatModel.trim().ifEmpty { "gemini-3.8-flash" })
            .putString(KEY_GEMINI_LIVE_MODEL, u.geminiLiveVoiceModel.trim().ifEmpty { "gemini-3.8-live" })
            .putString(KEY_OPENROUTER_MODEL, u.openRouterModel.trim().ifEmpty { "google/gemini-2.5-flash" })
            .putBoolean(KEY_LOCAL_BRAIN, u.localBrainMode)
            .putString(KEY_LOCAL_LLM_URL, u.localLlmEndpoint.trim().ifEmpty { "http://127.0.0.1:8080/v1/chat/completions" })
            .putString(KEY_GH_REPO, u.githubRepoSlug.trim())
            .putString(KEY_GH_TOKEN, KeystoreCryptoManager.encrypt(u.githubToken.trim()))
            .putString(KEY_GH_BRANCH, u.githubBaseBranch.trim().ifEmpty { "main" })
            .putString(KEY_WAKE_WORD, u.wakeWord.trim().lowercase().ifEmpty { "hey jarvis" })
            .putFloat(KEY_WAKE_SENS, u.wakeSensitivity.coerceIn(0.1f, 1.0f))
            .putString(KEY_LANGUAGE, u.languageTag)
            .putBoolean(KEY_AUTO_SPEAK, u.autoSpeak)
            .putBoolean(KEY_CONTINUOUS, u.continuousConversation)
            .putFloat(KEY_TTS_SPEED, u.ttsSpeed.coerceIn(0.6f, 1.6f))
            .putFloat(KEY_TTS_PITCH, u.ttsPitch.coerceIn(0.6f, 1.5f))
            .putString(KEY_TTS_STYLE, u.ttsStyle.name)
            .putBoolean(KEY_WAKE_ENABLED, u.wakeWordEnabled)
            .putBoolean(KEY_BT_ROUTING, u.bluetoothVoiceRouting)
            .putBoolean(KEY_MIC_MUTED, u.micPrivacyMuted)
            .putBoolean(KEY_FLOATING_ORB, u.floatingOrbEnabled)
            .putBoolean(KEY_LIVE_AUDIO, u.useGeminiLiveAudio)
            .putBoolean(KEY_WEB_GROUNDING, u.webSearchGrounding)
            .putBoolean(KEY_BIOMETRIC_LOCK, u.biometricSafetyLock)
            .putBoolean(KEY_CONFIRM_REPLY, u.confirmNotifReply)
            .putBoolean(KEY_PARALLAX, u.gyroscopeParallax)
            .putBoolean(KEY_OFFLINE_FAST, u.offlineFastCommands)
            .putBoolean(KEY_TRIG_BT, u.triggerBluetoothBriefing)
            .putBoolean(KEY_TRIG_CHARGE, u.triggerChargingAlert)
            .putBoolean(KEY_TRIG_LOWBAT, u.triggerLowBatterySaver)
            .putString(KEY_THEME, u.visualTheme.name)
            .putString(KEY_ORB_COLOR, u.orbColorPreset.name)
            .apply()
    }

    fun exportEncryptedBackupJson(): String {
        val s = _settings.value
        val obj = JSONObject().apply {
            put("userName", s.userName)
            put("activeProvider", s.activeProvider.name)
            put("geminiChatModel", s.geminiChatModel)
            put("geminiLiveVoiceModel", s.geminiLiveVoiceModel)
            put("openRouterModel", s.openRouterModel)
            put("localBrainMode", s.localBrainMode)
            put("githubRepoSlug", s.githubRepoSlug)
            put("githubBaseBranch", s.githubBaseBranch)
            put("wakeWord", s.wakeWord)
            put("languageTag", s.languageTag)
            put("visualTheme", s.visualTheme.name)
            put("orbColorPreset", s.orbColorPreset.name)
        }
        return KeystoreCryptoManager.encrypt(obj.toString())
    }

    fun importEncryptedBackupJson(encryptedBlob: String): Boolean {
        val plain = KeystoreCryptoManager.decrypt(encryptedBlob.trim())
        if (plain.isBlank()) return false
        return runCatching {
            val obj = JSONObject(plain)
            update { cur ->
                cur.copy(
                    userName = obj.optString("userName", cur.userName),
                    geminiChatModel = obj.optString("geminiChatModel", cur.geminiChatModel),
                    geminiLiveVoiceModel = obj.optString("geminiLiveVoiceModel", cur.geminiLiveVoiceModel),
                    openRouterModel = obj.optString("openRouterModel", cur.openRouterModel),
                    localBrainMode = obj.optBoolean("localBrainMode", cur.localBrainMode),
                    githubRepoSlug = obj.optString("githubRepoSlug", cur.githubRepoSlug),
                    githubBaseBranch = obj.optString("githubBaseBranch", cur.githubBaseBranch),
                    wakeWord = obj.optString("wakeWord", cur.wakeWord),
                    languageTag = obj.optString("languageTag", cur.languageTag)
                )
            }
            true
        }.getOrDefault(false)
    }

    companion object {
        private const val PREFS_NAME = "omega_pandu_v19_auto_prefs"
        private const val KEY_USER_NAME = "user_name"
        private const val KEY_PROVIDER = "active_provider"
        private const val KEY_GEMINI_KEY = "enc_gemini_key"
        private const val KEY_OPENROUTER_KEY = "enc_openrouter_key"
        private const val KEY_GEMINI_CHAT_MODEL = "gemini_chat_model"
        private const val KEY_GEMINI_LIVE_MODEL = "gemini_live_model"
        private const val KEY_OPENROUTER_MODEL = "openrouter_model"
        private const val KEY_LOCAL_BRAIN = "local_brain_mode"
        private const val KEY_LOCAL_LLM_URL = "local_llm_url"
        private const val KEY_GH_REPO = "gh_repo_slug"
        private const val KEY_GH_TOKEN = "enc_gh_token"
        private const val KEY_GH_BRANCH = "gh_base_branch"
        private const val KEY_WAKE_WORD = "wake_word"
        private const val KEY_WAKE_SENS = "wake_sens"
        private const val KEY_LANGUAGE = "language_tag"
        private const val KEY_AUTO_SPEAK = "auto_speak"
        private const val KEY_CONTINUOUS = "continuous_conv"
        private const val KEY_TTS_SPEED = "tts_speed"
        private const val KEY_TTS_PITCH = "tts_pitch"
        private const val KEY_TTS_STYLE = "tts_style"
        private const val KEY_WAKE_ENABLED = "wake_word_enabled"
        private const val KEY_BT_ROUTING = "bt_routing"
        private const val KEY_MIC_MUTED = "mic_muted"
        private const val KEY_FLOATING_ORB = "floating_orb_enabled"
        private const val KEY_LIVE_AUDIO = "use_live_audio"
        private const val KEY_WEB_GROUNDING = "web_grounding"
        private const val KEY_BIOMETRIC_LOCK = "biometric_lock"
        private const val KEY_CONFIRM_REPLY = "confirm_notif_reply"
        private const val KEY_PARALLAX = "gyro_parallax"
        private const val KEY_OFFLINE_FAST = "offline_fast_cmd"
        private const val KEY_TRIG_BT = "trig_bt"
        private const val KEY_TRIG_CHARGE = "trig_charge"
        private const val KEY_TRIG_LOWBAT = "trig_lowbat"
        private const val KEY_THEME = "visual_theme"
        private const val KEY_ORB_COLOR = "orb_color"
    }
}
