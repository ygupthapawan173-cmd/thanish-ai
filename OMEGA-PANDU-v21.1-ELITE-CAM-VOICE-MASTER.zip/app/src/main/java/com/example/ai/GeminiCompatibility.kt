package com.example.ai

internal object GeminiCompatibility {
    fun canDowngrade(message: String, hasTools: Boolean, hasToolHistory: Boolean): Boolean {
        val m = message.lowercase()
        return hasTools && !hasToolHistory && m.contains("http 400") &&
            ((m.contains("function calling") || m.contains("function declarations") || m.contains("tools")) &&
            (m.contains("not enabled") || m.contains("not supported") || m.contains("unsupported") || m.contains("does not support") || m.contains("not available")))
    }
    fun tryAnotherModel(message: String): Boolean = listOf("HTTP 404", "HTTP 429", "HTTP 500", "HTTP 502", "HTTP 503", "HTTP 504").any { message.contains(it,ignoreCase=true) } || canDowngrade(message, true, false)
}
