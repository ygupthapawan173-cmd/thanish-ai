package com.example.ai

import android.app.ActivityManager
import android.content.Context
import android.net.Uri
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.File
import java.security.MessageDigest
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlin.coroutines.coroutineContext

/** Explicitly imported model, isolated in app-private storage. No API calls or generated tool execution. */
internal object EmbeddedLocalModel {
    private val lock = Mutex()
    private val _status = MutableStateFlow("Not tested")
    val status = _status.asStateFlow()
    private const val MAX_BYTES = 2_000_000_000L
    private fun file(c: Context) = File(c.noBackupFilesDir, "local-brain.task")
    fun installed(c: Context) = file(c).isFile
    suspend fun install(c: Context, uri: Uri): String = lock.withLock {
        withContext(Dispatchers.IO) {
            val dst = file(c); val tmp = File(dst.parentFile, "local-brain.import.task")
            try {
                require(dst.parentFile!!.usableSpace > 100_000_000L) { "Insufficient storage" }
                val hash = MessageDigest.getInstance("SHA-256")
                var count = 0L
                c.contentResolver.openInputStream(uri)?.use { input ->
                    tmp.outputStream().buffered().use { out ->
                        val buf = ByteArray(1024 * 1024)
                        while (true) {
                            coroutineContext.ensureActive()
                            val n = input.read(buf); if (n < 0) break
                            count += n; require(count <= MAX_BYTES) { "Model exceeds 2 GB import limit" }
                            require(dst.parentFile!!.usableSpace > 32_000_000L) { "Insufficient storage" }
                            out.write(buf, 0, n); hash.update(buf, 0, n)
                        }
                    }
                } ?: error("Cannot open model")
                require(count >= 1_000_000L) { "Model is too small" }
                val mem = ActivityManager.MemoryInfo().also { c.getSystemService(ActivityManager::class.java).getMemoryInfo(it) }
                require(!mem.lowMemory && mem.availMem >= maxOf(1_200_000_000L, count * 2)) { "Insufficient RAM to validate model; existing model retained" }
                _status.value = "Validating imported model on-device"
                val opts = LlmInference.LlmInferenceOptions.builder().setModelPath(tmp.absolutePath).setMaxTokens(128).setMaxTopK(1).build()
                val probe = LlmInference.createFromOptions(c.applicationContext, opts).use { it.generateResponse("Say hello in one word.").trim() }
                require(probe.isNotBlank()) { "Model returned no response; existing model retained" }
                coroutineContext.ensureActive()
                // Atomic rename on same private filesystem; old file retained if validation or rename fails.
                android.system.Os.rename(tmp.absolutePath, dst.absolutePath)
                _status.value = "Imported; smoke inference passed"
                "Imported ${count / 1_000_000} MB; SHA-256 ${hash.digest().joinToString("") { "%02x".format(it) }}. Smoke inference passed."
            } catch (e: LinkageError) {
                _status.value = "Native model validation unavailable; existing model retained"
                throw IllegalStateException("Native model validation unavailable", e)
            } catch (e: Exception) {
                _status.value = "Import failed or cancelled; existing model retained"
                throw e
            } finally { tmp.delete() }
        }
    }
    suspend fun remove(c: Context) = lock.withLock { withContext(Dispatchers.IO) {
        val f = file(c); check(!f.exists() || f.delete()) { "Could not delete model" }; _status.value = "No model installed"
    } }
    suspend fun answer(c: Context, prompt: String): String? = lock.withLock {
        withContext(Dispatchers.IO) {
            val model = file(c); if (!model.isFile) return@withContext null
            val mem = ActivityManager.MemoryInfo().also { c.getSystemService(ActivityManager::class.java).getMemoryInfo(it) }
            if (mem.lowMemory || mem.availMem < maxOf(1_200_000_000L, model.length() * 2)) {
                _status.value = "Insufficient available RAM; local fallback"; return@withContext null
            }
            try {
                _status.value = "Running on-device inference"
                val options = LlmInference.LlmInferenceOptions.builder().setModelPath(model.absolutePath).setMaxTokens(512).setMaxTopK(40).build()
                val text = LlmInference.createFromOptions(c.applicationContext, options).use { engine ->
                    engine.generateResponse(prompt.take(1200)).trim()
                }
                coroutineContext.ensureActive()
                _status.value = if (text.isBlank()) "Empty model reply" else "On-device inference succeeded"
                text.ifBlank { null }
            } catch (e: CancellationException) { _status.value = "Inference cancelled"; throw e }
            catch (e: Exception) { _status.value = "Model failed: ${e.javaClass.simpleName}"; null }
            catch (e: LinkageError) { _status.value = "Native runtime unavailable"; null }
        }
    }
}
