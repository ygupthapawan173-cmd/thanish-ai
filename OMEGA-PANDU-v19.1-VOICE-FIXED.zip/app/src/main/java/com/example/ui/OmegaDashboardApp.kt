package com.example.ui

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.Send
import androidx.compose.material.icons.automirrored.rounded.VolumeOff
import androidx.compose.material.icons.automirrored.rounded.VolumeUp
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.data.OmegaVisualTheme
import com.example.data.OrbColorPreset
import com.example.ui.components.OmegaHorizonOrb
import com.example.ui.components.ParticleAiOrb
import com.example.ui.components.rememberParallaxOffset
import com.example.ui.theme.OmegaColors
import com.example.ui.theme.OmegaLiquidBackdrop
import com.example.ui.theme.accentColor
import com.example.ui.theme.mutedText
import com.example.ui.theme.omegaGlassCard
import com.example.ui.theme.primaryText
import java.util.Calendar

@Composable
fun OmegaDashboardApp(viewModel: PanduViewModel) {
    val uiState by viewModel.uiState.collectAsState()
    val context = LocalContext.current

    val micLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) viewModel.startVoiceListening()
    }
    val camPreview = rememberLauncherForActivityResult(ActivityResultContracts.TakePicturePreview()) { bmp ->
        if (bmp != null) viewModel.analyzeCameraBitmap(bmp)
    }
    val camPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) camPreview.launch(null)
    }

    fun launchVoice() {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            viewModel.startVoiceListening()
        } else micLauncher.launch(Manifest.permission.RECORD_AUDIO)
    }

    fun launchCamera() {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            camPreview.launch(null)
        } else camPerm.launch(Manifest.permission.CAMERA)
    }

    LaunchedEffect(uiState.pendingWidgetCameraLaunch) {
        if (uiState.pendingWidgetCameraLaunch) {
            viewModel.consumeWidgetCameraLaunch()
            launchCamera()
        }
    }

    Crossfade(targetState = uiState.currentScreen, label = "nav") { screen ->
        when (screen) {
            OmegaScreen.HOME -> HomeScreen(
                uiState = uiState,
                onVoiceClick = { launchVoice() },
                onUnmuteClick = { viewModel.unmuteMicAndListen() },
                onStopClick = { viewModel.stopAllActivity() },
                onChatClick = { viewModel.navigateTo(OmegaScreen.CHAT) },
                onRoutinesClick = { viewModel.navigateTo(OmegaScreen.ROUTINES) },
                onCameraClick = { launchCamera() },
                onSettingsClick = { viewModel.navigateTo(OmegaScreen.SETTINGS) },
                onLabClick = { viewModel.navigateTo(OmegaScreen.AUTONOMOUS_LAB) },
                onToggleLocalBrain = { viewModel.toggleLocalBrainMode() },
                onDailyBriefing = { viewModel.runDailyBriefing() },
                onDismissTrigger = { viewModel.dismissTriggerBanner() },
                onQuickPrompt = { viewModel.sendTextPrompt(it, openChat = true) }
            )
            OmegaScreen.LISTENING -> ListeningScreen(
                uiState = uiState,
                onBack = { viewModel.stopAllActivity(); viewModel.navigateTo(OmegaScreen.HOME) },
                onChat = { viewModel.navigateTo(OmegaScreen.CHAT) },
                onUnmuteClick = { viewModel.unmuteMicAndListen() },
                onToggleMic = {
                    if (uiState.isListening || uiState.liveDuplexState.isConnected) viewModel.stopVoiceListening()
                    else launchVoice()
                },
                onCycleLang = { viewModel.cycleVoiceLanguage() },
                onToggleAutoSpeak = { viewModel.toggleAutoSpeak() },
                onToggleLiveMode = { viewModel.toggleLiveDuplexMode() }
            )
            OmegaScreen.CHAT -> ChatScreen(
                uiState = uiState,
                onBack = { viewModel.navigateTo(OmegaScreen.HOME) },
                onMic = { launchVoice() },
                onCamera = { launchCamera() },
                onSummarize = { viewModel.summarizeConversation() },
                onConfirmReply = { viewModel.confirmPendingNotifReply() },
                onCancelReply = { viewModel.cancelPendingNotifReply() },
                onSend = { viewModel.sendTextPrompt(it, openChat = false) },
                onSpeak = { viewModel.speakMessage(it) }
            )
            OmegaScreen.ROUTINES -> RoutinesAndMemoryScreen(
                settings = uiState.settings,
                routines = uiState.routines,
                memories = uiState.memories,
                locationReminders = uiState.locationReminders,
                onBack = { viewModel.navigateTo(OmegaScreen.HOME) },
                onUpdateSettings = { viewModel.updateSettings(it) },
                onTestTrigger = { viewModel.testSmartTrigger(it) },
                onScheduleRoutine = { name, h, m -> viewModel.scheduleDailyRoutine(name, h, m) },
                onRunRoutine = { viewModel.runRoutineNow(it) },
                onAddRoutine = { n, t, s, j -> viewModel.saveCustomRoutine(n, t, s, j) },
                onDeleteRoutine = { viewModel.deleteRoutine(it) },
                onDeleteMemory = { viewModel.deleteMemory(it) }
            )
            OmegaScreen.AUTONOMOUS_LAB -> AutonomousLabScreen(
                uiState = uiState,
                onBack = { viewModel.navigateTo(OmegaScreen.HOME) },
                onSaveSettings = { viewModel.updateSettings(it) },
                onRunDiagnostics = { viewModel.runSystemDiagnostics() },
                onStartSelfUpgrade = { req, path -> viewModel.startSelfUpgrade(req, path) },
                onEmergencyStop = { viewModel.emergencyStopUpgrade() },
                onCheckReleaseUpdate = { viewModel.checkReleaseUpdate() },
                onApproveAndInstallUpdate = { viewModel.approveAndInstallRelease() }
            )
            OmegaScreen.SETTINGS -> SettingsScreen(
                uiState = uiState,
                onBack = { viewModel.navigateTo(OmegaScreen.HOME) },
                onSaveSettings = { viewModel.updateSettings(it) },
                onRunConnectionTest = { viewModel.runConnectionTest(it) },
                onDiscoverModels = { viewModel.discoverRealModels() },
                onTestSpeaker = { viewModel.testSpeakerVoice() },
                onToggleWakeService = { viewModel.setWakeWordEnabled(it) },
                onExportBackup = { viewModel.exportEncryptedBackup() },
                onImportBackup = { viewModel.importEncryptedBackup(it) },
                onClearCrashLogs = { viewModel.clearCrashLogs() },
                onClearHistory = { viewModel.clearChatHistory() }
            )
        }
    }
}

@Composable
private fun AdaptiveCentralOrb(
    theme: OmegaVisualTheme,
    preset: OrbColorPreset,
    orbState: String,
    audioLevel: Float,
    size: Dp,
    parallaxEnabled: Boolean,
    onClick: () -> Unit
) {
    val tilt by rememberParallaxOffset(enabled = parallaxEnabled, maxDpShift = 10f)
    val pulseInf = rememberInfiniteTransition(label = "halo")
    val haloScale by pulseInf.animateFloat(0.96f, 1.06f, infiniteRepeatable(tween(2400, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "h")
    val c1 = Color(preset.primaryHex)
    val c2 = Color(preset.secondaryHex)
    val c3 = Color(preset.accentHex)

    Box(
        modifier = Modifier.offset(x = tilt.x.dp, y = tilt.y.dp).clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Box(
            modifier = Modifier
                .size(size * haloScale * 1.14f)
                .clip(CircleShape)
                .border(1.4.dp, Brush.sweepGradient(listOf(c1.copy(0.70f), c2.copy(0.35f), c3.copy(0.55f), c1.copy(0.70f))), CircleShape)
        )
        if (theme == OmegaVisualTheme.CYBER_HORIZON_WEBGL) {
            OmegaHorizonOrb(orbState = orbState, audioLevel = audioLevel, size = size)
        } else {
            ParticleAiOrb(
                size = size,
                isListening = orbState == "listening" || orbState == "thinking" || orbState == "speaking",
                audioAmplitude = audioLevel,
                preset = preset
            )
        }
    }
}

@Composable
private fun HomeScreen(
    uiState: PanduUiState,
    onVoiceClick: () -> Unit,
    onUnmuteClick: () -> Unit,
    onStopClick: () -> Unit,
    onChatClick: () -> Unit,
    onRoutinesClick: () -> Unit,
    onCameraClick: () -> Unit,
    onSettingsClick: () -> Unit,
    onLabClick: () -> Unit,
    onToggleLocalBrain: () -> Unit,
    onDailyBriefing: () -> Unit,
    onDismissTrigger: () -> Unit,
    onQuickPrompt: (String) -> Unit
) {
    val theme = uiState.settings.visualTheme
    val preset = uiState.settings.orbColorPreset
    val accent = theme.accentColor(preset)
    var promptText by remember { mutableStateOf("") }

    val timeGreeting = remember {
        when (Calendar.getInstance().get(Calendar.HOUR_OF_DAY)) {
            in 5..11 -> "Good Morning"
            in 12..16 -> "Good Afternoon"
            in 17..20 -> "Good Evening"
            else -> "Welcome"
        }
    }

    OmegaLiquidBackdrop(theme = theme, preset = preset) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(horizontal = 20.dp, vertical = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Clean Cockpit Top Header (Never overlapped!)
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Row(
                    modifier = Modifier
                        .omegaGlassCard(20.dp, theme, preset)
                        .clickable { if (uiState.settings.micPrivacyMuted) onUnmuteClick() else onSettingsClick() }
                        .padding(horizontal = 12.dp, vertical = 7.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(7.dp)
                ) {
                    val statusColor = when {
                        uiState.settings.micPrivacyMuted -> OmegaColors.CrimsonErr
                        uiState.isThinking || uiState.isSpeaking -> accent
                        else -> OmegaColors.EmeraldLive
                    }
                    Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(statusColor))
                    val statusLabel = when {
                        uiState.settings.micPrivacyMuted -> "MIC MUTED • TAP"
                        uiState.isThinking -> "THINKING..."
                        uiState.isSpeaking -> "SPEAKING..."
                        else -> "${uiState.settings.activeProvider.name} • ${uiState.batteryPercent}%"
                    }
                    Text(statusLabel, color = theme.primaryText(), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (uiState.isThinking || uiState.isSpeaking) {
                        Box(
                            modifier = Modifier.clip(RoundedCornerShape(18.dp)).background(OmegaColors.CrimsonErr).clickable { onStopClick() }.padding(horizontal = 12.dp, vertical = 9.dp)
                        ) { Text("STOP", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                    }
                    GlassCircleButton(Icons.Rounded.AutoFixHigh, theme = theme, preset = preset, onClick = onLabClick)
                    GlassCircleButton(Icons.Rounded.Bolt, theme = theme, preset = preset, onClick = onRoutinesClick)
                    GlassCircleButton(Icons.Rounded.Settings, theme = theme, preset = preset, onClick = onSettingsClick)
                }
            }

            AnimatedVisibility(visible = uiState.lastTriggerBanner != null) {
                if (uiState.lastTriggerBanner != null) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(top = 10.dp).omegaGlassCard(16.dp, theme, preset).clickable { onDismissTrigger() }.padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.weight(1f)) {
                            Icon(Icons.Rounded.AutoAwesome, null, tint = accent, modifier = Modifier.size(16.dp))
                            Text(uiState.lastTriggerBanner, color = theme.primaryText(), fontSize = 12.sp, maxLines = 2)
                        }
                        Icon(Icons.Rounded.Close, "Dismiss", tint = theme.mutedText(), modifier = Modifier.size(16.dp))
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))
            Text("$timeGreeting, ${uiState.settings.userName}", fontSize = 26.sp, fontWeight = FontWeight.Bold, color = theme.primaryText())
            Spacer(modifier = Modifier.height(4.dp))
            Box(modifier = Modifier.clip(RoundedCornerShape(12.dp)).background(accent.copy(0.14f)).padding(horizontal = 10.dp, vertical = 3.dp)) {
                Text(uiState.settings.activeChatModel(), fontSize = 11.5.sp, color = accent, fontWeight = FontWeight.SemiBold)
            }

            Spacer(modifier = Modifier.height(14.dp))
            AdaptiveCentralOrb(
                theme = theme,
                preset = preset,
                orbState = if (uiState.isThinking) "thinking" else if (uiState.isSpeaking) "speaking" else "idle",
                audioLevel = if (uiState.isThinking || uiState.isSpeaking) 0.55f else 0.14f,
                size = 162.dp,
                parallaxEnabled = uiState.settings.gyroscopeParallax,
                onClick = { if (uiState.settings.micPrivacyMuted) onUnmuteClick() else onVoiceClick() }
            )

            Spacer(modifier = Modifier.height(10.dp))
            Text(
                text = if (uiState.settings.micPrivacyMuted) "Tap orb to Unmute Mic & Speak"
                else if (uiState.settings.wakeWordEnabled) "Tap Orb or say \"${uiState.settings.wakeWord}\""
                else "Tap Orb to Speak",
                color = if (uiState.settings.micPrivacyMuted) OmegaColors.CrimsonErr else theme.mutedText(),
                fontSize = 12.sp,
                fontWeight = FontWeight.Medium
            )

            Spacer(modifier = Modifier.height(14.dp))

            // Quick Smart Chips
            Row(modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                SmartChip(theme, preset, if (uiState.settings.localBrainMode) "Local Brain: ON" else "Local Brain: OFF") { onToggleLocalBrain() }
                SmartChip(theme, preset, "Self-Upgrade Lab") { onLabClick() }
                SmartChip(theme, preset, "Daily Briefing") { onDailyBriefing() }
                if (uiState.unreadNotifCount > 0) {
                    SmartChip(theme, preset, "Unread (${uiState.unreadNotifCount})") { onQuickPrompt("Read my latest notifications.") }
                }
                SmartChip(theme, preset, "Live Weather") { onQuickPrompt("What is the weather right now?") }
                SmartChip(theme, preset, "Torch ON") { onQuickPrompt("Turn on flashlight") }
                SmartChip(theme, preset, "Good Night") { onQuickPrompt("good night") }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Ultra Bento 2x2 Action Grid
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                BentoTile(
                    theme, preset, Icons.Rounded.Mic,
                    title = "Voice Agent",
                    subtitle = if (uiState.settings.wakeWordEnabled) "Wake Active" else "Tap to Speak",
                    badge = if (uiState.settings.autoSpeak) "TTS ON" else "MUTE",
                    modifier = Modifier.weight(1f),
                    onClick = onVoiceClick
                )
                BentoTile(
                    theme, preset, Icons.Rounded.ChatBubbleOutline,
                    title = "Supreme Chat",
                    subtitle = "Memory & Search",
                    badge = "${uiState.memories.size} MEM",
                    modifier = Modifier.weight(1f),
                    onClick = onChatClick
                )
            }
            Spacer(modifier = Modifier.height(12.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                BentoTile(
                    theme, preset, Icons.Rounded.CenterFocusWeak,
                    title = "Vision Scan",
                    subtitle = "Camera & Screen",
                    badge = "LIVE",
                    modifier = Modifier.weight(1f),
                    onClick = onCameraClick
                )
                BentoTile(
                    theme, preset, Icons.Rounded.Bolt,
                    title = "Automations",
                    subtitle = "Triggers & Macros",
                    badge = "${uiState.routines.size} RUN",
                    modifier = Modifier.weight(1f),
                    onClick = onRoutinesClick
                )
            }

            Spacer(modifier = Modifier.weight(1f))

            // Bottom Liquid Glass Command Bar
            Row(
                modifier = Modifier.fillMaxWidth().omegaGlassCard(30.dp, theme, preset).padding(horizontal = 10.dp, vertical = 5.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onCameraClick) { Icon(Icons.Rounded.CameraAlt, "Vision", tint = accent, modifier = Modifier.size(20.dp)) }
                TextField(
                    value = promptText,
                    onValueChange = { promptText = it },
                    placeholder = { Text("Ask OMEGA 19 Ultra...", color = theme.mutedText(), fontSize = 13.5.sp) },
                    colors = TextFieldDefaults.colors(
                        focusedContainerColor = Color.Transparent, unfocusedContainerColor = Color.Transparent,
                        focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent,
                        focusedTextColor = theme.primaryText(), unfocusedTextColor = theme.primaryText()
                    ),
                    singleLine = true,
                    modifier = Modifier.weight(1f)
                )
                IconButton(onClick = onVoiceClick) { Icon(Icons.Rounded.Mic, "Voice", tint = accent, modifier = Modifier.size(20.dp)) }
                Box(
                    modifier = Modifier.size(42.dp).clickable {
                        if (promptText.isNotBlank()) { onQuickPrompt(promptText); promptText = "" } else onChatClick()
                    },
                    contentAlignment = Alignment.Center
                ) {
                    ParticleAiOrb(size = 40.dp, preset = preset)
                    Icon(Icons.AutoMirrored.Rounded.Send, "Send", tint = Color.White, modifier = Modifier.size(16.dp))
                }
            }
        }
    }
}

@Composable
private fun SmartChip(theme: OmegaVisualTheme, preset: OrbColorPreset, label: String, onClick: () -> Unit) {
    Box(modifier = Modifier.omegaGlassCard(18.dp, theme, preset).clickable { onClick() }.padding(horizontal = 13.dp, vertical = 7.dp)) {
        Text(label, color = theme.primaryText(), fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun BentoTile(
    theme: OmegaVisualTheme,
    preset: OrbColorPreset,
    icon: ImageVector,
    title: String,
    subtitle: String,
    badge: String,
    modifier: Modifier,
    onClick: () -> Unit
) {
    val accent = theme.accentColor(preset)
    Column(
        modifier = modifier.height(106.dp).omegaGlassCard(22.dp, theme, preset).clickable(onClick = onClick).padding(14.dp),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier.size(34.dp).clip(CircleShape)
                    .background(Brush.linearGradient(listOf(Color(preset.primaryHex).copy(0.28f), Color(preset.secondaryHex).copy(0.22f)))),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, title, tint = accent, modifier = Modifier.size(18.dp))
            }
            Box(modifier = Modifier.clip(RoundedCornerShape(8.dp)).background(accent.copy(0.14f)).padding(horizontal = 7.dp, vertical = 2.dp)) {
                Text(badge, color = accent, fontSize = 9.5.sp, fontWeight = FontWeight.Bold)
            }
        }
        Column {
            Text(title, fontSize = 14.5.sp, fontWeight = FontWeight.Bold, color = theme.primaryText())
            Text(subtitle, fontSize = 11.sp, color = theme.mutedText(), maxLines = 1)
        }
    }
}

@Composable
private fun ListeningScreen(
    uiState: PanduUiState,
    onBack: () -> Unit,
    onChat: () -> Unit,
    onUnmuteClick: () -> Unit,
    onToggleMic: () -> Unit,
    onCycleLang: () -> Unit,
    onToggleAutoSpeak: () -> Unit,
    onToggleLiveMode: () -> Unit
) {
    val theme = uiState.settings.visualTheme
    val preset = uiState.settings.orbColorPreset
    val accent = theme.accentColor(preset)
    val isLive = uiState.settings.useGeminiLiveAudio
    val activeAmp = if (isLive) uiState.liveDuplexState.amplitude else uiState.audioAmplitude
    val isActive = if (isLive) uiState.liveDuplexState.isConnected else uiState.isListening

    val orbState = when {
        uiState.voiceError != null || uiState.liveDuplexState.error != null -> "error"
        uiState.isThinking -> "thinking"
        uiState.isSpeaking || uiState.liveDuplexState.isAiSpeaking -> "speaking"
        isActive -> "listening"
        else -> "idle"
    }

    val header = when {
        uiState.settings.micPrivacyMuted -> "Microphone Muted"
        isLive -> uiState.liveDuplexState.statusText
        uiState.liveToolStatus != null -> uiState.liveToolStatus
        uiState.isListening -> "Listening..."
        uiState.isThinking -> "Thinking..."
        uiState.isSpeaking -> "Speaking..."
        else -> "Tap orb to speak"
    }

    val subtitle = when {
        uiState.settings.micPrivacyMuted -> "Microphone Privacy Mute is enabled. Tap Unmute Mic below."
        isLive && uiState.liveDuplexState.error != null -> uiState.liveDuplexState.error
        isLive -> "Gemini Live Duplex Voice Active"
        uiState.voiceError != null -> uiState.voiceError
        uiState.liveTranscript.isNotBlank() && uiState.isListening -> "\"${uiState.liveTranscript}\""
        uiState.isThinking -> uiState.liveToolStatus ?: "Processing \"${uiState.liveTranscript}\"..."
        uiState.lastAiReply.isNotBlank() -> uiState.lastAiReply
        else -> "Speak naturally in Telugu, English, or Tenglish."
    }

    OmegaLiquidBackdrop(theme = theme, preset = preset) {
        Column(
            modifier = Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(horizontal = 20.dp, vertical = 14.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                GlassCircleButton(Icons.AutoMirrored.Rounded.ArrowBack, theme = theme, preset = preset, onClick = onBack)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Box(modifier = Modifier.omegaGlassCard(18.dp, theme, preset).clickable { onToggleLiveMode() }.padding(horizontal = 12.dp, vertical = 8.dp)) {
                        Text(if (isLive) "Live WS" else "Voice Agent", color = accent, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                    if (!isLive) {
                        val langLabel = when (uiState.settings.languageTag) { "te-IN" -> "తెలుగు"; "en-IN" -> "EN-IN"; else -> "AUTO" }
                        Box(modifier = Modifier.omegaGlassCard(18.dp, theme, preset).clickable { onCycleLang() }.padding(horizontal = 12.dp, vertical = 8.dp)) {
                            Text(langLabel, color = theme.primaryText(), fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                        }
                    }
                }
                GlassCircleButton(if (uiState.settings.autoSpeak) Icons.AutoMirrored.Rounded.VolumeUp else Icons.AutoMirrored.Rounded.VolumeOff, theme = theme, preset = preset, onClick = onToggleAutoSpeak)
            }

            Spacer(modifier = Modifier.height(22.dp))
            Text(header, fontSize = 22.sp, fontWeight = FontWeight.Bold, color = theme.primaryText(), textAlign = TextAlign.Center)
            Spacer(modifier = Modifier.height(18.dp))

            AdaptiveCentralOrb(
                theme = theme,
                preset = preset,
                orbState = orbState,
                audioLevel = if (uiState.isThinking) 0.55f else activeAmp,
                size = 216.dp,
                parallaxEnabled = uiState.settings.gyroscopeParallax,
                onClick = { if (uiState.settings.micPrivacyMuted) onUnmuteClick() else onToggleMic() }
            )

            Spacer(modifier = Modifier.height(20.dp))
            Box(
                modifier = Modifier.fillMaxWidth().heightIn(min = 72.dp, max = 165.dp).omegaGlassCard(20.dp, theme, preset).padding(16.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(subtitle, fontSize = 14.sp, color = if (orbState == "error" || uiState.settings.micPrivacyMuted) OmegaColors.CrimsonErr else theme.primaryText(), textAlign = TextAlign.Center, lineHeight = 20.sp)
                    if (uiState.settings.micPrivacyMuted) {
                        Button(onClick = onUnmuteClick, colors = ButtonDefaults.buttonColors(containerColor = OmegaColors.EmeraldLive), shape = RoundedCornerShape(14.dp)) {
                            Text("Unmute Mic & Listen", color = Color.White, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.weight(1f))
            InteractiveVoiceSpectrum(isActive = isActive || uiState.isSpeaking || uiState.liveDuplexState.isAiSpeaking, amplitude = activeAmp, preset = preset)
            Spacer(modifier = Modifier.height(20.dp))

            Row(modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
                GlassCircleButton(Icons.Rounded.ChatBubbleOutline, 50.dp, theme, preset, onChat)
                Box(
                    modifier = Modifier.size(74.dp).clip(CircleShape).background(accent.copy(0.25f)).clickable {
                        if (uiState.settings.micPrivacyMuted) onUnmuteClick() else onToggleMic()
                    },
                    contentAlignment = Alignment.Center
                ) {
                    Box(
                        modifier = Modifier.size(58.dp).clip(CircleShape).background(
                            Brush.linearGradient(
                                if (isActive) listOf(OmegaColors.CrimsonErr, Color(0xFFF97316))
                                else listOf(Color(preset.primaryHex), Color(preset.secondaryHex), Color(preset.accentHex))
                            )
                        ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(if (isActive) Icons.Rounded.Stop else Icons.Rounded.Mic, "Mic", tint = Color.White, modifier = Modifier.size(28.dp))
                    }
                }
                GlassCircleButton(Icons.Rounded.Close, 50.dp, theme, preset, onBack)
            }
        }
    }
}

@Composable
private fun InteractiveVoiceSpectrum(isActive: Boolean, amplitude: Float, preset: OrbColorPreset) {
    val weights = listOf(0.35f, 0.65f, 0.90f, 1.0f, 0.78f, 0.95f, 0.60f, 0.40f)
    val inf = rememberInfiniteTransition(label = "spec")
    val barBrush = Brush.verticalGradient(listOf(Color(preset.primaryHex), Color(preset.secondaryHex)))
    Row(horizontalArrangement = Arrangement.spacedBy(5.dp), verticalAlignment = Alignment.CenterVertically, modifier = Modifier.height(42.dp)) {
        weights.forEachIndexed { idx, w ->
            val h by inf.animateFloat(
                8f,
                if (isActive) (16f + amplitude * 28f) * w else 8f,
                infiniteRepeatable(tween(280 + idx * 55, easing = FastOutSlowInEasing), RepeatMode.Reverse),
                label = "sp$idx"
            )
            Box(modifier = Modifier.width(4.5.dp).height(h.coerceIn(6f, 40f).dp).clip(RoundedCornerShape(4.dp)).background(barBrush))
        }
    }
}

@Composable
private fun ChatScreen(
    uiState: PanduUiState,
    onBack: () -> Unit,
    onMic: () -> Unit,
    onCamera: () -> Unit,
    onSummarize: () -> Unit,
    onConfirmReply: () -> Unit,
    onCancelReply: () -> Unit,
    onSend: (String) -> Unit,
    onSpeak: (String) -> Unit
) {
    val theme = uiState.settings.visualTheme
    val preset = uiState.settings.orbColorPreset
    val accent = theme.accentColor(preset)
    var text by remember { mutableStateOf("") }
    val listState = rememberLazyListState()

    LaunchedEffect(uiState.messages.size, uiState.isThinking) {
        if (uiState.messages.isNotEmpty()) listState.animateScrollToItem(uiState.messages.lastIndex)
    }

    OmegaLiquidBackdrop(theme = theme, preset = preset) {
        Column(modifier = Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(horizontal = 16.dp, vertical = 12.dp)) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                GlassCircleButton(Icons.AutoMirrored.Rounded.ArrowBack, theme = theme, preset = preset, onClick = onBack)
                Text(if (uiState.lastLatencyMs > 0) "Supreme Chat (${uiState.lastLatencyMs}ms)" else "Supreme Chat", color = theme.primaryText(), fontSize = 16.sp, fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    GlassCircleButton(Icons.Rounded.Summarize, theme = theme, preset = preset, onClick = onSummarize)
                    GlassCircleButton(Icons.Rounded.CameraAlt, theme = theme, preset = preset, onClick = onCamera)
                }
            }

            AnimatedVisibility(visible = uiState.pendingNotifReply != null) {
                val p = uiState.pendingNotifReply
                if (p != null) {
                    Column(modifier = Modifier.fillMaxWidth().padding(top = 10.dp).omegaGlassCard(18.dp, theme, preset).padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("Confirm Reply to ${p.resolvedTitle} (${p.appName})", color = accent, fontSize = 12.5.sp, fontWeight = FontWeight.Bold)
                        Text("\"${p.replyText}\"", color = theme.primaryText(), fontSize = 13.sp)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = onConfirmReply, colors = ButtonDefaults.buttonColors(containerColor = OmegaColors.EmeraldLive), shape = RoundedCornerShape(12.dp)) { Text("Send", color = Color.White, fontSize = 12.sp) }
                            OutlinedButton(onClick = onCancelReply, shape = RoundedCornerShape(12.dp)) { Text("Cancel", color = theme.primaryText(), fontSize = 12.sp) }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))
            LazyColumn(state = listState, modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                items(uiState.messages, key = { it.id }) { m ->
                    if (m.isFromUser) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                            Column(
                                modifier = Modifier.widthIn(max = 280.dp).clip(RoundedCornerShape(20.dp))
                                    .background(Brush.linearGradient(listOf(Color(preset.secondaryHex), Color(preset.primaryHex).copy(0.85f))))
                                    .padding(horizontal = 14.dp, vertical = 10.dp)
                            ) {
                                if (m.isVoiceInput) Text("Voice • ${m.audioDuration}", color = Color.White.copy(0.85f), fontSize = 10.5.sp, fontWeight = FontWeight.SemiBold)
                                if (m.hasImageAttachment) Text("Vision Image Attached", color = Color.White.copy(0.9f), fontSize = 10.5.sp, fontWeight = FontWeight.SemiBold)
                                Text(m.text, color = Color.White, fontSize = 13.5.sp, lineHeight = 19.sp)
                            }
                        }
                    } else {
                        Row(modifier = Modifier.fillMaxWidth(0.92f), verticalAlignment = Alignment.Top, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            ParticleAiOrb(size = 26.dp, preset = preset)
                            Column(modifier = Modifier.omegaGlassCard(18.dp, theme, preset).padding(horizontal = 14.dp, vertical = 11.dp)) {
                                if (m.executedTools.isNotEmpty()) {
                                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.padding(bottom = 5.dp)) {
                                        m.executedTools.distinct().take(3).forEach { tool ->
                                            Box(modifier = Modifier.clip(RoundedCornerShape(10.dp)).background(accent.copy(0.18f)).padding(horizontal = 8.dp, vertical = 2.dp)) {
                                                Text(tool, color = accent, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                            }
                                        }
                                    }
                                }
                                Text(m.text, color = if (m.isError) OmegaColors.CrimsonErr else theme.primaryText(), fontSize = 13.5.sp, lineHeight = 19.sp)
                                if (!m.isError) {
                                    Spacer(modifier = Modifier.height(5.dp))
                                    Row(modifier = Modifier.clickable { onSpeak(m.text) }, verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                        Icon(Icons.AutoMirrored.Rounded.VolumeUp, null, tint = accent, modifier = Modifier.size(14.dp))
                                        Text("Listen", color = accent, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                                    }
                                }
                            }
                        }
                    }
                }
                if (uiState.isThinking) {
                    item {
                        Box(modifier = Modifier.omegaGlassCard(16.dp, theme, preset).padding(horizontal = 14.dp, vertical = 10.dp)) {
                            Text(uiState.liveToolStatus ?: "OMEGA 19 Ultra thinking...", color = accent, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))
            Row(modifier = Modifier.fillMaxWidth().omegaGlassCard(28.dp, theme, preset).padding(horizontal = 8.dp, vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onCamera) { Icon(Icons.Rounded.Add, "Camera Vision", tint = accent) }
                TextField(
                    value = text,
                    onValueChange = { text = it },
                    placeholder = { Text("Type your message...", color = theme.mutedText(), fontSize = 14.sp) },
                    colors = TextFieldDefaults.colors(
                        focusedContainerColor = Color.Transparent, unfocusedContainerColor = Color.Transparent,
                        focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent,
                        focusedTextColor = theme.primaryText(), unfocusedTextColor = theme.primaryText()
                    ),
                    singleLine = true,
                    modifier = Modifier.weight(1f)
                )
                IconButton(onClick = onMic) { Icon(Icons.Rounded.Mic, "Voice", tint = accent) }
                Box(
                    modifier = Modifier.size(40.dp).clickable { if (text.isNotBlank() && !uiState.isThinking) { onSend(text); text = "" } },
                    contentAlignment = Alignment.Center
                ) {
                    ParticleAiOrb(size = 38.dp, preset = preset)
                    Icon(Icons.AutoMirrored.Rounded.Send, "Send", tint = Color.White, modifier = Modifier.size(16.dp))
                }
            }
        }
    }
}

@Composable
fun GlassCircleButton(
    icon: ImageVector,
    size: Dp = 42.dp,
    theme: OmegaVisualTheme,
    preset: OrbColorPreset = OrbColorPreset.AURORA_CYAN,
    onClick: () -> Unit
) {
    IconButton(onClick = onClick, modifier = Modifier.size(size).omegaGlassCard(size / 2, theme, preset)) {
        Icon(icon, contentDescription = null, tint = theme.primaryText(), modifier = Modifier.size(20.dp))
    }
}
