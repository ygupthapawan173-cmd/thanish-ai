package com.example.ui.theme

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.SwitchColors
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.TextFieldColors
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.data.OmegaVisualTheme
import com.example.data.OrbColorPreset
import kotlin.math.cos
import kotlin.math.sin

object OmegaColors {
    val ObsidianTop = Color(0xFF030712)
    val ObsidianMid = Color(0xFF0A1328)
    val ObsidianBottom = Color(0xFF0F0D24)

    val RoyalTop = Color(0xFF0B0A22)
    val RoyalMid = Color(0xFF16133B)
    val RoyalBottom = Color(0xFF09152E)

    val ElectricCyan = Color(0xFF00E5FF)
    val RoyalIndigo = Color(0xFF6366F1)
    val CoralRose = Color(0xFFFF4D94)
    val EmeraldLive = Color(0xFF10B981)
    val AmberWarn = Color(0xFFF59E0B)
    val CrimsonErr = Color(0xFFF43F5E)
}

fun OmegaVisualTheme.isDark(): Boolean = true
fun OmegaVisualTheme.primaryText(): Color = Color(0xFFF4F7FF)
fun OmegaVisualTheme.mutedText(): Color = Color(0xFF93A8CE)
fun OmegaVisualTheme.accentColor(preset: OrbColorPreset): Color = Color(preset.primaryHex)

@Composable
fun omegaSwitchColors(theme: OmegaVisualTheme, preset: OrbColorPreset): SwitchColors {
    val accent = Color(preset.primaryHex)
    return SwitchDefaults.colors(
        checkedThumbColor = Color(0xFF040814),
        checkedTrackColor = accent,
        checkedBorderColor = accent,
        uncheckedThumbColor = Color(0xFF94A3B8),
        uncheckedTrackColor = Color(0xFF172036),
        uncheckedBorderColor = Color.White.copy(0.14f)
    )
}

@Composable
fun omegaTextFieldColors(theme: OmegaVisualTheme, preset: OrbColorPreset): TextFieldColors {
    val accent = Color(preset.primaryHex)
    return OutlinedTextFieldDefaults.colors(
        focusedBorderColor = accent,
        unfocusedBorderColor = Color.White.copy(0.16f),
        focusedContainerColor = Color(0x88050A18),
        unfocusedContainerColor = Color(0x55050A18),
        focusedTextColor = Color(0xFFF4F7FF),
        unfocusedTextColor = Color(0xFFE2E8F0),
        focusedLabelColor = accent,
        unfocusedLabelColor = Color(0xFF93A8CE),
        cursorColor = accent
    )
}

fun Modifier.omegaBackground(theme: OmegaVisualTheme): Modifier = this.background(
    brush = if (theme == OmegaVisualTheme.MIDNIGHT_ROYAL) {
        Brush.linearGradient(listOf(OmegaColors.RoyalTop, OmegaColors.RoyalMid, OmegaColors.RoyalBottom), Offset(0f, 0f), Offset(950f, 2000f))
    } else {
        Brush.linearGradient(listOf(OmegaColors.ObsidianTop, OmegaColors.ObsidianMid, OmegaColors.ObsidianBottom), Offset(0f, 0f), Offset(950f, 2000f))
    }
)

@Composable
fun OmegaLiquidBackdrop(
    theme: OmegaVisualTheme,
    preset: OrbColorPreset,
    modifier: Modifier = Modifier,
    content: @Composable BoxScope.() -> Unit
) {
    val inf = rememberInfiniteTransition(label = "liquidMesh")
    val phase by inf.animateFloat(0f, (2 * Math.PI).toFloat(), infiniteRepeatable(tween(15000, easing = LinearEasing)), label = "p")
    val cPrimary = Color(preset.primaryHex)
    val cSecondary = Color(preset.secondaryHex)
    val cAccent = Color(preset.accentHex)

    Box(modifier = modifier.fillMaxSize().omegaBackground(theme)) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width; val h = size.height
            val p1 = Offset(w * (0.16f + 0.08f * cos(phase)), h * (0.12f + 0.05f * sin(phase)))
            val p2 = Offset(w * (0.86f + 0.08f * sin(phase)), h * (0.80f + 0.05f * cos(phase)))
            val p3 = Offset(w * 0.50f, h * (0.38f + 0.03f * sin(phase * 1.4f)))
            drawCircle(Brush.radialGradient(listOf(cPrimary.copy(0.18f), Color.Transparent), p1, w * 0.80f), w * 0.80f, p1)
            drawCircle(Brush.radialGradient(listOf(cSecondary.copy(0.22f), Color.Transparent), p2, w * 0.76f), w * 0.76f, p2)
            drawCircle(Brush.radialGradient(listOf(cAccent.copy(0.12f), Color.Transparent), p3, w * 0.65f), w * 0.65f, p3)
        }
        content()
    }
}

fun Modifier.omegaGlassCard(
    cornerRadius: Dp = 24.dp,
    theme: OmegaVisualTheme,
    preset: OrbColorPreset = OrbColorPreset.AURORA_CYAN
): Modifier {
    val cPrimary = Color(preset.primaryHex)
    val cSecondary = Color(preset.secondaryHex)
    return this
        .shadow(
            elevation = 14.dp,
            shape = RoundedCornerShape(cornerRadius),
            ambientColor = cPrimary.copy(0.22f),
            spotColor = cSecondary.copy(0.24f)
        )
        .clip(RoundedCornerShape(cornerRadius))
        .background(Brush.linearGradient(listOf(Color(0xE0111D38), Color(0xCC091024))))
        .border(
            width = 1.1.dp,
            brush = Brush.linearGradient(listOf(cPrimary.copy(0.45f), cSecondary.copy(0.22f), Color.White.copy(0.10f))),
            shape = RoundedCornerShape(cornerRadius)
        )
}
