package com.example.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.data.OrbColorPreset
import kotlin.math.cos
import kotlin.math.sin

/**
 * Volumetric 3D J.A.R.V.I.S. Plasma & Holographic HUD Orb (v19 Ultra):
 * Multi-layered glowing nebula clouds, rotating segmented HUD telemetry arcs,
 * luminous stardust particles, and deep glass Fresnel rim lighting.
 */
@Composable
fun ParticleAiOrb(
    size: Dp = 180.dp,
    isListening: Boolean = false,
    audioAmplitude: Float = 0f,
    preset: OrbColorPreset = OrbColorPreset.AURORA_CYAN,
    modifier: Modifier = Modifier
) {
    val inf = rememberInfiniteTransition(label = "volumetricOrb")
    val smoothAmp by animateFloatAsState(
        targetValue = audioAmplitude.coerceIn(0f, 1f),
        animationSpec = spring(stiffness = Spring.StiffnessMediumLow),
        label = "amp"
    )
    val rotFast by inf.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(if (isListening) 5500 else 14000, easing = LinearEasing)),
        label = "rotF"
    )
    val rotSlow by inf.animateFloat(
        initialValue = 360f,
        targetValue = 0f,
        animationSpec = infiniteRepeatable(tween(if (isListening) 9000 else 22000, easing = LinearEasing)),
        label = "rotS"
    )
    val breathe by inf.animateFloat(
        initialValue = 0.96f,
        targetValue = 1.04f,
        animationSpec = infiniteRepeatable(tween(2200, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "breathe"
    )

    val c1 = Color(preset.primaryHex)
    val c2 = Color(preset.secondaryHex)
    val c3 = Color(preset.accentHex)
    val scale = if (isListening) 1f + smoothAmp * 0.12f else breathe
    val isMini = size.value < 55f

    Canvas(
        modifier = modifier
            .size(size * scale)
            .shadow(
                elevation = if (isMini) 8.dp else (28 + smoothAmp * 18).dp,
                shape = CircleShape,
                ambientColor = c1,
                spotColor = c2
            )
            .clip(CircleShape)
    ) {
        val w = this.size.width
        val h = this.size.height
        val r = this.size.minDimension / 2f
        val center = Offset(w / 2f, h / 2f)

        // 1. Deep Obsidian Sphere Base
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(Color(0xFF0E1B3B), Color(0xFF070D21), Color(0xFF030612)),
                center = center,
                radius = r
            )
        )

        // 2. Volumetric Orbiting Plasma Clouds (Smooth, glowing, organic — no flat stripes!)
        val rad1 = Math.toRadians(rotFast.toDouble())
        val rad2 = Math.toRadians(rotSlow.toDouble() + 120.0)
        val rad3 = Math.toRadians(rotFast.toDouble() * 0.7 + 240.0)

        val orbShift = r * (0.26f + smoothAmp * 0.14f)
        val lobe1 = Offset(center.x + (cos(rad1) * orbShift).toFloat(), center.y + (sin(rad1) * orbShift).toFloat())
        val lobe2 = Offset(center.x + (cos(rad2) * orbShift).toFloat(), center.y + (sin(rad2) * orbShift).toFloat())
        val lobe3 = Offset(center.x + (cos(rad3) * orbShift * 0.85f).toFloat(), center.y + (sin(rad3) * orbShift * 0.85f).toFloat())

        drawCircle(
            brush = Brush.radialGradient(listOf(c1.copy(0.82f), c1.copy(0.28f), Color.Transparent), lobe1, r * 0.88f),
            radius = r * 0.88f,
            center = lobe1
        )
        drawCircle(
            brush = Brush.radialGradient(listOf(c2.copy(0.78f), c2.copy(0.24f), Color.Transparent), lobe2, r * 0.85f),
            radius = r * 0.85f,
            center = lobe2
        )
        drawCircle(
            brush = Brush.radialGradient(listOf(c3.copy(0.68f), c3.copy(0.18f), Color.Transparent), lobe3, r * 0.76f),
            radius = r * 0.76f,
            center = lobe3
        )

        // 3. Incandescent White-Cyan Core Singularity
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(Color.White.copy(0.95f), c1.copy(0.70f), Color.Transparent),
                center = center,
                radius = r * (0.42f + smoothAmp * 0.18f)
            ),
            radius = r * (0.42f + smoothAmp * 0.18f),
            center = center
        )

        // 4. Holographic J.A.R.V.I.S. Segmented HUD Arcs (on full-size orb)
        if (!isMini) {
            rotate(degrees = rotFast, pivot = center) {
                val arcR = r * 0.78f
                val tl = Offset(center.x - arcR, center.y - arcR)
                val sz = Size(arcR * 2, arcR * 2)
                drawArc(c1.copy(0.75f), 0f, 70f, false, tl, sz, style = Stroke(2.2.dp.toPx(), cap = StrokeCap.Round))
                drawArc(c3.copy(0.60f), 120f, 55f, false, tl, sz, style = Stroke(1.8.dp.toPx(), cap = StrokeCap.Round))
                drawArc(Color.White.copy(0.65f), 220f, 80f, false, tl, sz, style = Stroke(1.5.dp.toPx(), cap = StrokeCap.Round))
            }
            rotate(degrees = rotSlow, pivot = center) {
                val arcR2 = r * 0.60f
                val tl2 = Offset(center.x - arcR2, center.y - arcR2)
                val sz2 = Size(arcR2 * 2, arcR2 * 2)
                drawArc(Color.White.copy(0.45f), 30f, 95f, false, tl2, sz2, style = Stroke(1.4.dp.toPx(), cap = StrokeCap.Round))
                drawArc(c2.copy(0.70f), 200f, 110f, false, tl2, sz2, style = Stroke(1.8.dp.toPx(), cap = StrokeCap.Round))
            }
        }

        // 5. Orbiting Luminous Micro-Particles
        val count = if (isMini) 6 else 22
        for (i in 0 until count) {
            val a = Math.toRadians((rotFast * (if (i % 2 == 0) 1.0 else -0.8)) + i * (360.0 / count))
            val pr = r * (0.35f + (i % 5) * 0.11f) * (1f + smoothAmp * 0.08f)
            val px = center.x + (cos(a) * pr).toFloat()
            val py = center.y + (sin(a * 1.1) * pr * 0.9f).toFloat()
            val pRadius = (if (isMini) 1.1f else (1.2f + (i % 3) * 0.9f)).dp.toPx()
            drawCircle(
                color = if (i % 3 == 0) Color.White.copy(0.9f) else c1.copy(0.8f),
                radius = pRadius,
                center = Offset(px, py)
            )
        }

        // 6. Glass Sphere Specular Dome & Fresnel Rim
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(Color.White.copy(0.42f), Color.Transparent),
                center = Offset(center.x - r * 0.34f, center.y - r * 0.36f),
                radius = r * 0.48f
            )
        )
        drawCircle(
            brush = Brush.sweepGradient(listOf(c1.copy(0.80f), c2.copy(0.55f), c3.copy(0.70f), c1.copy(0.80f))),
            radius = r - 1.5.dp.toPx(),
            center = center,
            style = Stroke(width = 2.dp.toPx())
        )
    }
}
