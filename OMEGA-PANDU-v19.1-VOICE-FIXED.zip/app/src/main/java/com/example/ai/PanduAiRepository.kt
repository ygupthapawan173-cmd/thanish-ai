package com.example.ai

import com.example.control.DeviceActionExecutor
import com.example.control.NotificationInbox
import com.example.data.AiProvider
import com.example.data.ApiQuotaTracker
import com.example.data.AppDatabase
import com.example.data.OmegaSettings
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

data class AgentReplyResult(
    val replyText: String,
    val executedTools: List<String> = emptyList(),
    val latencyMs: Long = 0L,
    val usedModel: String = ""
)

data class ConnectionDiagnosticResult(
    val isSuccess: Boolean,
    val provider: AiProvider,
    val modelId: String,
    val latencyMs: Long,
    val summary: String
)

class PanduAiRepository(
    private val settingsProvider: () -> OmegaSettings,
    private val actionExecutor: DeviceActionExecutor,
    private val database: AppDatabase
) {
    private val localRouter = LocalCommandRouter(actionExecutor, database)
    private val localBrain = LocalBrainEngine(localRouter, actionExecutor, database)
    private val discoveryService = ModelDiscoveryService()
    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(50, TimeUnit.SECONDS)
        .writeTimeout(25, TimeUnit.SECONDS)
        .build()

    private val conversationHistory = mutableListOf<JSONObject>()
    @Volatile private var cachedDiscoveredGeminiModels: List<String> = emptyList()

    fun seedHistoryFromDatabase() {
        conversationHistory.clear()
        database.getRecentMessages(limit = 16).forEach { msg ->
            if (!msg.isError && msg.text.isNotBlank()) {
                conversationHistory.add(
                    JSONObject().put("role", if (msg.isFromUser) "user" else "model")
                        .put("parts", JSONArray().put(JSONObject().put("text", msg.text)))
                )
            }
        }
    }

    fun clearHistory() { conversationHistory.clear() }

    /**
     * Dedicated raw engineering call for SelfCodingEngine (Gemini -> OpenRouter fallback).
     */
    suspend fun sendRawEngineeringPrompt(prompt: String): Result<String> = withContext(Dispatchers.IO) {
        val s = settingsProvider()
        val geminiKey = s.effectiveGeminiKey()
        val orKey = s.effectiveOpenRouterKey()
        val startMs = System.currentTimeMillis()

        if (s.activeProvider == AiProvider.OPENROUTER && orKey.isNotBlank()) {
            return@withContext runCatching {
                val r = postOpenRouter(orKey, s.openRouterModel, prompt, "You are a senior Android Kotlin engineer. Output clean, secure code.")
                ApiQuotaTracker.recordSuccess(s.openRouterModel, prompt.length, r.length, System.currentTimeMillis() - startMs)
                r
            }
        }

        if (geminiKey.isNotBlank()) {
            val res = runCatching {
                val payload = JSONObject().put(
                    "contents",
                    JSONArray().put(JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("text", prompt))))
                )
                val (json, model) = postGeminiWithFallback(geminiKey, buildGeminiFallbackList(s.geminiChatModel), payload)
                val txt = json.optJSONArray("candidates")?.optJSONObject(0)?.optJSONObject("content")
                    ?.optJSONArray("parts")?.optJSONObject(0)?.optString("text", "").orEmpty().trim()
                if (txt.isBlank()) throw IOException("Empty code response from Gemini.")
                ApiQuotaTracker.recordSuccess(model, prompt.length, txt.length, System.currentTimeMillis() - startMs)
                txt
            }
            if (res.isSuccess) return@withContext res
            if (orKey.isNotBlank()) {
                return@withContext runCatching {
                    val r = postOpenRouter(orKey, s.openRouterModel, prompt, "You are a senior Android Kotlin engineer.")
                    ApiQuotaTracker.recordSuccess(s.openRouterModel, prompt.length, r.length, System.currentTimeMillis() - startMs)
                    r
                }
            }
            return@withContext res
        }

        if (orKey.isNotBlank()) {
            return@withContext runCatching {
                postOpenRouter(orKey, s.openRouterModel, prompt, "You are a senior Android Kotlin engineer.")
            }
        }
        Result.failure(IllegalStateException("Configure Gemini or OpenRouter API key for AI Self-Coding."))
    }

    suspend fun discoverModelsForActiveProvider(): Result<DiscoveredModelsResult> {
        val s = settingsProvider()
        return when (s.activeProvider) {
            AiProvider.GEMINI -> {
                val res = discoveryService.discoverGeminiModels(s.effectiveGeminiKey())
                res.onSuccess { cachedDiscoveredGeminiModels = it.chatModels }
                res
            }
            AiProvider.OPENROUTER -> {
                discoveryService.discoverOpenRouterModels(s.effectiveOpenRouterKey()).map { list ->
                    DiscoveredModelsResult(list, emptyList(), "Discovered ${list.size} OpenRouter models.")
                }
            }
        }
    }

    suspend fun runConnectionDiagnostic(provider: AiProvider): ConnectionDiagnosticResult = withContext(Dispatchers.IO) {
        val s = settingsProvider()
        val startMs = System.currentTimeMillis()
        val key = if (provider == AiProvider.GEMINI) s.effectiveGeminiKey() else s.effectiveOpenRouterKey()
        val model = if (provider == AiProvider.GEMINI) s.geminiChatModel.trim() else s.openRouterModel.trim()

        if (key.isBlank()) {
            return@withContext ConnectionDiagnosticResult(false, provider, model, 0L, "${provider.displayName} API key is empty.")
        }

        return@withContext try {
            val reply = when (provider) {
                AiProvider.GEMINI -> {
                    val payload = JSONObject().put(
                        "contents",
                        JSONArray().put(JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("text", "Reply OK."))))
                    )
                    val res = postGemini(key, model, payload)
                    res.optJSONArray("candidates")?.optJSONObject(0)?.optJSONObject("content")
                        ?.optJSONArray("parts")?.optJSONObject(0)?.optString("text", "")?.trim().orEmpty().ifBlank { "OK" }
                }
                AiProvider.OPENROUTER -> postOpenRouter(key, model, "Reply OK.", "Be concise.")
            }
            val elapsed = System.currentTimeMillis() - startMs
            ApiQuotaTracker.recordSuccess(model, 10, reply.length, elapsed)
            ConnectionDiagnosticResult(true, provider, model, elapsed, "CONNECTED (${elapsed}ms) • $model • $reply")
        } catch (e: Exception) {
            val elapsed = System.currentTimeMillis() - startMs
            ApiQuotaTracker.recordFailure()
            ConnectionDiagnosticResult(false, provider, model, elapsed, "FAILED (${elapsed}ms): ${e.message}")
        }
    }

    private fun runGroundedGoogleSearch(apiKey: String, model: String, query: String): String {
        return try {
            val payload = JSONObject().apply {
                put("contents", JSONArray().put(JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("text", "Search live web and answer concisely: $query")))))
                put("tools", JSONArray().put(JSONObject().put("google_search", JSONObject())))
            }
            val res = postGemini(apiKey, model, payload)
            val parts = res.optJSONArray("candidates")?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts")
                ?: return "No live web results found."
            val sb = StringBuilder()
            for (i in 0 until parts.length()) {
                val t = parts.getJSONObject(i).optString("text", "")
                if (t.isNotBlank()) sb.append(t).append(" ")
            }
            sb.toString().trim().ifBlank { "No live web results found." }
        } catch (e: Exception) {
            "Live web search failed: ${e.message}"
        }
    }

    suspend fun sendMessage(
        userMessage: String,
        attachedImageBase64: String? = null,
        onToolStatus: (String) -> Unit = {}
    ): Result<AgentReplyResult> = withContext(Dispatchers.IO) {
        val settings = settingsProvider()
        val startMs = System.currentTimeMillis()

        // 0. 100% On-Device Local Brain Mode (Zero Internet, Zero API Cost!)
        if (settings.localBrainMode && attachedImageBase64.isNullOrBlank()) {
            val local = localBrain.processOffline(userMessage, settings)
            rememberTurn(userMessage, local.text)
            return@withContext Result.success(
                AgentReplyResult(local.text, local.toolsUsed, (System.currentTimeMillis() - startMs).coerceAtLeast(1L), local.engineTag)
            )
        }

        // 1. Offline Instant Fast-Path for phone commands
        if (attachedImageBase64.isNullOrBlank() && settings.offlineFastCommands) {
            val localHit = localRouter.tryHandleInstant(userMessage)
            if (localHit != null) {
                rememberTurn(userMessage, localHit.replyText)
                return@withContext Result.success(
                    AgentReplyResult(localHit.replyText, listOf(localHit.executedTool, "offline_instant"), (System.currentTimeMillis() - startMs).coerceAtLeast(1L), "local-instant")
                )
            }
        }

        // 2. OpenRouter Path if active
        if (settings.activeProvider == AiProvider.OPENROUTER) {
            val orKey = settings.effectiveOpenRouterKey()
            if (orKey.isBlank()) {
                // Automatic Local Brain fallback when no keys are configured
                val local = localBrain.processOffline(userMessage, settings)
                return@withContext Result.success(AgentReplyResult(local.text, local.toolsUsed, (System.currentTimeMillis() - startMs).coerceAtLeast(1L), local.engineTag))
            }
            return@withContext try {
                val reply = postOpenRouter(orKey, settings.openRouterModel, userMessage, buildContextAwareSystemPrompt(settings, userMessage))
                val lat = System.currentTimeMillis() - startMs
                ApiQuotaTracker.recordSuccess(settings.openRouterModel, userMessage.length, reply.length, lat)
                rememberTurn(userMessage, reply)
                Result.success(AgentReplyResult(reply, emptyList(), lat, settings.openRouterModel))
            } catch (e: Exception) {
                ApiQuotaTracker.recordFailure()
                val local = localBrain.processOffline(userMessage, settings)
                Result.success(AgentReplyResult("${local.text}\n(Cloud unreachable: ${e.message})", local.toolsUsed + "offline_fallback", System.currentTimeMillis() - startMs, local.engineTag))
            }
        }

        // 3. Gemini Path with 404/429 Fallback -> OpenRouter Failover -> 100% On-Device Local Brain Fallback
        val geminiKey = settings.effectiveGeminiKey()
        if (geminiKey.isBlank()) {
            val orKey = settings.effectiveOpenRouterKey()
            if (orKey.isNotBlank()) {
                return@withContext runCatching {
                    val r = postOpenRouter(orKey, settings.openRouterModel, userMessage, buildContextAwareSystemPrompt(settings, userMessage))
                    val lat = System.currentTimeMillis() - startMs
                    ApiQuotaTracker.recordSuccess(settings.openRouterModel, userMessage.length, r.length, lat)
                    rememberTurn(userMessage, r)
                    AgentReplyResult(r, listOf("openrouter_failover"), lat, settings.openRouterModel)
                }
            }
            val local = localBrain.processOffline(userMessage, settings)
            return@withContext Result.success(AgentReplyResult(local.text, local.toolsUsed, (System.currentTimeMillis() - startMs).coerceAtLeast(1L), local.engineTag))
        }

        val executedTools = mutableListOf<String>()
        val fallbackChain = buildGeminiFallbackList(settings.geminiChatModel)
        var activeModel = fallbackChain.first()

        try {
            val userParts = JSONArray().apply {
                put(JSONObject().put("text", userMessage))
                if (!attachedImageBase64.isNullOrBlank()) {
                    put(JSONObject().put("inline_data", JSONObject().put("mime_type", "image/jpeg").put("data", attachedImageBase64)))
                }
            }

            val workingContents = JSONArray().apply {
                conversationHistory.forEach { put(it) }
                put(JSONObject().put("role", "user").put("parts", userParts))
            }

            var finalReplyText = ""

            for (hop in 0 until 8) {
                val payload = JSONObject().apply {
                    put("system_instruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", buildContextAwareSystemPrompt(settings, userMessage)))))
                    put("contents", workingContents)
                    put("tools", buildToolsSchema(includeWebSearch = settings.webSearchGrounding))
                }

                val (responseJson, resolvedModel) = postGeminiWithFallback(geminiKey, fallbackChain, payload)
                activeModel = resolvedModel

                val modelContent = responseJson.optJSONArray("candidates")?.optJSONObject(0)?.optJSONObject("content")
                    ?: return@withContext Result.failure(IOException("Gemini returned an empty response."))
                val parts = modelContent.optJSONArray("parts") ?: JSONArray()
                workingContents.put(modelContent)

                val functionCalls = mutableListOf<JSONObject>()
                val textBuilder = StringBuilder()

                for (i in 0 until parts.length()) {
                    val p = parts.getJSONObject(i)
                    if (p.has("functionCall")) functionCalls.add(p.getJSONObject("functionCall"))
                    val t = p.optString("text", "")
                    if (t.isNotBlank()) {
                        if (textBuilder.isNotEmpty()) textBuilder.append("\n")
                        textBuilder.append(t)
                    }
                }

                if (functionCalls.isEmpty()) {
                    finalReplyText = textBuilder.toString().trim()
                    break
                }

                val responseParts = JSONArray()
                var pendingScreenshot: String? = null

                for (call in functionCalls) {
                    val toolName = call.optString("name")
                    val toolArgs = call.optJSONObject("args") ?: JSONObject()
                    executedTools.add(toolName)

                    val out = actionExecutor.executeTool(
                        name = toolName,
                        args = toolArgs,
                        webSearchRunner = { q -> runGroundedGoogleSearch(geminiKey, activeModel, q) },
                        onActionLog = onToolStatus
                    )
                    if (out.capturedImageBase64 != null) pendingScreenshot = out.capturedImageBase64
                    responseParts.put(JSONObject().put("functionResponse", JSONObject().put("name", toolName).put("response", out.responseJson)))
                }
                workingContents.put(JSONObject().put("role", "user").put("parts", responseParts))

                if (!pendingScreenshot.isNullOrBlank()) {
                    workingContents.put(
                        JSONObject().put("role", "user").put(
                            "parts",
                            JSONArray().apply {
                                put(JSONObject().put("text", "Captured live screenshot attached. Inspect it; tap via tap_screen_coordinates(x_norm, y_norm) if needed."))
                                put(JSONObject().put("inline_data", JSONObject().put("mime_type", "image/jpeg").put("data", pendingScreenshot)))
                            }
                        )
                    )
                }
            }

            if (finalReplyText.isBlank()) {
                finalReplyText = if (executedTools.isNotEmpty()) "Done! Executed: ${executedTools.joinToString(", ")}."
                else "No response received."
            }

            val elapsed = System.currentTimeMillis() - startMs
            ApiQuotaTracker.recordSuccess(activeModel, userMessage.length, finalReplyText.length, elapsed)
            rememberTurn(userMessage, finalReplyText)
            Result.success(AgentReplyResult(finalReplyText, executedTools, elapsed, activeModel))
        } catch (e: Exception) {
            val orKey = settings.effectiveOpenRouterKey()
            if (orKey.isNotBlank()) {
                val orRes = runCatching {
                    val r = postOpenRouter(orKey, settings.openRouterModel, userMessage, buildContextAwareSystemPrompt(settings, userMessage))
                    val lat = System.currentTimeMillis() - startMs
                    ApiQuotaTracker.recordSuccess(settings.openRouterModel, userMessage.length, r.length, lat)
                    rememberTurn(userMessage, r)
                    AgentReplyResult(r, listOf("openrouter_failover"), lat, settings.openRouterModel)
                }
                if (orRes.isSuccess) return@withContext orRes
            }
            ApiQuotaTracker.recordFailure()
            // Ultimate offline safety net: 100% On-Device Local Brain
            val local = localBrain.processOffline(userMessage, settings)
            Result.success(
                AgentReplyResult(
                    replyText = "${local.text}\n(Switched to On-Device Local Brain: ${e.message})",
                    executedTools = local.toolsUsed + "offline_fallback",
                    latencyMs = System.currentTimeMillis() - startMs,
                    usedModel = local.engineTag
                )
            )
        }
    }

    private fun buildGeminiFallbackList(primary: String): List<String> {
        val list = LinkedHashSet<String>()
        if (primary.isNotBlank()) list.add(primary.trim())
        cachedDiscoveredGeminiModels.take(3).forEach { list.add(it) }
        list.add("gemini-3.8-flash")
        list.add("gemini-2.5-flash")
        list.add("gemini-2.5-flash-lite")
        return list.toList()
    }

    private fun postGeminiWithFallback(apiKey: String, models: List<String>, payload: JSONObject): Pair<JSONObject, String> {
        var lastErr: Exception? = null
        for (model in models) {
            try {
                return postGemini(apiKey, model, payload) to model
            } catch (e: IOException) {
                lastErr = e
                val msg = e.message.orEmpty()
                if (!(msg.contains("HTTP 404") || msg.contains("HTTP 429") || msg.contains("HTTP 503"))) throw e
            }
        }
        throw lastErr ?: IOException("All Gemini fallback models failed.")
    }

    private fun rememberTurn(userText: String, modelText: String) {
        conversationHistory.add(JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("text", userText))))
        conversationHistory.add(JSONObject().put("role", "model").put("parts", JSONArray().put(JSONObject().put("text", modelText))))
        while (conversationHistory.size > 24) conversationHistory.removeAt(0)
    }

    private fun buildContextAwareSystemPrompt(settings: OmegaSettings, query: String): String {
        val nowLabel = SimpleDateFormat("EEEE, hh:mm a", Locale.getDefault()).format(Date())
        val batteryPct = actionExecutor.getBatteryPercent()
        val unreadCount = NotificationInbox.items.value.size
        val memories = database.formatRelevantMemoriesForPrompt(query)
        val routines = database.getAllRoutines().joinToString(", ") { "${it.name} (${it.triggerPhrase})" }

        val sb = StringBuilder()
        sb.append("You are OMEGA 19 Autonomous, an elite personal Android AI assistant for ${settings.userName}. ")
        sb.append("Reply naturally in the user's language (Telugu, Tenglish, or English). Keep voice replies crisp and smart. ")
        sb.append("Context: Time=$nowLabel | Battery=$batteryPct% | UnreadNotifs=$unreadCount | Routines=[$routines]")
        if (memories.isNotBlank()) sb.append("\n\nRelevant Memories:\n").append(memories)
        return sb.toString()
    }

    private fun postGemini(apiKey: String, model: String, payload: JSONObject): JSONObject {
        val url = "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent"
        val req = Request.Builder()
            .url(url)
            .addHeader("x-goog-api-key", apiKey)
            .addHeader("Content-Type", "application/json")
            .post(payload.toString().toRequestBody("application/json; charset=utf-8".toMediaType()))
            .build()

        httpClient.newCall(req).execute().use { resp ->
            val raw = resp.body?.string().orEmpty()
            if (!resp.isSuccessful) {
                val msg = runCatching { JSONObject(raw).optJSONObject("error")?.optString("message") }.getOrNull()
                throw IOException("HTTP ${resp.code}: ${msg ?: "Gemini API request failed"}")
            }
            return JSONObject(raw)
        }
    }

    private fun postOpenRouter(apiKey: String, model: String, userMessage: String, systemPrompt: String): String {
        val messages = JSONArray().apply {
            put(JSONObject().put("role", "system").put("content", systemPrompt))
            put(JSONObject().put("role", "user").put("content", userMessage))
        }
        val payload = JSONObject().put("model", model).put("messages", messages)
        val req = Request.Builder()
            .url("https://openrouter.ai/api/v1/chat/completions")
            .addHeader("Authorization", "Bearer $apiKey")
            .addHeader("HTTP-Referer", "https://omega-pandu.app")
            .addHeader("X-Title", "OMEGA 19 Autonomous")
            .addHeader("Content-Type", "application/json")
            .post(payload.toString().toRequestBody("application/json; charset=utf-8".toMediaType()))
            .build()

        httpClient.newCall(req).execute().use { resp ->
            val raw = resp.body?.string().orEmpty()
            if (!resp.isSuccessful) {
                val msg = runCatching { JSONObject(raw).optJSONObject("error")?.optString("message") }.getOrNull()
                throw IOException("HTTP ${resp.code}: ${msg ?: "OpenRouter failed"}")
            }
            return JSONObject(raw).optJSONArray("choices")?.optJSONObject(0)?.optJSONObject("message")
                ?.optString("content", "")?.trim().orEmpty().ifBlank { "Empty reply from OpenRouter." }
        }
    }

    private fun buildToolsSchema(includeWebSearch: Boolean): JSONArray {
        val declarations = JSONArray()
        fun add(name: String, desc: String, props: Map<String, Pair<String, String>> = emptyMap(), req: List<String> = emptyList()) {
            val d = JSONObject().put("name", name).put("description", desc)
            if (props.isNotEmpty()) {
                val pObj = JSONObject()
                props.forEach { (k, v) -> pObj.put(k, JSONObject().put("type", v.first).put("description", v.second)) }
                val params = JSONObject().put("type", "OBJECT").put("properties", pObj)
                if (req.isNotEmpty()) params.put("required", JSONArray(req))
                d.put("parameters", params)
            }
            declarations.put(d)
        }

        if (includeWebSearch) {
            add("live_web_search", "Search live Google Search for current weather, scores, news, or live facts.",
                mapOf("query" to ("STRING" to "Search query")), listOf("query"))
        }
        add("open_app", "Launch an installed app by name.", mapOf("app_name" to ("STRING" to "App name")), listOf("app_name"))
        add("tap_ui_text", "Tap visible UI button text via Accessibility automation.", mapOf("target_text" to ("STRING" to "Button text")), listOf("target_text"))
        add("tap_screen_coordinates", "Tap normalized screen coordinates (0..1000) after screenshot inspection.",
            mapOf("x_norm" to ("INTEGER" to "0-1000"), "y_norm" to ("INTEGER" to "0-1000"), "label" to ("STRING" to "Label")), listOf("x_norm", "y_norm"))
        add("type_screen_text", "Type text into focused input box.", mapOf("text" to ("STRING" to "Text")), listOf("text"))
        add("scroll_screen", "Scroll active screen up or down.", mapOf("direction" to ("STRING" to "down or up")), listOf("direction"))
        add("navigate_device", "Global navigation: back, home, recents, notifications.", mapOf("action" to ("STRING" to "Action")), listOf("action"))
        add("capture_screen_vision", "Capture a live screenshot for visual inspection.")
        add("read_notifications", "Read recent incoming notifications.", mapOf("limit" to ("INTEGER" to "Max items")))
        add("reply_notification", "Reply directly to a WhatsApp/SMS notification.",
            mapOf("sender_or_app" to ("STRING" to "Sender/app"), "reply_text" to ("STRING" to "Message")), listOf("sender_or_app", "reply_text"))
        add("read_calendar", "Read upcoming calendar events.", mapOf("days" to ("INTEGER" to "Days ahead")))
        add("create_calendar_event", "Open Calendar to add an event.", mapOf("title" to ("STRING" to "Title"), "description" to ("STRING" to "Notes")), listOf("title"))
        add("compose_email", "Draft an email.", mapOf("to" to ("STRING" to "Email"), "subject" to ("STRING" to "Subject"), "body" to ("STRING" to "Body")), listOf("to"))
        add("read_clipboard", "Read current clipboard text.")
        add("write_clipboard", "Copy text to clipboard.", mapOf("text" to ("STRING" to "Text")), listOf("text"))
        add("add_location_reminder", "Save a place-based reminder.", mapOf("place" to ("STRING" to "Place"), "reminder" to ("STRING" to "Reminder")), listOf("place", "reminder"))
        add("get_battery_status", "Check phone battery level and charging status.")
        add("toggle_flashlight", "Turn flashlight ON or OFF.", mapOf("enabled" to ("BOOLEAN" to "true/false")), listOf("enabled"))
        add("set_media_volume", "Set media volume % (0-100).", mapOf("percent" to ("INTEGER" to "0-100")), listOf("percent"))
        add("set_alarm", "Set an alarm.", mapOf("hour_24" to ("INTEGER" to "0-23"), "minute" to ("INTEGER" to "0-59"), "label" to ("STRING" to "Label")), listOf("hour_24", "minute"))
        add("set_timer", "Start countdown timer.", mapOf("seconds" to ("INTEGER" to "Seconds"), "label" to ("STRING" to "Label")), listOf("seconds"))
        add("lookup_contact", "Search Contacts by name.", mapOf("name" to ("STRING" to "Name")), listOf("name"))
        add("make_phone_call", "Call a contact or phone number.", mapOf("contact_or_number" to ("STRING" to "Name/number")), listOf("contact_or_number"))
        add("send_whatsapp_message", "Open WhatsApp draft to a contact or number.", mapOf("contact_or_number" to ("STRING" to "Name/number"), "message" to ("STRING" to "Message")), listOf("message"))
        add("open_system_settings", "Open Settings: wifi, bluetooth, brightness, sound, dnd, battery, accessibility, general.", mapOf("section" to ("STRING" to "Section")), listOf("section"))
        add("save_memory", "Encrypt and save a personal fact.", mapOf("key" to ("STRING" to "Key"), "value" to ("STRING" to "Value")), listOf("key", "value"))
        add("recall_memories", "Search personal memories semantically.", mapOf("query" to ("STRING" to "Topic")))
        add("run_routine", "Execute a saved voice routine.", mapOf("routine_name" to ("STRING" to "Routine")), listOf("routine_name"))

        return JSONArray().put(JSONObject().put("function_declarations", declarations))
    }
}
