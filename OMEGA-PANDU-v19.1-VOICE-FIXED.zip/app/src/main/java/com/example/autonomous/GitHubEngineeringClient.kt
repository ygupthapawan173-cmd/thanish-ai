package com.example.autonomous

import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

data class RepoFileSnapshot(
    val path: String,
    val sha: String,
    val content: String
)

data class WorkflowRunStatus(
    val runId: Long,
    val status: String,     // queued | in_progress | completed
    val conclusion: String, // success | failure | cancelled | ""
    val htmlUrl: String
)

/**
 * Real GitHub REST API v3 Engineering Client:
 * - Zero embedded credentials; requires user-provided encrypted least-privilege token
 * - Strictly creates isolated `omega-auto/*` branches and Pull Requests (NEVER force-pushes main)
 */
class GitHubEngineeringClient {

    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(35, TimeUnit.SECONDS)
        .build()

    private fun baseReq(url: String, token: String): Request.Builder = Request.Builder()
        .url(url)
        .addHeader("Accept", "application/vnd.github+json")
        .addHeader("X-GitHub-Api-Version", "2022-11-28")
        .apply {
            if (token.isNotBlank()) addHeader("Authorization", "Bearer ${token.trim()}")
        }

    suspend fun getBranchHeadSha(repoSlug: String, branch: String, token: String): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            val req = baseReq("https://api.github.com/repos/$repoSlug/git/ref/heads/$branch", token).get().build()
            client.newCall(req).execute().use { resp ->
                val raw = resp.body?.string().orEmpty()
                if (!resp.isSuccessful) throw IOException("GitHub ref HTTP ${resp.code}: ${extractErr(raw)}")
                JSONObject(raw).getJSONObject("object").getString("sha")
            }
        }
    }

    suspend fun createIsolatedBranch(repoSlug: String, newBranch: String, baseSha: String, token: String): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            val payload = JSONObject().put("ref", "refs/heads/$newBranch").put("sha", baseSha)
            val req = baseReq("https://api.github.com/repos/$repoSlug/git/refs", token)
                .post(payload.toString().toRequestBody("application/json; charset=utf-8".toMediaType()))
                .build()
            client.newCall(req).execute().use { resp ->
                val raw = resp.body?.string().orEmpty()
                if (!resp.isSuccessful) throw IOException("Branch create HTTP ${resp.code}: ${extractErr(raw)}")
                newBranch
            }
        }
    }

    suspend fun fetchFileContent(repoSlug: String, path: String, branch: String, token: String): Result<RepoFileSnapshot> = withContext(Dispatchers.IO) {
        runCatching {
            val req = baseReq("https://api.github.com/repos/$repoSlug/contents/$path?ref=$branch", token).get().build()
            client.newCall(req).execute().use { resp ->
                val raw = resp.body?.string().orEmpty()
                if (!resp.isSuccessful) throw IOException("Fetch $path HTTP ${resp.code}: ${extractErr(raw)}")
                val obj = JSONObject(raw)
                val sha = obj.getString("sha")
                val b64 = obj.getString("content").replace("\n", "")
                val decoded = String(Base64.decode(b64, Base64.DEFAULT), Charsets.UTF_8)
                RepoFileSnapshot(path, sha, decoded)
            }
        }
    }

    suspend fun commitFilePatch(
        repoSlug: String,
        path: String,
        branch: String,
        baseFileSha: String,
        newContent: String,
        commitMessage: String,
        token: String
    ): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            val b64 = Base64.encodeToString(newContent.toByteArray(Charsets.UTF_8), Base64.NO_WRAP)
            val payload = JSONObject()
                .put("message", commitMessage)
                .put("content", b64)
                .put("sha", baseFileSha)
                .put("branch", branch)
            val req = baseReq("https://api.github.com/repos/$repoSlug/contents/$path", token)
                .put(payload.toString().toRequestBody("application/json; charset=utf-8".toMediaType()))
                .build()
            client.newCall(req).execute().use { resp ->
                val raw = resp.body?.string().orEmpty()
                if (!resp.isSuccessful) throw IOException("Commit HTTP ${resp.code}: ${extractErr(raw)}")
                JSONObject(raw).getJSONObject("commit").getString("sha")
            }
        }
    }

    suspend fun getLatestWorkflowRunForBranch(repoSlug: String, branch: String, token: String): Result<WorkflowRunStatus?> = withContext(Dispatchers.IO) {
        runCatching {
            val req = baseReq("https://api.github.com/repos/$repoSlug/actions/runs?branch=$branch&per_page=1", token).get().build()
            client.newCall(req).execute().use { resp ->
                val raw = resp.body?.string().orEmpty()
                if (!resp.isSuccessful) throw IOException("Actions poll HTTP ${resp.code}: ${extractErr(raw)}")
                val arr = JSONObject(raw).optJSONArray("workflow_runs")
                if (arr == null || arr.length() == 0) return@use null
                val r = arr.getJSONObject(0)
                WorkflowRunStatus(
                    runId = r.getLong("id"),
                    status = r.optString("status", ""),
                    conclusion = r.optString("conclusion", ""),
                    htmlUrl = r.optString("html_url", "")
                )
            }
        }
    }

    suspend fun fetchFailedJobSummary(repoSlug: String, runId: Long, token: String): String = withContext(Dispatchers.IO) {
        runCatching {
            val req = baseReq("https://api.github.com/repos/$repoSlug/actions/runs/$runId/jobs", token).get().build()
            client.newCall(req).execute().use { resp ->
                val raw = resp.body?.string().orEmpty()
                if (!resp.isSuccessful) return@use "Workflow failed (HTTP ${resp.code})."
                val jobs = JSONObject(raw).optJSONArray("jobs") ?: return@use "No job details."
                val sb = StringBuilder()
                for (i in 0 until jobs.length()) {
                    val job = jobs.getJSONObject(i)
                    val steps = job.optJSONArray("steps") ?: continue
                    for (j in 0 until steps.length()) {
                        val st = steps.getJSONObject(j)
                        if (st.optString("conclusion") == "failure") {
                            sb.append("Failed step: ${st.optString("name")} (job: ${job.optString("name")})\n")
                        }
                    }
                }
                sb.toString().ifBlank { "Build/Test step failed. Check Actions log." }
            }
        }.getOrDefault("Unable to inspect failure logs.")
    }

    suspend fun createPullRequest(
        repoSlug: String,
        headBranch: String,
        baseBranch: String,
        title: String,
        body: String,
        token: String
    ): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            val payload = JSONObject()
                .put("title", title)
                .put("head", headBranch)
                .put("base", baseBranch)
                .put("body", body)
            val req = baseReq("https://api.github.com/repos/$repoSlug/pulls", token)
                .post(payload.toString().toRequestBody("application/json; charset=utf-8".toMediaType()))
                .build()
            client.newCall(req).execute().use { resp ->
                val raw = resp.body?.string().orEmpty()
                if (!resp.isSuccessful) throw IOException("PR create HTTP ${resp.code}: ${extractErr(raw)}")
                JSONObject(raw).getString("html_url")
            }
        }
    }

    private fun extractErr(raw: String): String =
        runCatching { JSONObject(raw).optString("message") }.getOrNull().orEmpty().ifBlank { raw.take(180) }
}
