package com.example.voice
import android.content.Context
internal object GeminiSpeechPreferences {
    private fun prefs(c: Context) = c.getSharedPreferences("gemini_speech_v105", Context.MODE_PRIVATE)
    fun enabled(c: Context) = prefs(c).getBoolean("enabled", false)
    fun enabled(c: Context, value: Boolean) {
        if (value) CloudVoicePreferences.enabled(c, false)
        prefs(c).edit().putBoolean("enabled", value).apply()
    }
    fun voice(c: Context, lang: String) = GeminiSpeechPolicy.speaker(prefs(c).getString(lang, "").orEmpty(), lang)
    fun voice(c: Context, lang: String, value: String) { if (lang in listOf("en", "te") && value in GeminiSpeechPolicy.speakers) prefs(c).edit().putString(lang, value).apply() }
}
