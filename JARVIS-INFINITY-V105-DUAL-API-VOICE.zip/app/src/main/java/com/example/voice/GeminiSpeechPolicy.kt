package com.example.voice

import java.nio.ByteBuffer
import java.nio.ByteOrder

internal object GeminiSpeechPolicy {
    const val MODEL = "gemini-2.5-flash-preview-tts"
    const val MAX_PCM = 8 * 1024 * 1024
    val speakers = listOf("Zephyr", "Puck", "Charon", "Kore", "Fenrir", "Leda", "Orus", "Aoede", "Callirrhoe", "Autonoe", "Enceladus", "Iapetus", "Umbriel", "Algieba", "Despina", "Erinome", "Algenib", "Rasalgethi", "Laomedeia", "Achernar", "Alnilam", "Schedar", "Gacrux", "Pulcherrima", "Achird", "Zubenelgenubi", "Vindemiatrix", "Sadachbia", "Sadaltager", "Sulafat")
    fun speaker(value: String, lang: String) = value.takeIf { it in speakers } ?: if (lang == "te") "Kore" else "Charon"
    fun allowed(enabled: Boolean, gateway: Boolean, live: Boolean, privacy: Boolean, foreground: Boolean, keyPresent: Boolean, length: Int): Boolean = enabled && gateway && !live && !privacy && foreground && keyPresent && length in 1..CloudVoicePolicy.MAX_TEXT
    fun wav(pcm: ByteArray): ByteArray {
        require(pcm.isNotEmpty() && pcm.size <= MAX_PCM && pcm.size % 2 == 0)
        return ByteBuffer.allocate(44 + pcm.size).order(ByteOrder.LITTLE_ENDIAN)
            .put("RIFF".toByteArray(Charsets.US_ASCII)).putInt(36 + pcm.size).put("WAVEfmt ".toByteArray(Charsets.US_ASCII))
            .putInt(16).putShort(1.toShort()).putShort(1.toShort()).putInt(24000).putInt(48000).putShort(2.toShort()).putShort(16.toShort())
            .put("data".toByteArray(Charsets.US_ASCII)).putInt(pcm.size).put(pcm).array()
    }
}
