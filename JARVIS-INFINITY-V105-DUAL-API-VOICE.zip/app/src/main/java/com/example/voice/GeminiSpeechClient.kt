package com.example.voice

import android.util.Base64
import com.example.ai.awaitParsed
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import org.json.JSONArray
import java.io.IOException
import java.util.concurrent.TimeUnit

internal object GeminiSpeechClient {
    private const val MAX_JSON = 12L * 1024 * 1024
    private val client = OkHttpClient.Builder().followRedirects(false).followSslRedirects(false)
        .retryOnConnectionFailure(false).connectTimeout(8, TimeUnit.SECONDS).callTimeout(35, TimeUnit.SECONDS).build()
    suspend fun synthesize(key: String, text: String, speaker: String): ByteArray {
        require(key.isNotBlank() && text.length in 1..CloudVoicePolicy.MAX_TEXT && speaker in GeminiSpeechPolicy.speakers)
        val voice = JSONObject().put("prebuiltVoiceConfig", JSONObject().put("voiceName", speaker))
        val generation = JSONObject().put("responseModalities", JSONArray().put("AUDIO")).put("speechConfig", JSONObject().put("voiceConfig", voice))
        val payload = JSONObject().put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", "Read the following text aloud naturally, exactly as written:\n$text"))))).put("generationConfig", generation)
        val request = Request.Builder().url("https://generativelanguage.googleapis.com/v1beta/models/${GeminiSpeechPolicy.MODEL}:generateContent")
            .header("x-goog-api-key", key).post(payload.toString().toRequestBody("application/json".toMediaType())).build()
        return client.newCall(request).awaitParsed { response ->
            if (!response.isSuccessful) throw IOException("Gemini speech HTTP ${response.code}")
            val body = response.body ?: throw IOException("Missing speech body")
            val source = body.source()
            if (body.contentLength() > MAX_JSON || source.request(MAX_JSON + 1)) throw IOException("Speech response exceeds limit")
            val candidate = JSONObject(source.readUtf8()).optJSONArray("candidates")?.optJSONObject(0) ?: throw IOException("Missing speech candidate")
            if (candidate.optString("finishReason") != "STOP") throw IOException("Incomplete speech")
            val parts = candidate.optJSONObject("content")?.optJSONArray("parts") ?: throw IOException("Missing speech parts")
            val out = java.io.ByteArrayOutputStream()
            for (i in 0 until parts.length()) {
                val data = parts.optJSONObject(i)?.optJSONObject("inlineData") ?: continue
                val mime = data.optString("mimeType").lowercase().replace(" ", "")
                if (!mime.startsWith("audio/l16") && !mime.startsWith("audio/pcm")) throw IOException("Unexpected speech format")
                if (mime.contains("rate=") && !mime.contains("rate=24000")) throw IOException("Unsupported sample rate")
                val encoded = data.optString("data")
                if (encoded.length > MAX_JSON) throw IOException("Audio exceeds limit")
                val chunk = Base64.decode(encoded, Base64.DEFAULT)
                if (out.size() + chunk.size > GeminiSpeechPolicy.MAX_PCM) throw IOException("Audio exceeds limit")
                out.write(chunk)
            }
            GeminiSpeechPolicy.wav(out.toByteArray())
        }
    }
}
